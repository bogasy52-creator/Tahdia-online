import test from 'node:test';
import assert from 'node:assert/strict';
import {createDOM} from './dom-harness.mjs';
import {createSudoku} from '../public/assets/js/engines/sudoku-engine.js';

const flush=async()=>{for(let i=0;i<25;i++)await Promise.resolve();};

test('online Sudoku creates private room, shows 81 LTR cells, validates input on the client and shares a clean link',async()=>{
 const connections=[];
 class Socket {
   static OPEN=1;
   constructor(url,protocols){this.url=url;this.protocols=protocols;this.readyState=1;this.sent=[];connections.push(this);}
   send(text){this.sent.push(JSON.parse(text));}
   close(){this.readyState=3;}
 }
 const history={replaceState(){}};
 const h=await createDOM('sudoku-online.html',{
   history,WebSocket:Socket,
   fetch:async (path,opt)=>({ok:true,status:201,json:async()=>path==='/api/sudoku/rooms'?({ok:true,code:'123456',hostKey:'secret-key',playerLimit:2,difficulty:0}):({ok:true,status:'lobby',players:1,playerLimit:2})}),
 });
 await h.runFile('assets/js/sudoku-online.js');
 h.doc.getElementById('soName').value='اختبار';
 h.doc.getElementById('soLimit').value='2';
 h.doc.getElementById('soDifficulty').value='0';
 await h.doc.getElementById('soCreate').onclick();await flush();
 assert.equal(connections.length,1);
 assert.equal(h.doc.getElementById('soRoomCode').textContent,'123456');
 assert.equal(connections[0].protocols.includes('busraj-sudoku-v1'),true);
 const puzzle=createSudoku(1),free=puzzle.initial.findIndex(x=>!x);
 const publicState={code:'123456',status:'lobby',playerLimit:2,difficulty:0,level:1,
   initial:puzzle.initial,board:puzzle.board,playerId:'A',role:'host',startAt:null,endsAt:null,serverNow:Date.now(),won:false,
   players:[{id:'A',role:'host',name:'اختبار',rank:1,filled:0,total:81-puzzle.initial.filter(Boolean).length,connected:true}]};
 connections[0].onmessage({data:JSON.stringify({type:'welcome',token:'a-token',playerId:'A',state:publicState})});
 assert.equal(h.doc.getElementById('soStart').hidden,false);
 h.doc.getElementById('soStart').click();
 assert.equal(connections[0].sent.at(-1).type,'start');
 publicState.status='playing';publicState.endsAt=Date.now()+60000;
 connections[0].onmessage({data:JSON.stringify({type:'state',state:publicState})});
 assert.equal(h.doc.getElementById('soBoard').children.length,81);
 assert.equal(h.doc.getElementById('soPad').children.length,9);
 assert.match(h.doc.getElementById('soBoard').getAttribute('dir'),/ltr/);
 const cell=h.doc.getElementById('soBoard').children[free];cell.click();
 const duplicate=puzzle.initial.find((v,i)=>v!==0&&(Math.floor(i/9)===Math.floor(free/9)||i%9===free%9));
 h.doc.getElementById('soPad').children[duplicate-1].click();
 assert.equal(connections[0].sent.filter(x=>x.type==='move').length,0,'no duplicate goes to server');
 const valid=await import('../public/assets/js/engines/sudoku-core.js');
 const answer=valid.solveSudoku(puzzle.initial).solution[free];
 h.doc.getElementById('soPad').children[answer-1].click();
 assert.deepEqual(connections[0].sent.at(-1),{type:'move',cell:free,value:answer});
 publicState.board=[...puzzle.initial];publicState.board[free]=answer;
 connections[0].onmessage({data:JSON.stringify({type:'state',state:publicState})});
 assert.equal(h.doc.getElementById('soBoard').children[free].children[0].textContent,String(answer));
});
