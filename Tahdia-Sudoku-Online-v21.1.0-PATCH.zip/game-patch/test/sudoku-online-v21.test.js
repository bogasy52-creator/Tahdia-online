import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { SudokuRoom,legalSudokuOnlineMove,SUDOKU_LOBBY_MS } from '../src/sudoku/sudoku-room.js';
import { createSudoku,moveSudoku } from '../public/assets/js/engines/sudoku-engine.js';
import {solveSudoku,sudokuLogicalStep,sudokuConflicts} from '../public/assets/js/engines/sudoku-core.js';

function harness(){
 const map=new Map(),sockets=[],alarms=[];
 const storage={get:async k=>map.get(k),put:async(k,v)=>map.set(k,structuredClone(v)),delete:async k=>map.delete(k),setAlarm:async at=>alarms.push(at)};
 const ctx={storage,blockConcurrencyWhile:fn=>Promise.resolve().then(fn),getWebSockets:()=>sockets};
 return {ctx,map,sockets,alarms};
}
function addSocket(ctx,p){
 const packets=[],att={sudoku:true,playerId:p.id,connection:crypto.randomUUID()};p.connection=att.connection;p.connected=true;
 const ws={readyState:1,closed:false,deserializeAttachment:()=>att,send:text=>packets.push(JSON.parse(text)),close:()=>{ws.closed=true;}};
 ctx.sockets.push(ws);return {ws,packets};
}
function initPayload(limit=10,difficulty=2){return new Request('https://sudoku.internal/init',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({code:'123456',hostKey:'host-key-must-have-32-characters-long-xxxx',playerLimit:limit,difficulty})});}

test('120 levels and a year of generated daily challenges each have one valid solution',()=>{
 for(let i=1;i<=120;i++){
  const s=createSudoku(i),result=solveSudoku(s.initial);
  assert.equal(result.count,1,`stage ${i}`);assert.equal(result.limited,false);
  assert.equal(sudokuConflicts(result.solution).length,0);
  assert.equal(s.initial.every((v,k)=>v===0||v===result.solution[k]),true);
 }
 for(let day=1;day<=366;day++){
  const date=new Date(Date.UTC(2027,0,day)).toISOString().slice(0,10);
  const s=createSudoku(1,date),result=solveSudoku(s.initial);
  assert.equal(result.count,1,`daily ${date}`);assert.equal(result.limited,false);
 }
});

test('logical hints never propose a wrong number in a well-formed stage',()=>{
 for(let level=1;level<=120;level++){
  const st=createSudoku(level),solution=solveSudoku(st.initial).solution,board=st.initial.slice();
  for(let stepNumber=0;stepNumber<36;stepNumber++){
   const step=sudokuLogicalStep(board);if(step){assert.equal(step.value,solution[step.cell],`level ${level}, step ${stepNumber}`);board[step.cell]=step.value;}
   else {const open=board.findIndex(v=>!v);if(open===-1)break;board[open]=solution[open];}
  }
 }
});

test('online move validation forbids overwritten clues, duplicates, and nonnumeric values',()=>{
 const s=createSudoku(24),initial=s.initial,board=s.board;
 const fixed=initial.findIndex(Boolean),free=initial.findIndex(v=>!v),duplicate=initial[fixed];
 assert.equal(legalSudokuOnlineMove(initial,board,fixed,0),false);
 assert.equal(legalSudokuOnlineMove(initial,board,free,10),false);
 assert.equal(legalSudokuOnlineMove(initial,board,free,2.4),false);
 assert.equal(legalSudokuOnlineMove(initial,board,free,null),false);
 const neighbour=board.findIndex((v,i)=>v!==0&&i!==free&&(Math.floor(i/9)===Math.floor(free/9)||i%9===free%9));
 assert.ok(neighbour!==-1);assert.equal(legalSudokuOnlineMove(initial,board,free,board[neighbour]),false);
 const sol=solveSudoku(initial).solution;
 assert.equal(legalSudokuOnlineMove(initial,board,free,sol[free]),true);
 const move=moveSudoku(s,{cell:free,value:sol[free]});assert.equal(move.accepted,true);
});

test('the server maintains 10 isolated grids, host-only countdown and verified finish order',async()=>{
 const h=harness(),room=new SudokuRoom(h.ctx,{});await room.ready;
 assert.equal((await room.fetch(initPayload(10,4))).status,201);
 assert.equal(room.room.players.length,0);assert.equal(room.room.difficulty,4);
 const a=room.addPlayer('الأول','host',null),b=room.addPlayer('الثاني','guest',null),players=[a,b];
 for(let i=3;i<=10;i++)players.push(room.addPlayer('لاعب '+i,'guest',null));
 const streams=players.map(p=>addSocket(h,p));
 assert.equal(room.room.players.length,10);
 assert.equal(room.publicState(a).players.length,10);
 assert.equal('solution' in room.publicState(a),false);
 const fixed=room.room.initial.findIndex(Boolean);
 await room.webSocketMessage(streams[1].ws,JSON.stringify({type:'start'}));assert.equal(room.room.status,'lobby');
 await room.webSocketMessage(streams[0].ws,JSON.stringify({type:'difficulty',difficulty:0}));
 assert.equal(room.room.difficulty,0);
 await room.webSocketMessage(streams[0].ws,JSON.stringify({type:'start'}));
 assert.equal(room.room.status,'countdown');assert.ok(room.room.startAt>Date.now());assert.equal(SUDOKU_LOBBY_MS,20_000);
 room.room.startAt=Date.now()-1000;await room.advance();assert.equal(room.room.status,'playing');
 await room.webSocketMessage(streams[0].ws,JSON.stringify({type:'move',cell:fixed,value:0}));
 assert.equal(room.room.players[0].board[fixed],room.room.initial[fixed]);
 const blank=room.room.initial.findIndex(v=>v===0),wrong=room.room.initial.findIndex((v,i)=>v&&Math.floor(i/9)===Math.floor(blank/9));
 assert.notEqual(wrong,-1);
 await room.webSocketMessage(streams[0].ws,JSON.stringify({type:'move',cell:blank,value:room.room.initial[wrong]}));
 assert.equal(room.room.players[0].board[blank],0);
 assert.ok(a.mistakes>=1);
 const solution=solveSudoku(room.room.initial).solution;
 for(let i=0;i<81;i++)if(!b.board[i])await room.webSocketMessage(streams[1].ws,JSON.stringify({type:'move',cell:i,value:solution[i]}));
 assert.equal(b.finishedAt!==null,true);
 assert.equal(a.finishedAt,null);
 assert.equal(room.room.status,'playing');
 assert.equal(room.publicState(b).players[0].id,b.id);
 assert.equal(room.publicState(a).board[blank],0);
 assert.equal(room.publicState(b).board[blank],solution[blank]);
 assert.equal(streams[0].packets.some(p=>p.state?.solution),false);
 for(let i=0;i<81;i++)if(!a.board[i])await room.webSocketMessage(streams[0].ws,JSON.stringify({type:'move',cell:i,value:solution[i]}));
 assert.equal(a.finishedAt!==null,true);
 assert.equal(room.publicState(a).winnerId,b.id);
 // A player cannot forge a whole-board submission.
 const before=players[2].board.join('');
 await room.webSocketMessage(streams[2].ws,JSON.stringify({type:'board',board:solution}));
 assert.equal(players[2].board.join(''),before);
});

test('old socket cannot write after reconnect and expiry does not leak a solution',async()=>{
 const h=harness(),room=new SudokuRoom(h.ctx,{});await room.ready;
 await room.fetch(initPayload(1,0));
 const p=room.addPlayer('ضيف','host',null),old=addSocket(h,p),fresh=addSocket(h,p);
 room.room.status='playing';room.room.endsAt=Date.now()+120_000;
 const blank=room.room.initial.findIndex(x=>!x),correct=room.room.solution[blank];
 await room.webSocketMessage(old.ws,JSON.stringify({type:'move',cell:blank,value:correct}));
 assert.equal(p.board[blank],0);
 await room.webSocketMessage(fresh.ws,JSON.stringify({type:'move',cell:blank,value:correct}));
 assert.equal(p.board[blank],correct);
 const publicView=JSON.stringify(room.publicState(p));assert.equal(publicView.includes('solution'),false);
 room.room.expiresAt=Date.now()-1;await room.alarm();assert.equal(room.room,null);
 assert.equal(h.map.has('sudokuRoom'),false);
});

test('Sudoku page links to dedicated online screen with 1-10 and 5 difficulties',async()=>{
 const [solo,online,client,worker,css]=await Promise.all([
  readFile(new URL('../public/sudoku.html',import.meta.url),'utf8'),
  readFile(new URL('../public/sudoku-online.html',import.meta.url),'utf8'),
  readFile(new URL('../public/assets/js/sudoku-online.js',import.meta.url),'utf8'),
  readFile(new URL('../src/index.js',import.meta.url),'utf8'),
  readFile(new URL('../public/assets/css/sudoku-online.css',import.meta.url),'utf8')]);
 assert.match(solo,/href="\/sudoku-online"/);
 for(let n=1;n<=10;n++)assert.match(online,new RegExp(`<option value="${n}"`));
 for(let n=0;n<=4;n++)assert.match(online,new RegExp(`<option value="${n}"`));
 assert.match(client,/busraj-sudoku-v1/);
 assert.match(worker,/__sudoku__:/);
 assert.match(worker,/sudokuDelegate\(\)/);
 assert.match(css, /grid-template-columns:minmax\(0,1fr\)/);
});
