import {isColorState,createColorTable,playColorTable,colorTimeout,chooseColorMove} from '../../public/assets/js/engines/color-tables-v33-14.js';
// Tahdia 33.0.0 — the board tables (الثعبان والسلالم، الزهرة، جاكارو، تحدي النرد، والبلياردو من 33.9.0)
// inside the BoardRoom Durable Object.
// - A table starts with whoever is in the room. Seats nobody took are given to
//   bots, a mix of easy, medium and hard; a quick table (العب الحين) is filled
//   to a comfortable size, a friends' room only to the smallest real table.
// - Bots play at once on the server. Every move (the player's and the bots'
//   after it) is kept as a step, so each table animates them in order, and one
//   player action costs one Durable Object request however many bots answer.
// - Each seat carries its owner's dice, stone and character from the shop.
import {chooseChoiceTurn,bestChoice} from '../../public/assets/js/engines/snakes-choice.js';
import { createSnakesServerGame, rollSnakesServer, normalizeSnakesVariant } from './snakes-server.js';
import { snakesTurnDisplayMs } from '../../public/assets/js/snakes-v4-fx.js';
import { createLudoGame, getLegalLudoMoves, applyLudoMove, passLudoTurn } from '../../public/assets/js/engines/ludo-engine.js';
import { createJackarooGame, getJackarooActions, playJackarooAction, jackarooArm, burnJackarooHand } from '../../public/assets/js/engines/jackaroo-engine.js';
import { createRaceDiceGame, rollRaceDice, bankRaceDice } from '../../public/assets/js/engines/dice-engine.js';
import { createPoolGame, playPoolShot, poolTimeout, choosePoolShot, poolProgress } from '../../public/assets/js/engines/pool-engine.js';
// 33.9.10: carrom is a table of two like billiards: the room plays each shot to its end
import { createCarromDuel, playCarromShot, carromTimeout, chooseCarromShot, carromProgress } from '../../public/assets/js/carrom/engine.js';
// 33.10.1: «شطرنج الذاكرة» — two to four players, the room keeps the colours under the pawns
import {createPegsRace,playPegsRace,advancePegsRace,choosePegsRaceMove} from '../../public/assets/js/engines/pegs-race-engine.js';
import {PEG_VARIANTS,pegsOptions} from '../../public/assets/js/engines/pegs-engine.js';
import { createPegsGame, rollPegs, pickPegs, peekPegs, pegsTimeout, choosePegsMove, pegsProgress } from '../../public/assets/js/engines/pegs-engine.js';
import { createJewelsDuel, playJewelsSwap, playJewelsBooster, playJewelsAuto, jewelsTimeout, jewelsProgress, jewelsMoveMs } from '../../public/assets/js/engines/jewels-duel-engine.js';
import {createJewelsRace,playJewelsRaceSwap,playJewelsRaceBooster,finishJewelsRace,advanceJewelsRace,chooseJewelsRaceMove} from '../../public/assets/js/engines/jewels-race-engine.js';
import { chooseJackarooMove, chooseLudoMove, chooseSnakePower, shouldBankDice } from '../../public/assets/js/engines/bot-strategy.js';
import { Career } from '../career/core.js';

// 33.9.0: billiards (8-ball pool) is a table of two: a quick table gives you a person or a computer player
// 33.9.5: «ماستر الجواهر» is a duel too: one board, two players
export const TABLE_GAMES = Object.freeze(['snakes', 'zahra', 'jackaroo', 'dice', 'billiards', 'jewels', 'carrom', 'pegs']);
export const MAX_SEATS = Object.freeze({ snakes: 10, zahra: 6, jackaroo: 6, dice: 10, billiards: 2, jewels: 2, carrom: 2, pegs: 6 });
export const QUICK_SEATS = Object.freeze({ snakes: 4, zahra: 6, jackaroo: 6, dice: 3, billiards: 2, jewels: 2, carrom: 2, pegs: 2 });
export const TABLE_LOBBY_MS = 10_000;
// a group room's table starts when all its players are in, or this long after the first one came
// 33.9.1: the group room's players come straight in, so a missing one is waited for 15 seconds
export const PARTY_TABLE_WAIT_MS = 15_000;
export const DICE_TARGET = 50;
// how long a table needs on screen for one step (dice, walk, ladder or snake…)
export const STEP_MS = Object.freeze({ snakes: 2700, zahra: 1250, jackaroo: 1500, dice: 900, billiards: 900, jewels: 900, carrom: 900, pegs: 350 });
// a computer player at the billiards table takes at most this many shots at once; the rest follow on the alarm
export const POOL_BOT_SHOTS = 2;
export const TURN_MS = Object.freeze({ room: 60_000, quick: 35_000, away: 9_000 });
export const MAX_STEPS = 60;
export const BOT_NAMES = Object.freeze(['سلطان', 'نايف', 'بندر', 'مشعل', 'تركي', 'فيصل', 'ريان', 'فهد', 'عبدالله', 'خالد', 'نورة', 'ريم', 'سارة', 'هيا', 'لمى', 'جود', 'منيرة', 'عبير']);
export const BOT_LEVELS = Object.freeze(['easy', 'medium', 'hard']);

const items = (type) => (Career?.CATALOG || []).filter((item) => item.type === type).map((item) => item.id);
const DICE = items('dice'), PAWNS = items('pawn'), HEROES = (Career?.HEROES || []).map((hero) => hero.id);
export const DEFAULT_LOOK = Object.freeze({ dice: 'dice-ivory', pawn: 'pawn-classic', character: 'fox' });
/** The dice and stones everyone owns: what a guest (no account) may show. */
export const FREE_LOOK_ITEMS = Object.freeze((Career?.CATALOG || []).filter((item) => (item.type === 'dice' || item.type === 'pawn') && item.price === 0 && !item.source).map((item) => item.id));

/** A seat's look from what its owner equipped; anything unknown falls back to the default. */
export function cleanLook({ dice, pawn, character, frame } = {}) {
  const hero = String(character || '').replace(/^character-/, '');
  return {
    ...(items('frame').includes(frame)&&frame!=='frame-none'?{frame}:{}),
    dice: DICE.includes(dice) ? dice : DEFAULT_LOOK.dice,
    pawn: PAWNS.includes(pawn) ? pawn : DEFAULT_LOOK.pawn,
    character: HEROES.includes(hero) ? hero : DEFAULT_LOOK.character,
  };
}

/** Bots come in all strengths: 35% easy, 40% medium, 25% hard. */
export function pickBotLevel(rng = Math.random) {
  const x = rng();
  return x < 0.35 ? 'easy' : x < 0.75 ? 'medium' : 'hard';
}

// 33.4.0: snakes & ladders lets you pick the table size: 2, 3 or 4 players
export const TABLE_SIZES = Object.freeze({ snakes: [2, 3, 4], dice:[2,3,4,5,6,7,8,9,10], zahra:[4,6],jackaroo:[4,6], pegs: [2, 3, 4, 5, 6], ludo: [2, 3, 4, 6] });
/** A table size the player picked, when this game offers one; otherwise null. */
export function chosenSeats(game, value, variant = null) {
  const n = Number(value);
  if(game==='pegs'&&variant==='teams')return [4,6].includes(n)?n:6;
  // 33.10.5: «لودو» (a zahra table on the cross board) also lets you pick 2, 3 or 4
  return TABLE_SIZES[game === 'zahra' && isLudoVariant(variant) ? 'ludo' : game]?.includes(n) ? n : null;
}
/** How many seats the table gets for this many players (and the size picked, if any). */
export function seatsFor(game, humans, quick = false, chosen = null, variant = null) {
  if(game==='pegs'&&variant==='teams')return Math.max(4,humans>4||Number(chosen)>4?6:4);
  if (game === 'jackaroo') return humans>4||Number(chosen)===6||quick&&Number(chosen)!==4?6:4;
  if (game === 'billiards' || game === 'jewels' || game === 'carrom') return 2;
  const picked = chosenSeats(game, chosen, variant);
  const least = picked || (quick ? QUICK_SEATS[game] : 2);
  const size=Math.min(seatLimit(game, variant, MAX_SEATS[game]),Math.max(least,humans));
  return game==='zahra'&&isLudoVariant(variant)&&size===5?6:size;
}

/** Seat → player id (null for a bot). In Jackaroo the first players in sit as partners. */
export function seatPlan(game, humanIds, seats) {
  const order = Array(seats).fill(null);
  const pattern = game === 'jackaroo' ? (seats === 6 ? [0, 2, 4, 1, 3, 5] : [0, 2, 1, 3]) : [...Array(seats).keys()];
  humanIds.slice(0, seats).forEach((id, i) => { order[pattern[i]] = id; });
  return order;
}

function makeBot(seat, rng, taken) {
  const pool = BOT_NAMES.filter((name) => !taken.has(name));
  const name = pool.length ? pool[Math.floor(rng() * pool.length)] : 'لاعب ' + (seat + 1);
  taken.add(name);
  const pick = (list) => list[Math.floor(rng() * list.length)] || null;
  return {
    id: 'bot:' + seat + ':' + Math.floor(rng() * 1e9).toString(36),
    bot: true, level: pickBotLevel(rng), name, role: 'bot', ready: true, connected: true, disconnectedAt: null,
    look: cleanLook({ dice: pick(DICE), pawn: rng() < 0.6 ? 'pawn-character' : pick(PAWNS), character: pick(HEROES) }),
  };
}

/** 33.10.4: the ways a table can be played. Snakes keep theirs; جاكارو and الزهرة have «سريع»
    (the first marble or stone home wins); every other game plays its one way. */
export function tableVariant(game, variant) {
  if(game==='pegs')return PEG_VARIANTS.includes(variant)?variant:'classic';
  if (game === 'snakes') { try { return normalizeSnakesVariant(variant || 'classic'); } catch { return 'classic'; } }
  if ((game === 'jackaroo' || game === 'zahra') && variant === 'quick') return 'quick';
  // 33.10.5: «لودو» is a zahra table on the classic cross board (2–4 players), with its own «سريع»
  if (game === 'zahra' && (variant === 'ludo' || variant === 'ludo-quick')) return variant;
  return 'classic';
}
export const isLudoVariant = (variant) => variant === 'ludo' || variant === 'ludo-quick';
export function seatLimit(game, variant, limit) {
  return limit;
}

function createState(game, names, variant, rng, now=Date.now()) {
  if (game === 'snakes') return createSnakesServerGame(names, { variant: variant || 'classic' });
  if (game === 'zahra') return createLudoGame(names, { quick: variant === 'quick' || variant === 'ludo-quick', ...(isLudoVariant(variant) ? { layout: 'classic' } : {}) });
  // 33.7.0: four seats play on the board of the picture: 19 places a seat, the home lane filled
  if (game === 'jackaroo') return createJackarooGame(names, { rng, arm: jackarooArm(names.length), home: 'fill', quick: variant === 'quick' });
  if (game === 'billiards') return createPoolGame(names, { rng, first: rng() < 0.5 ? 0 : 1 });
  if (game === 'jewels') return createJewelsRace(names, { rng,now });
  if (game === 'carrom') return createCarromDuel(names, { rng, first: rng() < 0.5 ? 0 : 1 });
  if (game === 'pegs') { if(['bluff','vault'].includes(variant))return createColorTable(names,{mode:variant,rng,now});if(variant==='race'||variant==='race-large')return createPegsRace(names,{rng,now,...pegsOptions(variant)});const g = createPegsGame(names, { rng, now,...pegsOptions(variant) }); g.salt = Math.floor(rng() * 1e6); return g; }
  return createRaceDiceGame(names, DICE_TARGET);
}

// Dice come from `roll` (1–6); everything else random from `rng`. The room passes its own
// server die, so a test can set the dice without touching names or shuffles.
const rollWith = (rng) => () => 1 + Math.floor(rng() * 6);
const unitOf = (roll) => () => (roll() - 1) / 6;
export const isPegsRaceTable=room=>room?.game==='pegs'&&room.state?.mode==='race';
export const isJewelsRaceTable=room=>room?.game==='jewels'&&room.state?.mode==='race';
export const tableOver = (room) => {
  const s = room.state;
  if (!s) return true;
  return room.game === 'jackaroo' ? s.winnerTeam !== null && s.winnerTeam !== undefined : s.winner !== null && s.winner !== undefined;
};

/* ---------- steps: what each table animates, in order ---------- */
export function beginSteps(room) { return { from: room.version, list: [] }; }
export function recordStep(room, steps) {
  room.version = (room.version || 0) + 1;
  steps.list.push({ version: room.version, state: structuredClone(room.state), pendingRoll: room.pendingRoll ?? null });
  if (steps.list.length > MAX_STEPS) steps.list.splice(0, steps.list.length - MAX_STEPS);
}
export const stepsTime = (room, steps) => isColorState(room.state)?(steps?.list||[]).reduce((n,x)=>n+(x.state.last?.ms||0),0): (isJewelsRaceTable(room)||isPegsRaceTable(room))?0:room.game==='snakes'
  ? (steps?.list||[]).reduce((total,step)=>total+(step.state?.pendingChoice?650:snakesTurnDisplayMs(step.state?.lastEvent)),0)
  // a billiards shot takes as long as its balls roll, and a moment to read what happened
  : room.game==='jewels' ? (steps?.list||[]).reduce((total,step)=>total+(step.state?.last?jewelsMoveMs(step.state.last):300),0)
  : room.game==='billiards' ? (steps?.list||[]).reduce((total,step)=>total+(step.state?.last?(step.state.last.ms||0)+STEP_MS.billiards:300),0)
  : room.game==='carrom' ? (steps?.list||[]).reduce((total,step)=>total+(step.state?.last?(step.state.last.ms||0)+STEP_MS.carrom:300),0)
  // the opening look at the colours, then each roll and each pawn turned over
  : room.game==='pegs' ? (steps?.list||[]).reduce((total,step)=>total+(step.state?.last?(step.state.last.ms||0)+STEP_MS.pegs:step.state?.seq===0?(step.state.showMs||0)+600:300),0)
  : (steps?.list?.length || 0) * (STEP_MS[room.game] || 1000);

/* ---------- starting a table ---------- */
export function startTable(room, { quick = false, rng = Math.random, roll = rollWith(rng), now = Date.now() } = {}) {
  const humans = room.order.filter((id) => room.players[id] && !room.players[id].bot);
  const seats = seatsFor(room.game, humans.length, quick, room.tableSeats, room.variant);
  const plan = seatPlan(room.game, humans, seats);
  const taken = new Set(humans.map((id) => room.players[id].name));
  for (let seat = 0; seat < seats; seat++) {
    if (plan[seat]) continue;
    const bot = makeBot(seat, rng, taken);
    room.players[bot.id] = bot;
    plan[seat] = bot.id;
  }
  // a player beyond the table's seats (never more than the room allows) waits out this match
  room.order = plan;
  room.state = createState(room.game, plan.map((id) => room.players[id].name), room.variant, rng, now);
  room.status = 'playing';
  room.startedAt = now;
  room.rewardsComplete = false;
  room.pendingRoll = null;
  room.lobbyDeadline = null;
  for (const id of plan) room.players[id].ready = true;
  const steps = beginSteps(room);
  recordStep(room, steps); // the starting position
  if(isJewelsRaceTable(room)){
    room.jewelsBotAt=plan.some((id,i)=>room.players[id]?.bot&&!room.state.players[i].done)?now+1500:null;
    room.turnDeadline=room.state.endsAt;room.turnTotal=room.state.durationMs;
    return steps;
  }
  if(isPegsRaceTable(room)){room.pegsBotAt=plan.some(id=>room.players[id]?.bot)?now+room.state.runs[0].showMs+1000:null;room.turnDeadline=room.state.endsAt;room.turnTotal=room.state.endsAt-now;return steps;}
  runBots(room, steps, rng, roll);
  return steps;
}

/** Drops the bots of the last match, back to the lobby with the same people. */
export function resetTable(room) {
  for (const id of Object.keys(room.players)) if (room.players[id].bot) delete room.players[id];
  room.order = room.order.filter((id) => room.players[id]);
  room.state = null;
  room.pendingRoll = null;
  room.turnDeadline = null;
  room.jewelsBotAt = null;
}

/* ---------- moves ---------- */
const seatOf = (room) => room.state.turn;
export const seatIsBot = (room, seat) => Boolean(room.players[room.order[seat]]?.bot);

function playSnakes(room, seat, roll, power = null) {
  room.state = rollSnakesServer(room.state, seat, unitOf(roll), { power }).state;
}
function rollZahra(room, roll) {
  const value = roll(), legal = getLegalLudoMoves(room.state, value);
  if (!legal.length) { room.state = passLudoTurn(room.state, value); room.pendingRoll = null; return null; }
  room.pendingRoll = value;
  return value;
}
function moveZahra(room, token) {
  room.state = applyLudoMove(room.state, token, room.pendingRoll);
  room.pendingRoll = null;
}

/** One bot turn (Zahra: the roll and the move are two steps). */
export function botTurn(room, steps, rng, roll = rollWith(rng)) {
  const seat = seatOf(room), bot = room.players[room.order[seat]], level = bot?.level || 'medium';
  const s = room.state;
  if (room.game === 'snakes') {
    if(s.variant==='choice'){
      if(!s.pendingChoice){playSnakes(room,seat,roll);recordStep(room,steps);}
      room.state=chooseChoiceTurn(room.state,bestChoice(room.state));recordStep(room,steps);return true;
    }
    const want = chooseSnakePower(s, level, rng);
    playSnakes(room, seat, roll, s.variant==='portals'?(s.players[seat].double>0&&s.players[seat].position<90&&rng()<.25?'double':null):s.variant==='strategy'?want:want === 'double' && s.rulesVersion === 2 && s.players[seat].double > 0 && s.players[seat].position > 0 ? 'double' : null);
    recordStep(room, steps);
  } else if (room.game === 'zahra') {
    const value = room.pendingRoll ?? rollZahra(room, roll);
    recordStep(room, steps);
    if (value !== null) { moveZahra(room, chooseLudoMove(room.state, value, level, rng)); recordStep(room, steps); }
  } else if (room.game === 'jackaroo') {
    const move = chooseJackarooMove(s, level, rng) || firstJackarooMove(s, seat);
    if (!move) return false;
    room.state = playJackarooAction(s, move.cardIndex, move.action, seat);
    recordStep(room, steps);
  } else if (room.game === 'jewels') {
    room.state = playJewelsAuto(s, level, rng);
    recordStep(room, steps);
  } else if (room.game === 'billiards') {
    try { room.state = playPoolShot(s, seat, choosePoolShot(s, level, rng)); }
    catch { room.state = poolTimeout(s); }
    recordStep(room, steps);
  } else if (room.game === 'carrom') {
    try { room.state = playCarromShot(s, seat, chooseCarromShot(structuredClone(s), level)); }
    catch { room.state = carromTimeout(s); }
    recordStep(room, steps);
  } else if (room.game === 'pegs') {
    if(isColorState(s)){room.state=playColorTable(s,seat,chooseColorMove(s,level,rng),{rng,now:Math.max(Date.now(),s.lookUntil)});recordStep(room,steps);return true;}
    const move = choosePegsMove(s, level, rng);
    try { room.state = move.type === 'roll' ? rollPegs(s, seat, rng) : pickPegs(s, seat, move.peg, rng); }
    catch { room.state = pegsTimeout(s, rng); }
    recordStep(room, steps);
  } else {
    if (s.turnTotal > 0 && shouldBankDice(s, level)) room.state = bankRaceDice(s);
    else room.state = rollRaceDice(s, roll());
    trimDice(room);
    recordStep(room, steps);
  }
  return true;
}
function firstJackarooMove(state, seat) {
  const hand = state.hands?.[seat] || [];
  for (let cardIndex = 0; cardIndex < hand.length; cardIndex++) {
    const legal = getJackarooActions(state, cardIndex, seat);
    const action = legal.find((a) => a.type !== 'discard') || legal[0];
    if (action) return { cardIndex, action };
  }
  return null;
}
const trimDice = (room) => { if (room.state?.history?.length > 30) room.state.history = room.state.history.slice(-30); };

/** Bots act until a person must, or the match ends. */
export function runBots(room, steps, rng, roll = rollWith(rng)) {
  if(isJewelsRaceTable(room)||isPegsRaceTable(room))return steps;
  let guard = 0;
  const limit = room.game === 'billiards' || room.game === 'carrom' ? POOL_BOT_SHOTS : 500;
  while (room.status === 'playing' && !tableOver(room) && seatIsBot(room, seatOf(room)) && guard++ < limit) {
    if (!botTurn(room, steps, rng, roll)) break;
  }
  return steps;
}

/** A person's move. Returns the steps, or throws a short reason. */
export function playerMove(room, seat, msg, rng, roll = rollWith(rng), now=Date.now()) {
  if (room.status !== 'playing' || !room.state || tableOver(room)) throw new Error('match_not_playing');
  if(isPegsRaceTable(room)){const steps=beginSteps(room);room.state=playPegsRace(room.state,seat,msg,{now,rng});recordStep(room,steps);return steps;}
  if(isJewelsRaceTable(room)){
    const steps=beginSteps(room),advanced=advanceJewelsRace(room.state,now);
    if(advanced!==room.state){room.state=advanced;room.jewelsBotAt=null;recordStep(room,steps);return steps;}
    if(!Number.isSafeInteger(msg.seq))throw Error('invalid_sequence');
    const options={expectedSeq:msg.seq,now};
    if(msg.type==='jewels_swap')room.state=playJewelsRaceSwap(room.state,seat,msg.a,msg.b,options);
    else if(msg.type==='jewels_booster')room.state=playJewelsRaceBooster(room.state,seat,String(msg.id||''),msg.cell,options);
    else if(msg.type==='jewels_finish')room.state=finishJewelsRace(room.state,{seat,...options});
    else throw Error('invalid_action');
    recordStep(room,steps);return steps;
  }
  if (seat !== seatOf(room)) throw new Error('wrong_turn');
  const steps = beginSteps(room);
  if(isColorState(room.state)){room.state=playColorTable(room.state,seat,msg,{rng,now});recordStep(room,steps);runBots(room,steps,rng,roll);return steps;}
  if (room.game === 'snakes') {
    if(room.state.variant==='choice'){
      if(msg.power)throw Error('power_unavailable');
      if(msg.type==='roll')playSnakes(room,seat,roll);
      else if(msg.type==='snakes_choose')room.state=chooseChoiceTurn(room.state,msg.index);
      else throw Error('invalid_action');
      recordStep(room,steps);if(!room.state.pendingChoice)runBots(room,steps,rng,roll);return steps;
    }
    if (msg.type !== 'roll') throw new Error('invalid_action');
    const power = msg.power ?? null, p = room.state.players[seat];
    if(power!==null){
      const strategy=['strategy','portals'].includes(room.state.variant);
      const allowed=strategy?['shield','double'].includes(power)&&p[power]>0:power==='double'&&room.state.rulesVersion===2&&p.double>0&&p.position>0;
      if(!allowed)throw new Error('power_unavailable');
    }
    playSnakes(room, seat, roll, power);
  } else if (room.game === 'zahra') {
    if (msg.type === 'roll') { if (room.pendingRoll !== null) throw new Error('move_first'); rollZahra(room, roll); }
    else if (msg.type === 'ludo_move') { if (room.pendingRoll === null) throw new Error('roll_first'); moveZahra(room, Number(msg.token)); }
    else throw new Error('invalid_action');
  } else if (room.game === 'jewels') {
    if (msg.type === 'jewels_swap') room.state = playJewelsSwap(room.state, seat, Number(msg.a), Number(msg.b));
    else if (msg.type === 'jewels_booster') room.state = playJewelsBooster(room.state, seat, String(msg.id || ''), Number(msg.cell));
    else throw new Error('invalid_action');
  } else if (room.game === 'billiards') {
    if (msg.type !== 'pool_shot') throw new Error('invalid_action');
    room.state = playPoolShot(room.state, seat, { dir: msg.dir, power: msg.power, spin: msg.spin, cue: msg.cue });
  } else if (room.game === 'carrom') {
    if (msg.type !== 'carrom_shot') throw new Error('invalid_action');
    room.state = playCarromShot(room.state, seat, { x: Number(msg.x), angle: Number(msg.angle), power: Number(msg.power) });
  } else if (room.game === 'pegs') {
    if (now < Number(room.state.lookUntil || 0) - 250) throw new Error('look_phase');
    if (msg.type === 'pegs_roll') room.state = rollPegs(room.state, seat, rng);
    else if (msg.type === 'pegs_pick') room.state = pickPegs(room.state, seat, Number(msg.peg), rng);
    else if (msg.type === 'pegs_peek') room.state = peekPegs(room.state, seat, Number(msg.peg));
    else throw new Error('invalid_action');
  } else if (room.game === 'jackaroo') {
    // 33.8.0: a hand that cannot move anything may be burnt at once (the player asked and confirmed)
    if (msg.type === 'jackaroo_burn_all') room.state = burnJackarooHand(room.state, seat);
    else {
      if (msg.type !== 'jackaroo_play') throw new Error('invalid_action');
      const cardIndex = Number(msg.cardIndex), legal = getJackarooActions(room.state, cardIndex, seat), sig = JSON.stringify(msg.action);
      if (!legal.some((a) => JSON.stringify(a) === sig)) throw new Error('illegal_move');
      room.state = playJackarooAction(room.state, cardIndex, msg.action, seat);
    }
  } else {
    if (msg.type === 'dice_roll') room.state = rollRaceDice(room.state, roll());
    else if (msg.type === 'dice_bank') { if (!(room.state.turnTotal > 0)) throw new Error('roll_first'); room.state = bankRaceDice(room.state); }
    else throw new Error('invalid_action');
    trimDice(room);
  }
  recordStep(room, steps);
  if (room.game !== 'zahra' || room.pendingRoll === null) runBots(room, steps, rng, roll);
  return steps;
}

/** The server plays for a person whose time ran out (a fair, plain move; never a power). */
export function timeoutMove(room, rng, roll = rollWith(rng), now=Date.now()) {
  if (room.status !== 'playing' || !room.state || tableOver(room)) return null;
  if(isPegsRaceTable(room)){
    const steps=beginSteps(room),advanced=advancePegsRace(room.state,now);
    if(advanced!==room.state){room.state=advanced;room.pegsBotAt=null;recordStep(room,steps);return steps;}
    if(!room.pegsBotAt||now<room.pegsBotAt)return null;
    for(let seat=0;seat<room.order.length;seat++){if(!seatIsBot(room,seat))continue;const move=choosePegsRaceMove(room.state,seat,room.players[room.order[seat]]?.level||'medium',rng,now);if(move){room.state=playPegsRace(room.state,seat,move,{now,rng});recordStep(room,steps);if(tableOver(room))break;}}
    room.pegsBotAt=tableOver(room)?null:now+1900;return steps.list.length?steps:null;
  }
  if(isJewelsRaceTable(room)){
    const steps=beginSteps(room),advanced=advanceJewelsRace(room.state,now);
    if(advanced!==room.state){room.state=advanced;room.jewelsBotAt=null;recordStep(room,steps);return steps;}
    if(!room.jewelsBotAt||now<room.jewelsBotAt)return null;
    for(let seat=0;seat<room.order.length;seat++){
      if(!seatIsBot(room,seat)||room.state.players[seat].done)continue;
      const move=chooseJewelsRaceMove(room.state,seat,room.players[room.order[seat]]?.level||'medium',rng);
      if(!move)room.state=finishJewelsRace(room.state,{seat,now});
      else if(move.type==='booster')room.state=playJewelsRaceBooster(room.state,seat,move.id,move.cell,{now});
      else room.state=playJewelsRaceSwap(room.state,seat,move.a,move.b,{now});
      recordStep(room,steps);
    }
    room.jewelsBotAt=room.order.some((id,i)=>room.players[id]?.bot&&!room.state.players[i].done)?now+1400:null;
    return steps.list.length?steps:null;
  }
  const seat = seatOf(room), steps = beginSteps(room), s = room.state;
  if (room.game === 'snakes') {
    if(s.variant==='choice'){if(!s.pendingChoice){playSnakes(room,seat,roll);recordStep(room,steps);}room.state=chooseChoiceTurn(room.state,bestChoice(room.state));}
    else playSnakes(room,seat,roll,null);recordStep(room,steps);
  }
  else if (room.game === 'zahra') {
    const value = room.pendingRoll ?? rollZahra(room, roll);
    recordStep(room, steps);
    if (value !== null) { moveZahra(room, chooseLudoMove(room.state, value, 'medium', rng)); recordStep(room, steps); }
  } else if (room.game === 'jackaroo') {
    const move = chooseJackarooMove(s, 'medium', rng) || firstJackarooMove(s, seat);
    if (!move) return null;
    room.state = playJackarooAction(s, move.cardIndex, move.action, seat);
    recordStep(room, steps);
  } else if (room.game === 'jewels') {
    if (seatIsBot(room, seat)) botTurn(room, steps, rng, roll);
    else { room.state = jewelsTimeout(s); recordStep(room, steps); }
  } else if (room.game === 'billiards') {
    // a computer player whose shots were left for the alarm plays on; a person out of time gives a foul
    if (seatIsBot(room, seat)) { botTurn(room, steps, rng, roll); }
    else { room.state = poolTimeout(s); recordStep(room, steps); }
  } else if (room.game === 'carrom') {
    if (seatIsBot(room, seat)) { botTurn(room, steps, rng, roll); }
    else { room.state = carromTimeout(s); recordStep(room, steps); }
  } else if (room.game === 'pegs') {
    if (seatIsBot(room, seat)) { botTurn(room, steps, rng, roll); }
    else { room.state = isColorState(s)?colorTimeout(s,{rng}):pegsTimeout(s, rng); recordStep(room, steps); }
  } else {
    room.state = s.turnTotal > 0 ? bankRaceDice(s) : rollRaceDice(s, roll());
    trimDice(room);
    recordStep(room, steps);
  }
  runBots(room, steps, rng, roll);
  return steps;
}

/** The winner seats of a finished table (a team in Jackaroo). */
export function winnerSeats(room) {
  const s = room.state;
  if (!s) return [];
  if(isJewelsRaceTable(room)&&s.winner===-1)return[];
  if(room.game==='pegs'&&s.teams)return s.winnerTeam===-1?[]:room.order.map((_,i)=>i).filter(i=>i%(s.players.length/2)===s.winnerTeam);
  if(room.game==='pegs'&&s.ties?.length>1)return [];
  if (room.game === 'jackaroo') return s.winnerTeam === null || s.winnerTeam === undefined ? [] : room.order.map((_, i) => i).filter((i) => i % 2 === s.winnerTeam);
  return s.winner === null || s.winner === undefined ? [] : [s.winner];
}

/** How far each seat got, for rankings (party links, results). */
export function seatProgress(room, seat) {
  const sp = room.state?.players?.[seat] || {};
  if (room.game === 'snakes') return Number(sp.position) || 0;
  if (room.game === 'zahra') return (sp.tokens || []).reduce((n, t) => n + Math.max(0, t + 1), 0);
  if (room.game === 'jackaroo') return (sp.marbles || []).reduce((n, t) => n + Math.max(0, t + 1), 0);
  if (room.game === 'billiards') return poolProgress(room.state, seat);
  if (room.game === 'jewels') return jewelsProgress(room.state, seat);
  if (room.game === 'carrom') return carromProgress(room.state, seat);
  if (room.game === 'pegs') return isColorState(room.state)?Number(sp.score)||0:pegsProgress(room.state, seat);
  return Number(sp.score) || 0;
}
