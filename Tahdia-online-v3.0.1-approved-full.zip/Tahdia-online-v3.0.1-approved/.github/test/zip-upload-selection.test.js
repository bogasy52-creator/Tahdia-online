import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm, unlink, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const findZipScript = fileURLToPath(new URL('../scripts/find-uploaded-zip.sh', import.meta.url));

function run(command, args, cwd) {
  return spawnSync(command, args, { cwd, encoding: 'utf8' });
}

function git(repo, ...args) {
  const result = run('git', args, repo);
  assert.equal(result.status, 0, result.stderr);
  return result.stdout.trim();
}

async function repository(t) {
  const repo = await mkdtemp(join(tmpdir(), 'busraj-upload-selection-'));
  t.after(() => rm(repo, { recursive: true, force: true }));
  git(repo, 'init', '-q');
  git(repo, 'config', 'user.name', 'ZIP Test');
  git(repo, 'config', 'user.email', 'zip-test@example.com');
  await writeFile(join(repo, 'README.md'), 'fixture\n');
  git(repo, 'add', 'README.md');
  git(repo, 'commit', '-qm', 'Initial fixture');
  return repo;
}

test('selects only the ZIP added by this commit when an older ZIP remains', async (t) => {
  const repo = await repository(t);
  await writeFile(join(repo, 'old-failed-update.zip'), 'old\n');
  git(repo, 'add', 'old-failed-update.zip');
  git(repo, 'commit', '-qm', 'Keep failed upload for diagnosis');
  const before = git(repo, 'rev-parse', 'HEAD');

  const uploadedName = '\u200fتحديث اللعبة الجديد.zip';
  await writeFile(join(repo, uploadedName), 'new\n');
  git(repo, 'add', uploadedName);
  git(repo, 'commit', '-qm', 'Upload replacement');
  const after = git(repo, 'rev-parse', 'HEAD');

  const result = run('bash', [findZipScript, before, after], repo);

  assert.equal(result.status, 0, result.stderr);
  assert.equal(result.stdout, `${uploadedName}\n`);
});

test('deleting a ZIP is a successful no-op', async (t) => {
  const repo = await repository(t);
  const uploadedName = 'finished-update.zip';
  await writeFile(join(repo, uploadedName), 'fixture\n');
  git(repo, 'add', uploadedName);
  git(repo, 'commit', '-qm', 'Add upload');
  const before = git(repo, 'rev-parse', 'HEAD');

  await unlink(join(repo, uploadedName));
  git(repo, 'add', '-u');
  git(repo, 'commit', '-qm', 'Remove processed upload');
  const after = git(repo, 'rev-parse', 'HEAD');

  const result = run('bash', [findZipScript, before, after], repo);

  assert.equal(result.status, 0, result.stderr);
  assert.equal(result.stdout, '');
});
