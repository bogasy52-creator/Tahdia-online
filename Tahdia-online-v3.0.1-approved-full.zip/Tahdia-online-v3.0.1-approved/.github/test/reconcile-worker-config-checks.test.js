import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const reconciler = fileURLToPath(new URL('../scripts/reconcile-worker-config-checks.mjs', import.meta.url));

function runNode(args, cwd) {
  const env = { ...process.env };
  delete env.NODE_TEST_CONTEXT;
  return spawnSync(process.execPath, args, { cwd, env, encoding: 'utf8' });
}

test('legacy package checks accept the preserved BoardGameRoom rename migration', async (t) => {
  const project = await mkdtemp(join(tmpdir(), 'busraj-worker-config-'));
  t.after(() => rm(project, { recursive: true, force: true }));
  await mkdir(join(project, 'test'), { recursive: true });
  await mkdir(join(project, 'scripts'), { recursive: true });
  await writeFile(join(project, 'package.json'), '{"type":"module"}\n');
  await writeFile(join(project, 'wrangler.jsonc'), JSON.stringify({
    durable_objects: {
      bindings: [{ name: 'BOARD_ROOMS', class_name: 'BoardRoom' }],
    },
    migrations: [
      { tag: 'v2', new_sqlite_classes: ['BoardGameRoom'] },
      {
        tag: 'v3-board-room-rename',
        renamed_classes: [{ from: 'BoardGameRoom', to: 'BoardRoom' }],
      },
    ],
  }, null, 2));

  const legacyAssertion = "assert.ok(config.migrations.some((m) => (m.new_sqlite_classes || []).includes('BoardRoom')));";
  await writeFile(join(project, 'test', 'platform-smoke.test.js'), [
    "import test from 'node:test';",
    "import assert from 'node:assert/strict';",
    "import { readFile } from 'node:fs/promises';",
    "import { join } from 'node:path';",
    "const root = new URL('../', import.meta.url).pathname;",
    "test('worker binds a dedicated durable object for online board games', async () => {",
    "  const config = JSON.parse(await readFile(join(root, 'wrangler.jsonc'), 'utf8'));",
    `  ${legacyAssertion}`,
    '});',
    '',
  ].join('\n'));
  await writeFile(join(project, 'scripts', 'verify-worker-offline.mjs'), [
    "import assert from 'node:assert/strict';",
    "import { readFile } from 'node:fs/promises';",
    "import { join } from 'node:path';",
    "const root = new URL('../', import.meta.url).pathname;",
    "const config = JSON.parse(await readFile(join(root, 'wrangler.jsonc'), 'utf8'));",
    "assert.ok(config.migrations?.some((m) => (m.new_sqlite_classes || []).includes('BoardRoom')));",
    '',
  ].join('\n'));

  const legacySmoke = runNode(['--test', 'test/platform-smoke.test.js'], project);
  assert.notEqual(legacySmoke.status, 0, `${legacySmoke.stdout}\n${legacySmoke.stderr}`);
  const legacyWorkerCheck = runNode(['scripts/verify-worker-offline.mjs'], project);
  assert.notEqual(legacyWorkerCheck.status, 0, `${legacyWorkerCheck.stdout}\n${legacyWorkerCheck.stderr}`);

  const reconcile = runNode([reconciler, project], project);
  assert.equal(reconcile.status, 0, reconcile.stderr);

  const smoke = runNode(['--test', 'test/platform-smoke.test.js'], project);
  assert.equal(smoke.status, 0, smoke.stderr);
  const verifyWorker = runNode(['scripts/verify-worker-offline.mjs'], project);
  assert.equal(verifyWorker.status, 0, verifyWorker.stderr);
});
