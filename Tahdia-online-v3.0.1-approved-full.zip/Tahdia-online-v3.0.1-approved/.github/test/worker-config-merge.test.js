import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const merger = fileURLToPath(new URL('../scripts/merge-worker-config.mjs', import.meta.url));

function config({ social = false, mutateHistory = false } = {}) {
  const migrations = [
    { tag: 'v1', new_sqlite_classes: ['GameRoom'] },
    { tag: 'v2', new_sqlite_classes: [mutateHistory ? 'WrongRoom' : 'BoardGameRoom'] },
    { tag: 'v3-board-room-rename', renamed_classes: [{ from: 'BoardGameRoom', to: 'BoardRoom' }] },
  ];
  const bindings = [
    { name: 'ROOMS', class_name: 'GameRoom' },
    { name: 'BOARD_ROOMS', class_name: 'BoardRoom' },
  ];
  if (social) {
    bindings.push({ name: 'SOCIAL_USERS', class_name: 'SocialUser' });
    migrations.push({ tag: 'v4-social-users', new_sqlite_classes: ['SocialUser'] });
  }
  return {
    name: 'tahdia-online',
    main: 'src/index.js',
    compatibility_date: social ? '2099-01-01' : '2026-08-30',
    assets: { directory: './public', binding: 'ASSETS', run_worker_first: ['/api/*'] },
    durable_objects: { bindings },
    migrations,
    observability: { enabled: true },
  };
}

async function fixture(t) {
  const dir = await mkdtemp(join(tmpdir(), 'busraj-worker-merge-'));
  t.after(() => rm(dir, { recursive: true, force: true }));
  return {
    dir,
    deployed: join(dir, 'deployed.jsonc'),
    incoming: join(dir, 'incoming.jsonc'),
    output: join(dir, 'output.jsonc'),
  };
}

function run(paths) {
  return spawnSync(process.execPath, [merger, paths.deployed, paths.incoming, paths.output], { encoding: 'utf8' });
}

test('preserves deployed config while safely appending a new Durable Object migration/binding', async (t) => {
  const paths = await fixture(t);
  await writeFile(paths.deployed, `${JSON.stringify(config(), null, 2)}\n`);
  await writeFile(paths.incoming, `${JSON.stringify(config({ social: true }), null, 2)}\n`);

  const result = run(paths);
  assert.equal(result.status, 0, result.stderr);
  const merged = JSON.parse(await readFile(paths.output, 'utf8'));

  assert.equal(merged.compatibility_date, '2026-08-30', 'deployed non-migration config stays authoritative');
  assert.equal(merged.migrations.length, 4);
  assert.deepEqual(merged.migrations.slice(0, 3), config().migrations);
  assert.deepEqual(merged.migrations[3], { tag: 'v4-social-users', new_sqlite_classes: ['SocialUser'] });
  assert.deepEqual(merged.durable_objects.bindings.at(-1), { name: 'SOCIAL_USERS', class_name: 'SocialUser' });
});

test('rejects an incoming ZIP that rewrites deployed migration history', async (t) => {
  const paths = await fixture(t);
  await writeFile(paths.deployed, `${JSON.stringify(config(), null, 2)}\n`);
  await writeFile(paths.incoming, `${JSON.stringify(config({ social: true, mutateHistory: true }), null, 2)}\n`);

  const result = run(paths);
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /migration history changed/i);
});

test('rejects a new Durable Object binding without an appended migration', async (t) => {
  const paths = await fixture(t);
  const incoming = config();
  incoming.durable_objects.bindings.push({ name: 'BAD', class_name: 'UnmigratedRoom' });
  await writeFile(paths.deployed, `${JSON.stringify(config(), null, 2)}\n`);
  await writeFile(paths.incoming, `${JSON.stringify(incoming, null, 2)}\n`);

  const result = run(paths);
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /requires an appended migration/i);
});
