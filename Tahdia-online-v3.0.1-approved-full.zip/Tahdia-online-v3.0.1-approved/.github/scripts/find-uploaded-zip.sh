#!/usr/bin/env bash
set -euo pipefail

ZIPS=()

if [ "$#" -eq 0 ]; then
  mapfile -d '' -t ZIPS < <(
    find . -maxdepth 1 -type f -iname '*.zip' -printf '%f\0' | LC_ALL=C sort -z
  )
elif [ "$#" -eq 2 ]; then
  BEFORE_SHA=$1
  AFTER_SHA=$2
  CHANGED_PATHS=()

  if [[ "$BEFORE_SHA" =~ ^0+$ ]] || ! git cat-file -e "$BEFORE_SHA^{commit}" 2>/dev/null; then
    mapfile -d '' -t CHANGED_PATHS < <(
      git diff-tree --root --no-commit-id --name-only -r -z --diff-filter=AM "$AFTER_SHA"
    )
  else
    mapfile -d '' -t CHANGED_PATHS < <(
      git diff --name-only -z --diff-filter=AM "$BEFORE_SHA" "$AFTER_SHA"
    )
  fi

  shopt -s nocasematch
  for path in "${CHANGED_PATHS[@]}"; do
    if [[ "$path" != */* && "$path" == *.zip && -f "$path" ]]; then
      ZIPS+=("$path")
    fi
  done
  shopt -u nocasematch
else
  echo "Usage: find-uploaded-zip.sh [<before-sha> <after-sha>]" >&2
  exit 2
fi

if [ "${#ZIPS[@]}" -eq 0 ]; then
  exit 0
fi

if [ "${#ZIPS[@]}" -ne 1 ]; then
  echo "Upload exactly one new ZIP file to the repository root." >&2
  exit 1
fi

printf '%s\n' "${ZIPS[0]}"
