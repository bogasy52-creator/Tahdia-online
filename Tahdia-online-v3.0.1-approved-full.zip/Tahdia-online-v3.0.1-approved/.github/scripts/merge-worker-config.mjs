import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

if (process.argv.length !== 5) {
  console.error('Usage: merge-worker-config.mjs <deployed-config> <incoming-config> <output-config>');
  process.exit(2);
}

const [deployedPath, incomingPath, outputPath] = process.argv.slice(2).map((path) => resolve(path));

function parseJsonc(raw, label) {
  // Wrangler files in this project are JSON-compatible JSONC. Strip full-line comments only;
  // do not attempt a permissive parser that could hide malformed configuration.
  try {
    return JSON.parse(raw.replace(/^\s*\/\/.*$/gm, ''));
  } catch (error) {
    throw new Error(`${label} is not valid JSON/JSONC: ${error.message}`);
  }
}

function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.keys(value).sort().map((key) => [key, canonical(value[key])]));
  }
  return value;
}

function equalJson(a, b) {
  return JSON.stringify(canonical(a)) === JSON.stringify(canonical(b));
}

function fail(message) {
  console.error(`Unsafe worker configuration update: ${message}`);
  process.exit(1);
}

const deployed = parseJsonc(await readFile(deployedPath, 'utf8'), 'deployed wrangler.jsonc');
const incoming = parseJsonc(await readFile(incomingPath, 'utf8'), 'incoming wrangler.jsonc');

const deployedBindings = deployed.durable_objects?.bindings || [];
const incomingBindings = incoming.durable_objects?.bindings || [];
const deployedMigrations = deployed.migrations || [];
const incomingMigrations = incoming.migrations || [];

// Legacy/update ZIPs that do not declare Durable Object state cannot mutate the
// deployed Worker config. Preserve it byte-for-byte for backward compatibility.
if (incomingBindings.length === 0 && incomingMigrations.length === 0) {
  await writeFile(outputPath, await readFile(deployedPath, 'utf8'));
  console.log('Worker config preserved unchanged (incoming ZIP declares no Durable Object state).');
  process.exit(0);
}
const incomingByName = new Map(incomingBindings.map((binding) => [binding.name, binding]));

for (const binding of deployedBindings) {
  const candidate = incomingByName.get(binding.name);
  if (!candidate) fail(`existing Durable Object binding ${binding.name} cannot be removed`);
  if (candidate.class_name !== binding.class_name) {
    fail(`existing Durable Object binding ${binding.name} cannot change class (${binding.class_name} -> ${candidate.class_name})`);
  }
}

const duplicateBindingNames = incomingBindings
  .map((binding) => binding.name)
  .filter((name, index, all) => all.indexOf(name) !== index);
if (duplicateBindingNames.length) fail(`duplicate Durable Object binding name: ${duplicateBindingNames[0]}`);

if (incomingMigrations.length < deployedMigrations.length) {
  fail('migration history cannot be shortened');
}

for (let index = 0; index < deployedMigrations.length; index += 1) {
  if (!equalJson(deployedMigrations[index], incomingMigrations[index])) {
    fail(`migration history changed at index ${index} (tag ${deployedMigrations[index]?.tag || 'unknown'})`);
  }
}

const tags = incomingMigrations.map((migration) => migration?.tag).filter(Boolean);
const duplicateTags = tags.filter((tag, index, all) => all.indexOf(tag) !== index);
if (duplicateTags.length) fail(`duplicate migration tag: ${duplicateTags[0]}`);

const appendedMigrations = incomingMigrations.slice(deployedMigrations.length);
const introducedClasses = new Set();
for (const migration of appendedMigrations) {
  for (const className of migration?.new_classes || []) introducedClasses.add(className);
  for (const className of migration?.new_sqlite_classes || []) introducedClasses.add(className);
  for (const rename of migration?.renamed_classes || []) {
    if (rename?.to) introducedClasses.add(rename.to);
  }
}

const deployedBindingNames = new Set(deployedBindings.map((binding) => binding.name));
for (const binding of incomingBindings) {
  if (deployedBindingNames.has(binding.name)) continue;
  if (!introducedClasses.has(binding.class_name)) {
    fail(`new Durable Object binding ${binding.name}/${binding.class_name} requires an appended migration introducing ${binding.class_name}`);
  }
}

const merged = structuredClone(deployed);
merged.durable_objects = {
  ...(deployed.durable_objects || {}),
  bindings: incomingBindings,
};
merged.migrations = incomingMigrations;

await writeFile(outputPath, `${JSON.stringify(merged, null, 2)}\n`);
console.log(`Worker config merged safely: preserved ${deployedMigrations.length} migration(s), appended ${appendedMigrations.length}.`);
