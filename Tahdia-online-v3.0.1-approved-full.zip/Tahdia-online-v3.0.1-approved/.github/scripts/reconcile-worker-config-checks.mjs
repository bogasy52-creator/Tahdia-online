import { readFile, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';

if (process.argv.length !== 3) {
  console.error('Usage: reconcile-worker-config-checks.mjs <project-directory>');
  process.exit(2);
}

const projectRoot = resolve(process.argv[2]);
const checkFiles = [
  join(projectRoot, 'test', 'platform-smoke.test.js'),
  join(projectRoot, 'scripts', 'verify-worker-offline.mjs'),
];
const legacyBoardRoomCheck = /^([ \t]*)assert\.ok\(config\.migrations(?:\?\.|\.)some\(\(m\) => \(m\.new_sqlite_classes \|\| \[\]\)\.includes\('BoardRoom'\)\)\);[ \t]*$/gm;

function migrationAwareCheck(indent) {
  return [
    `${indent}assert.ok(config.migrations?.some(`,
    `${indent}  (migration) =>`,
    `${indent}    (migration.new_sqlite_classes || []).includes('BoardRoom') ||`,
    `${indent}    (migration.renamed_classes || []).some(`,
    `${indent}      (rename) => rename.from === 'BoardGameRoom' && rename.to === 'BoardRoom'`,
    `${indent}    )`,
    `${indent}));`,
  ].join('\n');
}

let reconciled = 0;
for (const file of checkFiles) {
  let source;
  try {
    source = await readFile(file, 'utf8');
  } catch (error) {
    if (error.code === 'ENOENT') continue;
    throw error;
  }

  const next = source.replace(legacyBoardRoomCheck, (_match, indent) => {
    reconciled += 1;
    return migrationAwareCheck(indent);
  });
  if (next !== source) await writeFile(file, next);
}

console.log(`Reconciled ${reconciled} legacy BoardRoom configuration check(s).`);
