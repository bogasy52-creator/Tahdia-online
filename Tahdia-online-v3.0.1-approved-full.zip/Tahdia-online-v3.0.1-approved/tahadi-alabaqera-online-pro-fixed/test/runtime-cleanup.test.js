import test from 'node:test';
import assert from 'node:assert/strict';
import { access, readFile } from 'node:fs/promises';
import { constants } from 'node:fs';
import { join } from 'node:path';

const root = process.cwd();
const pub = join(root, 'public');

async function missing(path) {
  await assert.rejects(access(path, constants.F_OK));
}

test('obsolete board-room runtime clients cannot be reintroduced accidentally', async () => {
  await Promise.all([
    missing(join(pub, 'assets/js/online/room-client.js')),
    missing(join(pub, 'assets/js/games/snakes-ui.js')),
    missing(join(pub, 'assets/js/games/jackaroo-ui.js')),
  ]);
  const board = await readFile(join(pub, 'assets/js/board-online.js'), 'utf8');
  assert.match(board, /\/api\/board\/rooms/);
  assert.doesNotMatch(board, /\/api\/games\/rooms/);
  assert.match(board, /protocols=\['busraj-v1'\]/);
  assert.doesNotMatch(board, /searchParams\.set\(['"](?:token|hostKey)/);
});
