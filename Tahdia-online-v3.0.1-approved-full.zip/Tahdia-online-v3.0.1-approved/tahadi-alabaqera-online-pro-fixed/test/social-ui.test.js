import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const index = await readFile(new URL('../public/index.html', import.meta.url), 'utf8');
const social = await readFile(new URL('../public/social.html', import.meta.url), 'utf8');
const client = await readFile(new URL('../public/assets/js/social-client.js', import.meta.url), 'utf8');
const wrangler = JSON.parse(await readFile(new URL('../wrangler.jsonc', import.meta.url), 'utf8'));

test('home exposes friends entry and loads the social client', () => {
  assert.match(index, /data-social-open/);
  assert.match(index, /assets\/js\/social-client\.js/);
  assert.match(index, /👥 الأصدقاء/);
});

test('social page provides account, friends, requests, notifications and privacy surfaces', () => {
  for (const marker of ['loginForm', 'signupForm', 'friendUsername', 'data-tab="friends"', 'data-tab="requests"', 'data-tab="notifications"', 'data-tab="settings"', 'إظهار حالة الاتصال', "BS_SOCIAL.block"]) {
    assert.ok(social.includes(marker), `missing social UI marker ${marker}`);
  }
});

test('social client uses bearer auth and websocket subprotocol rather than query-string session tokens', () => {
  assert.match(client, /authorization/);
  assert.match(client, /busraj-social-v1/);
  assert.match(client, /`st\.\$\{token\(\)\}`/);
  assert.doesNotMatch(client, /searchParams\.set\(['"]token/);
});

test('Cloudflare config adds SocialUser after preserving BoardRoom rename history', () => {
  const bindings = wrangler.durable_objects.bindings;
  assert.ok(bindings.some((x) => x.name === 'SOCIAL_USERS' && x.class_name === 'SocialUser'));
  const renameIndex = wrangler.migrations.findIndex((m) => (m.renamed_classes || []).some((r) => r.from === 'BoardGameRoom' && r.to === 'BoardRoom'));
  const socialIndex = wrangler.migrations.findIndex((m) => (m.new_sqlite_classes || []).includes('SocialUser'));
  assert.ok(renameIndex >= 0 && socialIndex > renameIndex);
});
