import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const html=await readFile(new URL('../public/snakes.html',import.meta.url),'utf8');
const part=(a,b)=>html.slice(html.indexOf(a),html.indexOf(b,html.indexOf(a)+1));
test('R5 keeps four reusable pawns above game SVG instead of rebuilding every tile',()=>{
 const render=part('function renderTokens(', 'function canAct()');
 assert.match(render,/cachedPawns\[i\]/);
 assert.match(render,/token\.parentElement!==layer/);
 assert.match(render,/layer\.append\(token\)/);
 assert.doesNotMatch(render,/querySelectorAll\(['"]\.token-stack/);
 assert.match(html,/\.snake-pawn-layer\{[^}]*z-index:12/);
 assert.match(html,/#paths\{[^}]*z-index:4/);
 assert.match(html,/\.snake-board\{[^}]*z-index:1/);
});
test('R5 move trajectory uses composited transforms and a capped duration',()=>{
 const move=part('async function animatePawnPath(', 'async function animateLadderRide(');
 assert.match(move,/translate3d\(/);
 assert.match(move,/Math\.min\(740,Math\.max\(250/);
 assert.match(move,/pulseScale/);
 assert.doesNotMatch(move,/\.map\(frame=>\(\{left:/);
});
test('R5 reduces ladder/snake reaction duration but preserves phases and engine',()=>{
 assert.match(html,/\[160,205,400,330,210\]/);
 assert.match(html,/createReactionPlan\('ladder'/);
 assert.match(html,/createReactionPlan\('snake'/);
 assert.match(html,/createBoardMovePlan\(/);
 assert.match(html,/DEFAULT_SNAKES_JUMPS/);
});
test('R5 board remains correctly aligned and avoids unnecessary SVG rebuilds',()=>{
 assert.match(html,/pathsDrawStamp===fingerprint/);
 assert.match(html,/function reflowBoard\(/);
 assert.match(html,/ResizeObserver/);
 assert.match(html,/<style id="snakes-royale-r5">/);
 assert.match(html,/\.snake-board-wrap\{[^}]*transform:none!important/);
 assert.match(html, /\.snake-cell\[data-n="100"\]/);
});
test('R5 preserves selectable original and royal pieces while adding portraits',()=>{
 assert.match(html,/id="pieceStyle"/);
 assert.match(html,/makePawnPortrait/);
 assert.match(html,/data-piece-art="royal"/);
 assert.match(html,/data-piece-art="original"/);
 assert.match(html,/value="fast" selected/);
});
