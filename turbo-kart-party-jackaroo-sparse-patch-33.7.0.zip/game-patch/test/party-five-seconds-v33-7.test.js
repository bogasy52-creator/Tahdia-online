import test from 'node:test';
import assert from 'node:assert/strict';
import { PARTY_COUNTDOWN_MS, PARTY_BREAK_MS } from '../public/assets/js/engines/party-catalog-v29.js';
import { PARTY_NEXT_MS, PARTY_BACK_MS } from '../src/party/party-engine.js';

test('the group room moves from one game to the next in five seconds', () => {
  assert.equal(PARTY_COUNTDOWN_MS, 5000);
  assert.equal(PARTY_BREAK_MS, 5000);
  assert.equal(PARTY_NEXT_MS, 5000);
  assert.ok(PARTY_BACK_MS <= 2000, 'once everyone is back the next game follows at once');
});
