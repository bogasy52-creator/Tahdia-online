import {readdir,readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';import{fileURLToPath}from'node:url';
const root=fileURLToPath(new URL('../public/',import.meta.url));
let count=0;const css='<link rel="stylesheet" href="/assets/css/tahdia-ui-v26.css?v=26.0.0">';
const scripts='<script src="/assets/js/tahdia-fx-v26.js?v=26.0.0"></script><script src="/assets/js/tahdia-ui-v26.js?v=26.0.0"></script>';
// Release 25 shipped a bolt-on navigation layer. Pages that still reference it must not load it next to the new shell.
const legacy=/<link\b[^>]*tahdia-premium-v25\.css[^>]*>|<script\b[^>]*tahdia-premium-v25\.js[^>]*><\/script>/g;
for(const name of await readdir(root)){
 if(!name.endsWith('.html')||['offline.html','admin.html'].includes(name))continue;
 const target=path.join(root,name);const raw=await readFile(target,'utf8');let next=raw.replace(legacy,'');
 if(!next.includes('tahdia-ui-v26.css'))next=next.replace(/<\/head>/i,css+'</head>');
 if(!next.includes('tahdia-ui-v26.js'))next=next.replace(/<\/body>/i,scripts+'</body>');
 if(next!==raw){await writeFile(target,next);count++;}
}
console.log('Tahdia UI 26 active on '+count+' route(s).');
