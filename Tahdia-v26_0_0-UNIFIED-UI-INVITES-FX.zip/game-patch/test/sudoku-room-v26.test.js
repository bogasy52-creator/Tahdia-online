import test from 'node:test';import assert from 'node:assert/strict';
import {SudokuRoom,SUDOKU_MAX_MISTAKES} from '../src/sudoku/sudoku-room.js';import {SUDOKU_PEERS} from '../public/assets/js/engines/sudoku-core.js';import {oracleSudoku} from './sudoku-oracle.mjs';
function fixture(){let now=1000000;const values=new Map(),sockets=[],ctx={storage:{get:async k=>structuredClone(values.get(k)),put:async(k,v)=>values.set(k,structuredClone(v)),setAlarm:async t=>ctx.alarmAt=t,deleteAll:async()=>values.clear()},blockConcurrencyWhile:fn=>Promise.resolve().then(fn),getWebSockets:()=>sockets};const room=new SudokuRoom(ctx,{});const original=Date.now;Date.now=()=>now;return {room,time:t=>now=t,restore:()=>Date.now=original,async init(capacity=10){await room.ready;assert.equal((await room.fetch(new Request('https://sudoku.internal/init',{method:'POST',body:JSON.stringify({code:'123456',hostKey:'h'.repeat(40),capacity,difficulty:1})}))).status,201);},add(id,role='guest'){const p={id,role,name:id,token:id,connection:id,connected:true,joinedAt:now};room.room.players[id]=p;room.room.order.push(id);const messages=[],socket={deserializeAttachment:()=>({sudoku:true,playerId:id,connection:id}),send:v=>messages.push(JSON.parse(v)),close(){}};sockets.push(socket);return {p,socket,messages,send:message=>room.webSocketMessage(socket,JSON.stringify(message))};}};}
async function start(f,...names){await f.init();const players=names.map((n,i)=>f.add(n,i?'guest':'host'));await players[0].send({type:'start'});f.time(f.room.room.startsAt);await f.room.alarm();return players;}
// A wrong value that does not duplicate anything in its row, column or box, so the server accepts and counts it.
function wrongMove(r,player,solution,from=0){for(let cell=from;cell<81;cell++){if(r.initial[cell]||player.p.board[cell])continue;const value=[1,2,3,4,5,6,7,8,9].find(v=>v!==solution[cell]&&!SUDOKU_PEERS[cell].some(i=>player.p.board[i]===v));if(value)return {cell,value};}throw Error('no wrong move found');}
async function mistake(f,player,solution){const r=f.room.room,m=wrongMove(r,player,solution);await player.send({type:'move',...m,round:r.round,seq:player.p.seq+1});}
test('the server eliminates a player on the fifth wrong entry, rejects further moves, and never refunds a mistake',async()=>{
  const f=fixture();try{const [host,guest]=await start(f,'host','guest'),r=f.room.room,solution=oracleSudoku(r.initial).solution;
    assert.equal(SUDOKU_MAX_MISTAKES,5);assert.equal(f.room.snapshot('host').maxMistakes,5);
    for(let i=1;i<=4;i++){await mistake(f,host,solution);assert.equal(host.p.mistakes,i);assert.equal(host.p.out,false);}
    await host.send({type:'undo',round:r.round,seq:host.p.seq+1});assert.equal(host.p.mistakes,4,'undo does not refund a mistake');
    assert.equal(f.room.snapshot('host').me.mistakes,4);
    await mistake(f,host,solution);
    assert.equal(host.p.mistakes,5);assert.equal(host.p.out,true);
    assert.equal(r.status,'finished','the only other player is the last one standing, so the round ends');assert.equal(r.winnerId,'guest');
    const snap=f.room.snapshot('host');assert.equal(snap.me.out,true);assert.equal(snap.players.at(-1).id,'host','an eliminated player is ranked last');
  }finally{f.restore();}
});
test('an eliminated player cannot move while others keep playing, and cannot win on timeout',async()=>{
  const f=fixture();try{const [host,guest,third]=await start(f,'host','guest','third'),r=f.room.room,solution=oracleSudoku(r.initial).solution;
    // the guest solves one cell correctly so they lead on correct cells
    const good=r.initial.findIndex(n=>!n);await guest.send({type:'move',cell:good,value:solution[good],round:r.round,seq:1});
    for(let i=0;i<5;i++)await mistake(f,host,solution);
    assert.equal(host.p.out,true);assert.equal(r.status,'playing','two players are still alive');
    const seq=host.p.seq,before=[...host.p.board];await host.send({type:'move',cell:good,value:solution[good],round:r.round,seq:seq+1});
    assert.equal(host.p.seq,seq);assert.deepEqual(host.p.board,before);assert.match(host.messages.at(-1).message,/خسرت/);
    // the eliminated host had more correct cells than the rest, but still cannot be crowned at the deadline
    host.p.correct=70;f.time(r.deadline+1);await f.room.alarm();
    assert.equal(r.status,'finished');assert.equal(r.winnerId,'guest');
  }finally{f.restore();}
});
test('if everyone is eliminated the round ends without a winner, and a rematch clears the counters',async()=>{
  const f=fixture();try{const [host]=await start(f,'host'),r=f.room.room,solution=oracleSudoku(r.initial).solution;
    for(let i=0;i<5;i++)await mistake(f,host,solution);
    assert.equal(r.status,'finished');assert.equal(r.winnerId,null);
    await host.send({type:'rematch'});assert.equal(host.p.mistakes,0);assert.equal(host.p.out,false);
  }finally{f.restore();}
});
