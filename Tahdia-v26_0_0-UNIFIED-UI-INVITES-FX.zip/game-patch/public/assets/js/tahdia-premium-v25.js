/* Retired in 26.0.0: replaced by tahdia-fx-v26.js and tahdia-ui-v26.js. Intentionally inert. */
window.__TAHDIA_PREMIUM_25__=true;
