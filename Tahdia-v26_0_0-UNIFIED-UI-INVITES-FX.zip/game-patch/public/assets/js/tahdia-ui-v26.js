/* Tahdia 26 — one app bar (back / title / invite) and a real friend-invitation sheet for every game. */
(()=>{'use strict';
 const w=window,d=document;
 if(w.__TAHDIA_UI_26__)return;w.__TAHDIA_UI_26__=true;
 const el=(tag,cls,text)=>{const n=d.createElement(tag);if(cls)n.className=cls;if(text!=null)n.textContent=text;return n;};
 const svg=(path,cls='t26-ico')=>{const s=d.createElementNS('http://www.w3.org/2000/svg','svg');s.setAttribute('viewBox','0 0 24 24');s.setAttribute('class',cls);s.setAttribute('aria-hidden','true');s.setAttribute('focusable','false');s.innerHTML=path;return s;};
 const ICON={
  back:'<path d="m9 5 7 7-7 7"/>',
  invite:'<circle cx="9" cy="8" r="3.6"/><path d="M2.6 20v-1.2a6.4 6.4 0 0 1 12.8 0V20"/><path d="M19 7.5v6M16 10.5h6"/>',
  close:'<path d="M6 6l12 12M18 6 6 18"/>',
  copy:'<rect x="9" y="9" width="11" height="11" rx="3"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>',
  share:'<circle cx="18" cy="5.5" r="2.6"/><circle cx="6" cy="12" r="2.6"/><circle cx="18" cy="18.5" r="2.6"/><path d="m8.3 10.7 7.4-4M8.3 13.3l7.4 4"/>',
  chat:'<path d="M4 20l1.3-4.2A8 8 0 1 1 8.4 18.8z"/><path d="M9 9.5c.4 2.2 2.3 4 4.6 4.6l1.3-1.3-1.8-1-.8.6a3.7 3.7 0 0 1-1.7-1.7l.6-.8-1-1.8z"/>',
  check:'<path d="m5 12.5 4.5 4.5L19 7.5"/>'
 };
 const route=location.pathname.replace(/\/$/,'').replace(/\.html$/,'').split('/').at(-1)||'home';
 const home=route==='home'||route==='index';
 const PAGES={home:'الرئيسية',index:'الرئيسية',online:'مواجهة الأسئلة',local:'أسئلة على جهاز واحد',quiz:'الأسئلة',sudoku:'سودوكو','paths-online':'توصيل الأرقام',serpent:'حلبة الثعابين',journey:'رحلة النجوم',shop:'المتجر',social:'الأصدقاء والحساب',snakes:'الثعبان والسلالم',jackaroo:'جاكارو',zahra:'الزهرة',dice:'سباق النرد',logic:'المنطق',puzzle:'الألغاز',memory:'الذاكرة',reaction:'سرعة الاستجابة',accuracy:'الدقة',v5:'الألعاب',picture:'سباق الصور'};
 const GAME_NAME={quiz:'مواجهة الأسئلة',serpent:'حلبة الثعابين',picture:'سباق الصور',sudoku:'سودوكو',paths:'توصيل الأرقام',snakes:'الثعبان والسلالم',zahra:'الزهرة',jackaroo:'جاكارو'};
 const ROOM_GAMES=Object.keys(GAME_NAME);
 const GAME_OF_ROUTE={online:'quiz',serpent:'serpent',picture:'picture',sudoku:'sudoku','paths-online':'paths',snakes:'snakes',zahra:'zahra',jackaroo:'jackaroo'};
 const NAV=[['/','الرئيسية','home'],['/#games','الألعاب','games'],['/shop','المتجر','shop'],['/journey','رحلة النجوم','journey'],['/social','الأصدقاء','social']];
 const canonical=url=>{try{const u=new URL(url,location.href);return ['http:','https:'].includes(u.protocol)&&u.origin===location.origin?u.href:location.href;}catch{return location.href;}};
 const toast=msg=>{if(w.BS_PLATFORM?.toast){w.BS_PLATFORM.toast(String(msg));return;}let box=d.getElementById('t26Toast');if(!box){box=el('div','t26-toast');box.id='t26Toast';box.setAttribute('role','status');d.body.append(box);}box.textContent=String(msg);box.hidden=false;clearTimeout(box._t);box._t=setTimeout(()=>{box.hidden=true;},3000);};

 /* ---------- app bar ---------- */
 function brandName(){return d.querySelector('.bs-brand-copy b')?.textContent?.trim()||'تحدي العباقرة';}
 function goBack(){try{if(history.length>1&&d.referrer&&new URL(d.referrer).origin===location.origin){history.back();return;}}catch{}location.assign('/');}
 function addBar(){
  if(d.querySelector('.t26-bar'))return;
  const bar=el('header','t26-bar');bar.setAttribute('role','banner');
  const start=el('div','t26-bar-side t26-bar-start'),end=el('div','t26-bar-side t26-bar-end');
  if(home){const a=el('a','t26-brand');a.href='/';a.setAttribute('aria-label','الصفحة الرئيسية');a.append(el('span','t26-mark','✦'),el('span','t26-brand-name',brandName()));start.append(a);}
  else{const back=el('button','t26-back');back.type='button';back.setAttribute('aria-label','رجوع');back.append(svg(ICON.back),el('span','','رجوع'));back.onclick=goBack;start.append(back);}
  const title=el('div','t26-bar-title');const t=el('span','t26-page-title',home?'':(PAGES[route]||'تهدئة'));title.append(t);
  const nav=el('nav','t26-nav');nav.setAttribute('aria-label','التنقل الرئيسي');for(const [href,label,key] of NAV){const a=el('a','t26-nav-link',label);a.href=href;if(key===route||(key==='home'&&home))a.setAttribute('aria-current','page');nav.append(a);}
  const invite=el('button','t26-invite');invite.type='button';invite.setAttribute('aria-label','دعوة صديق');invite.append(svg(ICON.invite),el('span','','دعوة صديق'));invite.onclick=openInvite;end.append(invite);
  bar.append(start,title,nav,end);d.body.insertBefore(bar,d.body.firstChild);
  d.body.classList.add('t26-ready');if(d.querySelector('.mobile-dock'))d.body.classList.add('t26-dock');
 }

 /* ---------- invitation context ---------- */
 function context(){
  const data=w.BS_INVITES?.data?.()||{},params=new URLSearchParams(location.search);
  let code=String(data.code||params.get('room')||'').trim();
  if(!/^\d{6}$/.test(code))for(const id of ['soCode','pathRoomCode','roomCode','code']){const n=d.getElementById(id),txt=n?.textContent?.trim();if(n&&n.tagName!=='INPUT'&&/^\d{6}$/.test(txt||'')&&!n.closest('[hidden],.hidden')){code=txt;break;}}
  let game=data.game||GAME_OF_ROUTE[route]||route;if(route==='journey')game=params.get('game')||game;
  const gameKnown=ROOM_GAMES.includes(game);
  const joinable=gameKnown&&/^\d{6}$/.test(code)&&data.joinable!==false;
  const url=new URL(canonical(data.url||location.href));url.hash='';if(joinable){url.searchParams.set('room',code);}
  return{game,gameKnown,code,joinable,url:url.href,name:GAME_NAME[game]||PAGES[route]||'تهدئة'};
 }
 const message=(ctx,friend)=>(friend?'يا '+friend+'، ':'')+(ctx.joinable?'تعال نلعب '+ctx.name+' — الغرفة '+ctx.code+'.':'جرّب تغلبني في '+ctx.name+'!');

 /* ---------- social helpers (BS_SOCIAL when present, raw API otherwise) ---------- */
 const sessionToken=()=>{try{return localStorage.getItem('bs_social_session')||'';}catch{return '';}};
 async function raw(path,{method='GET',body}={}){const res=await fetch(path,{method,headers:{...(body?{'content-type':'application/json'}:{}),...(sessionToken()?{authorization:'Bearer '+sessionToken()}:{})},body:body?JSON.stringify(body):undefined,cache:'no-store'});const data=await res.json().catch(()=>({}));if(!res.ok||data.ok===false)throw Error(data.error||'تعذر تنفيذ الطلب');return data;}
 const social={
  signedIn:()=>w.BS_SOCIAL?.isLoggedIn?.()??Boolean(sessionToken()),
  me:()=>w.BS_SOCIAL?.me?w.BS_SOCIAL.me(true):raw('/api/social/me'),
  invite:(username,game,roomCode)=>w.BS_SOCIAL?.invite?w.BS_SOCIAL.invite(username,game,roomCode):raw('/api/social/invites',{method:'POST',body:{username,game,roomCode}}),
  async login(username,password){if(w.BS_SOCIAL?.login)return w.BS_SOCIAL.login({username,password});const data=await raw('/api/social/login',{method:'POST',body:{username,password}});try{localStorage.setItem('bs_social_session',data.token);}catch{}w.dispatchEvent(new CustomEvent('bs-social-session'));return data;},
  async signup(username,displayName,password){if(w.BS_SOCIAL?.signup)return w.BS_SOCIAL.signup({username,displayName,password});const data=await raw('/api/social/signup',{method:'POST',body:{username,displayName,password}});try{localStorage.setItem('bs_social_session',data.token);}catch{}w.dispatchEvent(new CustomEvent('bs-social-session'));return data;}
 };

 /* ---------- invitation sheet ---------- */
 let sheet=null;
 function openInvite(){
  if(sheet)return;const ctx=context(),prev=d.activeElement;
  const shade=el('div','t26-sheet-shade'),card=el('section','t26-sheet');card.setAttribute('role','dialog');card.setAttribute('aria-modal','true');card.setAttribute('aria-label','دعوة صديق');
  const onKey=e=>{if(e.key==='Escape'){e.preventDefault();close();}if(e.key==='Tab'){const items=[...card.querySelectorAll('button,a,input')].filter(n=>!n.disabled&&n.offsetParent!==null);if(!items.length)return;const first=items[0],last=items.at(-1);if(!card.contains(d.activeElement)){e.preventDefault();first.focus();}else if(e.shiftKey&&d.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&d.activeElement===last){e.preventDefault();first.focus();}}};
  const close=()=>{d.removeEventListener('keydown',onKey,true);shade.classList.add('out');d.documentElement.classList.remove('t26-lock');setTimeout(()=>shade.remove(),220);sheet=null;prev?.focus?.();};
  const head=el('header','t26-sheet-head'),icon=el('span','t26-sheet-icon');icon.append(svg(ICON.invite));
  const titles=el('div','t26-sheet-titles');titles.append(el('h2','','ادعُ صديقك'),el('p','',ctx.name));
  const x=el('button','t26-sheet-close');x.type='button';x.setAttribute('aria-label','إغلاق');x.append(svg(ICON.close));x.onclick=close;
  head.append(icon,titles,x);card.append(head);

  /* room / link block */
  const box=el('div','t26-room');
  if(ctx.joinable){const code=el('button','t26-code');code.type='button';code.setAttribute('aria-label','نسخ رمز الغرفة '+ctx.code);code.append(el('small','','رمز الغرفة'),el('b','',ctx.code.split('').join(' ')),svg(ICON.copy));code.onclick=()=>copy(ctx.code,'تم نسخ رمز الغرفة');box.append(code,el('p','t26-hint','أصدقاؤك يدخلون بالرمز أو الرابط. أو أرسل لهم دعوة مباشرة بالأسفل.'));}
  else if(ctx.gameKnown)box.append(el('p','t26-hint t26-hint-block','الدعوة المباشرة تصل صديقك كإشعار داخل اللعبة، وتعمل من غرفة أونلاين مفتوحة. أنشئ غرفة في هذه اللعبة ثم افتح هذه القائمة مرة ثانية، أو شارك رابط التحدّي الآن.'));
  else box.append(el('p','t26-hint t26-hint-block','هذه اللعبة تُلعب على جهازك. شارك رابط التحدّي مع أصدقائك ليجرّبوا يتغلبون عليك.'));
  card.append(box);

  /* share actions */
  const actions=el('div','t26-share');
  const act=(label,ico,fn,cls='')=>{const b=el('button','t26-share-btn '+cls);b.type='button';b.append(svg(ICON[ico]),el('span','',label));b.onclick=fn;actions.append(b);return b;};
  act('واتساب','chat',()=>{w.open('https://wa.me/?text='+encodeURIComponent(message(ctx)+'\n'+ctx.url),'_blank','noopener');},'t26-whatsapp');
  act('مشاركة','share',async()=>{try{if(navigator.share)await navigator.share({title:'تهدئة — '+ctx.name,text:message(ctx),url:ctx.url});else await copy(ctx.url,'تم نسخ الرابط');}catch(e){if(e?.name!=='AbortError')toast('تعذرت المشاركة — جرّب نسخ الرابط');}});
  act('نسخ الرابط','copy',()=>copy(ctx.url,'تم نسخ رابط الدعوة'));
  card.append(actions);

  /* friends */
  const friends=el('section','t26-friends');card.append(friends);
  shade.append(card);d.body.append(shade);d.documentElement.classList.add('t26-lock');sheet={close};
  shade.addEventListener('click',e=>{if(e.target===shade)close();});
  d.addEventListener('keydown',onKey,true);
  x.focus({preventScroll:true});
  renderFriends(friends,ctx);
 }
 async function copy(text,ok){try{await navigator.clipboard.writeText(text);toast(ok);}catch{const t=el('textarea');t.value=text;t.style.cssText='position:fixed;opacity:0';d.body.append(t);t.select();try{d.execCommand('copy');toast(ok);}catch{toast('انسخ يدويًا: '+text);}t.remove();}}

 function renderFriends(host,ctx){
  host.replaceChildren(el('h3','t26-section-title','أصدقاؤك'));
  if(!social.signedIn()){host.append(authForm(()=>renderFriends(host,ctx)));return;}
  const status=el('p','t26-hint','جاري تحميل أصدقائك…');host.append(status);
  social.me().then(data=>{
   const list=[...(data.friends||[])].sort((a,b)=>Number(b.online)-Number(a.online)||String(a.displayName).localeCompare(String(b.displayName),'ar'));
   status.remove();
   if(!list.length){const empty=el('div','t26-empty');empty.append(el('p','','ما عندك أصدقاء بعد. أضف صديقًا باسم المستخدم ثم ارجع هنا لدعوته.'));const a=el('a','t26-btn t26-btn-soft','فتح قائمة الأصدقاء');a.href='/social';empty.append(a);host.append(empty);return;}
   let filter=null;if(list.length>5){filter=el('input','t26-search');filter.type='search';filter.placeholder='ابحث عن صديق…';filter.setAttribute('aria-label','ابحث عن صديق');host.append(filter);}
   const rows=el('div','t26-friend-list');host.append(rows);
   const draw=()=>{const q=(filter?.value||'').trim().toLowerCase();rows.replaceChildren();for(const f of list){const label=f.displayName||f.username;if(q&&!(label+f.username).toLowerCase().includes(q))continue;rows.append(friendRow(f,label,ctx));}if(!rows.children.length)rows.append(el('p','t26-hint','لا يوجد صديق بهذا الاسم.'));};
   filter?.addEventListener('input',draw);draw();
  }).catch(err=>{status.textContent=err.message||'تعذر تحميل الأصدقاء.';const retry=el('button','t26-btn t26-btn-soft','إعادة المحاولة');retry.type='button';retry.onclick=()=>renderFriends(host,ctx);host.append(retry);});
 }
 function friendRow(f,label,ctx){
  const row=el('div','t26-friend'),avatar=el('span','t26-avatar',Array.from(label)[0]||'؟');if(f.online)avatar.classList.add('on');
  const who=el('div','t26-friend-info');who.append(el('b','',label),el('small','','@'+f.username+' · '+(f.online?'متصل الآن':'غير متصل')));
  const btn=el('button','t26-btn t26-btn-primary',ctx.joinable?'دعوة':'شارك له');btn.type='button';
  btn.onclick=async()=>{
   if(!ctx.joinable){const text=message(ctx,label)+'\n'+ctx.url;try{if(navigator.share)await navigator.share({title:'تهدئة — '+ctx.name,text:message(ctx,label),url:ctx.url});else await copy(text,'تم نسخ رسالة لـ '+label);}catch(e){if(e?.name!=='AbortError')toast('تعذرت المشاركة');}return;}
   btn.disabled=true;btn.textContent='جاري الإرسال…';
   try{await social.invite(f.username,ctx.game,ctx.code);btn.replaceChildren(svg(ICON.check),el('span','','تم الإرسال'));btn.classList.add('done');toast('وصلت دعوتك إلى '+label);}
   catch(err){btn.disabled=false;btn.textContent='دعوة';toast(err.message||'تعذر إرسال الدعوة');}
  };
  row.append(avatar,who,btn);return row;
 }
 function authForm(done){
  const wrap=el('div','t26-auth'),tabs=el('div','t26-auth-tabs'),login=el('button','active','تسجيل الدخول'),signup=el('button','','حساب جديد');
  for(const b of [login,signup])b.type='button';tabs.append(login,signup);
  wrap.append(el('p','t26-hint','سجّل دخولك لتظهر قائمة أصدقائك هنا وترسل لهم الدعوات مباشرة.'),tabs);
  const form=el('form','t26-form');form.noValidate=true;
  const field=(label,type,name,extra={})=>{const l=el('label','t26-field');const i=el('input');i.type=type;i.name=name;Object.assign(i,extra);l.append(el('span','',label),i);return{l,i};};
  const name=field('اسمك الظاهر','text','display',{autocomplete:'name',maxLength:24,placeholder:'مثال: فهد'}),user=field('اسم المستخدم','text','username',{autocomplete:'username',maxLength:20,placeholder:'fahad_7'}),pass=field('كلمة المرور','password','password',{autocomplete:'current-password',maxLength:72,placeholder:'8 أحرف على الأقل'});
  user.i.dir='ltr';user.i.autocapitalize='none';user.i.spellcheck=false;name.l.hidden=true;
  const err=el('p','t26-error');err.setAttribute('role','alert');const submit=el('button','t26-btn t26-btn-primary t26-wide','دخول');submit.type='submit';
  form.append(name.l,user.l,pass.l,err,submit);wrap.append(form);
  let mode='login';const setMode=m=>{mode=m;login.classList.toggle('active',m==='login');signup.classList.toggle('active',m==='signup');name.l.hidden=m==='login';pass.i.autocomplete=m==='login'?'current-password':'new-password';submit.textContent=m==='login'?'دخول':'إنشاء الحساب';err.textContent='';};
  login.onclick=()=>setMode('login');signup.onclick=()=>setMode('signup');
  form.onsubmit=async e=>{e.preventDefault();const u=user.i.value.trim().toLowerCase(),p=pass.i.value,n=name.i.value.trim();
   if(!/^[a-z0-9_]{3,20}$/.test(u))return void(err.textContent='اسم المستخدم: 3–20 حرفًا إنجليزيًا أو أرقامًا أو _');
   if(p.length<8)return void(err.textContent='كلمة المرور 8 أحرف على الأقل');
   submit.disabled=true;err.textContent='';const label=submit.textContent;submit.textContent='لحظة…';
   try{if(mode==='login')await social.login(u,p);else await social.signup(u,n||u,p);toast('أهلًا بك!');done();}
   catch(ex){err.textContent=ex.message||'تعذر تسجيل الدخول';submit.disabled=false;submit.textContent=label;}};
  return wrap;
 }

 /* ---------- wiring ---------- */
 let roomStore={};
 /* Pages that never loaded the older feedback script still need the room context games publish. */
 function attach(){const original=w.BS_INVITES;if(original&&!original.__t26)w.BS_INVITES={...original,open:openInvite,__t26:true};else if(!original)w.BS_INVITES=Object.freeze({open:openInvite,data:()=>({...roomStore}),set:value=>{roomStore=value&&typeof value==='object'?value:{};},__t26:true});}
 function setup(){addBar();attach();}
 if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',setup,{once:true});else setup();
 d.addEventListener('DOMContentLoaded',attach,{once:true});setTimeout(attach,900);
 w.TAHDIA_UI=Object.freeze({openInvite,toast,context});
})();
