import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';

const root = process.cwd();

test('snake arena is rendered as a live CSS/SVG board', async () => {
  const html = await readFile(join(root, 'public', 'snakes.html'), 'utf8');
  const css = await readFile(join(root, 'public', 'assets', 'css', 'snake-live-arena.css'), 'utf8');
  assert.match(html, /assets\/css\/snake-live-arena\.css/);
  assert.match(html, /classList\.add\('arena-live'\)/);
  assert.doesNotMatch(html, /snake-reference-skin\.png/);
  assert.match(css, /CSS\/SVG\/DOM only/);
  assert.match(css, /\.snake-cell:hover/);
  assert.match(css, /\.snake-side #roll/);
  assert.match(html, /function launchConfetti\(\)/);
});

test('snake turn has a keyboard-safe action path and no stale overlay badge', async () => {
  const html = await readFile(join(root, 'public', 'snakes.html'), 'utf8');
  assert.match(html, /function rollTurn\(\)/);
  assert.match(html, /document\.addEventListener\('keydown'/);
  assert.match(html, /classList\.add\('has-rolled'\)/);
  assert.match(html, /console\.error\('Snake turn failed'/);
});
