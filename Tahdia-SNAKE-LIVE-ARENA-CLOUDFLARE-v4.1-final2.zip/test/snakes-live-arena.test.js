import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';

const root = process.cwd();

test('live arena keeps board cells, pawns and controls visible', async () => {
  const html = await readFile(join(root, 'public', 'snakes.html'), 'utf8');
  const css = await readFile(join(root, 'public', 'assets', 'css', 'snake-live-arena.css'), 'utf8');

  assert.match(html, /assets\/css\/snake-live-arena\.css/);
  assert.match(css, /\.snake-cell,[\s\S]*color:\s*#e8f7ff/);
  assert.match(css, /\.token-stack[\s\S]*pointer-events:\s*auto/);
  assert.match(css, /\.snake-side #roll[\s\S]*color:\s*#fff/);
  assert.doesNotMatch(html, /snake-reference-skin\.png/);
  assert.match(html, /d\.tabIndex=0/);
  assert.match(html, /inspectBoardCell/);
  assert.match(html, /function launchConfetti\(\)/);
});

test('snakes page exposes resilient interaction handlers', async () => {
  const html = await readFile(join(root, 'public', 'snakes.html'), 'utf8');
  assert.match(html, /async function rollTurn\(\)/);
  assert.match(html, /finally\{[^}]*busy=false;render\(\)/s);
  assert.match(html, /document\.addEventListener\('keydown'/);
  assert.match(html, /classList\.add\('has-rolled'\)/);
});
