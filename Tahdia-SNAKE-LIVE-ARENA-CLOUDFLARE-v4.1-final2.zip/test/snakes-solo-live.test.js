import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

test('snakes UI exposes the live arena and solo AI mode', async()=>{
  const html=await readFile(new URL('../public/snakes.html',import.meta.url),'utf8');
  assert.match(html,/snake-live-arena\.css/);
  assert.match(html,/arena-live/);
  assert.doesNotMatch(html,/snake-reference-skin\.png/);
  assert.match(html,/تدريب فردي ضد الذكاء الاصطناعي/);
  assert.match(html,/runSoloAi/);
});
