/* Tahdia 26 — shared game feedback: canvas particles, correct / wrong / progress effects,
   the legendary winner celebration and a sober defeat card. Visual first; sound and vibration
   follow the player's existing "effects" setting. Honors prefers-reduced-motion. */
(()=>{'use strict';
 const w=window,d=document;
 if(w.__TAHDIA_FX_26__)return;w.__TAHDIA_FX_26__=true;
 const old=w.BS_GAME_FX||{};
 const reduced=()=>Boolean(w.matchMedia?.('(prefers-reduced-motion: reduce)').matches);
 const sfx=()=>w.BS_AUDIO?.getSettings?.().effects!==false;
 const el=(tag,cls,text)=>{const n=d.createElement(tag);if(cls)n.className=cls;if(text!=null)n.textContent=text;return n;};
 const rand=(a,b)=>a+Math.random()*(b-a);
 const pick=list=>list[Math.floor(Math.random()*list.length)];
 const PAL={ok:['#34d399','#6ee7b7','#a7f3d0','#ffe08a','#ffffff'],bad:['#fb7185','#f43f5e','#fda4af','#fff1f2'],gold:['#ffe08a','#ffd166','#f5a524','#fff3c4','#ffffff'],party:['#ffd166','#8b7bff','#34d399','#fb7185','#58d3f7','#ffffff','#f08adf'],ember:['#fb923c','#f59e0b','#a8a29e','#57534e']};
 const vibrate=p=>{try{if(sfx())navigator.vibrate?.(p);}catch{}};
 const play=name=>{try{w.BS_AUDIO?.play?.(name);}catch{}};

 /* ---------- canvas particle system ---------- */
 let canvas=null,ctx=null,parts=[],raf=0,last=0,dpr=1,timers=new Set();
 function resize(){if(!canvas)return;dpr=Math.min(2,w.devicePixelRatio||1);canvas.width=Math.round(innerWidth*dpr);canvas.height=Math.round(innerHeight*dpr);}
 function ensure(){const host=d.querySelector('dialog.t26-modal[open]')||d.body;if(canvas?.isConnected&&canvas.parentNode===host)return;canvas?.remove();canvas=el('canvas','t26-fx-canvas');canvas.setAttribute('aria-hidden','true');host.append(canvas);ctx=canvas.getContext('2d');resize();}
 addEventListener('resize',resize,{passive:true});
 function add(p){if(reduced())return;ensure();if(parts.length>650)parts.splice(0,40);parts.push(p);if(!raf){last=performance.now();raf=requestAnimationFrame(tick);}}
 function star(x,y,r){ctx.beginPath();for(let i=0;i<8;i++){const a=i*Math.PI/4,rad=i%2?r*.28:r;ctx.lineTo(x+Math.cos(a)*rad,y+Math.sin(a)*rad);}ctx.closePath();ctx.fill();}
 function tick(now){raf=0;const dt=Math.min(.05,(now-last)/1000);last=now;ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,innerWidth,innerHeight);
  for(const p of parts){p.life-=dt;if(p.life<=0)continue;const t=1-p.life/p.max;
   if(p.shape==='ring'){p.r=p.from+(p.to-p.from)*(1-Math.pow(1-t,3));ctx.globalAlpha=Math.max(0,1-t);ctx.strokeStyle=p.color;ctx.lineWidth=p.width*(1-t*.6);ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.stroke();continue;}
   p.px=p.x;p.py=p.y;p.vx*=p.drag;p.vy=p.vy*p.drag+p.g*dt;p.x+=p.vx*dt+(p.sway?Math.sin(p.life*6+p.seed)*p.sway*dt:0);p.y+=p.vy*dt;p.rot+=p.spin*dt;
   const fade=p.fade?Math.min(1,p.life/(p.max*.45)):1;ctx.globalAlpha=Math.max(0,fade);ctx.fillStyle=p.color;ctx.strokeStyle=p.color;
   if(p.shape==='rect'){ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.rot);ctx.scale(1,Math.cos(p.life*7+p.seed));ctx.fillRect(-p.size,-p.size*.5,p.size*2,p.size);ctx.restore();}
   else if(p.shape==='star'){star(p.x,p.y,p.size*(.7+.3*Math.sin(p.life*12+p.seed)));}
   else if(p.shape==='streak'){ctx.lineWidth=p.size;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(p.px,p.py);ctx.lineTo(p.x,p.y);ctx.stroke();}
   else{ctx.beginPath();ctx.arc(p.x,p.y,p.size,0,Math.PI*2);ctx.fill();}}
  ctx.globalAlpha=1;parts=parts.filter(p=>p.life>0);
  if(parts.length||timers.size)raf=requestAnimationFrame(tick);else{ctx.clearRect(0,0,innerWidth,innerHeight);canvas.remove();canvas=null;}}
 function burst(x,y,o={}){const n=o.n??18,pal=o.palette||PAL.ok;for(let i=0;i<n;i++){const a=o.cone?(-Math.PI/2+rand(-o.cone,o.cone)):rand(0,Math.PI*2),sp=rand(o.speed*.45||90,o.speed||240),life=rand(.55,1)*(o.life||.9);add({x,y,px:x,py:y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,g:o.gravity??380,drag:o.drag??.985,life,max:life,size:rand(.6,1)*(o.size||4),color:pick(pal),shape:o.shape||'dot',rot:rand(0,6),spin:rand(-9,9),seed:rand(0,6),fade:true,sway:o.sway||0});}}
 function ring(x,y,o={}){add({shape:'ring',x,y,from:o.from||6,to:o.to||70,r:0,width:o.width||3,color:o.color||pick(PAL.ok),life:o.life||.6,max:o.life||.6});}
 function firework(x,y,pal=PAL.gold){const n=58,color=pick(pal);for(let i=0;i<n;i++){const a=i/n*Math.PI*2+rand(-.05,.05),sp=rand(150,330);const life=rand(.9,1.5);add({x,y,px:x,py:y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,g:210,drag:.972,life,max:life,size:rand(1.6,3),color:i%3?color:pick(pal),shape:'streak',rot:0,spin:0,seed:0,fade:true});}ring(x,y,{from:4,to:96,color,life:.5,width:2});burst(x,y,{n:14,palette:pal,speed:120,size:3,shape:'star',life:1.2,gravity:80});}
 function confetti(ms=5200,pal=PAL.party,rate=7){if(reduced())return;const until=performance.now()+ms,id=setInterval(()=>{if(performance.now()>until){clearInterval(id);timers.delete(id);return;}for(let i=0;i<rate;i++){const life=rand(2.2,3.6);add({x:rand(0,innerWidth),y:-12,px:0,py:0,vx:rand(-40,40),vy:rand(60,150),g:70,drag:.998,life,max:life,size:rand(3.5,6.5),color:pick(pal),shape:'rect',rot:rand(0,6),spin:rand(-5,5),seed:rand(0,6),fade:false,sway:rand(30,80)});}},90);timers.add(id);}
 function show(fn,ms){const id=setTimeout(()=>{timers.delete(id);fn();},ms);timers.add(id);return id;}

 /* ---------- small DOM effects ---------- */
 function where(target){const r=target?.getBoundingClientRect?.();if(r&&(r.width||r.height))return{x:r.left+r.width/2,y:r.top+r.height/2};return{x:innerWidth/2,y:innerHeight*.42};}
 function pulse(node,cls,ms=750){if(!node?.classList)return;node.classList.remove(cls);void node.offsetWidth;node.classList.add(cls);setTimeout(()=>node.classList.remove(cls),ms);}
 function edge(kind){const n=el('div','t26-edge t26-edge-'+kind);n.setAttribute('aria-hidden','true');d.body.append(n);setTimeout(()=>n.remove(),760);}
 function floating(x,y,text,kind){if(!text)return;const n=el('div','t26-float t26-float-'+kind,text);n.setAttribute('aria-hidden','true');n.style.left=x+'px';n.style.top=y+'px';d.body.append(n);setTimeout(()=>n.remove(),1150);}
 const shaker=target=>target?.closest?.('[data-fx-shake],.sudoku-board,.sudoku-grid-wrap,.paths-canvas-wrap,#soBoard,#sudokuBoard,.question-card,.choices,#choices')||null;

 function correct(target,o={}){const p=where(target);pulse(target,'t26-right');ring(p.x,p.y,{color:'#6ee7b7',to:62});burst(p.x,p.y,{n:o.n??14,palette:PAL.ok,speed:230,gravity:300,size:3.6});if(o.label!=='')floating(p.x,p.y-14,o.label??'✓','ok');if(o.edge!==false)edge('ok');if(o.sound)play('correct');vibrate(16);}
 function wrong(target,o={}){const p=where(target);pulse(target,'t26-wrong',650);pulse(shaker(target),'t26-shake',480);burst(p.x,p.y,{n:9,palette:PAL.bad,speed:170,gravity:240,size:3.2});if(o.label!=='')floating(p.x,p.y-14,o.label??'✕','bad');if(o.edge!==false)edge('bad');if(o.sound)play('wrong');vibrate([30,36,60]);}
 function progressFx(target,o={}){const p=where(target);ring(p.x,p.y,{color:'#ffd166',to:84,life:.7,width:3});burst(p.x,p.y,{n:o.n??16,palette:PAL.gold,speed:260,gravity:140,size:5,shape:'star',life:1.1});if(o.label!=='')floating(p.x,p.y-20,o.label??'+','gold');if(o.edge)edge('gold');if(o.sound)play('reward');vibrate(12);}

 /* ---------- sound: a short synthesized fanfare (no asset needed) ---------- */
 let actx=null;
 function tone(freq,at,len,type,vol){const o=actx.createOscillator(),g=actx.createGain();o.type=type;o.frequency.value=freq;g.gain.setValueAtTime(0.0001,at);g.gain.exponentialRampToValueAtTime(vol,at+.02);g.gain.exponentialRampToValueAtTime(0.0001,at+len);o.connect(g).connect(actx.destination);o.start(at);o.stop(at+len+.05);}
 function fanfare(kind='win'){if(!sfx())return;try{actx=actx||new(w.AudioContext||w.webkitAudioContext)();actx.resume?.();const t=actx.currentTime+.03;
  if(kind==='win'){[[523.25,0,.16],[659.25,.13,.16],[783.99,.26,.16],[1046.5,.4,.34],[783.99,.78,.14],[1046.5,.9,.14],[1318.5,1.04,.7]].forEach(([f,at,len])=>{tone(f,t+at,len,'triangle',.2);tone(f/2,t+at,len,'sine',.12);});[523.25,659.25,783.99,1046.5].forEach(f=>tone(f,t+1.04,1.1,'sawtooth',.045));}
  else{[[392,0,.28],[330,.25,.28],[262,.5,.6]].forEach(([f,at,len])=>tone(f,t+at,len,'triangle',.16));}}catch{}}

 /* ---------- the legendary winner celebration ---------- */
 const CROWN='<svg viewBox="0 0 120 92" aria-hidden="true"><defs><linearGradient id="t26g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff3c4"/><stop offset=".5" stop-color="#ffcf6b"/><stop offset="1" stop-color="#e08a14"/></linearGradient></defs><path d="M10 78 4 24l30 24 26-38 26 38 30-24-6 54z" fill="url(#t26g)" stroke="#fff3c4" stroke-width="2" stroke-linejoin="round"/><rect x="10" y="78" width="100" height="10" rx="4" fill="#e08a14"/><circle cx="60" cy="10" r="6" fill="#fff"/><circle cx="4" cy="24" r="5" fill="#fff"/><circle cx="116" cy="24" r="5" fill="#fff"/><circle cx="34" cy="62" r="5" fill="#fb7185"/><circle cx="60" cy="58" r="6" fill="#58d3f7"/><circle cx="86" cy="62" r="5" fill="#34d399"/></svg>';
 const DEFEAT='<svg viewBox="0 0 96 96" aria-hidden="true"><path d="M48 8 12 22v26c0 20 14 35 36 42 22-7 36-22 36-42V22z" fill="#27324f" stroke="#7d8bb8" stroke-width="3"/><path d="m34 36 28 28M62 36 34 64" stroke="#fb7185" stroke-width="7" stroke-linecap="round"/></svg>';
 const cleanName=v=>String(v??'').normalize('NFKC').replace(/[<>\u0000-\u001f\u202a-\u202e\u2066-\u2069]/g,'').replace(/\s+/g,' ').trim().slice(0,32);
 const careerName=()=>{try{return cleanName(w.BS_CAREER?.get?.()?.name||'');}catch{return '';}};
 let open=null;
 function overlay(kind,o){const prev=d.activeElement;open?.close();const shade=el('dialog','t26-modal t26-'+kind);shade.id='t26Result';shade.setAttribute('aria-label',kind==='win'?'احتفال الفوز':'نتيجة الجولة');
  let done=false;const close=()=>{if(done)return;done=true;shade.classList.add('out');setTimeout(()=>{try{shade.close?.();}catch{}shade.remove();},260);open=null;o.onClose?.();prev?.focus?.();};
  shade.addEventListener('cancel',e=>{e.preventDefault();close();});
  const btn=el('button','t26-modal-btn',o.button||(kind==='win'?'متابعة':'حسنًا'));btn.type='button';btn.onclick=close;
  shade.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();close();}if(e.key==='Tab'){e.preventDefault();btn.focus();}});
  shade.addEventListener('click',e=>{if(e.target===shade&&kind!=='win')close();});
  open={close};return{shade,btn,close};}
 function present(dlg){try{if(typeof dlg.showModal==='function')dlg.showModal();else dlg.setAttribute('open','');}catch{dlg.setAttribute('open','');}}
 function chips(list){if(!Array.isArray(list)||!list.length)return null;const row=el('div','t26-chips');for(const c of list.slice(0,4)){const chip=el('div','t26-chip');chip.append(el('b','',String(c.value)),el('span','',String(c.label)));row.append(chip);}return row;}
 function win(arg={}){if(arg instanceof Element)arg={node:arg};else if(typeof arg==='string')arg={name:arg};
  if(d.getElementById('t26Result'))return open;const name=cleanName(arg.name)||careerName()||'البطل';
  const {shade,btn,close}=overlay('win',arg),card=el('section','t26-card');
  shade.append(el('div','t26-rays'),el('div','t26-halo'));
  const crown=el('div','t26-crown');crown.innerHTML=CROWN;
  const h=el('h2','t26-name',name);h.dir='auto';
  card.append(crown,el('div','t26-kicker',arg.kicker||'بطل الجولة'),h);
  if(arg.subtitle)card.append(el('p','t26-sub',arg.subtitle));
  const row=chips(arg.stats);if(row)card.append(row);
  const actions=el('div','t26-actions');actions.append(btn);
  if(navigator.share&&arg.share!==false){const sh=el('button','t26-modal-btn t26-ghost','مشاركة الفوز');sh.type='button';sh.onclick=async()=>{try{await navigator.share({title:'تهدئة — فوز',text:name+' فاز '+(arg.subtitle?'· '+arg.subtitle:'')+' — تعال نلعب!',url:location.origin});}catch{}};actions.append(sh);}
  card.append(actions);shade.append(card);d.body.append(shade);present(shade);btn.focus({preventScroll:true});
  if(arg.sound!==false)fanfare('win');vibrate([60,40,60,40,180]);
  if(!reduced()){const cx=innerWidth/2;confetti(6200,PAL.party,8);[0,380,820,1280,1800,2500,3300,4200].forEach((ms,i)=>show(()=>firework(rand(cx*.35,cx*1.65),rand(innerHeight*.14,innerHeight*.5),i%2?PAL.gold:PAL.party),ms+200));show(()=>burst(cx,innerHeight*.3,{n:36,palette:PAL.gold,speed:320,gravity:200,size:5,shape:'star',life:1.4}),450);}
  return{close};}
 function lose(arg={}){if(typeof arg==='string')arg={title:arg};if(d.getElementById('t26Result'))return open;
  const {shade,btn,close}=overlay('lose',arg),card=el('section','t26-card');const icon=el('div','t26-defeat');icon.innerHTML=DEFEAT;
  card.append(icon,el('div','t26-kicker',arg.kicker||'انتهت المحاولة'),el('h2','t26-name',arg.title||'خسرت الجولة'));
  if(arg.detail)card.append(el('p','t26-sub',arg.detail));
  const row=chips(arg.stats);if(row)card.append(row);card.append(btn);shade.append(card);d.body.append(shade);present(shade);btn.focus({preventScroll:true});
  if(arg.sound!==false){fanfare('lose');}vibrate([180,60,120]);edge('bad');
  if(!reduced()){const id=setInterval(()=>{for(let i=0;i<3;i++){const life=rand(2.4,3.6);add({x:rand(0,innerWidth),y:-8,px:0,py:0,vx:rand(-14,14),vy:rand(40,80),g:12,drag:.999,life,max:life,size:rand(1.6,3),color:pick(PAL.ember),shape:'dot',rot:0,spin:0,seed:0,fade:true,sway:20});}},140);timers.add(id);show(()=>{clearInterval(id);timers.delete(id);},3200);}
  if(arg.autoClose!==0)setTimeout(close,arg.autoClose??6500);
  return{close};}

 function stageClear(node){if(d.getElementById('t26Result'))return;const p=where(node);progressFx(node,{label:'أحسنت!',n:34,edge:true});if(!reduced()){confetti(2200,PAL.party,5);show(()=>firework(p.x,Math.max(120,p.y*.7),PAL.gold),380);show(()=>firework(rand(innerWidth*.25,innerWidth*.75),rand(innerHeight*.18,innerHeight*.4),PAL.party),900);}fanfare('win');vibrate([40,30,40,30,120]);}
 /* ---------- named winners from the shared game layer ---------- */
 let lastKey='',lastAt=0;
 function celebrateNamed(name,o={}){const clean=cleanName(name)||careerName(),key=(o.key||clean)+':'+(o.round||''),now=Date.now();
  if(key===lastKey&&now-lastAt<12000)return;lastKey=key;lastAt=now;
  if(o.tie)return win({name:'تعادل',kicker:'نهاية متعادلة',subtitle:o.subtitle||'جولة قوية تستحق الإعادة.',stats:o.stats,sound:o.sound});
  if(o.self===false)return lose({kicker:'بطل الجولة',title:(clean||'الخصم')+' يفوز',detail:o.subtitle||'حسم الجولة بجدارة.',stats:o.stats,autoClose:o.hold?9000:5600,sound:o.sound});
  return win({name:clean,subtitle:o.subtitle,stats:o.stats,sound:o.sound});}
 /* The shared feedback layer builds its own simple victory card from inside a closure (board winners, quiz results).
    Take that card over: read what it says, remove it, and show the full celebration instead. */
 function takeOverVictory(node){if(!(node instanceof Element)||node.id!=='bsVictory'||node.dataset.t26)return;node.dataset.t26='1';
  const name=node.querySelector('h2')?.textContent||'',sub=node.querySelector('p')?.textContent||'',crown=node.querySelector('.bs-victory-crown')?.textContent||'';
  node.remove();celebrateNamed(name,{tie:crown==='◆',self:!node.classList.contains('is-rival'),subtitle:sub,sound:false,key:'v:'+name+':'+sub});}
 function watchVictory(){if(typeof MutationObserver!=='function')return;new MutationObserver(list=>{for(const m of list)for(const n of m.addedNodes)takeOverVictory(n);}).observe(d.documentElement,{childList:true,subtree:true});}
 if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',watchVictory,{once:true});else watchVictory();

 /* ---------- public API (superset of the older BS_GAME_FX contract) ---------- */
 function units(cells,board,index){const row=Math.floor(index/9),col=index%9,all=[Array.from({length:9},(_,i)=>row*9+i),Array.from({length:9},(_,i)=>i*9+col),Array.from({length:9},(_,i)=>(Math.floor(row/3)*3+Math.floor(i/3))*9+Math.floor(col/3)*3+i%3)];return all.filter(u=>u.every(i=>board[i])&&new Set(u.map(i=>board[i])).size===9);}
 const nodeOf=(cells,i)=>cells[i]?.el||cells[i];
 const api={
  cell:(node,kind='right')=>kind==='wrong'?wrong(node,{label:''}):kind==='shake'?pulse(node,'t26-shake',480):kind==='unit'?pulse(node,'t26-unit',900):correct(node,{n:8,label:'',edge:false}),
  wrong:node=>wrong(node,{label:''}),
  sudoku(cells,board,index,kind='right'){const node=nodeOf(cells,index);if(kind!=='right')return wrong(node,{label:''});correct(node,{n:10,label:''});const done=units(cells,board,index);if(done.length){const flat=[...new Set(done.flat())];for(const i of flat)pulse(nodeOf(cells,i),'t26-unit',900);progressFx(node,{label:done.length>1?'اكتمال مزدوج!':'اكتمل!',n:22});}},
  path(canvas,puzzle,points,color){old.path?.(canvas,puzzle,points,color);ring(where(canvas).x,where(canvas).y,{color:'#ffd166',to:90,life:.7});},
  progress:(node,current,total,label)=>{if(typeof old.progress==='function'&&Number.isFinite(total))old.progress(node,current,total,label);else progressFx(node,typeof current==='object'?current:{});},
  win:(arg,options={})=>arg instanceof Element?(options.name||options.celebrate?celebrateNamed(options.name,options):stageClear(arg)):win(arg),
  celebrate:(name,options={})=>celebrateNamed(name,options),
  correct,lose,confetti:ms=>confetti(ms),firework:(x,y)=>firework(x??innerWidth/2,y??innerHeight/3)
 };
 w.BS_GAME_FX=Object.freeze({...old,...api});
 w.TAHDIA_FX=Object.freeze({...api,progressFx,burst,ring});
})();
