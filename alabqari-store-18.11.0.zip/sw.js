/*! Alabqari Store 18.11.0 | App code rights reserved for the project owner. */
const CACHE="alabqari-store-al3b8ry-v18.11.0", PREFIX="alabqari-store-", CORE=["./js/cashier-plus.js", "./js/close-report.js", "./css/final-pro.css", "./js/catalog-pro.js", "./js/rewaa-import.js", "./js/rewaa-data.js", "./js/printer-setup.js", "./js/repair-layout.js", "./css/catalog-pro.css", "./js/customer-search-core.js", "./js/customer-search.js", "./css/customer-search.css", "./css/theme-consistency.css", "./js/performance-guard.js","./js/system-status.js", "./js/repair-cancellation-core.js", "./css/repair-list.css", "./js/repair-professional.js", "./js/warehouse-draft-core.js", "./js/warehouse-drafts.js", "./js/warehouse-hub.js", "./css/warehouse-workspace.css", "./js/store-format.js", "./js/repair-workspace.js", "./css/repair-workspace.css", "./js/customer-core.js", "./js/customer-workspace.js", "./js/repair-pricing-core.js", "./js/repair-pricing.js", "./js/invoice-review-core.js", "./js/invoice-review.js", "./css/workstation.css", "./js/persistence.js", "./js/logo-tools.js", "./js/transaction-store.js", "./js/transaction-ui.js", "./css/checkout.css", "./js/print-service.js", "./js/refinement.js", "./css/refinement.css", "./js/vendor/qz-tray-2.2.4.js", "./js/vendor/pdf.min.mjs", "./js/vendor/pdf.worker.min.mjs", "./js/invoice-document.js", "./js/id-factory.js", "./js/release-core.js", "./js/release-ui.js", "./js/product-files.js", "./js/vendor/pako_inflate.min.js", "./css/release.css", "./js/flex-core.js", "./js/invoice-files.js", "./js/print-layout.js", "./js/flex.js", "./css/flex.css", "./js/professional-core.js", "./js/professional.js", "./css/professional.css", "./js/cashier-core.js", "./css/design-system.css", "./js/design-system.js", "./assets/fonts/noto-sans-arabic-regular.woff", "./assets/fonts/noto-sans-arabic-bold.woff", "./js/order-actions-core.js", "./js/order-actions.js", "./css/order-actions.css", "./css/trade.css", "./js/trade-core.js", "./js/trade.js", "./js/final-core.js", "./js/recovery.js", "./js/final.js", "./js/secure-ui.js", "./css/final.css", "./css/operations.css", "./js/operations.js", "./css/platform.css", "./js/platform-core.js", "./js/platform.js", "./", "./manifest.webmanifest", "./assets/favicon.svg", "./assets/logo.jpeg", "./assets/logo-thermal.png", "./assets/icon-180.png", "./assets/icon-192.png", "./assets/icon-512.png", "./assets/icon-maskable-512.png", "./js/cloud-config.js", "./js/sync-core.js", "./js/ledger-core.js", "./js/archive-core.js", "./js/app.js", "./js/mobile-nav.js", "./js/enhancements.js", "./js/messages.js", "./js/quick-wa.js", "./js/barcode128.js", "./js/receipts.js", "./js/pos.js", "./js/accounts.js", "./js/printing.js", "./js/corrections.js", "./js/ui-fixes.js", "./js/inventory.js", "./js/ledger-ui.js", "./js/purchases.js", "./js/invoice-reader.js", "./js/invoice-import.js", "./js/reports.js", "./js/print-fit.js", "./js/backup-restore.js", "./js/archive.js", "./js/cloud-sync.js", "./js/workflow.js", "./js/warehouse-ui.js", "./js/warehouse-editor.js", "./js/shop-upgrade.js", "./js/staff.js", "./css/pro-ui.css", "./css/workspace.css", "./js/workspace-ui.js"];
const DOCUMENT_URL = new URL('./', self.registration.scope).href;

function navigationSafe(response) {
  if (!response.redirected) return response;
  const headers = new Headers(response.headers);
  // Fetch exposes a decoded body; these describe the original transfer.
  headers.delete('content-encoding');
  headers.delete('content-length');
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers
  });
}

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    const results = await Promise.allSettled(CORE.map(async resource => {
      const url = new URL(resource, self.registration.scope).href;
      const request = new Request(url, {cache:'reload', credentials:'same-origin', redirect:'follow'});
      const response = await fetch(request);
      if (!response.ok || new URL(response.url).origin !== self.location.origin) {
        throw new Error('Offline asset unavailable: ' + resource);
      }
      await cache.put(url, navigationSafe(response));
    }));
    const failed = results.find(result => result.status === 'rejected');
    if (failed) {
      await caches.delete(CACHE);
      throw failed.reason;
    }
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter(name => name.startsWith(PREFIX) && name !== CACHE).map(name => caches.delete(name)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  const navigation = request.mode === 'navigate';
  const configuration = url.pathname.endsWith('/js/cloud-config.js');
  const coreAsset = CORE.some(resource => new URL(resource, self.registration.scope).pathname === url.pathname);
  const runtimeAsset = /\/(?:assets|css|js)\//.test(url.pathname) && /\.(?:js|mjs|css|woff2?|ttf|otf|pfb|bcmap|png|jpe?g|webp|svg|txt)$/i.test(url.pathname);
  if (!navigation && !configuration && !coreAsset && !runtimeAsset) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const key = navigation ? DOCUMENT_URL : request;
    if (!configuration) {
      const cached = await cache.match(key, {ignoreSearch:true});
      if (cached) return navigationSafe(cached);
    }
    try {
      const response = navigationSafe(await fetch(request, {redirect:'follow', ...(configuration ? {cache:'no-store'} : {})}));
      if (response.ok) {
        event.waitUntil(cache.put(key, response.clone()).catch(() => {}));
      }
      return response;
    } catch (error) {
      const cached = await cache.match(key, {ignoreSearch:true});
      if (cached) return navigationSafe(cached);
      throw error;
    }
  })());
});
