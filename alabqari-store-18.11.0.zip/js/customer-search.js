/*! Alabqari Store 18.9.7 | Shared customer picker for sales and repair orders. */
(function () {
  'use strict';
  const core = window.CustomerSearchCore;
  function mount(parent, prefix, nameInput, phoneInput) {
    if (!parent || !nameInput || !phoneInput || document.getElementById(prefix + 'CustomerSearch')) return;
    const box = document.createElement('div');
    box.className = 'customer-lookup';
    const label = document.createElement('label');
    label.textContent = 'بحث عن عميل محفوظ بالاسم أو رقم الجوال';
    const input = document.createElement('input');
    input.id = prefix + 'CustomerSearch';
    input.type = 'search';
    input.autocomplete = 'off';
    input.maxLength = 200;
    input.placeholder = 'اكتب جزءًا من الاسم أو الجوال';
    input.setAttribute('role', 'combobox');
    input.setAttribute('aria-autocomplete', 'list');
    input.setAttribute('aria-expanded', 'false');
    const list = document.createElement('div');
    list.id = prefix + 'CustomerResults';
    list.className = 'customer-lookup-results';
    list.setAttribute('role', 'listbox');
    list.setAttribute('aria-label', 'العملاء المطابقون');
    list.hidden = true;
    input.setAttribute('aria-controls', list.id);
    label.append(input);
    const status = document.createElement('small');
    status.className = 'note customer-lookup-status';
    status.setAttribute('role', 'status');
    status.textContent = 'اختر العميل لتعبئة الاسم والجوال.';
    box.append(label, list, status);
    parent.prepend(box);
    let selected = -1;
    const close = () => {
      list.hidden = true;
      input.setAttribute('aria-expanded', 'false');
      input.removeAttribute('aria-activedescendant');
      selected = -1;
    };
    const choose = mobile => {
      const customer = core.rows(db).find(row => row.phone === mobile);
      if (!customer) { render(); return; }
      nameInput.value = customer.name;
      phoneInput.value = customer.phone;
      nameInput.dispatchEvent(new Event('input', {bubbles: true}));
      phoneInput.dispatchEvent(new Event('input', {bubbles: true}));
      input.value = '';
      close();
      status.textContent = 'تم اختيار ' + customer.name + ' · ' + customer.phone;
      nameInput.focus();
    };
    const render = () => {
      selected = -1;
      input.removeAttribute('aria-activedescendant');
      list.replaceChildren();
      const result = core.search(db, input.value);
      for (const [index, customer] of result.rows.entries()) {
        const option = document.createElement('button');
        option.type = 'button';
        option.id = prefix + 'CustomerOption' + index;
        option.className = 'customer-lookup-option';
        option.tabIndex = -1;
        option.setAttribute('role', 'option');
        option.setAttribute('aria-selected', 'false');
        const name = document.createElement('strong');
        name.textContent = customer.name;
        const mobile = document.createElement('bdi');
        mobile.textContent = customer.phone;
        mobile.dir = 'ltr';
        option.append(name, mobile);
        option.addEventListener('click', () => choose(customer.phone));
        list.append(option);
      }
      list.hidden = !result.rows.length;
      input.setAttribute('aria-expanded', String(!list.hidden));
      status.textContent = !core.text(input.value) ? 'اختر العميل لتعبئة الاسم والجوال.' : result.total
        ? (result.total > result.rows.length ? 'عرض أول ' + result.rows.length + ' من ' + result.total + ' عميل؛ أكمل البحث لتحديد العميل.' : result.total + ' عميل مطابق؛ اختر الاسم والجوال الصحيحين.')
        : 'لا يوجد عميل مطابق. يمكنك إدخال بيانات عميل جديد.';
    };
    input.addEventListener('input', render);
    input.addEventListener('focus', render);
    // Keep focus on the combobox until its selected result has handled the click.
    list.addEventListener('pointerdown', event => {
      if (event.target.closest('[role="option"]')) event.preventDefault();
    });
    input.addEventListener('keydown', event => {
      const options = Array.from(list.children);
      if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); close(); return; }
      if (event.key === 'Enter') event.preventDefault();
      if (!options.length || list.hidden) return;
      if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
        event.preventDefault();
        selected = event.key === 'ArrowDown' ? (selected + 1) % options.length : (selected <= 0 ? options.length - 1 : selected - 1);
        options.forEach((option, index) => option.setAttribute('aria-selected', String(index === selected)));
        input.setAttribute('aria-activedescendant', options[selected].id);
        options[selected].scrollIntoView({block: 'nearest'});
      } else if (event.key === 'Enter') {
        // A repeated name never silently chooses a customer or submits the order.
        if (selected >= 0) options[selected].click();
      }
    });
    box.addEventListener('focusout', event => {
      if (event.relatedTarget && box.contains(event.relatedTarget)) return;
      queueMicrotask(() => {
      if (!box.contains(document.activeElement)) close();
      });
    });
    parent.closest('dialog')?.addEventListener('close', () => { input.value = ''; close(); status.textContent = 'اختر العميل لتعبئة الاسم والجوال.'; });
  }
  function cashier() {
    const name = document.getElementById('posName');
    mount(name?.closest('.pos-fold-body'), 'posSaved', name, document.getElementById('posPhone'));
  }
  mount(document.getElementById('orderForm'), 'repairSaved', document.getElementById('name'), document.getElementById('phone'));
  cashier();
  // The cashier section is created on its first visit, after this module loads.
  const previousTab = window.tab;
  window.tab = function (...args) {
    const result = previousTab.apply(this, args);
    cashier();
    return result;
  };
})();
