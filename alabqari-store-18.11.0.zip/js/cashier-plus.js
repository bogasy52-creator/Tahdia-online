/*! Alabqari Store 18.11.0 | App code rights reserved for the project owner. */
/*! العبقري ستور — الكاشير: فواتير اليوم والسحب النقدي */
!(function () {
  "use strict";
  const h = (s) => esc(String(s ?? "")),
    PC = PlatformCore,
    WD = "سحب نقدي",
    REASONS = [
      ["rep", "مندوب / توصيل", WD + ": مندوب"],
      ["owner", "مسحوبات المالك", WD + ": مسحوبات المالك"],
      ["buy", "مشتريات للمحل", WD + ": مشتريات"],
      ["other", "سبب آخر", WD + ": أخرى"],
    ],
    st = { mode: "sale", filter: "all", q: "" },
    timeFmt = new Intl.DateTimeFormat("ar-SA-u-nu-latn", { timeZone: "Asia/Riyadh", hour: "numeric", minute: "2-digit" }),
    today = () => PC.dayKey(new Date().toISOString()),
    isWd = (e) => String(e?.category || "").startsWith(WD),
    walkIn = (p) => !p || "966500000000" === String(p);

  function withdrawalsOn(day) {
    return (db.inventory?.expenses || [])
      .filter((e) => isWd(e) && PC.dayKey(e.recordedAt || e.date) === day && !ProfessionalCore.cancellation(db, e.id))
      .sort((a, b) => String(b.recordedAt || b.date).localeCompare(String(a.recordedAt || a.date)));
  }

  function drawerNow() {
    try {
      const sh = ReleaseCore.activeShift(db);
      if (!sh || !Number.isSafeInteger(sh.opening)) return null;
      return sh.opening + PC.cashMovement(db, sh.opened, new Date().toISOString()).net;
    } catch (e) {
      return null;
    }
  }

  function todayData() {
    const d = today(),
      rep = PC.financialReport(db, d, d),
      methods = new Map();
    for (const e of PC.paymentEvents(db)) {
      if ("refund" === e.type || PC.dayKey(e.date) !== d) continue;
      const m = methods.get(e.orderId) || new Set();
      m.add(e.method);
      methods.set(e.orderId, m);
    }
    const rows = rep.orders
      .map((r) => ({ r, o: db.orders.find((o) => o.id === r.id) }))
      .filter((x) => x.o)
      .sort((a, b) => String(b.r.date).localeCompare(String(a.r.date)));
    return { d, rep, rows, methods, wd: withdrawalsOn(d) };
  }

  function lineSummary(o) {
    const lines = o.sale?.lines?.length ? o.sale.lines.map((l) => (l.name || "منتج") + (l.qty > 1 ? " ×" + l.qty : "")) : (o.devices || []).map((d) => d.model || "جهاز");
    return lines.slice(0, 3).join("، ") + (lines.length > 3 ? " +" + (lines.length - 3) : "");
  }

  function printOrder(o) {
    const html = "sale" === PC.kind(o) ? Receipts.saleHtml(o) : makePrintDocument(invoiceHTML(o, db.settings), db.settings.paper, 200);
    return window.PrintService ? window.PrintService.send(html, db.settings.printerInvoice) : browserPrint(html);
  }

  function renderToday() {
    const box = $("cpToday");
    if (!box) return;
    const { rep, rows, methods, wd } = todayData(),
      acc = can("accounts"),
      q = st.q.trim().toLowerCase(),
      list = rows.filter(
        ({ r, o }) =>
          ("all" === st.filter || r.source === st.filter || ("due" === st.filter && r.remaining > 0)) &&
          (!q || [invoiceNo(o.id), o.name, o.phone, lineSummary(o)].join(" ").toLowerCase().includes(q)),
      ),
      wdTotal = wd.reduce((s, e) => s + e.amount, 0),
      by = (m) => money(rep.by[m]?.net || 0),
      drawer = drawerNow();
    box.innerHTML =
      '<div class="cp-sum">' +
      "<div><small>فواتير اليوم</small><strong>" +
      rows.length +
      "</strong></div>" +
      '<div class="hl"><small>صافي المبيعات</small><strong>' +
      money(rep.netSales) +
      "</strong></div>" +
      (acc
        ? "<div><small>نقدًا</small><strong>" +
          by("نقدًا") +
          "</strong></div><div><small>شبكة</small><strong>" +
          by("شبكة") +
          "</strong></div><div><small>تحويل</small><strong>" +
          by("تحويل") +
          "</strong></div>"
        : "") +
      "<div><small>السحوبات النقدية</small><strong>" +
      money(wdTotal) +
      "</strong></div>" +
      (null !== drawer ? '<div class="hl"><small>المتوقع في الدرج الآن</small><strong>' + money(drawer) + "</strong></div>" : "") +
      '</div><div class="cp-filters"><input id="cpQ" type="search" placeholder="رقم الفاتورة، العميل، الجوال أو المنتج" value="' +
      h(st.q) +
      '">' +
      [
        ["all", "الكل"],
        ["sale", "بيع"],
        ["repair", "صيانة"],
        ["due", "عليها متبقي"],
      ]
        .map(([k, l]) => '<button type="button" data-cp-filter="' + k + '" aria-pressed="' + (st.filter === k) + '">' + l + "</button>")
        .join("") +
      '</div><div class="cp-list">' +
      (list
        .map(({ r, o }) => {
          const m = [...(methods.get(o.id) || [])].filter((x) => "غير محدد" !== x),
            ret = (o.returns || []).length;
          return (
            '<article class="cp-inv"><div class="cp-no">#' +
            h(invoiceNo(o.id)) +
            "<small>" +
            h(timeFmt.format(new Date(r.date))) +
            '</small></div><div class="cp-who"><b>' +
            h(walkIn(o.phone) && !o.name ? "عميل نقدي" : o.name || "عميل نقدي") +
            '<span class="cp-tag ' +
            r.source +
            '">' +
            ("sale" === r.source ? "بيع" : "صيانة") +
            "</span>" +
            (ret ? '<span class="cp-tag ret">مرتجع</span>' : "") +
            (r.remaining > 0 ? '<span class="cp-tag due">متبقي ' + money(r.remaining) + "</span>" : "") +
            "</b><small>" +
            h(lineSummary(o)) +
            (walkIn(o.phone) ? "" : " · " + h(o.phone)) +
            '</small></div><div class="cp-amt"><b>' +
            money(r.current) +
            "</b><small>" +
            h(m.join(" + ") || (r.remaining > 0 ? "آجل" : "—")) +
            '</small></div><div class="cp-act"><button type="button" data-cp-print="' +
            o.id +
            '">طباعة</button><button type="button" data-cp-open="' +
            o.id +
            '">عرض</button></div></article>'
          );
        })
        .join("") ||
        '<p class="wh-empty">' +
          (rows.length ? "لا توجد فواتير بهذا البحث." : "لا توجد فواتير اليوم بعد. أول بيع بيظهر هنا مباشرة.") +
          "</p>") +
      "</div>" +
      (wd.length
        ? '<div class="cp-wd"><h3>سحوبات اليوم</h3>' +
          wd
            .map(
              (e) =>
                '<div class="cp-wd-row"><span>' +
                h(timeFmt.format(new Date(e.recordedAt || e.date))) +
                " · " +
                h(e.category.replace(WD + ": ", "")) +
                (e.note ? " — " + h(e.note) : "") +
                "</span><b>" +
                money(e.amount) +
                "</b></div>",
            )
            .join("") +
          "</div>"
        : "");
    const qi = $("cpQ");
    qi &&
      (qi.oninput = () => {
        st.q = qi.value;
        const pos = qi.selectionStart;
        renderToday();
        const n = $("cpQ");
        n && (n.focus(), n.setSelectionRange(pos, pos));
      });
  }

  function count() {
    const c = $("cpTodayCount");
    if (!c) return;
    try {
      const d = today();
      c.textContent = PC.financialReport(db, d, d).orders.length;
    } catch (e) {}
  }

  function setMode(m) {
    const v = $("posView");
    if (!v) return;
    st.mode = m;
    v.dataset.cpMode = m;
    v.querySelectorAll("[data-cp-mode]").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.cpMode === m)));
    "today" === m && renderToday();
  }

  function ensure() {
    const v = $("posView");
    if (!v || !v.dataset.ready) return;
    const qt = v.querySelector(":scope>.quick-workspace-tabs"),
      existing = v.querySelector(":scope>.cp-bar");
    existing && qt && existing.previousElementSibling !== qt && qt.after(existing);
    if (!existing) {
      const bar = document.createElement("div");
      bar.className = "cp-bar";
      bar.innerHTML =
        '<div class="cp-modes" role="group" aria-label="الكاشير"><button type="button" data-cp-mode="sale" aria-pressed="true">البيع</button><button type="button" data-cp-mode="today" aria-pressed="false">فواتير اليوم <b id="cpTodayCount">0</b></button></div><button type="button" class="cp-withdraw" data-cp-withdraw>− سحب نقدي</button>';
      qt ? qt.after(bar) : v.prepend(bar);
      const panel = document.createElement("section");
      panel.id = "cpToday";
      panel.className = "panel";
      v.append(panel);
      v.addEventListener("click", async (e) => {
        const t = e.target.closest("[data-cp-mode],[data-cp-withdraw],[data-cp-filter],[data-cp-print],[data-cp-open]");
        if (!t || !v.contains(t)) return;
        try {
          if (t.dataset.cpMode) return setMode(t.dataset.cpMode);
          if (void 0 !== t.dataset.cpWithdraw) return openWithdraw();
          if (t.dataset.cpFilter) return ((st.filter = t.dataset.cpFilter), renderToday());
          const o = db.orders.find((x) => x.id === +(t.dataset.cpPrint || t.dataset.cpOpen));
          if (!o) return;
          if (t.dataset.cpPrint) {
            t.disabled = !0;
            try {
              await printOrder(o);
            } finally {
              t.disabled = !1;
            }
            return;
          }
          document.querySelectorAll("dialog[open]").forEach((d) => d.close());
          tab("invoices");
          Platform.showInvoice(o.id);
        } catch (x) {
          toast(x.message || "تعذر تنفيذ الطلب");
        }
      });
    }
    "today" === st.mode && "cpQ" === document.activeElement?.id ? count() : (setMode(st.mode), count());
  }

  /* ---------- السحب النقدي ---------- */
  const dlg = document.createElement("dialog");
  dlg.id = "cpWithdrawDialog";
  dlg.className = "cp-dialog";
  (document.body || document.documentElement).append(dlg);

  function voucherHtml(e) {
    const w = "58" === String(db.settings.paper) ? 58 : 80;
    return (
      '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>سند سحب نقدي</title><style>@page{size:' +
      w +
      "mm 110mm;margin:2mm}*{box-sizing:border-box}body{margin:0;width:" +
      (w - 4) +
      "mm;font-family:Tahoma,Arial,sans-serif;font-size:" +
      (58 === w ? 10 : 11.5) +
      "px;color:#000;line-height:1.5}h1{font-size:1.3em;text-align:center;margin:1mm 0}.c{text-align:center}.big{font-size:1.9em;font-weight:bold;text-align:center;margin:2mm 0;border:1px solid #000;padding:1.5mm}table{width:100%;border-collapse:collapse}td{padding:1mm 0;border-bottom:1px dashed #777;vertical-align:top}td:last-child{text-align:left}.sig{margin-top:7mm;display:flex;justify-content:space-between;gap:4mm}.sig span{flex:1;border-top:1px solid #000;padding-top:1mm;text-align:center;font-size:.9em}</style></head><body><h1>" +
      h(db.settings.shop) +
      '</h1><div class="c"><b>سند سحب نقدي من الدرج</b></div><div class="big">' +
      money(e.amount) +
      "</div><table><tr><td>النوع</td><td>" +
      h(e.category.replace(WD + ": ", "")) +
      "</td></tr><tr><td>السبب</td><td>" +
      h(e.note || "—") +
      "</td></tr><tr><td>التاريخ</td><td>" +
      h(StoreFormat.format(new Date(e.recordedAt))) +
      "</td></tr><tr><td>الموظف</td><td>" +
      h(currentStaffLabel()) +
      '</td></tr></table><div class="sig"><span>توقيع المستلم</span><span>توقيع الموظف</span></div></body></html>'
    );
  }

  function openWithdraw() {
    if (!can("expenses")) return toast("السحب النقدي يحتاج صلاحية المصروفات لهذا الحساب");
    const drawer = drawerNow();
    dlg.innerHTML =
      '<form method="dialog" class="panel"><div class="dialoghead"><div><h2>سحب نقدي من الدرج</h2><p class="note">يُسجَّل كحركة صادرة من الكاش ويظهر في إقفال اليوم وفواتير اليوم.</p></div><button type="button" data-cp-close>إغلاق</button></div>' +
      (null !== drawer ? '<p class="cp-drawer">المتوقع في الدرج الآن: <b>' + money(drawer) + "</b></p>" : "") +
      '<label class="cp-amount">المبلغ (ر.س)<input id="cpAmt" inputmode="decimal" autocomplete="off" required placeholder="0.00"></label><div class="cp-reasons" role="radiogroup" aria-label="نوع السحب">' +
      REASONS.map(
        ([k, l], i) => '<label><input type="radio" name="cpKind" value="' + k + '"' + (0 === i ? " checked" : "") + ">" + l + "</label>",
      ).join("") +
      '</div><label>السبب<input id="cpWhy" maxlength="300" required placeholder="مثال: مندوب سمسا — توصيل قطع شاشات"></label><label>المستلم (اختياري)<input id="cpWho" maxlength="100" placeholder="اسم المندوب أو الشخص"></label><label class="check" style="display:flex;flex-direction:row;align-items:center;gap:8px"><input type="checkbox" id="cpPrint"> اطبع سند السحب</label><p class="error" id="cpErr" role="alert"></p><div class="footer"><button type="submit" class="primary" id="cpSave">تسجيل السحب</button><button type="button" data-cp-close>رجوع</button></div></form>';
    dlg.querySelectorAll("[data-cp-close]").forEach((b) => (b.onclick = () => dlg.close()));
    dlg.querySelector("form").onsubmit = async (ev) => {
      ev.preventDefault();
      const err = $("cpErr"),
        btn = $("cpSave");
      err.textContent = "";
      try {
        let amount;
        try {
          amount = Ledger.parseMoney($("cpAmt").value.trim());
        } catch (x) {
          throw Error("اكتب مبلغ صحيح");
        }
        if (!Number.isSafeInteger(amount) || amount <= 0) throw Error("اكتب مبلغ أكبر من صفر");
        const why = $("cpWhy").value.replace(/\s+/g, " ").trim(),
          who = $("cpWho").value.replace(/\s+/g, " ").trim(),
          kind = REASONS.find(([k]) => k === dlg.querySelector("[name=cpKind]:checked")?.value) || REASONS[3];
        if (!why) throw Error("اكتب سبب السحب");
        const now = drawerNow();
        if (null !== now && amount > now && !(await askConfirm("المبلغ أكبر من المتوقع في الدرج (" + money(now) + "). تسجله؟"))) return;
        btn.disabled = !0;
        const next = copy(),
          rec = {
            id: IdFactory.uuid(),
            date: Ledger.dayToISO(today()),
            recordedAt: new Date().toISOString(),
            category: kind[2],
            amount,
            method: "نقدًا",
            note: (why + (who ? " · المستلم: " + who : "")).slice(0, 1e3),
            profitTreatment: "operating",
          };
        next.inventory.expenses = (Array.isArray(next.inventory.expenses) ? next.inventory.expenses : []).concat([rec]);
        if (!(await commitTransaction(next, { reason: "سحب نقدي" }))) return;
        const pr = $("cpPrint").checked;
        dlg.close();
        toast("تم تسجيل سحب " + money(amount));
        pr && Promise.resolve(window.PrintService ? window.PrintService.send(voucherHtml(rec), db.settings.printerInvoice) : browserPrint(voucherHtml(rec))).catch((x) => toast(x.message || "تعذرت الطباعة"));
        st.mode = "today";
        ensure();
      } catch (x) {
        err.textContent = x.message;
      } finally {
        btn.disabled = !1;
      }
    };
    dlg.showModal();
    setTimeout(() => $("cpAmt")?.focus(), 50);
  }

  /* ---------- الربط ---------- */
  const prevTab = window.tab;
  window.tab = function (id) {
    const r = prevTab.apply(this, arguments);
    "pos" === id && setTimeout(ensure, 0);
    return r;
  };
  for (const ev of ["store:committed", "store:synced", "ledger:refresh"])
    window.addEventListener(ev, () => {
      const v = $("posView");
      if (!v || v.hidden) return;
      ensure();
    });
  window.CashierPlus = { open: (m) => (tab("pos"), setTimeout(() => setMode(m || "today"), 0)), withdraw: openWithdraw, withdrawalsOn, isWithdrawal: isWd };
})();
