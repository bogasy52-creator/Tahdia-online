/*! Alabqari Store 18.11.0 | App code rights reserved for the project owner. */
/*! العبقري ستور — ترتيب نموذج طلب الصيانة: العميل ← الأجهزة والقطع ← الدفع. */
(function () {
  "use strict";
  const form = document.getElementById("orderForm");
  if (!form) return;

  const heading = (text, cls) => {
    const el = document.createElement("div");
    el.className = "rl-step " + (cls || "");
    el.textContent = text;
    return el;
  };
  const labelOf = (id) => document.getElementById(id)?.closest("label");

  function arrange() {
    if (form.querySelector(".rl-pay")) return;
    const lookup = form.querySelector(".customer-lookup");
    const controls = form.querySelector(".repair-device-controls");
    const totals = document.getElementById("totals");
    const consent = document.getElementById("consent")?.closest("label");
    if (!lookup || !controls || !totals) return;

    lookup.before(heading("١ · العميل", "rl-customer"));
    controls.before(heading("٢ · الأجهزة والقطع", "rl-devices"));

    // number of devices sits next to "add device"
    const count = labelOf("count");
    count && (count.classList.add("rl-count"), controls.append(count));

    // payment moves to the end, right above the totals
    const pay = document.createElement("div");
    pay.className = "rl-pay";
    pay.append(heading("٣ · الدفع والإجمالي", "rl-payment"));
    const grid = document.createElement("div");
    grid.className = "grid";
    [labelOf("repairPayMethod"), labelOf("paid")].forEach((l) => l && grid.append(l));
    pay.append(grid);
    totals.before(pay);
    pay.append(totals);
    consent && pay.after(consent);
  }

  // phone shown the way people type it: 05xxxxxxxx
  function localPhone() {
    const el = document.getElementById("phone");
    if (el && /^9665\d{8}$/.test(el.value)) el.value = "0" + el.value.slice(3);
  }

  // inside each device: model & price → parts → problem → status
  function openParts() {
    form.querySelectorAll("#deviceFields .device").forEach((card) => {
      const parts = card.querySelector(".parts-box");
      parts && !parts.dataset.rlOpened && ((parts.dataset.rlOpened = "1"), (parts.open = true));
    });
  }

  arrange();
  new MutationObserver(() => {
    arrange();
    openParts();
  }).observe(form, { childList: true, subtree: true });

  const editor = document.getElementById("editor");
  if (editor) {
    const show = editor.showModal.bind(editor);
    editor.showModal = function () {
      const r = show();
      setTimeout(() => (arrange(), openParts(), localPhone()), 0);
      return r;
    };
    editor.addEventListener("click", (e) => {
      e.target.closest("[data-customer-pick], .customer-search-results button, [role=option]") && setTimeout(localPhone, 0);
    });
  }
  form.addEventListener("focusout", (e) => e.target.id === "phone" && localPhone());
})();
