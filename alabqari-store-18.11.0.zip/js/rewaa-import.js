/*! Alabqari Store 18.11.0 | App code rights reserved for the project owner. */
/*! العبقري ستور — استيراد بيانات رواء وأرشيف فواتيرها. */
(function () {
  "use strict";
  const h = (v) => esc(String(v ?? ""));
  const norm = (v) =>
    String(v ?? "")
      .replace(/[٠-٩]/g, (d) => "٠١٢٣٤٥٦٧٨٩".indexOf(d))
      .replace(/[أإآ]/g, "ا")
      .replace(/ة/g, "ه")
      .replace(/ى/g, "ي")
      .replace(/ـ/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
  const nowIso = () => new Date().toISOString();
  const uuid = () => (window.IdFactory ? IdFactory.uuid() : crypto.randomUUID());

  /* ---------------- local archive (IndexedDB, this device only) ---------------- */
  const DB_NAME = "alabqari-rewaa-archive",
    STORE = "sales";
  function openArchive() {
    return new Promise((resolve, reject) => {
      const r = indexedDB.open(DB_NAME, 1);
      r.onupgradeneeded = () => {
        const d = r.result;
        d.objectStoreNames.contains(STORE) || d.createObjectStore(STORE, { keyPath: "no" });
        d.objectStoreNames.contains("meta") || d.createObjectStore("meta", { keyPath: "key" });
      };
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error || Error("تعذر فتح أرشيف رواء على هذا الجهاز"));
    });
  }
  async function saveArchive(sales, info) {
    const d = await openArchive();
    await new Promise((resolve, reject) => {
      const tx = d.transaction([STORE, "meta"], "readwrite");
      const st = tx.objectStore(STORE);
      st.clear();
      for (const s of sales) st.put(s);
      tx.objectStore("meta").put({ key: "info", ...info, savedAt: nowIso(), count: sales.length });
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error || Error("تعذر حفظ أرشيف رواء"));
      tx.onabort = () => reject(tx.error || Error("تعذر حفظ أرشيف رواء؛ قد تكون مساحة الجهاز ممتلئة"));
    });
    d.close();
  }
  async function loadArchive() {
    const d = await openArchive();
    const out = await new Promise((resolve, reject) => {
      const tx = d.transaction([STORE, "meta"], "readonly");
      const all = tx.objectStore(STORE).getAll();
      const meta = tx.objectStore("meta").get("info");
      tx.oncomplete = () => resolve({ sales: all.result || [], info: meta.result || null });
      tx.onerror = () => reject(tx.error);
    });
    d.close();
    out.sales.sort((a, b) => String(b.date).localeCompare(String(a.date)));
    return out;
  }
  async function archiveCount() {
    try {
      const d = await openArchive();
      const n = await new Promise((resolve) => {
        const r = d.transaction(STORE, "readonly").objectStore(STORE).count();
        r.onsuccess = () => resolve(r.result || 0);
        r.onerror = () => resolve(0);
      });
      d.close();
      return n;
    } catch (e) {
      return 0;
    }
  }

  /* ---------------- reading and planning ---------------- */
  function validateFile(data) {
    if (!data || data.format !== "alabqari-rewaa-import" || data.version !== 1)
      throw Error("هذا ليس ملف استيراد رواء. اختر الملف rewaa-import.json");
    for (const k of ["items", "customers", "sales"]) if (!Array.isArray(data[k])) throw Error("ملف رواء ناقص: " + k);
    for (const it of data.items) {
      if (!it || typeof it.name !== "string" || !it.name.trim()) throw Error("صنف بدون اسم في ملف رواء");
      for (const k of ["cost", "price", "stock"])
        if (!Number.isSafeInteger(it[k]) || it[k] < 0) throw Error("قيمة غير صالحة في الصنف " + it.name);
    }
    return data;
  }

  function itemIndex(items) {
    const bySku = new Map(),
      byName = new Map();
    for (const it of items) {
      if (it.active === false) continue;
      for (const code of [it.sku, it.barcode, ...(it.alternateBarcodes || [])]) {
        const c = norm(code);
        c && !bySku.has(c) && bySku.set(c, it);
      }
      const n = norm(it.name);
      n && !byName.has(n) && byName.set(n, it);
    }
    return { bySku, byName };
  }

  const partKey = (category, model, grade) =>
    model ? [norm(category).replace(/ات$/, ""), norm(model), norm(grade)].join("|") : "";
  const keyOf = (it) => partKey(it.category, it.model || (it.models || [])[0], it.grade);

  function plan(data, state) {
    const items = state.inventory?.items || [];
    const idx = itemIndex(items);
    const res = { newItems: [], matched: [], merges: [], customersNew: [], customersKnown: [], skippedCustomers: [] };
    const seen = new Set();
    // every name Rewaa ever used → an existing item with one of these names came from an earlier import
    const rewaaNames = new Set(
      data.items.flatMap((i) => [i.name, ...(i.aliases || []), ...(i.supplierNames || [])]).map(norm),
    );
    const own = (it) => it.importedFrom !== "rewaa" && !rewaaNames.has(norm(it.name));
    // the shop's own parts by device + type, e.g. the built-in "شاشة iPhone XS DBX"
    const byKey = new Map();
    for (const it of items) {
      if (it.active === false || !own(it)) continue;
      const k = keyOf(it);
      k && (byKey.has(k) ? byKey.get(k).push(it) : byKey.set(k, [it]));
    }
    for (const it of data.items) {
      const match =
        [it.sku, it.barcode].map(norm).filter(Boolean).map((c) => idx.bySku.get(c)).find(Boolean) ||
        idx.byName.get(norm(it.name)) ||
        [...(it.aliases || []), ...(it.supplierNames || [])].map((n) => idx.byName.get(norm(n))).find(Boolean);
      const twins = it.section === "parts" ? (byKey.get(partKey(it.category, (it.models || [])[0], it.grade)) || []).filter((x) => x.id !== match?.id && !seen.has(x.id)) : [];
      const twin = twins.length === 1 ? twins[0] : null;
      if (match && seen.has(match.id)) continue;
      if (match && twin && !own(match)) {
        // an earlier import created a duplicate of the shop's own part: keep the shop's item, retire the copy
        seen.add(match.id);
        seen.add(twin.id);
        res.merges.push({ src: it, keep: twin, drop: match });
      } else if (match) {
        seen.add(match.id);
        res.matched.push({ src: it, item: match });
      } else if (twin) {
        seen.add(twin.id);
        res.matched.push({ src: it, item: twin, adopt: true });
      } else res.newItems.push(it);
    }
    // empty built-in placeholders: no price, no cost, no stock, never moved
    const moved = new Set((state.inventory?.moves || []).map((m) => m.itemId));
    const used = new Set((state.orders || []).flatMap((o) => (o.devices || []).flatMap((d) => (d.parts || []).map((x) => x.itemId))));
    res.placeholders = items.filter(
      (it) =>
        it.active !== false &&
        /^(SCR|BAT)-/.test(String(it.sku || it.id)) &&
        !seen.has(it.id) &&
        !it.price &&
        !it.cost &&
        !it.stock &&
        !moved.has(it.id) &&
        !used.has(it.id),
    );
    const dir = state.settings?.customerDirectory || {};
    for (const c of data.customers) {
      if (!/^9665\d{8}$/.test(c.phone) || c.phone === "966500000000") res.skippedCustomers.push(c);
      else (dir[c.phone] ? res.customersKnown : res.customersNew).push(c);
    }
    return res;
  }

  function buildItem(src, createdAt, codes) {
    const models = (src.models || []).filter((m) => typeof m === "string" && m.trim()).map((m) => m.slice(0, 200));
    let sku = String(src.sku || "").slice(0, 100);
    if (sku && codes.has(norm(sku))) sku = "";
    sku && codes.add(norm(sku));
    const it = {
      id: uuid(),
      name: src.name.slice(0, 500),
      section: src.section === "parts" ? "parts" : "products",
      sku,
      category: String(src.category || "").slice(0, 200),
      platform: ["iphone", "android"].includes(src.platform) ? src.platform : "",
      model: models[0] || "",
      grade: String(src.grade || "").slice(0, 100),
      stock: src.trackStock === false ? 0 : src.stock,
      min: Number.isSafeInteger(src.min) && src.min >= 0 ? src.min : 0,
      alertMode: "manual",
      cost: src.cost,
      price: src.price,
      supplier: String(src.supplier || "").slice(0, 200),
      trackStock: src.trackStock !== false,
      serialRequired: false,
      warrantyDays: Number.isSafeInteger(src.warrantyDays) && src.warrantyDays <= 3650 ? src.warrantyDays : 0,
      active: true,
      importedFrom: "rewaa",
      createdAt,
    };
    models.length > 1 && (it.models = models);
    src.barcode && !codes.has(norm(src.barcode)) && ((it.barcode = String(src.barcode).slice(0, 100)), codes.add(norm(src.barcode)));
    return it;
  }

  function apply(data, opts, p) {
    const next = copy();
    const inv = (next.inventory = next.inventory && typeof next.inventory === "object" ? next.inventory : {});
    inv.items = Array.isArray(inv.items) ? inv.items : [];
    inv.moves = Array.isArray(inv.moves) ? inv.moves : [];
    const at = nowIso();
    const codes = new Set(inv.items.flatMap((i) => [i.sku, i.barcode, ...(i.alternateBarcodes || [])]).map(norm).filter(Boolean));
    const move = (itemId, type, qty, reason) =>
      inv.moves.push({ id: uuid(), date: at, type, qty, itemId, reason });
    let added = 0,
      updated = 0,
      stockSet = 0,
      merged = 0,
      hidden = 0;
    if (opts.items) {
      const base = Date.parse(at) - p.newItems.length;
      p.newItems.forEach((src, idx) => {
        // keep Rewaa's own order: the first product created in Rewaa is the oldest here too
        const it = buildItem(src, new Date(base + idx).toISOString(), codes);
        inv.items.push(it);
        it.stock > 0 && move(it.id, "in", it.stock, "رصيد افتتاحي من رواء");
        added++;
      });
      const all = [...p.matched, ...(p.merges || []).map((m) => ({ src: m.src, item: m.keep, adopt: true, drop: m.drop }))];
      for (const { src, item, adopt, drop } of all) {
        const it = inv.items.find((x) => x.id === item.id);
        if (!it) continue;
        let changed = false;
        const set = (k, v) => {
          if (it[k] !== v) (it[k] = v), (changed = true);
        };
        adopt && set("importedFrom", "rewaa");
        if (drop) {
          // move the duplicate's stock and codes onto the shop's own item, then hide the duplicate
          const d = inv.items.find((x) => x.id === drop.id);
          if (d) {
            const dStock = d.trackStock === false ? 0 : Number(d.stock || 0);
            const target = (it.stock || 0) > 0 ? Math.max(it.stock || 0, dStock) : dStock;
            if (target !== (it.stock || 0)) {
              move(it.id, target > (it.stock || 0) ? "in" : "out", Math.abs(target - (it.stock || 0)), "دمج مع صنف رواء المكرر");
              it.stock = target;
              changed = true;
            }
            dStock > 0 && move(d.id, "out", dStock, "دُمج في: " + String(src.name).slice(0, 120));
            d.stock = 0;
            d.active = false;
            d.mergedInto = it.id;
            !it.barcode && d.sku && d.sku !== it.sku && (it.barcode = d.sku);
            merged++;
          }
        }
        if (adopt && !drop && !(it.stock > 0) && src.trackStock !== false && src.stock > 0 && it.trackStock !== false) {
          // the shop's built-in part had nothing on it yet: take Rewaa's quantity as its opening balance
          move(it.id, "in", src.stock, "رصيد افتتاحي من رواء");
          it.stock = src.stock;
          changed = true;
        }
        const fromRewaa = adopt || [src.name, ...(src.aliases || [])].map(norm).includes(norm(it.name));
        fromRewaa && it.name !== src.name && set("name", src.name.slice(0, 500));
        if (fromRewaa && opts.prices) {
          set("section", src.section === "parts" ? "parts" : "products");
          src.category && set("category", src.category.slice(0, 200));
          const models = (src.models || []).filter((m) => typeof m === "string" && m.trim()).map((m) => m.slice(0, 200));
          if (models.length) {
            set("model", models[0]);
            models.length > 1 ? JSON.stringify(it.models) !== JSON.stringify(models) && ((it.models = models), (changed = true)) : it.models && (delete it.models, (changed = true));
          }
          src.grade !== undefined && set("grade", String(src.grade || "").slice(0, 100));
          ["iphone", "android"].includes(src.platform) && set("platform", src.platform);
        }
        it.section !== "parts" && it.section !== "products" && set("section", src.section === "parts" ? "parts" : "products");
        !it.category && src.category && set("category", src.category.slice(0, 200));
        !it.sku && src.sku && !codes.has(norm(src.sku)) && (set("sku", src.sku), codes.add(norm(src.sku)));
        !it.barcode && src.barcode && !codes.has(norm(src.barcode)) && (set("barcode", src.barcode), codes.add(norm(src.barcode)));
        if (opts.prices) {
          src.price && set("price", src.price);
          src.cost && set("cost", src.cost);
        } else {
          !it.price && src.price && set("price", src.price);
          !it.cost && src.cost && set("cost", src.cost);
        }
        !it.warrantyDays && src.warrantyDays && set("warrantyDays", src.warrantyDays);
        if (opts.stock && it.trackStock !== false && src.trackStock !== false && src.stock !== it.stock) {
          const diff = src.stock - (it.stock || 0);
          move(it.id, diff > 0 ? "in" : "out", Math.abs(diff), "مطابقة الكمية مع رواء");
          it.stock = src.stock;
          changed = true;
          stockSet++;
        }
        changed && updated++;
      }
      if (opts.cleanup)
        for (const ph of p.placeholders || []) {
          const it = inv.items.find((x) => x.id === ph.id);
          if (!it || it.active === false) continue;
          it.active = false;
          it.hiddenBy = "rewaa-cleanup";
          hidden++;
        }
    }
    let customers = 0,
      removed = 0;
    if (opts.customers) {
      const dir = next.settings.customerDirectory || {};
      const rows = [];
      for (const c of [...p.customersNew, ...p.customersKnown]) {
        const old = dir[c.phone];
        let own = String(old?.note || "");
        const at0 = own.indexOf("من رواء");
        at0 >= 0 && (own = own.slice(0, at0).replace(/\s*·\s*$/, "").trim());
        const note = (own ? own + " · " + c.note : String(c.note || "")).slice(0, 1000);
        if (old && old.note === note) continue;
        rows.push({ phone: c.phone, name: (old?.name || c.name).slice(0, 200), note, consent: old ? old.consent === true : false, marketingOptOut: old?.marketingOptOut === true });
      }
      if (rows.length) {
        const merged = CustomerCore.merge(next, rows, at);
        next.settings.customerDirectory = merged.settings.customerDirectory;
      }
      customers = rows.length;
      // customers of the old sweets business that an earlier import added: clear the Rewaa note (balances, totals)
      const drop = new Set(data.removeCustomers || []);
      const directory = next.settings.customerDirectory || {};
      for (const ph of Object.keys(directory)) {
        const entry = directory[ph];
        const note = String(entry.note || "");
        const at1 = note.indexOf("من رواء");
        if (!drop.has(ph) || at1 < 0) continue;
        const own = note.slice(0, at1).replace(/\s*·\s*$/, "").trim();
        const cleaned = { ...entry, updated: at };
        own ? (cleaned.note = own) : delete cleaned.note;
        directory[ph] = cleaned;
        removed++;
      }
    }
    return { next, added, updated, stockSet, customers, removed, merged, hidden };
  }

  /* ---------------- data shipped inside the app (encrypted) ---------------- */
  const CODE_KEY = "alabqari-rewaa-code-v1",
    DONE_KEY = "alabqari-rewaa-done-v1";
  const lsGet = (k) => {
    try {
      return localStorage.getItem(k) || "";
    } catch (e) {
      return "";
    }
  };
  const lsSet = (k, v) => {
    try {
      localStorage.setItem(k, v);
    } catch (e) {}
  };
  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const el = document.createElement("script");
      el.src = src;
      el.onload = resolve;
      el.onerror = () => reject(Error("تعذر تحميل " + src + "؛ تأكد من الاتصال وأعد المحاولة"));
      document.head.append(el);
    });
  }
  async function sealed() {
    if (!window.REWAA_SEALED) {
      try {
        await loadScript("js/rewaa-data.js");
      } catch (e) {
        return null;
      }
    }
    return window.REWAA_SEALED || null;
  }
  const b64 = (t) => Uint8Array.from(atob(t), (c) => c.charCodeAt(0));
  async function gunzip(bytes) {
    if (typeof DecompressionStream === "function") {
      const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("gzip"));
      return new TextDecoder().decode(await new Response(stream).arrayBuffer());
    }
    window.pako || (await loadScript("js/vendor/pako_inflate.min.js"));
    return new TextDecoder().decode(window.pako.inflate(bytes));
  }
  async function unseal(code) {
    const box = await sealed();
    if (!box) throw Error("بيانات رواء غير موجودة في هذا الإصدار");
    if (!crypto?.subtle) throw Error("افتح البرنامج من رابط https لفتح البيانات");
    const clean = String(code || "")
      .trim()
      .toLowerCase();
    if (clean.length < 4) throw Error("اكتب كلمة سر البيانات");
    const base = await crypto.subtle.importKey("raw", new TextEncoder().encode(clean), "PBKDF2", false, ["deriveKey"]);
    const key = await crypto.subtle.deriveKey(
      { name: "PBKDF2", salt: b64(box.salt), iterations: box.iter, hash: "SHA-256" },
      base,
      { name: "AES-GCM", length: 256 },
      false,
      ["decrypt"],
    );
    let plain;
    try {
      plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: b64(box.iv) }, key, b64(box.data));
    } catch (e) {
      throw Error("كلمة سر البيانات غير صحيحة");
    }
    const data = validateFile(JSON.parse(await gunzip(new Uint8Array(plain))));
    lsSet(CODE_KEY, clean);
    return data;
  }
  function alreadyImported(box) {
    const skus = new Set((box?.checkSkus || []).map(norm));
    return (db.inventory?.items || []).some((i) => i.active !== false && skus.has(norm(i.sku)));
  }

  /* ---------------- import dialog ---------------- */
  const dlg = document.createElement("dialog");
  dlg.id = "rewaaImport";
  dlg.className = "rewaa-dialog";
  document.body.append(dlg);
  let loaded = null;

  async function open() {
    if (typeof can === "function" && !can("warehouseEdit")) return toast("استيراد رواء يحتاج صلاحية المستودع");
    loaded = null;
    const box = await sealed();
    const c = box?.counts || {};
    dlg.innerHTML =
      '<div class="panel"><div class="dialoghead"><div><h2>استيراد بيانات رواء</h2><p class="note">يضيف المنتجات وقطع الغيار والعملاء بدون حذف أي شيء موجود، وتقدر تعيد الاستيراد بأمان لأن المكرر يتجاوزه.</p></div><button type="button" data-rw-close>إغلاق</button></div>' +
      (box
        ? '<form class="rw-sealed" id="rwSealed"><p><b>بيانات رواء موجودة داخل البرنامج</b> · ' +
          (c.products || 0) +
          " منتج · " +
          (c.parts || 0) +
          " قطعة غيار · " +
          (c.customers || 0) +
          " عميل · " +
          (c.sales || 0) +
          ' فاتورة</p><label>كلمة سر البيانات<input id="rwCode" type="password" autocomplete="off" autocapitalize="none" spellcheck="false" placeholder="كلمة السر" value="' +
          h(lsGet(CODE_KEY)) +
          '"></label><button class="primary" type="submit">فتح البيانات</button><small class="note">البيانات مقفلة بكلمة سر لأن ملفات الموقع يقدر يفتحها أي شخص عنده الرابط حتى بدون تسجيل دخول.</small></form><details class="rw-or"><summary>أو اختر ملف rewaa-import.json</summary>'
        : "") +
      '<label class="rw-file"><input type="file" id="rwFile" accept=".json,application/json"><span>اختيار ملف رواء</span></label>' +
      (box ? "</details>" : "") +
      '<div id="rwBody"></div><p class="error" id="rwError" role="alert"></p></div>';
    dlg.querySelector("[data-rw-close]").onclick = () => dlg.close();
    const sf = dlg.querySelector("#rwSealed");
    sf &&
      (sf.onsubmit = async (e) => {
        e.preventDefault();
        const btn = sf.querySelector("button");
        dlg.querySelector("#rwError").textContent = "";
        btn.disabled = true;
        btn.textContent = "جاري الفتح…";
        try {
          loaded = await unseal(dlg.querySelector("#rwCode").value);
          sf.hidden = true;
          dlg.querySelector(".rw-or")?.setAttribute("hidden", "");
          renderPlan();
        } catch (err) {
          dlg.querySelector("#rwError").textContent = err.message;
        } finally {
          btn.disabled = false;
          btn.textContent = "فتح البيانات";
        }
      });
    dlg.querySelector("#rwFile").onchange = async (e) => {
      const f = e.target.files[0];
      dlg.querySelector("#rwError").textContent = "";
      if (!f) return;
      try {
        if (f.size > 25 * 1024 * 1024) throw Error("الملف أكبر من المسموح");
        loaded = validateFile(JSON.parse(await f.text()));
        renderPlan();
      } catch (err) {
        loaded = null;
        dlg.querySelector("#rwBody").innerHTML = "";
        dlg.querySelector("#rwError").textContent = err instanceof SyntaxError ? "الملف تالف أو ليس JSON" : err.message;
      }
    };
    dlg.showModal();
  }

  function renderPlan() {
    const p = plan(loaded, db);
    const s = loaded.summary || {};
    const prod = p.newItems.filter((i) => i.section !== "parts").length;
    const parts = p.newItems.length - prod;
    const stockUnits = p.newItems.reduce((t, i) => t + (i.trackStock === false ? 0 : i.stock), 0);
    dlg.querySelector("#rwBody").innerHTML =
      '<div class="rw-cards">' +
      [
        ["منتجات جديدة", prod],
        ["قطع غيار جديدة", parts],
        ["أصناف موجودة تتحدث", p.matched.length],
        ["قطع مكررة تندمج", (p.merges || []).length],
        ["قطع فاضية تنخفي", (p.placeholders || []).length],
        ["عملاء جدد", p.customersNew.length],
        ["عملاء موجودين", p.customersKnown.length],
        ["فواتير رواء للأرشيف", loaded.sales.length],
      ]
        .map(([k, v]) => "<div><small>" + k + "</small><strong>" + v + "</strong></div>")
        .join("") +
      "</div>" +
      '<p class="note">الكميات الافتتاحية للأصناف الجديدة: ' +
      stockUnits +
      " وحدة" +
      (s.firstSale ? " · فواتير من " + h(String(s.firstSale).slice(0, 10)) + " إلى " + h(String(s.lastSale).slice(0, 10)) : "") +
      (p.skippedCustomers.length ? " · " + p.skippedCustomers.length + " عميل رقمه غير سعودي أو غير صالح لن يضاف" : "") +
      "</p>" +
      '<div class="rw-options">' +
      '<label class="check"><input type="checkbox" id="rwItems" checked> إضافة المنتجات وقطع الغيار</label>' +
      '<label class="check"><input type="checkbox" id="rwPrices" checked> تحديث أسعار وتكلفة الأصناف الموجودة من رواء</label>' +
      '<label class="check"><input type="checkbox" id="rwStock"> استبدال كميات الأصناف الموجودة بكميات رواء (يسجل حركة مخزون)</label>' +
      ((p.placeholders || []).length
        ? '<label class="check"><input type="checkbox" id="rwCleanup" checked> إخفاء ' +
          p.placeholders.length +
          " قطعة فاضية من القائمة التلقائية القديمة (بدون سعر ولا كمية ولا استخدام). ترجعها من «أدوات المستودع» متى ما تبي</label>"
        : "") +
      '<label class="check"><input type="checkbox" id="rwCustomers" checked> إضافة العملاء (مع مشترياتهم ورصيدهم في رواء كملاحظة)</label>' +
      '<label class="check"><input type="checkbox" id="rwSales" checked> حفظ فواتير رواء القديمة كأرشيف للبحث على هذا الجهاز (لا تدخل في الحسابات اليومية)</label>' +
      "</div>" +
      (p.matched.length
        ? '<details class="rw-matched"><summary>الأصناف الموجودة عندك والمطابقة لرواء (' +
          p.matched.length +
          ")</summary><ul>" +
          p.matched
            .slice(0, 80)
            .map((m) => "<li>" + h(m.item.name) + " ⇐ " + h(m.src.name) + "</li>")
            .join("") +
          "</ul></details>"
        : "") +
      '<div class="footer"><button type="button" data-rw-close2>إلغاء</button><button type="button" class="primary" id="rwGo">بدء الاستيراد</button></div>';
    dlg.querySelector("[data-rw-close2]").onclick = () => dlg.close();
    dlg.querySelector("#rwGo").onclick = go;
  }

  async function go() {
    const btn = dlg.querySelector("#rwGo");
    const err = dlg.querySelector("#rwError");
    err.textContent = "";
    const opts = {
      items: dlg.querySelector("#rwItems").checked,
      prices: dlg.querySelector("#rwPrices").checked,
      stock: dlg.querySelector("#rwStock").checked,
      cleanup: !!dlg.querySelector("#rwCleanup")?.checked,
      customers: dlg.querySelector("#rwCustomers").checked,
      sales: dlg.querySelector("#rwSales").checked,
    };
    btn.disabled = true;
    btn.textContent = "جاري الاستيراد…";
    try {
      const p = plan(loaded, db);
      const r = apply(loaded, opts, p);
      const msg = [];
      if (r.added || r.updated || r.customers || r.removed || r.merged || r.hidden) {
        const ok = await commitTransaction(r.next, { reason: "استيراد بيانات رواء" });
        if (ok === false) throw Error("لم يتم الحفظ. راجع الرسالة الظاهرة ثم حاول مرة ثانية.");
        r.added && msg.push("أضيف " + r.added + " صنف");
        r.updated && msg.push("تحدّث " + r.updated + " صنف");
        r.stockSet && msg.push("طوبقت كمية " + r.stockSet + " صنف");
        r.merged && msg.push("دُمج " + r.merged + " صنف مكرر");
        r.hidden && msg.push("أُخفيت " + r.hidden + " قطعة فاضية بدون سعر ولا كمية");
        r.customers && msg.push("أضيف أو تحدّث " + r.customers + " عميل");
        r.removed && msg.push("صُفّرت بيانات " + r.removed + " عميل من نشاط الحلويات");
      }
      if (opts.sales && loaded.sales.length) {
        await saveArchive(loaded.sales, { created: loaded.created, summary: loaded.summary || {} });
        msg.push("حُفظت " + loaded.sales.length + " فاتورة في أرشيف رواء");
      }
      dlg.querySelector("#rwBody").innerHTML =
        '<div class="rw-done"><h3>تم الاستيراد</h3><p>' +
        h(msg.join(" · ") || "لا يوجد جديد؛ البيانات مستوردة من قبل") +
        '</p><div class="footer"><button type="button" id="rwToParts">عرض قطع الغيار</button><button type="button" id="rwToArchive">فتح أرشيف فواتير رواء</button><button type="button" class="primary" id="rwToProducts">عرض المنتجات</button></div></div>';
      const goSection = (sec) => {
        dlg.close();
        tab("inventory");
        window.WarehouseHub?.section?.(sec);
      };
      dlg.querySelector("#rwToParts").onclick = () => goSection("parts");
      dlg.querySelector("#rwToProducts").onclick = () => goSection("products");
      dlg.querySelector("#rwToArchive").onclick = () => {
        dlg.close();
        openArchiveView();
      };
      lsSet(DONE_KEY, loaded.created || nowIso());
      document.querySelectorAll(".rw-banner").forEach((b) => b.remove());
      window.dispatchEvent(new Event("rewaa:imported"));
    } catch (e) {
      err.textContent = e.message;
      btn.disabled = false;
      btn.textContent = "بدء الاستيراد";
    }
  }

  /* ---------------- archive viewer ---------------- */
  const av = document.createElement("dialog");
  av.id = "rewaaArchive";
  av.className = "rewaa-dialog rewaa-archive";
  document.body.append(av);
  const st = { all: [], q: "", month: "", kind: "", page: 0 };

  async function openArchiveView(query) {
    av.innerHTML = '<div class="panel"><p class="note">جاري فتح الأرشيف…</p></div>';
    av.open || av.showModal();
    await sealed();
    let data;
    try {
      data = await loadArchive();
    } catch (e) {
      av.innerHTML = '<div class="panel"><p class="error">' + h(e.message) + '</p><button type="button" data-av-close>إغلاق</button></div>';
      av.querySelector("[data-av-close]").onclick = () => av.close();
      return;
    }
    st.all = data.sales;
    st.q = query || "";
    st.page = 0;
    const months = [...new Set(st.all.map((s) => String(s.date).slice(0, 7)))].sort().reverse();
    av.innerHTML =
      '<div class="panel"><div class="dialoghead"><div><h2>أرشيف فواتير رواء</h2><p class="note">فواتير رواء القديمة للبحث والمراجعة فقط، محفوظة على هذا الجهاز ولا تدخل في الإقفال أو الحسابات.</p></div><button type="button" data-av-close>إغلاق</button></div>' +
      (st.all.length
        ? '<div class="av-filters"><input id="avQ" placeholder="رقم الفاتورة، العميل، الجوال أو المنتج" value="' +
          h(st.q) +
          '"><select id="avMonth"><option value="">كل الشهور</option>' +
          months.map((m) => '<option value="' + m + '">' + m + "</option>").join("") +
          '</select><select id="avKind"><option value="">مبيعات ومرتجعات</option><option value="sale">مبيعات فقط</option><option value="return">مرتجعات فقط</option></select></div><div id="avSum" class="av-sum"></div><div id="avRows"></div><div class="av-pages"><button type="button" id="avPrev">السابق</button><span id="avPage"></span><button type="button" id="avNext">التالي</button></div>'
        : '<div class="wh-empty"><p>الأرشيف فاضي على هذا الجهاز.</p>' +
          (window.REWAA_SEALED
            ? '<form id="avLoad" class="rw-sealed"><label>كلمة سر البيانات<input id="avCode" type="password" autocomplete="off" autocapitalize="none" placeholder="كلمة السر" value="' +
              h(lsGet(CODE_KEY)) +
              '"></label><button class="primary" type="submit">تحميل فواتير رواء على هذا الجهاز</button><p class="error" id="avErr"></p></form>'
            : "<p>افتح «استيراد بيانات رواء» من أدوات المستودع.</p>") +
          "</div>") +
      "</div>";
    av.querySelector("[data-av-close]").onclick = () => av.close();
    const loadForm = av.querySelector("#avLoad");
    loadForm &&
      (loadForm.onsubmit = async (e) => {
        e.preventDefault();
        try {
          const d = await unseal(av.querySelector("#avCode").value);
          await saveArchive(d.sales, { created: d.created, summary: d.summary || {} });
          openArchiveView(query);
        } catch (err) {
          av.querySelector("#avErr").textContent = err.message;
        }
      });
    if (!st.all.length) return;
    const rerender = () => {
      st.page = 0;
      renderArchive();
    };
    av.querySelector("#avQ").oninput = (e) => ((st.q = e.target.value), rerender());
    av.querySelector("#avMonth").onchange = (e) => ((st.month = e.target.value), rerender());
    av.querySelector("#avKind").onchange = (e) => ((st.kind = e.target.value), rerender());
    av.querySelector("#avPrev").onclick = () => (st.page--, renderArchive());
    av.querySelector("#avNext").onclick = () => (st.page++, renderArchive());
    st.month = "";
    st.kind = "";
    renderArchive();
  }

  function archiveFiltered() {
    const words = norm(st.q).split(" ").filter(Boolean);
    return st.all.filter((s) => {
      if (st.month && !String(s.date).startsWith(st.month)) return false;
      if (st.kind && s.kind !== st.kind) return false;
      if (!words.length) return true;
      const hay = norm([s.no, s.customer, s.phone, s.phone && "0" + String(s.phone).slice(3), ...s.lines.map((l) => l[0] + " " + l[1])].join(" "));
      return words.every((w) => hay.includes(w));
    });
  }

  function renderArchive() {
    const list = archiveFiltered();
    const pages = Math.max(1, Math.ceil(list.length / 25));
    st.page = Math.max(0, Math.min(st.page, pages - 1));
    const sales = list.filter((s) => s.kind === "sale"),
      rets = list.filter((s) => s.kind === "return");
    const sum = (a) => a.reduce((t, s) => t + s.total, 0);
    const methods = {};
    for (const s of sales) for (const [m, v] of s.pays) methods[m] = (methods[m] || 0) + v;
    const top = new Map();
    for (const s of list)
      for (const l of s.lines) {
        const k = l[0] || l[1];
        const v = top.get(k) || { q: 0, t: 0 };
        const sign = s.kind === "return" ? -1 : 1;
        v.q += sign * l[2];
        v.t += sign * l[3];
        top.set(k, v);
      }
    const best = [...top.entries()]
      .filter(([k]) => k && !/^(صيانة الأجهزة|اشياء عامه)$/.test(k.trim()))
      .sort((a, b) => b[1].q - a[1].q)
      .slice(0, 5);
    av.querySelector("#avSum").innerHTML =
      "<div><small>عدد الفواتير</small><strong>" +
      sales.length +
      "</strong></div><div><small>إجمالي المبيعات</small><strong>" +
      money(sum(sales)) +
      "</strong></div><div><small>المرتجعات</small><strong>" +
      money(sum(rets)) +
      " (" +
      rets.length +
      ")</strong></div><div><small>الصافي</small><strong>" +
      money(sum(sales) - sum(rets)) +
      "</strong></div>" +
      (Object.keys(methods).length
        ? '<p class="note av-methods">' +
          Object.entries(methods)
            .sort((a, b) => b[1] - a[1])
            .map(([m, v]) => h(m) + ": " + money(v))
            .join(" · ") +
          "</p>"
        : "") +
      (best.length
        ? '<p class="note av-methods"><b>الأكثر مبيعًا:</b> ' +
          best.map(([k, v]) => h(k) + " (" + Math.round(v.q) + ")").join(" · ") +
          "</p>"
        : "");
    av.querySelector("#avRows").innerHTML =
      list
        .slice(st.page * 25, st.page * 25 + 25)
        .map(
          (s) =>
            '<details class="av-row' +
            (s.kind === "return" ? " is-return" : "") +
            '"><summary><span class="av-no"><bdi>' +
            h(s.no) +
            "</bdi>" +
            (s.kind === "return" ? ' <em>مرتجع</em>' : "") +
            "</span><span>" +
            h(StoreFormat.format(s.date)) +
            "</span><span>" +
            h(s.customer || "عميل نقدي") +
            "</span><b>" +
            money(s.total) +
            '</b></summary><table class="av-lines"><thead><tr><th>الصنف</th><th>الكمية</th><th>الإجمالي</th></tr></thead><tbody>' +
            s.lines.map((l) => "<tr><td>" + h(l[0]) + "</td><td>" + h(l[2]) + "</td><td>" + money(l[3]) + "</td></tr>").join("") +
            "</tbody></table><p class=\"note\">" +
            (s.discount ? "خصم " + money(s.discount) + " · " : "") +
            (s.vat ? "ضريبة " + money(s.vat) + " · " : "") +
            "الدفع: " +
            (s.pays.map((p) => h(p[0]) + " " + money(p[1])).join("، ") || "—") +
            (s.branch ? " · الفرع: " + h(s.branch) : "") +
            "</p></details>",
        )
        .join("") || '<p class="wh-empty">لا توجد فواتير مطابقة.</p>';
    av.querySelector("#avPage").textContent = st.page + 1 + " / " + pages;
    av.querySelector("#avPrev").disabled = st.page === 0;
    av.querySelector("#avNext").disabled = st.page >= pages - 1;
  }

  /* ---------------- entry points ---------------- */
  async function invoicesButton() {
    const view = document.getElementById("invoicesView");
    if (!view || view.hidden || view.querySelector("#rwArchiveOpen")) return;
    const n = await archiveCount();
    if (!n) return;
    const actions = view.querySelector(".pro-actions") || view.querySelector(".panel");
    if (!actions || view.querySelector("#rwArchiveOpen")) return;
    const b = document.createElement("button");
    b.type = "button";
    b.id = "rwArchiveOpen";
    b.textContent = "فواتير رواء القديمة (" + n + ")";
    b.onclick = () => openArchiveView(document.getElementById("piQ")?.value || "");
    actions.prepend(b);
  }
  function warehouseTools() {
    const menu = document.querySelector("#warehouseHub .wh-more > div");
    if (!menu || menu.querySelector("[data-rw-archive]")) return;
    const b = document.createElement("button");
    b.type = "button";
    b.dataset.rwArchive = "1";
    b.textContent = "أرشيف فواتير رواء";
    b.onclick = () => openArchiveView();
    const anchor = menu.querySelector('[data-wh-action="rewaa"]');
    anchor ? anchor.after(b) : menu.append(b);
    const back = document.createElement("button");
    back.type = "button";
    back.dataset.rwRestore = "1";
    back.textContent = "إرجاع القطع المخفية";
    back.onclick = restoreHidden;
    b.after(back);
  }
  async function banner(where) {
    if (typeof can === "function" && !can("warehouseEdit")) return;
    const view = document.getElementById(where === "inventory" ? "warehouseHub" : where + "View");
    if (!view || view.querySelector(".rw-banner")) return;
    const box = await sealed();
    if (!box || view.querySelector(".rw-banner")) return;
    const imported = alreadyImported(box);
    if (imported && lsGet(DONE_KEY) === box.created) return;
    const c = box.counts || {};
    const el = document.createElement("div");
    el.className = "rw-banner";
    el.innerHTML =
      "<div><b>" +
      (imported ? "تحديث بيانات رواء جاهز (أسعار القطع وسعر البضاعة)" : "بيانات رواء جاهزة داخل البرنامج") +
      "</b><span>" +
      (c.products || 0) +
      " منتج · " +
      (c.parts || 0) +
      " قطعة غيار · " +
      (c.customers || 0) +
      " عميل · " +
      (c.sales || 0) +
      ' فاتورة قديمة</span></div><button type="button" class="primary">' +
      (imported ? "تحديث الآن" : "استيراد الآن") +
      "</button>";
    el.querySelector("button").onclick = open;
    view.prepend(el);
  }
  async function restoreHidden() {
    const list = (db.inventory?.items || []).filter((i) => i.hiddenBy === "rewaa-cleanup" && i.active === false);
    if (!list.length) return toast("ما فيه قطع مخفية");
    if (typeof askConfirm === "function" && !(await askConfirm("إرجاع " + list.length + " قطعة مخفية للقائمة؟"))) return;
    const next = copy();
    for (const it of next.inventory.items) if (it.hiddenBy === "rewaa-cleanup" && it.active === false) (it.active = true), delete it.hiddenBy;
    const ok = await commitTransaction(next, { reason: "إرجاع القطع المخفية" });
    ok !== false && toast("رجعت " + list.length + " قطعة");
  }
  const prevTab = window.tab;
  window.tab = function (t) {
    prevTab.apply(this, arguments);
    "invoices" === t && setTimeout(invoicesButton, 0);
    "inventory" === t && setTimeout(() => (warehouseTools(), banner("inventory")), 0);
    "customers" === t && setTimeout(() => banner("customers"), 0);
    "dashboard" === t && setTimeout(() => banner("dashboard"), 0);
  };
  window.addEventListener("inventory:rendered", () => setTimeout(warehouseTools, 0));

  window.RewaaImport = { open, plan, apply, validateFile, unseal };
  window.RewaaArchive = { open: openArchiveView, load: loadArchive, count: archiveCount };
})();
