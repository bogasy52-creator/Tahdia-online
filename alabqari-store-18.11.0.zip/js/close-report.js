/*! Alabqari Store 18.11.0 | App code rights reserved for the project owner. */
/*! العبقري ستور — تقرير إقفال مختصر على مقاس الفاتورة + فتح اليوم المقفل بضغطة */
!(function () {
  "use strict";
  const h = (s) => esc(String(s ?? "")),
    PC = PlatformCore,
    WD = "سحب نقدي",
    num = (v) =>
      (v < 0 ? "−" : "") +
      (Math.abs(v || 0) / 100).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
    dayName = (d) => {
      try {
        return new Intl.DateTimeFormat("ar-SA-u-nu-latn", { timeZone: "Asia/Riyadh", weekday: "long" }).format(new Date(d + "T12:00:00+03:00"));
      } catch (e) {
        return "";
      }
    },
    closings = () => db.settings?.platform?.dayClosings || [];

  const CSS =
    "*{box-sizing:border-box}body{margin:0;font-family:Tahoma,Arial,sans-serif;color:#000;line-height:1.45}h1{font-size:1.35em;text-align:center;margin:0 0 .5mm}.c{text-align:center}.m{text-align:center;font-size:.88em}h2{font-size:1em;margin:2.2mm 0 .8mm;padding:.7mm 0;border-top:1.5px solid #000;border-bottom:1px solid #000;text-align:center}table{width:100%;border-collapse:collapse}td{padding:.5mm 0;vertical-align:top}td.n{text-align:left;direction:ltr;white-space:nowrap;font-variant-numeric:tabular-nums;padding-inline-start:2mm}tr.t td{font-weight:bold;border-top:1px dashed #000;padding-top:.9mm}tr.s td{font-size:.88em}.diff{margin:2mm 0 1mm;padding:1.4mm;border:1.5px solid #000;text-align:center;font-weight:bold;font-size:1.15em}.note{font-size:.9em;margin:1mm 0}.sig{margin-top:7mm;display:flex;gap:4mm}.sig span{flex:1;border-top:1px solid #000;padding-top:1mm;text-align:center;font-size:.85em}";

  const width = () => ("58" === String(db.settings?.paper) ? 58 : 80);

  function rows(list) {
    return (
      "<table>" +
      list
        .filter(Boolean)
        .map(([l, v, cls]) => '<tr class="' + (cls || "") + '"><td>' + l + '</td><td class="n">' + v + "</td></tr>")
        .join("") +
      "</table>"
    );
  }

  function body(rep, info) {
    const cash = rep.by?.["نقدًا"] || { received: 0, refunds: 0, net: 0 },
      methods = ["نقدًا", "شبكة", "تحويل", "غير محدد"].filter((m) => rep.by?.[m] && (rep.by[m].received || rep.by[m].refunds)),
      exp = Object.entries(rep.expensesBy || {}).filter(([, v]) => v),
      wd = exp.filter(([k]) => k.startsWith(WD)),
      other = exp.filter(([k]) => !k.startsWith(WD)),
      wdTotal = wd.reduce((s, [, v]) => s + v, 0),
      otherTotal = other.reduce((s, [, v]) => s + v, 0);
    let html =
      "<h1>" +
      h(db.settings.shop) +
      '</h1><div class="c"><b>' +
      h(info.title) +
      '</b></div><div class="m">' +
      h(dayName(rep.from)) +
      ' <bdi dir="ltr">' +
      h(rep.from) +
      "</bdi>" +
      (info.revision ? " · مراجعة " + info.revision : "") +
      "</div>" +
      '<div class="m">' +
      h(info.when) +
      (info.staff ? " · " + h(info.staff) : "") +
      '</div><div class="m">المبالغ بالريال السعودي</div>' +
      "<h2>المبيعات</h2>" +
      rows([
        ["فواتير بيع (" + (rep.posCount || 0) + ")", num(rep.saleGross)],
        ["صيانة مسلّمة (" + (rep.repairCount || 0) + ")", num(rep.repairGross)],
        rep.returnsValue ? ["المرتجعات", num(-rep.returnsValue)] : null,
        ["صافي المبيعات", num(rep.netSales), "t"],
        rep.remaining > 0 ? ["منها آجل غير محصل", num(rep.remaining), "s"] : null,
      ]) +
      "<h2>المقبوض حسب الطريقة</h2>" +
      rows(
        (methods.length ? methods : ["نقدًا"])
          .map((m) => [m + (rep.by[m]?.refunds ? " (بعد مردود " + num(rep.by[m].refunds) + ")" : ""), num(rep.by[m]?.net || 0)])
          .concat([["إجمالي المقبوض", num((rep.received || 0) - (rep.refunds || 0)), "t"]]),
      );
    (wd.length || other.length || rep.suppliers) &&
      (html +=
        "<h2>الصادر</h2>" +
        rows(
          []
            .concat(wd.map(([k, v]) => [h(k.replace(WD + ": ", "سحب: ")), num(v)]))
            .concat(other.map(([k, v]) => ["مصروف: " + h(k), num(v)]))
            .concat(rep.suppliers ? [["مدفوعات موردين", num(rep.suppliers)]] : [])
            .concat([["إجمالي الصادر", num(wdTotal + otherTotal + (rep.suppliers || 0)), "t"]]),
        ));
    html +=
      "<h2>الصندوق (الكاش)</h2>" +
      rows([
        null != info.opening ? ["الافتتاحي", num(info.opening)] : null,
        ["+ نقد مقبوض", num(cash.received)],
        cash.refunds ? ["− مردود نقدي", num(-cash.refunds)] : null,
        rep.expenseCash ? ["− مصروفات وسحب نقدي", num(-rep.expenseCash)] : null,
        rep.supplierCash ? ["− موردين نقدًا", num(-rep.supplierCash)] : null,
        null != info.opening ? ["= المتوقع في الدرج", num(info.opening + rep.cashNet), "t"] : ["صافي حركة الكاش", num(rep.cashNet), "t"],
        null != info.counted ? ["المعدود فعليًا", num(info.counted)] : null,
      ]);
    if (null != info.counted && null != info.opening) {
      const d = info.counted - (info.opening + rep.cashNet);
      html += '<div class="diff">' + (0 === d ? "الصندوق مطابق ✓" : (d > 0 ? "زيادة " : "عجز ") + num(Math.abs(d))) + "</div>";
    }
    info.note && (html += '<p class="note">ملاحظة: ' + h(info.note) + "</p>");
    rep.unknownOut && (html += '<p class="note">صادر بطريقة دفع غير محددة: ' + num(rep.unknownOut) + "</p>");
    html += '<div class="sig"><span>توقيع الموظف</span><span>توقيع المدير</span></div>';
    return html;
  }

  function measure(inner, w) {
    try {
      const host = document.createElement("div");
      host.style.cssText = "position:fixed;left:-10000px;top:0;visibility:hidden;pointer-events:none";
      const sh = host.attachShadow({ mode: "open" });
      sh.innerHTML =
        "<style>" + CSS.replace(/body\{/, ".b{") + '</style><div class="b" style="width:' + (w - 4) + "mm;font-size:" + (58 === w ? 10 : 11.5) + 'px">' + inner + "</div>";
      document.body.append(host);
      const px = sh.querySelector(".b").scrollHeight;
      host.remove();
      return Math.max(80, Math.ceil((px * 25.4) / 96) + 12);
    } catch (e) {
      return 260;
    }
  }

  function doc(inner, title) {
    const w = width(),
      hgt = measure(inner, w);
    return (
      '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>' +
      h(title) +
      "</title><style>@page{size:" +
      w +
      "mm " +
      hgt +
      "mm;margin:2mm}" +
      CSS +
      "body{width:" +
      (w - 4) +
      "mm;font-size:" +
      (58 === w ? 10 : 11.5) +
      "px}</style></head><body>" +
      inner +
      "</body></html>"
    );
  }

  function send(html) {
    return Promise.resolve(window.PrintService ? window.PrintService.send(html, db.settings.printerInvoice) : browserPrint(html)).catch((e) =>
      toast(e.message || "تعذرت الطباعة"),
    );
  }

  function printClosing(id) {
    const c = closings().find((x) => x.id === id);
    if (!c) return toast("الإقفال غير موجود");
    return send(
      doc(
        body(c.report, {
          title: "تقرير إقفال اليوم",
          revision: c.revision,
          when: "أُقفل " + StoreFormat.format(new Date(c.closedAt)),
          staff: c.staff,
          opening: c.opening,
          counted: c.counted,
          note: c.note,
        }),
        "إقفال " + c.day,
      ),
    );
  }

  function printLive(day) {
    const rep = PC.financialReport(db, day, day),
      val = (id) => {
        const v = document.getElementById(id)?.value.trim();
        if (!v) return null;
        try {
          return Ledger.parseMoney(v);
        } catch (e) {
          return null;
        }
      };
    return send(
      doc(
        body(rep, {
          title: "تقرير اليوم (قبل الإقفال)",
          when: "طُبع " + StoreFormat.format(new Date()),
          staff: currentStaffLabel(),
          opening: val("opsOpening"),
          counted: val("opsCounted"),
        }),
        "تقرير " + day,
      ),
    );
  }

  /* طباعة الإقفالات من السجل بالنسخة المختصرة */
  document.addEventListener(
    "click",
    (e) => {
      const b = e.target.closest?.("[data-day-print]");
      if (!b) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      printClosing(b.dataset.dayPrint);
    },
    !0,
  );

  /* أدوات صفحة الإقفال */
  let queued = !1;
  function decorate() {
    queued = !1;
    const form = document.getElementById("opsCloseForm");
    if (!form || form.dataset.cr) return;
    form.dataset.cr = "1";
    const day = document.getElementById("opsCloseDay")?.value || PC.dayKey(new Date().toISOString()),
      last = closings()
        .filter((c) => c.day === day)
        .sort((a, b) => b.revision - a.revision)[0],
      tools = document.createElement("div");
    tools.className = "cr-tools";
    tools.innerHTML =
      '<button type="button" data-cr-live>🖨 طباعة تقرير اليوم (قبل الإقفال)</button>' +
      (last ? '<button type="button" data-cr-last>🖨 طباعة آخر إقفال</button>' : "");
    form.after(tools);
    const note = document.createElement("p");
    note.className = "cr-note";
    note.textContent =
      "بعد الإقفال يتوقف تسجيل أي بيع أو دفعة بتاريخ " +
      day +
      ". لو احتجت تكمل بيع بعده، البرنامج يعرض عليك «فتح اليوم» بضغطة وحدة، وتقفله مرة ثانية آخر الدوام.";
    tools.after(note);
    tools.querySelector("[data-cr-live]").onclick = () => printLive(day);
    last && (tools.querySelector("[data-cr-last]").onclick = () => printClosing(last.id));
  }
  new MutationObserver(() => {
    queued || ((queued = !0), requestAnimationFrame(decorate));
  }).observe(document.body, { childList: !0, subtree: !0 });

  /* بعد نجاح الإقفال: اعرض الطباعة. ولو اليوم مقفل وحاولت تبيع: اعرض فتحه */
  const LOCKED = /اليوم (\d{4}-\d{2}-\d{2}) مقفل/,
    CLOSED = /تم حفظ إقفال (\d{4}-\d{2}-\d{2})/;
  let busy = !1,
    last = "";
  const orig = window.toast;
  if ("function" == typeof orig)
    window.toast = function (msg) {
      const r = orig.apply(this, arguments),
        s = String(msg ?? "");
      try {
        const m = LOCKED.exec(s),
          c = CLOSED.exec(s);
        m && setTimeout(() => offerReopen(m[1]), 60);
        c && setTimeout(() => offerPrint(c[1]), 60);
      } catch (e) {}
      return r;
    };

  async function offerPrint(day) {
    if (busy) return;
    const c = closings()
      .filter((x) => x.day === day)
      .sort((a, b) => b.revision - a.revision)[0];
    if (!c) return;
    busy = !0;
    try {
      (await askConfirm("تم إقفال " + day + " ✓\nتطبع تقرير الإقفال على طابعة الفواتير؟")) && (await printClosing(c.id));
    } finally {
      busy = !1;
    }
  }

  async function offerReopen(day) {
    if (busy || last === day + Math.floor(Date.now() / 3e3)) return;
    last = day + Math.floor(Date.now() / 3e3);
    if ("function" != typeof can || !can("reopenDay")) return;
    let lock;
    try {
      lock = ProfessionalCore.dayStatus(db, day);
    } catch (e) {
      return;
    }
    if (!lock || "locked" !== lock.status) return;
    busy = !0;
    try {
      const when = lock.date ? " (أُقفل " + StoreFormat.format(new Date(lock.date)) + ")" : "";
      if (
        !(await askConfirm(
          "يوم " +
            day +
            " مقفل" +
            when +
            ".\nتبي تفتحه الحين وتكمل؟ الإقفال السابق يبقى محفوظ في السجل، وتقدر تقفل اليوم مرة ثانية آخر الدوام.",
        ))
      )
        return;
      const next = ProfessionalCore.setDayStatus(db, {
        day,
        status: "open",
        date: new Date().toISOString(),
        staff: currentStaffLabel(),
        reason: "متابعة البيع بعد الإقفال",
      });
      (await commitTransaction(next, { reason: "فتح اليوم بعد الإقفال" })) && orig("تم فتح يوم " + day + " — أعد المحاولة الحين");
    } catch (e) {
      orig(e.message || "تعذر فتح اليوم");
    } finally {
      busy = !1;
    }
  }

  /* عملية معلقة ما تقدر تتأكد (مثل إقفال انحفظ في السحابة من محاولة سابقة): تجاهلها بأمان بعد التأكيد */
  document.addEventListener("click", async (e) => {
    const b = e.target.closest?.("[data-drop-transaction]");
    if (!b) return;
    const id = b.dataset.dropTransaction;
    if (
      !(await askConfirm(
        "تجاهل هذه العملية المعلقة؟\nاستخدمها فقط إذا تأكدت أن العملية موجودة في السحابة أو إنك بتعيدها من جديد (مثل الإقفال: تقدر تقفل مرة ثانية).\nبيانات الجهاز ما تتغير، وبعدها تكمل المزامنة عادي.",
      ))
    )
      return;
    try {
      b.disabled = !0;
      await TransactionStore.remove(id);
      window.dispatchEvent(new Event("transactions:changed"));
      toast("تم تجاهل العملية المعلقة — جارٍ المزامنة");
      setTimeout(() => document.getElementById("syncNow")?.click(), 300);
    } catch (x) {
      b.disabled = !1;
      toast(x.message || "تعذر تجاهل العملية");
    }
  });

  window.CloseReport = { printClosing, printLive, html: (rep, info) => doc(body(rep, info || { title: "تقرير", when: "" }), "تقرير") };
})();
