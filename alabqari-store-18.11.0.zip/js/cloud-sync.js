/*! Alabqari Store 18.9.7 | App code rights reserved for the project owner. */
/*! العبقري ستور — حقوق تطوير هذه النسخة محفوظة لصاحب المشروع. */
!function() {
    "use strict";
    const t = "alabqari-cloud-config-v1", e = "alabqari-cloud-session-v1", a = window.ALABQARI_CLOUD;
    let n, r, s = a ? {
        ...a
    } : I(t), o = I(e), i = !1, c = "", l = !1, d = !1, u = !1;
    const p = StoreData, y = "undefined" != typeof newDevice && newDevice ? p.clean(db) : null;
    let w = null, h = null, b = !1, f = "";
    window.addEventListener("store:committed", () => {
        b = !0;
    });
    let m = null, g = "";
    const v = () => !0 === s?.backend, S = () => "alabqari-api" === s?.gateway, E = () => v() || S();
    let k = 0, _ = 0;
    function x(t) {
        if (!E() || !t) return;
        const e = !p.equal(m, t);
        m = t, e && window.dispatchEvent(new Event("store:profile"));
    }
    function I(t) {
        try {
            return JSON.parse(localStorage.getItem(t) || "null");
        } catch (t) {
            return null;
        }
    }
    const q = t => t ? t.url + "/" + t.shop + (t.backend ? "/server-v1" : "") : "", L = () => !(!s || db._sync?.base && p.equal(p.clean(db), db._sync.base)), D = () => !!document.querySelector('dialog[open]:not(#syncDialog):not([data-sync-safe="true"])') || d && !$("settingsView").hidden || !!document.querySelector('main>section:not([hidden]) [data-sync-draft="true"]');
    function C(t) {
        if (a && (!t || [ "url", "key", "shop", "backend", "gateway" ].some(e => t[e] !== a[e]))) throw Error("هذه النسخة مخصصة لمحل العبقري. لا يمكن تغيير محلها أو مسار خادمها.");
        if (!t || !/^https:\/\/[a-z0-9]{20}\.supabase\.co$/.test(t.url)) throw Error("أدخل رابط مشروع Supabase بصيغة https://…supabase.co");
        if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(t.shop)) throw Error("معرّف المحل يجب أن يكون UUID من ملف الإعداد");
        let e;
        try {
            e = JSON.parse(atob(t.key.split(".")[1].replace(/-/g, "+").replace(/_/g, "/"))).role;
        } catch (t) {}
        if (!/^sb_publishable_[A-Za-z0-9_-]+$/.test(t.key) && "anon" !== e) throw Error("استخدم Publishable key أو anon فقط. المفاتيح السرية مرفوضة.");
        return t;
    }
    async function T(t, e, a, n = "POST") {
        C(s);
        const r = new AbortController, o = setTimeout(() => r.abort(), t.startsWith("/api/offers/") ? 45e3 : 15e3);
        try {
            const o = {
                apikey: s.key,
                "Content-Type": "application/json"
            };
            a && (o.Authorization = "Bearer " + a);
            const i = E() && !t.startsWith("/auth/");
            i && (o["X-Alabqari-Shop"] = s.shop);
            const c = i && v() ? location.origin : i && S() ? s.url + "/functions/v1/" + s.gateway : s.url, l = await fetch(c + t, {
                method: n,
                headers: o,
                body: void 0 === e ? void 0 : JSON.stringify(e),
                signal: r.signal,
                cache: "no-store",
                credentials: "omit"
            }), d = await l.json().catch(() => ({}));
            if (!l.ok) {
                let t = "invalid_credentials" === d.error_code ? "البريد أو كلمة مرور حساب المزامنة غير صحيحين." : 401 === l.status ? "انتهت الجلسة أو بيانات الدخول غير صحيحة؛ سجّل الدخول مجددًا." : 403 === l.status ? "الحساب غير مخوّل لهذا المحل؛ أضفه في إعداد قاعدة البيانات." : 404 === l.status ? "إعداد المزامنة غير موجود؛ نفّذ ملف setup.sql أولًا." : 429 === l.status ? "طلبات كثيرة؛ ستتم إعادة المحاولة لاحقًا." : d.message || d.msg || d.error_description || "تعذر الاتصال بالسحابة (" + l.status + ")";
                i && d.message && (t = d.message), /accounting_period|accounting_reset|stale_accounting_records/.test(String(d.message || "")) && (t = "بدأت فترة حساب جديدة أو تغيّرت بيانات المحل. احفظ نسخة جهازك ثم استقبل بيانات السحابة؛ لن تُدمج سجلات التجربة القديمة."), 
                i && (401 === l.status || d.authBlocked) && (m = null, u = !0, $("authGate").classList.remove("hidden"), 
                window.dispatchEvent(new Event("store:profile")));
                const e = new Error(t);
                throw e.status = l.status, e;
            }
            return d;
        } finally {
            clearTimeout(o);
        }
    }
    function O(t) {
        if (!t?.access_token || !t.refresh_token || !t.user?.id) throw Error("استجابة تسجيل الدخول غير مكتملة");
        t.expires_at = t.expires_at || Math.floor(Date.now() / 1e3) + t.expires_in, t.binding = q(s), 
        localStorage.setItem(e, JSON.stringify(t)), o = t;
    }
    async function F() {
        if (o = I(e), !o || o.binding !== q(s)) throw Error("سجّل الدخول السحابي لهذا المحل.");
        return 1e3 * o.expires_at > Date.now() + 6e4 ? o.access_token : (r || (r = (async () => {
            const t = async () => {
                if (o = I(e), !o) throw Error("سجّل الدخول مجددًا.");
                if (1e3 * o.expires_at <= Date.now() + 6e4) try {
                    O(await T("/auth/v1/token?grant_type=refresh_token", {
                        refresh_token: o.refresh_token
                    }));
                } catch (t) {
                    throw 400 !== t.status && 401 !== t.status || (localStorage.removeItem(e), o = null), 
                    t;
                }
                return o.access_token;
            };
            return navigator.locks ? navigator.locks.request("alabqari-refresh", t) : t();
        })().finally(() => {
            r = null;
        })), r);
    }

    async function readInvoice(file,requestId,{signal}={}){
        C(s);
        if(!E())throw Error('سجّل الدخول السحابي لقراءة الفاتورة الذكية');
        if(!navigator.onLine)throw Error('القراءة الذكية تحتاج اتصالًا؛ يمكنك اختيار القراءة المحلية');
        const authorization=await F(),controller=new AbortController();
        const abort=()=>controller.abort();
        if(signal?.aborted)throw Error('أُلغيت القراءة');
        signal?.addEventListener('abort',abort,{once:true});
        const timer=setTimeout(abort,105000);
        try{
            const form=new FormData();form.append('file',file,file.name||'invoice');
            const endpoint=v()?location.origin:s.url+'/functions/v1/'+s.gateway;
            const response=await fetch(endpoint+'/api/invoice-ai',{method:'POST',headers:{apikey:s.key,Authorization:'Bearer '+authorization,'X-Alabqari-Shop':s.shop,'X-Invoice-Request-Id':requestId},body:form,signal:controller.signal,cache:'no-store',credentials:'omit'});
            const result=await response.json().catch(()=>({}));
            if(!response.ok||result.ok!==true){
                const error=Error(result.error||result.message||'تعذر الاتصال بقارئ الفواتير');
                error.status=response.status;error.resetRequest=result.resetRequest;throw error;
            }
            if(!Array.isArray(result.result?.lines))throw Error('نتيجة القراءة غير مكتملة');
            return result.result;
        }catch(error){
            if(error.name==='AbortError')throw Error(signal?.aborted?'أُلغيت القراءة':'لم يصل رد القراءة؛ أعد المحاولة على الملف نفسه للتحقق من الطلب السابق');
            throw error;
        }finally{clearTimeout(timer);signal?.removeEventListener('abort',abort);}
    }
    async function R(t, e, a, n) {
        const r = await T("/rest/v1/rpc/alabqari_sync", {
            p_shop: s.shop,
            p_revision: t,
            p_data: e,
            p_write: a,
            p_request_id: n
        }, await F());
        return x(r.profile), g = r.backupWarning || "", r;
    }
    async function U(t, e) {
        if (v()) throw Error("المرفقات السحابية في هذه الحزمة تعمل مع اتصال Supabase المباشر");
        FlexCore.validateReference(t, String(t.path || "").split("/")[2], s?.shop);
        const a = await F(), n = new AbortController, r = setTimeout(() => n.abort(), 6e4);
        try {
            const r = t.path.split("/").map(encodeURIComponent).join("/"), o = {
                apikey: s.key,
                Authorization: "Bearer " + a
            };
            e && (o["Content-Type"] = t.type, o["x-upsert"] = "false");
            const i = await fetch(s.url + "/storage/v1/object/" + (e ? "" : "authenticated/") + t.bucket + "/" + r, {
                method: e ? "POST" : "GET",
                headers: o,
                body: e,
                signal: n.signal,
                cache: "no-store",
                credentials: "omit"
            });
            if (!i.ok) {
                const a = await i.json().catch(() => ({}));
                if (e && (409 === i.status || "409" === String(a.statusCode) || /already exists|duplicate/i.test(a.message || a.error || ""))) {
                    const e = await U(t);
                    if (e.size === t.size && await InvoiceFiles.hash(e) === t.sha256) return !0;
                    throw Error("ملف موجود ببصمة مختلفة؛ لم يتم استبداله");
                }
                throw Error(401 === i.status ? "سجّل الدخول السحابي لمشاركة الصور" : 403 === i.status ? "صلاحيات المرفقات غير مفعلة؛ نفّذ ملف إعداد Storage للمحل" : 404 === i.status || /bucket not found/i.test(a.message || "") ? "مخزن صور الفواتير غير مفعّل؛ نفّذ ملف إعداد Storage مرة واحدة" : a.message || a.error || "تعذر مشاركة الصورة (" + i.status + ")");
            }
            return !!e || await i.blob();
        } catch (t) {
            if ("AbortError" === t.name) throw Error("انتهت مهلة الصورة؛ الملف المحلي محفوظ ويمكن إعادة المحاولة");
            throw t;
        } finally {
            clearTimeout(r);
        }
    }
    function A(t, e, a) {
        const n = p.clone(t);
        return n.settings.printerInvoice = db.settings.printerInvoice, n.settings.printerLabel = db.settings.printerLabel, 
        n._sync = {
            bound: q(s),
            base: p.clean(e),
            revision: a,
            lastSuccess: (new Date).toISOString(),
            userId: o?.user?.id || db._sync?.userId
        }, n;
    }
    function M() {
        const t = s ? u ? "المزامنة متوقفة على هذه النافذة" : o ? navigator.onLine ? c || (l ? "بيانات موجودة بالسحابة · اربط هذا الجهاز لدمجها أو تنزيلها" : i ? "جارٍ المزامنة…" : D() ? "المزامنة مؤجلة · احفظ الإعدادات أو أغلق نموذج التعديل" : L() ? "تعديلات محفوظة · بانتظار المزامنة" : "تمت المزامنة") : L() ? "دون اتصال · تعديلات محفوظة بانتظار الرفع" : "دون اتصال · نسخة محفوظة على الجهاز" : "يلزم تسجيل الدخول السحابي" : "المزامنة غير مفعّلة";
        for (const e of [ "syncStatus", "syncDetail" ]) $(e) && ($(e).textContent = t + (g ? " · " + g : ""));
        if ($("syncStatus") && $("syncStatus").classList.toggle("sync-warning", !!c || !!g || L() || !s), 
        $("syncLast") && ($("syncLast").textContent = db._sync?.lastSuccess ? "آخر نجاح: " + date(db._sync.lastSuccess) : "لم تتم مزامنة ناجحة بعد."), 
        $("syncAccount") && ($("syncAccount").textContent = o?.user?.email || "غير مسجّل"), 
        $("syncDownload") && ($("syncDownload").hidden = !s || !o, $("syncDownload").disabled = i), 
        $("syncUpload") && ($("syncUpload").hidden = !s || !o, $("syncUpload").disabled = i), 
        $("syncNow") && ($("syncNow").disabled = i || !s || !o), $("syncBootstrap") && ($("syncBootstrap").hidden = !l), 
        $("syncMerge") && ($("syncMerge").hidden = !s || !o || !!db._sync?.base, $("syncMerge").disabled = i), 
        $("syncCounts")) {
            const t = p.summary(db);
            $("syncCounts").textContent = "هذا الجهاز: " + t.orders + " طلب وفاتورة بيع · " + t.invoiceDocs + " فاتورة مستوردة · " + t.customers + " عميل · " + t.items + " صنف مخزون" + (null === w ? " · لم تُفحص السحابة بعد." : " · السحابة: " + w + " طلب وفاتورة بيع · " + (h || 0) + " فاتورة مستوردة");
        }
    }
    function N(t = 800) {
        clearTimeout(n), n = setTimeout(() => {
            G();
        }, t);
    }
    async function G() {
        if (!i && s && o && !u && storageOK && navigator.onLine && !D()) {
            i = !0, c = "", M();
            try {
                if (C(s), db._sync?.bound && db._sync.bound !== q(s)) throw Error("هذا الجهاز مرتبط بمحل آخر. لن تُرفع بياناته.");
                const t = async () => {
                    if (localStorage.getItem(key) !== persistedRaw) throw Error("تغيّرت البيانات في نافذة أخرى. حدّث الصفحة.");
                    if (S() && db._sync?.base && !L()) {
                        const t = m?.role, e = await T("/api/revision", void 0, await F(), "GET");
                        x(e.profile);
                        const a = (e.marketingRevision || "") !== f;
                        if (f = e.marketingRevision || "", e.revision === db._sync.revision && t === m?.role && !a) return k = 0, 
                        void (_ = Date.now() + 1e4);
                    }
                    for (let t = 0; t < 3; t++) {
                        const t = await R(null, null, !1);
                        if (u || D()) return;
                        if (!Number.isSafeInteger(t.revision) || t.revision < 0) throw Error("إصدار سحابي غير صالح");
                        if (t.state && p.validate(t.state), w = t.state?.orders.length || 0, h = t.state?.inventory?.invoiceDocs?.length || 0, 
                        !db._sync?.base) {
                            const e = p.clean(db);
                            return t.state && (p.equal(e, t.state) || newDevice && !b || y && p.equal(e, y)) ? (applySyncedState(A(t.state, t.state, t.revision)), 
                            void (l = !1)) : void (l = !0);
                        }
                        const e = p.clean(db), a = t.state ? p.merge(db._sync.base, e, t.state) : e;
                        if (p.validate(a), t.state && p.equal(a, t.state)) return applySyncedState(A(a, t.state, t.revision)), 
                        void (l = !1);
                        const n = await R(t.revision, a, !0);
                        if (u) return;
                        if (!n.ok) continue;
                        p.validate(n.state), w = n.state.orders.length;
                        const r = p.clean(db), s = p.equal(r, e) ? n.state : p.merge(e, r, n.state);
                        return D() ? void N(1e3) : (applySyncedState(A(s, n.state, n.revision)), l = !1, 
                        void (L() && N()));
                    }
                    throw Error("تعديلات متزامنة كثيرة؛ أعد المحاولة بعد لحظات.");
                };
                navigator.locks ? await navigator.locks.request("alabqari-sync", t) : await t(), 
                k = 0, _ = Date.now() + 1e4;
            } catch (t) {
                _ = Date.now() + Math.min(6e4, 1e4 * 2 ** Math.min(++k, 3)), c = "AbortError" === t.name ? "انتهت مهلة الاتصال؛ البيانات محفوظة وستُعاد المحاولة." : t instanceof TypeError ? "تعذر الاتصال؛ البيانات محفوظة على الجهاز وستُعاد المحاولة." : t.message;
            } finally {
                i = !1, M();
            }
        } else M();
    }
    async function j(t, e = {}) {
        if (!S()) throw Error("تأكيد العمليات يحتاج مسار الخادم الآمن");
        if (!navigator.onLine || !o || !m || u) throw Error("يلزم اتصال بالمزامنة لتأكيد العملية؛ احتفظ بالسلة وأعد المحاولة بعد الاتصال");
        if (!db._sync?.base || db._sync.bound !== q(s)) throw Error("استقبل بيانات المحل أو اربط الجهاز قبل إتمام البيع");
        const a = e.requestId || IdFactory.uuid();
        let n = await TransactionStore.get(a);
        const r = !!n;
        if (n && n.userId !== o.user.id) throw Error("العملية مرتبطة بحساب موظف آخر");
        n ? t = SyncCache.parse(n.raw) : (e.restore ? (p.validate(t), t._sync = p.clone(db._sync)) : t = prepareChange(t), 
        n = {
            id: a,
            userId: o.user.id,
            raw: SyncCache.serialize(t),
            restore: !0 === e.restore,
            orderId: e.orderId,
            reason: e.reason || "تأكيد عملية",
            date: (new Date).toISOString()
        }, await TransactionStore.put(n));
        const i = p.clean(db), d = t._sync.base, y = p.clean(t);
        let w = !1, h = r;
        const b = async () => {
            if (localStorage.getItem(key) !== persistedRaw) throw Error("تغيّرت البيانات في نافذة أخرى؛ حدّث الصفحة ثم راجع العملية المعلقة");
            for (let e = 0; e < 4; e++) {
                const e = await T("/api/receipt/" + a, void 0, await F(), "GET"), r = await R(null, null, !1);
                let s;
                if (e.found) s = {
                    ...r,
                    ok: !0
                }; else {
                    if (n.restore && r.revision !== t._sync.revision) throw Object.assign(Error("تغيّرت السحابة؛ راجع النسخة والأرقام مجددًا قبل الاستعادة"), {
                        status: 409
                    });
                    const e = n.restore ? y : p.merge(d, y, r.state);
                    if (p.validate(e), h = !0, s = n.restore ? await T("/api/restore-file", {
                        revision: r.revision,
                        state: e,
                        requestId: a
                    }, await F()) : await R(r.revision, e, !0, a), h = !1, !s.ok) continue;
                }
                w = !0;
                const o = p.clean(db), u = p.equal(i, o) ? s.state : p.merge(i, o, s.state);
                return applySyncedState(A(u, s.state, s.revision)), await TransactionStore.remove(a), 
                l = !1, c = "", M(), !0;
            }
            throw Error("تغيّرت البيانات عدة مرات؛ أعد التحقق من العملية");
        };
        try {
            return navigator.locks ? await navigator.locks.request("alabqari-sync", b) : await b();
        } catch (t) {
            throw w || h && !(t.status && t.status < 500 && 408 !== t.status && 429 !== t.status) ? (t.uncertain = !0, 
            t.requestId = a, t.message = (w ? "حُفظت العملية في الخادم؛ تعذر تحديث هذه النافذة. " : "لم يصل تأكيد العملية بعد. ") + "استخدم «مراجعة العمليات المعلقة» قبل إنشاء فاتورة أخرى. " + t.message) : await TransactionStore.remove(a), 
            t;
        }
    }
    function B(t, e) {
        const a = document.createElement("a");
        a.href = URL.createObjectURL(new Blob([ JSON.stringify(t, null, 2) ], {
            type: "application/json"
        })), a.download = e + "-" + (new Date).toISOString().replace(/[:.]/g, "-") + ".json", 
        a.click(), setTimeout(() => URL.revokeObjectURL(a.href), 1e3);
    }
    function z() {
        const t = p.clone(db);
        delete t._sync, B(t, "alabqari-before-sync");
    }
    const J = (t, e, a) => "AbortError" === t.name ? e : t instanceof TypeError ? a : t.message;
    async function P() {
        if (i || u || !s || !o || !storageOK || !navigator.onLine) return void M();
        if (db._sync?.base) return G();
        let t;
        i = !0, c = "", M();
        try {
            const e = await R(null, null, !1);
            e.state && p.validate(e.state), w = e.state?.orders.length || 0;
            const a = p.clean(db), n = e.state ? p.firstMerge(a, e.state) : p.validate(p.clone(a));
            t = "سيتم دمج طلبات هذا الجهاز والسحابة وحركات المخزون دون حذف السجلات. ستُعتمد إعدادات المحل الموجودة على هذا الجهاز، وتُحفظ نسخة أمان قبل الدمج.\n\nالسحابة — " + p.compareText(e.state || {
                orders: []
            }, n, "السحابة") + "\n\nهذا الجهاز — " + p.compareText(a, n, "هذا الجهاز") + "\n\nمتابعة؟";
        } catch (t) {
            return c = J(t, "انتهت مهلة الربط. البيانات المحلية محفوظة؛ أعد المحاولة.", "تعذر الاتصال. البيانات المحلية محفوظة؛ أعد المحاولة."), 
            i = !1, void M();
        }
        if (i = !1, M(), await askConfirm(t) && !i && !u) {
            i = !0, c = "", M();
            try {
                if (db._sync?.bound && db._sync.bound !== q(s)) throw Error("هذا الجهاز مرتبط بمحل آخر. لن تُرفع بياناته.");
                const t = async () => {
                    if (localStorage.getItem(key) !== persistedRaw) throw Error("تغيّرت البيانات في نافذة أخرى. حدّث الصفحة.");
                    await Recovery.captureState(db, "قبل ربط الجهاز", !0);
                    for (let t = 0; t < 3; t++) {
                        const t = await R(null, null, !1);
                        if (u || D()) throw Error("أغلق نموذج التعديل ثم أعد ربط الجهاز.");
                        if (!Number.isSafeInteger(t.revision) || t.revision < 0) throw Error("إصدار سحابي غير صالح");
                        t.state && p.validate(t.state), w = t.state?.orders.length || 0;
                        const e = p.clean(db), a = t.state ? p.firstMerge(e, t.state) : p.validate(e), n = t.state && p.equal(a, t.state) ? {
                            ...t,
                            ok: !0
                        } : await R(t.revision, a, !0);
                        if (u) return;
                        if (!n.ok) continue;
                        p.validate(n.state);
                        const r = p.clean(db), s = p.equal(r, e) ? n.state : p.merge(e, r, n.state);
                        if (D()) throw Error("تم الرفع؛ أغلق نموذج التعديل ثم أعد ربط الجهاز لاستقبال النتيجة.");
                        return applySyncedState(A(s, n.state, n.revision)), w = n.state.orders.length, l = !1, 
                        toast("تم ربط الجهاز. المزامنة الآن ترفع التعديلات وتستقبل بيانات الأجهزة الأخرى."), 
                        void (L() && N());
                    }
                    throw Error("تعديلات متزامنة كثيرة؛ أعد المحاولة بعد لحظات.");
                };
                navigator.locks ? await navigator.locks.request("alabqari-sync", t) : await t();
            } catch (t) {
                c = "AbortError" === t.name ? "انتهت مهلة الربط. البيانات المحلية محفوظة؛ أعد المحاولة." : "QuotaExceededError" === t.name ? "لا توجد مساحة لحفظ نسخة الأمان. صدّر بيانات هذا الجهاز قبل الربط." : t instanceof TypeError ? "تعذر الاتصال. البيانات المحلية محفوظة؛ أعد المحاولة." : t.message;
            } finally {
                i = !1, M();
            }
        }
    }
    async function V() {
        if (i || u) return;
        let t;
        i = !0, c = "", M();
        try {
            if (t = await R(null, null, !1), !t.state) throw Error("السحابة فارغة. استخدم «رفع نسخة هذا الجهاز للسحابة» لرفع بيانات هذا الجهاز.");
            p.validate(t.state), w = t.state.orders.length;
        } catch (t) {
            return c = J(t, "انتهت مهلة الاتصال.", "تعذر الاتصال بالسحابة."), i = !1, void M();
        }
        if (i = !1, M(), await askConfirm("سيتم استبدال بيانات هذا الجهاز بنسخة السحابة. تُنزَّل نسخة احتياطية من بيانات هذا الجهاز أولًا.\n\n" + p.compareText(p.clean(db), t.state, "هذا الجهاز") + "\n\nمتابعة؟")) {
            i = !0, M();
            try {
                const e = p.clean(db), a = await R(null, null, !1);
                if (!a.state) throw Error("السحابة فارغة.");
                if (p.validate(a.state), JSON.stringify(p.summary(a.state)) !== JSON.stringify(p.summary(t.state))) throw Error("تغيّرت السحابة أثناء المراجعة؛ أعد المحاولة لرؤية الأرقام الجديدة.");
                if (w = a.state.orders.length, !p.equal(e, p.clean(db))) throw Error("تغيّرت البيانات أثناء التنزيل؛ أعد المحاولة.");
                z(), await Recovery.captureState(db, "قبل تنزيل السحابة", !0), applySyncedState(A(a.state, a.state, a.revision)), 
                l = !1, c = "", toast("تم تنزيل بيانات المحل، وحُفظت نسخة من البيانات السابقة.");
            } catch (t) {
                c = t.message;
            } finally {
                i = !1, M();
            }
        }
    }
    async function H() {
        if (i || u || !s || !o || !storageOK || !navigator.onLine) return void M();
        if (D()) return c = "أغلق نموذج التعديل أو احفظ الإعدادات ثم أعد المحاولة.", void M();
        let t;
        i = !0, c = "", M();
        try {
            t = await R(null, null, !1), t.state && p.validate(t.state), w = t.state ? t.state.orders.length : 0;
        } catch (t) {
            return c = J(t, "انتهت مهلة الاتصال.", "تعذر الاتصال بالسحابة."), i = !1, void M();
        }
        i = !1, M();
        const e = p.clean(db);
        try {
            p.validate(e);
        } catch (t) {
            return c = "بيانات هذا الجهاز غير صالحة للرفع: " + t.message, void M();
        }
        if (await askConfirm("سيتم استبدال نسخة السحابة بنسخة هذا الجهاز. تُنزَّل نسخة من السحابة أولًا للاحتياط.\n\n" + p.compareText(t.state || {
            orders: []
        }, e, "السحابة") + "\n\nمتابعة؟")) {
            i = !0, M();
            try {
                const e = async () => {
                    if (localStorage.getItem(key) !== persistedRaw) throw Error("تغيّرت البيانات في نافذة أخرى. حدّث الصفحة.");
                    const e = await R(null, null, !1);
                    if (e.revision !== t.revision) throw Error("تغيّرت السحابة أثناء المراجعة؛ أعد المحاولة لرؤية الأرقام الجديدة.");
                    if (D()) throw Error("أغلق نموذج التعديل ثم أعد المحاولة.");
                    e.state && B(e.state, "alabqari-cloud-before-upload");
                    const a = p.clean(db), n = await R(e.revision, a, !0);
                    if (!n.ok) throw Error("تغيّرت السحابة أثناء الرفع؛ أعد المحاولة.");
                    p.validate(n.state);
                    const r = p.clean(db), s = p.equal(r, a) ? n.state : p.merge(a, r, n.state);
                    applySyncedState(A(s, n.state, n.revision)), w = n.state.orders.length, l = !1, 
                    toast("تم رفع نسخة هذا الجهاز إلى السحابة."), L() && N();
                };
                navigator.locks ? await navigator.locks.request("alabqari-sync", e) : await e();
            } catch (t) {
                c = J(t, "انتهت مهلة الاتصال؛ لم يتغير شيء.", "تعذر الاتصال؛ لم يتغير شيء.");
            } finally {
                i = !1, M();
            }
        }
    }
    async function K(t, e) {
        if (!s) throw Error("أدخل إعدادات المزامنة أولًا.");
        if (C(s), i) throw Error("انتظر انتهاء المزامنة الحالية.");
        i = !0;
        try {
            const a = await T("/auth/v1/token?grant_type=password", {
                email: String(t).trim(),
                password: e
            }), n = await T("/rest/v1/rpc/alabqari_sync", {
                p_shop: s.shop,
                p_revision: null,
                p_data: null,
                p_write: !1
            }, a.access_token);
            n.state && p.validate(n.state);
            const r = E() && db._sync?.userId && db._sync.userId !== a.user?.id, o = E() && !1 === n.profile?.permissions?.costs && ((db.inventory?.items || []).some(t => t.cost > 0) || db.settings.staff || db.settings.managerPin || (db.inventory?.costAudit || []).length), i = !db._sync?.base && (newDevice && !b || y && p.equal(p.clean(db), y));
            n.state && E() && (r || o) && !newDevice && await Recovery.captureState(db, "قبل تغيير حساب الموظف", !0), 
            O(a), x(n.profile), n.state && E() && (i || r || o) && (applySyncedState(A(n.state, n.state, n.revision)), 
            w = n.state.orders.length, l = !1), u = !1, $("authGate").classList.add("hidden"), 
            $("authPass").value = "", c = "";
        } finally {
            i = !1, M(), N(0);
        }
    }
    const W = document.createElement("style");
    W.textContent = ".sync-strip{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:0 0 16px;padding:10px 14px;border:1px solid #d7e7da;border-radius:12px;background:#f0f8f1;color:#235939;font-size:13px}.sync-strip button{min-height:36px;padding:4px 10px;margin-inline-start:auto}.sync-warning{color:#885812}#syncDialog{max-width:650px}#syncDialog input[dir=ltr]{text-align:left}#syncDialog .actions{gap:8px}.theme-dark .sync-strip{background:#19352b;border-color:#315641;color:#b9e9d1}.theme-dark .sync-warning{color:#f2ce75}#syncDetail{overflow-wrap:anywhere}", 
    document.head.append(W);
    const Q = document.createElement("div");
    Q.className = "sync-strip", Q.innerHTML = '<span id="syncStatus" role="status" aria-live="polite"></span><button type="button" id="syncBootstrap" hidden>ربط هذا الجهاز</button><button type="button" id="openSync">المزامنة</button>', 
    document.querySelector("main .top").after(Q);
    const X = document.createElement("dialog");
    if (X.id = "syncDialog", X.innerHTML = '<div class="dialoghead"><h2>مزامنة المحل</h2><button type="button" data-close="syncDialog">إغلاق</button></div><p id="syncDetail" class="note" role="status"></p><p id="syncLast" class="muted"></p><p id="syncCounts" class="note" aria-live="polite"></p><p>الحساب: <b id="syncAccount"></b></p><div class="actions"><button type="button" class="primary" id="syncNow">مزامنة الآن — إرسال واستقبال</button><button type="button" class="primary" id="syncMerge" hidden>ربط ودمج بيانات هذا الجهاز</button><button type="button" id="syncExport">حفظ نسخة من هذا الجهاز</button><button type="button" id="syncUpload" hidden>رفع نسخة هذا الجهاز للسحابة (استبدال)</button><button type="button" id="syncDownload" hidden>استقبال نسخة السحابة بدل بيانات الجهاز</button></div><p class="muted">لإضافة جهاز جديد استخدم «ربط ودمج بيانات هذا الجهاز». بعدها تُرسل وتُستقبل التعديلات تلقائيًا. خيارات الاستبدال مخصصة للاستعادة فقط. يظهر لك عدد الطلبات والعملاء والمخزون قبل كل خطوة لتتأكد أنه أقل أو أكثر مما تتوقع.</p><details id="syncSetup"><summary>إعداد الاتصال وتسجيل الدخول</summary><p class="note">الاتصال مضبوط لمحل العبقري. استخدم البريد وكلمة المرور لحساب المزامنة الخاص بالمحل.</p><form id="syncForm"><div class="grid"><label class="full">رابط مشروع Supabase<input name="url" dir="ltr" type="url" required placeholder="https://xxxxxxxxxxxxxxxxxxxx.supabase.co"></label><label class="full">المفتاح العام Publishable / anon<input name="key" dir="ltr" required autocomplete="off" placeholder="sb_publishable_..."></label><label class="full">معرّف المحل<input name="shop" dir="ltr" required placeholder="UUID"></label><label>البريد الإلكتروني لحساب المزامنة<input name="email" type="email" autocomplete="username" required dir="ltr"></label><label>كلمة المرور<input name="password" type="password" autocomplete="current-password" required></label></div><p class="error" id="syncFormError" role="alert"></p><div class="footer"><button class="primary" id="syncConnect">حفظ الاتصال وتسجيل الدخول</button></div></form></details><p class="muted">بعد ربط الجهاز، تُرسل تعديلاته وتُستقبل تعديلات الأجهزة الأخرى تلقائيًا بعد الحفظ وكل 10 ثوانٍ أثناء فتح التطبيق. استخدم نفس رابط المتجر وحساب المحل على الجهازين. عند انقطاع الإنترنت يستمر الحفظ المحلي. تعارض نفس الطلب أو نفاد المخزون يوقف الرفع للمراجعة. إصدار التطبيق: 18.9.7.</p>', 
    document.body.append(X), E()) {
        const t = X.querySelector("p.muted:last-child");
        t && (t.textContent = "استخدم حسابًا مستقلًا لكل موظف. يراجع الخادم الصلاحيات ويؤكد العمليات المالية قبل اعتمادها. عند انقطاع الاتصال احتفظ بالسلة وأكمل الدفع بعد عودة الإنترنت. تُحدّث بيانات الأجهزة تلقائيًا كل 10 ثوانٍ أثناء فتح المنصة. إصدار التطبيق: 18.9.7.");
    }
    function Z() {
        const t = $("syncForm");
        for (const e of [ "url", "key", "shop" ]) t.elements.namedItem(e).value = s?.[e] || "";
        for (const e of [ "url", "key", "shop" ]) t.elements.namedItem(e).readOnly = !!a;
        if (t.elements.namedItem("email").value = o?.user?.email || "", t.elements.namedItem("password").value = "", 
        $("syncSetup").open = !s || !o, !$("sharedFilesStatus")) {
            const t = document.createElement("div");
            t.className = "panel", t.innerHTML = '<h3>صور الفواتير بين الأجهزة</h3><p id="sharedFilesStatus" class="note"></p><button type="button" id="shareOldFiles">مشاركة صور هذا الجهاز / إعادة المحاولة</button><p class="note">المخزن خاص بحسابات المحل. الصور القديمة تُرفع من الجهاز الذي يحتوي عليها بعد تفعيل Storage.</p>', 
            X.querySelector("details").before(t), $("shareOldFiles").onclick = async () => {
                await (window.InvoiceFiles?.flush(!0));
                const t = window.InvoiceFiles?.status();
                t && ($("sharedFilesStatus").textContent = "مشتركة: " + t.shared + " · بانتظار الجهاز الأصلي: " + t.pending + (t.error ? " · " + t.error : ""));
            };
        }
        const e = window.InvoiceFiles?.status();
        e && ($("sharedFilesStatus").textContent = "مشتركة: " + e.shared + " · بانتظار الجهاز الأصلي: " + e.pending + (e.error ? " · " + e.error : "")), 
        M(), X.open || X.showModal();
    }
    $("openSync").onclick = Z, $("syncNow").onclick = async () => {
        l = !1, await G(), l && Z();
    }, $("syncBootstrap").onclick = Z, $("syncMerge").onclick = () => {
        P();
    }, $("syncExport").onclick = z, $("syncDownload").onclick = () => {
        V();
    }, $("syncUpload").onclick = () => {
        H();
    }, $("syncForm").onsubmit = async e => {
        e.preventDefault(), $("syncFormError").textContent = "", $("syncConnect").disabled = !0;
        try {
            const n = new FormData(e.target), r = C({
                ...a,
                url: String(n.get("url")).trim().replace(/\/$/, ""),
                key: String(n.get("key")).trim(),
                shop: String(n.get("shop")).trim().toLowerCase()
            });
            if (i) throw Error("انتظر انتهاء المزامنة الحالية.");
            if (db._sync?.bound && db._sync.bound !== q(r)) throw Error("هذا الجهاز مرتبط بمحل مختلف. استخدم متصفحًا مستقلًا للمحل الآخر.");
            s = r, localStorage.setItem(t, JSON.stringify(s)), await K(String(n.get("email")).trim(), String(n.get("password"))), 
            e.target.elements.namedItem("password").value = "", $("syncSetup").open = !1, toast("تم تسجيل الدخول.");
        } catch (t) {
            $("syncFormError").textContent = t.message;
        } finally {
            $("syncConnect").disabled = !1, M();
        }
    };
    const Y = window.settings;
    window.settings = function() {
        Y(), d = !1;
        const t = document.createElement("div");
        t.className = "panel", t.style.marginTop = "18px", t.innerHTML = '<h2>المزامنة بين الأجهزة</h2><p>اربط أجهزة المحل لمشاركة الطلبات والعملاء والمخزون.</p><button type="button">فتح إعدادات المزامنة</button>', 
        t.querySelector("button").onclick = Z, $("settingsView").append(t);
    }, document.addEventListener("input", t => {
        t.target.closest("#settingsForm") && (d = !0);
    }), window.addEventListener("store:committed", () => {
        d = !1, M(), N();
    }), window.addEventListener("online", () => N(0)), window.addEventListener("offline", M), 
    document.addEventListener("visibilitychange", () => {
        document.hidden || N(0);
    }), document.addEventListener("close", () => N(), !0), window.addEventListener("storage", a => {
        if (a.key === t && (u = !0, c = "تغيّر إعداد الاتصال في نافذة أخرى؛ حدّث الصفحة.", 
        M()), a.key === e && (o = I(e), !o && s && (u = !0, $("authGate").classList.remove("hidden")), 
        M()), a.key === key && a.newValue !== persistedRaw) {
            if (i || D()) return c = "تغيّرت البيانات في نافذة أخرى؛ أغلق النموذج وحدّث الصفحة قبل الحفظ.", 
            void M();
            try {
                const t = SyncCache.parse(a.newValue);
                p.validate(t), db = t, persistedRaw = a.newValue, render(), window.renderInventory?.(), 
                M();
            } catch (t) {
                c = "تعذر قراءة تحديث النافذة الأخرى.", M();
            }
        }
    }), window.StoreSync = {
        open: Z,
        readInvoice,
        invoiceStatus:()=>StoreSync.api('/api/invoice-ai/status',undefined,'GET'),
        sync: G,
        login: K,
        logout: async function() {
            if (L() && !await askConfirm("توجد تعديلات لم تُرفع. ستبقى على هذا الجهاز لتُزامن بعد تسجيل الدخول. تسجيل الخروج؟")) return !1;
            u = !0;
            const t = o;
            return localStorage.removeItem(e), o = null, m = null, E() && ($("authGate").classList.remove("hidden"), 
            window.dispatchEvent(new Event("store:profile"))), M(), s && t && navigator.onLine && await T("/auth/v1/logout?scope=local", void 0, t.access_token).catch(() => {}), 
            !0;
        },
        linkDevice: P,
        uploadLocal: H,
        downloadCloud: V,
        configured: () => !!s,
        storage: {
            upload: U,
            download: t => U(t)
        },
        secureMode: E,
        backendMode: v,
        userId: () => o?.user?.id,
        secureProfile: () => m,
        shop: () => s?.shop,
        receipt: async t => T("/api/receipt/" + encodeURIComponent(t), void 0, await F(), "GET"),
        atomicCommit: j,
        resumeTransaction: async t => {
            const e = await TransactionStore.get(t);
            if (!e || e.userId !== o?.user?.id) throw Error("العملية غير موجودة لهذا الحساب");
            return j(SyncCache.parse(e.raw), {
                requestId: t,
                restore: e.restore,
                orderId: e.orderId,
                reason: e.reason
            });
        },
        status: () => ({
            running: i,
            stopped: u,
            editing: D(),
            pending: L(),
            needsDownload: l,
            error: c,
            lastSuccess: db._sync?.lastSuccess || null
        }),
        api: async (t, e, a = "POST") => {
            if (!E()) throw Error("وضع الخادم غير مفعّل");
            const n = await T(t, e, await F(), a);
            return x(n.profile), n;
        },
        adopt(t) {
            if (!t.ok || !t.state) throw Error("نسخة خادم غير صالحة");
            x(t.profile), applySyncedState(A(t.state, t.state, t.revision)), l = !1, M();
        },
        prepare(t) {
            if (u) throw Error("حدّث الصفحة قبل الحفظ.");
            if (s && !o) throw Error("سجّل الدخول السحابي قبل تعديل البيانات.");
            if (E() && !m) throw Error("انتظر التحقق من حساب الموظف على الخادم قبل الحفظ.");
            return db._sync ? t._sync = p.clone(db._sync) : delete t._sync, t;
        }
    }, s && ($("authUser").placeholder = "البريد الإلكتروني", $("authUser").type = "email", 
    E() || o?.binding !== q(s) || db._sync?.bound !== q(s) ? $("authGate").classList.remove("hidden") : $("authGate").classList.add("hidden")), 
    M(), N(0), setInterval(() => {
        document.hidden || Date.now() < _ || G();
    }, 1e4), E() && o?.binding === q(s) && F().then(t => T("/api/profile", void 0, t, "GET")).then(t => {
        x(t), $("authGate").classList.add("hidden"), N(0);
    }).catch(() => {
        m = null, $("authGate").classList.remove("hidden");
    });
}();
