/*! Alabqari Store 18.9.7 */
(function(){
'use strict';
let version=0;
async function open(){
 const token=++version;
 const dialog=LedgerUI.dialog('systemStatusDialog','حالة النظام','<div id="systemStatusBody" role="status">جارٍ الفحص…</div>');
 dialog.showModal();
 const rows=[],add=(label,value)=>rows.push('<div class="panel"><b>'+esc(label)+'</b><p>'+esc(value)+'</p></div>');
 const sync=StoreSync.status();const files=InvoiceFiles.status();
 add('نسخة الواجهة','18.9.7');
 add('حساب الموظف',currentStaffLabel());
 add('المزامنة',sync.error||(!navigator.onLine?'الجهاز دون اتصال':sync.stopped?'المزامنة متوقفة':sync.pending?'تعديلات بانتظار التأكيد':sync.lastSuccess?'آخر نجاح: '+date(sync.lastSuccess):'لم يتم تأكيد المزامنة بعد'));
 add('مرفقات الفواتير','مشتركة: '+files.shared+' · بانتظار الرفع: '+files.pending+(files.error?' · '+files.error:''));
 try{const pending=(await TransactionStore.list()).filter(r=>r.userId===StoreSync.userId());add('العمليات المعلقة',pending.length?'عدد العمليات: '+pending.length+'؛ راجعها من شريط المزامنة قبل تسجيل دفعة جديدة':'لا توجد عمليات معلقة لهذا الحساب');}catch{add('العمليات المعلقة','تعذر قراءة قائمة الجهاز');}
 if(can('purchases'))try{const result=await StoreSync.invoiceStatus();add('قراءة الفواتير الذكية',result.configured?'جاهزة · حد PDF: '+result.limits.pages+' صفحة':'تحتاج تفعيل خدمة القراءة من مدير المشروع');}catch(error){add('قراءة الفواتير الذكية',error.message);}
 try{const last=localStorage.getItem('alabqari-last-complete-backup');add('آخر تنزيل نسخة شاملة على هذا الجهاز',last?date(last):'لم يسجل هذا الجهاز تنزيل نسخة شاملة؛ احتفظ بنسخة تشمل المرفقات');}catch{add('نسخة الجهاز','تعذر قراءة تاريخ التصدير');}
 if(can('backups'))try{const backup=await StoreSync.api('/api/backups',undefined,'GET');add('نسخ حالة المحل على الخادم','عدد النسخ: '+backup.rows.length+' · هذه النسخ لا تتضمن صور الملفات نفسها');}catch(error){add('نسخ الخادم',error.message);}
 if(token!==version||!dialog.open)return;
 dialog.querySelector('#systemStatusBody').innerHTML=rows.join('')+'<div class="footer"><button type="button" id="statusRefresh">إعادة الفحص</button>'+(can('backups')?'<button type="button" id="statusBackup">تنزيل نسخة شاملة مع المرفقات</button>':'')+'</div>';
 dialog.querySelector('#statusRefresh').onclick=open;
 dialog.querySelector('#statusBackup')?.addEventListener('click',async event=>{event.target.disabled=true;try{if(await BackupFiles.exportComplete())toast('احتفظ بالملف في مكان مستقل عن بيانات الموقع');}finally{event.target.disabled=false;}});
}
window.SystemStatus={open};
})();

