/*! Alabqari Store 18.9.7 | App code rights reserved for the project owner. */
/*! العبقري ستور — حقوق تطوير هذه النسخة محفوظة لصاحب المشروع. */
!function() {
    "use strict";
    const e = e => String(e ?? "").replace(/[&<>"']/g, e => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    }[e])), t = () => (db.inventory = db.inventory && "object" == typeof db.inventory ? db.inventory : {
        items: [],
        moves: []
    }, db.inventory.invoiceDocs = Array.isArray(db.inventory.invoiceDocs) ? db.inventory.invoiceDocs : [], 
    db.inventory), i = e => (Number(e || 0) / 100).toLocaleString("ar-SA-u-nu-latn", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }) + " ر.س", a = e => String(e ?? "").replace(/[\u0660-\u0669]/g, e => "٠١٢٣٤٥٦٧٨٩".indexOf(e)).replace(/[\u06f0-\u06f9]/g, e => "۰۱۲۳۴۵۶۷۸۹".indexOf(e)), n = e => {
        let t = a(e).replace(/[,\u060c\u066c\s]/g, "").replace(/\u066b/g, ".");
        if (!t) return 0;
        if (!/^\d+(\.\d{1,2})?$/.test(t)) return 0;
        let [i, n = ""] = t.split(".");
        return 100 * Number(i) + Number((n + "00").slice(0, 2));
    }, r = () => Ledger.dayKey((new Date).toISOString()), o = e => {
        const t = document.getElementById("iiProgress");
        t && (t.textContent = e);
    };
    let s = null;
    function l(e, t, i, a, n, r) {
        const o = document.createElement("canvas");
        o.width = Math.max(1, Math.round(a * r)), o.height = Math.max(1, Math.round(n * r));
        const s = o.getContext("2d");
        return s.fillStyle = "#fff", s.fillRect(0, 0, o.width, o.height), s.imageSmoothingQuality = "high", 
        s.drawImage(e, t, i, a, n, 0, 0, o.width, o.height), o;
    }
    const d = (e, t, i, a, n) => (e.words || []).filter(e => e.text && e.text.trim() && (void 0 === e.confidence || e.confidence >= (n || 0))).map(e => ({
        text: e.text,
        conf: e.confidence,
        x0: e.bbox.x0 / t + i,
        y0: e.bbox.y0 / t + a,
        x1: e.bbox.x1 / t + i,
        y1: e.bbox.y1 / t + a
    }));
    async function c(e) {
        if (!window.InvoiceReader) return null;
        if (!await (window.Tesseract ? Promise.resolve(!0) : s || (s = (e => {
            let t;
            return Promise.race([ e, new Promise((e, i) => t = setTimeout(() => i(Error("تعذر تحميل قارئ الفاتورة؛ تحقق من الاتصال وحاول مرة أخرى")), 3e4)) ]).finally(() => clearTimeout(t));
        })(new Promise(e => {
            const t = document.createElement("script");
            t.src = "https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js", t.onload = () => e(!!window.Tesseract), 
            t.onerror = () => {
                t.remove(), e(!1);
            }, document.head.append(t);
        })).then(e => (e || (s = null), e), () => (s = null, !1)), s))) return null;
        let i = null;
        try {
            o("تجهيز الصورة (تعديل الميلان وإزالة خطوط الجدول)..."), await new Promise(e => setTimeout(e, 30));
            const a = e.width, n = e.height, r = function(e, t, i) {
                const a = document.createElement("canvas");
                a.width = t, a.height = i;
                const n = a.getContext("2d"), r = n.createImageData(t, i);
                for (let t = 0, i = 0; i < e.length; t += 4, i++) r.data[t] = r.data[t + 1] = r.data[t + 2] = e[i], 
                r.data[t + 3] = 255;
                n.putImageData(r, 0, 0);
                const o = document.createElement("canvas");
                o.width = 2 * t, o.height = 2 * i;
                const s = o.getContext("2d");
                return s.imageSmoothingQuality = "high", s.drawImage(a, 0, 0, o.width, o.height), 
                o;
            }(window.InvoiceReader.prepare(function(e) {
                const {data: t} = e.getContext("2d", {
                    willReadFrequently: !0
                }).getImageData(0, 0, e.width, e.height), i = new Uint8Array(e.width * e.height);
                for (let e = 0, a = 0; a < i.length; e += 4, a++) i[a] = 77 * t[e] + 150 * t[e + 1] + 29 * t[e + 2] >> 8;
                return i;
            }(e), a, n).gray, a, n);
            i = await Tesseract.createWorker("ara+eng", 1, {
                logger: e => {
                    e.status && o((e => ({
                        "loading tesseract core": "تجهيز قارئ الفاتورة",
                        "initializing tesseract": "تجهيز قارئ الفاتورة",
                        "loading language traineddata": "تحميل اللغة العربية",
                        "initializing api": "بدء قراءة الفاتورة",
                        "recognizing text": "قراءة النص والبنود"
                    }[e] || "قراءة الفاتورة"))(e.status) + (Number.isFinite(e.progress) ? " " + Math.round(100 * e.progress) + "%" : ""));
                }
            }), await i.setParameters({
                tessedit_pageseg_mode: "11",
                tessedit_char_whitelist: ""
            });
            const s = await i.recognize(r), c = d(s.data, 2, 0, 0);
            let u, p = [];
            const f = window.InvoiceReader.codeBand(c);
            if (f) {
                u = f.x0, o("قراءة أكواد الأصناف..."), await i.setParameters({
                    tessedit_pageseg_mode: "6",
                    tessedit_char_whitelist: "0123456789"
                });
                const e = Math.max(0, 2 * f.x0), t = l(r, e, 0, Math.min(r.width - e, 2 * (f.x1 - f.x0)), .62 * r.height, 1.5);
                p = d((await i.recognize(t)).data, 3, Math.max(0, f.x0), 0, 60);
            }
            o("قراءة رأس الفاتورة..."), await i.setParameters({
                tessedit_pageseg_mode: "6",
                tessedit_char_whitelist: ""
            });
            const h = (await i.recognize(l(e, 0, 0, a, .09 * n, 2))).data.text || "", g = window.InvoiceReader.parseLayout(c, a, n, {
                codeWords: p,
                codeX0: u,
                topText: h,
                knownSkus: (t().items || []).flatMap(e => [ e.sku, e.supplierSku, e.code ]).filter(Boolean).map(String),
                vocab: (t().items || []).flatMap(e => String(e.name || "").toUpperCase().split(/[^A-Z]+/)).filter(e => e.length >= 2)
            }), m = InvoiceReviewCore.parseWords(c, a, n), v = InvoiceReviewCore.reconcile(g, m);
            return v.rawText = (s.data.text || "").trim(), v;
        } catch (e) {
            return console.warn("invoice layout read failed", e), null;
        } finally {
            try {
                i && await i.terminate();
            } catch (e) {}
        }
    }

    async function aiFile(file){
        if(file.size<=8*1024*1024&&['image/jpeg','image/png','image/webp','application/pdf'].includes(file.type))return file;
        if(file.type==='application/pdf'||/\.pdf$/i.test(file.name||''))throw Error('الحد الأقصى للقراءة الذكية 8 ميجابايت و20 صفحة PDF');
        if(!file.type.startsWith('image/'))throw Error('اختر صورة أو PDF صالحًا');
        let bitmap;
        try{bitmap=await createImageBitmap(file,{imageOrientation:'from-image'});}catch{throw Error('تعذر فتح نوع الصورة؛ احفظها JPG أو PNG وأعد المحاولة');}
        try{
            const scale=Math.min(1,2500/Math.max(bitmap.width,bitmap.height));
            const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(bitmap.width*scale));canvas.height=Math.max(1,Math.round(bitmap.height*scale));
            const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(bitmap,0,0,canvas.width,canvas.height);
            const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',.92));
            if(!blob||blob.size>8*1024*1024)throw Error('الصورة أكبر من حد القراءة الذكية؛ قسّم الفاتورة أو قلّل حجمها');
            return new File([blob],(file.name||'invoice').replace(/\.[^.]*$/,'')+'.jpg',{type:'image/jpeg'});
        }finally{bitmap.close?.();}
    }
    function u() {
        if (!can("purchases")) return void toast("استيراد المشتريات يحتاج صلاحية");
        t();
        let e = document.getElementById("invoiceImportDialog");
        e || (e = document.createElement("dialog"), e.id = "invoiceImportDialog", 
        e.className = "lg-dialog", document.body.append(e)), e._parsed = null, e._file = null, 
        e._chosenFile = null, e._storedFile = null, e._saving = !1, e._draftSaving = !1, 
        e._readToken = (e._readToken || 0) + 1, e.innerHTML = '<div class="handle"></div><div class="dialoghead"><h2>استيراد فاتورة مورد</h2><button type="button" data-close="invoiceImportDialog">إغلاق</button></div><p class="note">اختر صورة واضحة أو ملف PDF. تظهر البنود للمراجعة قبل الحفظ، ولا تتغير كميات المخزون حتى تعتمد فاتورة الشراء.</p><label>طريقة القراءة<select id="iiEngine"><option value="ai">قراءة ذكية</option><option value="local">قراءة محلية</option></select></label><p class="note" id="iiEngineHelp">القراءة الذكية: حتى 8 ميجابايت و20 صفحة PDF. تظهر النتيجة للمراجعة قبل إضافة المخزون.</p><div class="grid"><label>اختيار صورة أو PDF<input id="iiFile" type="file" accept="image/*,application/pdf,.pdf"></label><label>تصوير الفاتورة<input id="iiCamera" type="file" accept="image/*" capture="environment"></label></div><label>أو الصق تفاصيل الفاتورة<textarea id="iiPaste" rows="5" placeholder="اسم الصنف، الكمية، سعر الوحدة والإجمالي"></textarea></label><button type="button" id="iiParsePaste">قراءة التفاصيل</button><div id="iiProgress" class="muted" role="status" aria-live="polite"></div><button type="button" id="iiRetryRead" hidden>إعادة قراءة الملف</button><button type="button" id="iiLocalRead" hidden>استخدام القراءة المحلية</button><div id="iiPreview"></div><div class="footer"><button type="button" data-close="invoiceImportDialog">إلغاء</button><button type="button" class="primary" id="iiSave" disabled>حفظ للمراجعة</button></div>', 
        e.addEventListener('close',()=>{e._readAbort?.abort();e._readToken++;},{once:true});
        e.showModal();
        e.querySelector('#iiEngine').value=window.StoreSync?.secureMode?.()?'ai':'local';
        const readinessToken=e._readToken;
        if(window.StoreSync?.invoiceStatus)StoreSync.invoiceStatus().then(status=>{if(!e.open||e._readToken!==readinessToken||e._chosenFile)return;if(!status.configured){e.querySelector('#iiEngine').value='local';e.querySelector('#iiEngineHelp').textContent='القراءة الذكية تحتاج تفعيل خدمة القراءة من مدير المشروع. القراءة المحلية متاحة الآن، ويمكن اختيار الذكية بعد التفعيل.';}}).catch(()=>{});
        e.querySelector('#iiEngine').onchange=()=>{e.querySelector('#iiEngineHelp').textContent=e.querySelector('#iiEngine').value==='ai'?'القراءة الذكية: حتى 8 ميجابايت و20 صفحة PDF؛ يلزم الدخول والاتصال.':'القراءة المحلية: لا تُرسل الصورة لمزود AI؛ حتى 15 ميجابايت و100 صفحة PDF، وقد تحتاج تحميل ملفات القارئ.';e.querySelector('#iiRetryRead').hidden=!e._chosenFile;};
        e.querySelector('#iiRetryRead').onclick=()=>x(e,undefined,e._chosenFile);
        e.querySelector('#iiLocalRead').onclick=()=>{e.querySelector('#iiEngine').value='local';e.querySelector('#iiEngine').onchange();x(e,undefined,e._chosenFile);};
        e.querySelector("#iiFile").onchange = () => {
            x(e, void 0, e.querySelector("#iiFile").files[0]);
        }, e.querySelector("#iiCamera").onchange = () => {
            x(e, void 0, e.querySelector("#iiCamera").files[0]);
        }, e.querySelector("#iiParsePaste").onclick = () => x(e, e.querySelector("#iiPaste").value), 
        e.querySelector("#iiSave").onclick = () => async function(e) {
            if (!e._saving && !e._draftSaving) {
                e._saving = !0;
                try {
                    if (!can("purchases")) throw Error("حفظ المشتريات يحتاج صلاحية");
                    if (!e._parsed) throw Error("اقرأ الفاتورة أو أكمل بياناتها أولًا");
                    const t = JSON.parse(JSON.stringify(e._parsed)), i = p(e).edit;
                    if (t.supplier = String(i.iiSupplier || "").trim(), t.no = String(i.iiNo || "").trim(), 
                    t.date = i.iiDate || r(), t.raw = i.iiRaw || t.raw || "", Ledger.dayToISO(t.date), 
                    t.lines = (t.lines || []).map((e, t) => {
                        const a = i.lines[t] || {}, n = String(a.name ?? e.name ?? "").trim();
                        if (!n) throw Error("اكتب اسم البند " + (t + 1));
                        return {
                            name: n,
                            sku: String(a.sku ?? e.sku ?? "").trim(),
                            qty: Ledger.parseQty(a.qty ?? String(e.qty)),
                            cost: Ledger.parseMoney(a.cost ?? String(e.cost / 100), !0)
                        };
                    }), !t.lines.length) throw Error("أضف بندًا واحدًا على الأقل");
                    for (const [e, a] of [ [ "discount", "iiDiscount" ], [ "extra", "iiExtra" ], [ "paid", "iiPaid" ] ]) t[e] = Ledger.parseMoney(i[a] || "0", !0);
                    if (!e.querySelector("#iiReviewed")?.checked) throw Error("راجع كل البنود والإجمالي وأكد المراجعة قبل الحفظ");
                    if ((e._parsed.warnings?.length || e._parsed.unread?.length || e._parsed.lines.some(e => !1 === e.exact) || t.readTotal && Math.abs(t.readTotal - v(t) + t.discount - t.extra) > 1) && !e.querySelector("#iiIssuesReviewed")?.checked) throw Error("راجع البنود غير المؤكدة وفرق الإجمالي وأكد معالجتها");

                    const expectedLines=i.iiExpectedLines?.trim()?Ledger.parseQty(i.iiExpectedLines):null;
                    const expectedQuantity=i.iiExpectedQuantity?.trim()?Ledger.parseQty(i.iiExpectedQuantity):null;
                    if(expectedLines!==null&&expectedLines!==t.lines.length)throw Error('عدد البنود لا يطابق العدد المطبوع؛ أضف الناقص أو صحح العدد من الأصل');
                    if(expectedQuantity!==null&&expectedQuantity!==t.lines.reduce((sum,line)=>sum+line.qty,0))throw Error('مجموع الكميات لا يطابق الإجمالي المطبوع؛ راجع كل البنود');
                    const a = Ledger.invoiceTotals(t.lines, t.discount, t.extra, t.paid);
                    t.lines.forEach(e => e.total = e.qty * e.cost);
                    const n = e._warehouseDraft;
                    WarehouseDrafts.setBusy(e, !0), await f(e, n);
                    const o = copy();
                    if (o.inventory.invoiceDocs.some(e => e.id === n.id)) throw Error("هذا المستند محفوظ؛ افتحه من سجل الفواتير");
                    const s = {
                        id: n.id,
                        draftId: n.id,
                        supplier: t.supplier,
                        no: t.no,
                        date: t.date,
                        lines: t.lines,
                        raw: t.raw,
                        ...a,
                        prevBalance: t.prevBalance || 0,
                        status: "pending",
                        fileName: n.fileName || "",
                        fileType: n.fileType || "",
                        hasFile: !!n.hasFile,
                        created: (new Date).toISOString()
                    };
                    if (n.fileStorage && (s.fileStorage = n.fileStorage), o.inventory.invoiceDocs.push(s), 
                    WarehouseDrafts.finish(o, n, s.id), !await commitTransaction(o, {
                        reason: "حفظ مستند فاتورة مورد"
                    })) throw Error("لم يتأكد الحفظ؛ بقي المستند مفتوحًا");
                    WarehouseDrafts.clear(n.id), n.status = "completed", e.close(), window.dispatchEvent(new Event("ledger:refresh")), 
                    toast("حُفظ المستند؛ اربط القطع واعتمد الفاتورة لإضافة الكميات");
                } catch (t) {
                    WarehouseDrafts.status(e, t.message, !0), o(t.message);
                } finally {
                    WarehouseDrafts.setBusy(e, !1), e._saving = !1;
                }
            }
        }(e), h(e); return e;
    }
    function p(e) {
        const t = {};
        for (const i of [ "iiSupplier", "iiNo", "iiDate", "iiRaw", "iiDiscount", "iiExtra", "iiPaid", "iiExpectedLines", "iiExpectedQuantity" ]) {
            const a = e.querySelector("#" + i);
            a && (t[i] = a.value);
        }
        return t.lines = [ ...e.querySelectorAll(".ii-line") ].map(e => Object.fromEntries([ ...e.querySelectorAll("input[data-k]") ].filter(e => "total" !== e.dataset.k).map(e => [ e.dataset.k, e.value ]))), 
        {
            parsed: e._parsed ? JSON.parse(JSON.stringify(e._parsed)) : null,
            paste: e.querySelector("#iiPaste").value,
            edit: t
        };
    }
    async function f(e, t) {
        const i = e._chosenFile || e._file;
        if (i) {
            if (i.size > 15728640) throw Error("حجم الملف كبير؛ الحد الأقصى 15 ميجابايت");
            if (e._storedFile !== i || e._storedFileDraft !== t.id) {
                if (e._fileStore?.file === i && e._fileStore.id === t.id) return e._fileStore.promise;
                const request = {file:i,id:t.id,promise:null};
                e._fileStore = request;
                request.promise = (async () => {
                    const meta = {name:i.name || t.fileName || "فاتورة",type:i.type || t.fileType || ""};
                    const local = await InvoiceFiles.put(t.id, i, meta);
                    let reference = t.fileStorage || null;
                    if (!local || reference) {
                        const hash = await InvoiceFiles.hash(i);
                        if (reference && reference.sha256 !== hash) reference = null;
                        if (!local && !reference) {
                            if (!navigator.onLine || !window.StoreSync?.storage?.upload || StoreSync.backendMode?.()) throw Error("تعذر حفظ المرفق محليًا؛ افتح الموقع في تبويب عادي أو اتصل بالإنترنت لحفظه سحابيًا. الملف ما زال في النموذج المفتوح");
                            reference = FlexCore.reference(StoreSync.shop(),t.id,hash,i.size,meta.type);
                            try { await StoreSync.storage.upload(reference,i); }
                            catch (error) { throw Error("تعذر حفظ المرفق محليًا وسحابيًا: " + error.message + ". الملف ما زال في النموذج المفتوح"); }
                        }
                        if (reference) FlexCore.validateReference(reference,t.id,StoreSync.shop());
                    }
                    if (e._chosenFile && e._chosenFile !== i) return;
                    if (reference) t.fileStorage = reference; else delete t.fileStorage;
                    t.hasFile = true; t.fileName = meta.name; t.fileType = meta.type;
                    e._storedFile = i; e._storedFileDraft = t.id;
                })();
                try { await request.promise; }
                finally { if (e._fileStore === request) e._fileStore = null; }
            }
        }
    }
    function h(e, t) {
        e._draftControls?.abort();
        const i = new AbortController;
        e._draftControls = i, e.querySelector("[data-draft-save]")?.remove(), e.querySelector("[data-draft-status]")?.remove();
        const a = t || WarehouseDrafts.create("import", p(e), "استيراد فاتورة مورد");
        e._warehouseDraft = a;
        let n = JSON.stringify((db.inventory.drafts || []).find(e => e.id === a.id)?.payload || null);
        const r = e.querySelector(".footer");
        r.insertAdjacentHTML("beforebegin", '<p class="draft-status" data-draft-status role="status">تقدر تحفظ البنود الناقصة كمسودة وتكمل المراجعة لاحقًا.</p>'), 
        r.insertAdjacentHTML("afterbegin", '<button type="button" data-draft-save>حفظ مسودة</button>');
        const o = () => {
            if (!e._draftSaving && !e._saving) try {
                if (a.payload = p(e), JSON.stringify(a.payload) === n) return;
                a.title = "استيراد " + (a.payload.edit.iiSupplier || a.payload.parsed?.supplier || "فاتورة مورد"), 
                (a.payload.parsed || a.payload.paste.trim() || a.hasFile || a.version) && WarehouseDrafts.cache(a);
            } catch (t) {
                WarehouseDrafts.status(e, t.message, !0);
            }
        };
        e._cacheDraft = o, e.addEventListener("input", o, {
            signal: i.signal
        }), e.addEventListener("change", () => {
            o(), f(e, a).then(o).catch(t => WarehouseDrafts.status(e, t.message, !0));
        }, {
            signal: i.signal
        }), e.addEventListener("click", e => {
            e.target.closest("#iiAdd,[data-del]") && queueMicrotask(o);
        }, {
            signal: i.signal
        }), e.addEventListener("cancel", t => {
            (e._draftSaving || e._saving) && t.preventDefault();
        }, {
            signal: i.signal
        }), e.addEventListener("close", () => {
            e._readToken++, (WarehouseDrafts.all().some(e => e.id === a.id) || "completed" !== a.status) && o();
        }, {
            once: !0,
            signal: i.signal
        }), e.querySelector("[data-draft-save]").onclick = async () => {
            if (!e._draftSaving && !e._saving) {
                o(), e._draftSaving = !0, WarehouseDrafts.setBusy(e, !0);
                try {
                    await f(e, a);
                    const t = await WarehouseDrafts.save(a);
                    Object.assign(a, t), n = JSON.stringify(t.payload), WarehouseDrafts.status(e, "المسودة متزامنة. المرفق محفوظ ويشارك عند إغلاق النموذج. لا تغيير في المخزون."), 
                    toast("تم حفظ مسودة الاستيراد");
                } catch (t) {
                    WarehouseDrafts.status(e, t.message + " — بقيت البيانات على هذا الجهاز.", !0);
                } finally {
                    WarehouseDrafts.setBusy(e, !1), e._draftSaving = !1;
                }
            }
        };
    }
    const g = "<style>#iiPreview .ii-line{border:1px solid var(--line,#8884);border-radius:12px;padding:8px;margin:8px 0;display:grid;gap:6px}#iiPreview .ii-line.bad{border-color:#d9822b;background:#d9822b14}#iiPreview .ii-row{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px}#iiPreview .ii-row label,#iiPreview .ii-tot label{display:grid;gap:2px;font-size:.78rem}#iiPreview .ii-row input,#iiPreview .ii-line>input{width:100%;min-width:0;box-sizing:border-box}#iiPreview .ii-tot{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:10px}#iiPreview .ii-tot input{width:100%;min-width:0;box-sizing:border-box}#iiPreview .ii-sum{display:flex;justify-content:space-between;gap:8px;font-weight:700}#iiPreview .ii-ok{color:#2e9d5b}#iiPreview .ii-warn{color:#d9822b;margin:4px 0}#iiPreview .ii-x{justify-self:end;padding:2px 10px}</style>", m = (t, i) => {
        const a = !1 === t.exact || !t.name;
        return '<div class="ii-line' + (a ? " bad" : "") + '" data-line="' + i + '"><input data-k="name" data-i="' + i + '" placeholder="اسم الصنف" value="' + e(t.name) + '"><div class="ii-row"><label>الكود<input data-k="sku" data-i="' + i + '" inputmode="numeric" value="' + e(t.sku) + '"></label><label>الكمية<input data-k="qty" data-i="' + i + '" inputmode="numeric" value="' + (t.qty??'') + '"></label><label>سعر الوحدة<input data-k="cost" data-i="' + i + '" inputmode="decimal" value="' + (t.cost===null||t.cost===undefined?'':(t.cost / 100).toFixed(2)) + '"></label><label>الإجمالي<input data-k="total" data-i="' + i + '" value="' + (t.qty * t.cost / 100).toFixed(2) + '" readonly></label></div>' + (a ? '<div class="ii-warn">راجع هذا البند مع الفاتورة</div>' : "") + '<button type="button" class="ii-x" data-del="' + i + '">حذف البند</button></div>';
    }, v = e => e.lines.reduce((e, t) => e + Math.round((Number(t.qty) || 0) * (Number(t.cost) || 0)), 0);
    function w(e) {
        const t = e._parsed, a = e.querySelector("#iiTotals");
        if (!a) return;
        const n = v(t), r = n - (t.discount || 0) + (t.extra || 0), o = r - (t.paid || 0);
        a.querySelector("#iiSub").textContent = i(n), a.querySelector("#iiFinal").textContent = i(r);
        const s = a.querySelector("#iiRem");
        s.textContent = i(o), s.className = o < 0 ? "ii-warn" : "";
        const l = e.querySelector("#iiCheck");
        l && (t.readTotal && Math.abs(t.readTotal - r) > 1 ? l.innerHTML = '<span class="ii-warn">إجمالي الفاتورة المقروء ' + i(t.readTotal) + " لا يطابق مجموع البنود " + i(r) + " — راجع الأسعار والكميات.</span>" : t.readTotal ? l.innerHTML = '<span class="ii-ok">✓ مجموع البنود يطابق إجمالي الفاتورة المكتوب (' + i(t.readTotal) + ")</span>" : l.textContent = "");
    }
    function y(t) {
        const a = t._parsed, n = (a.warnings || []).map(t => '<div class="ii-warn">' + e(t) + "</div>").join("");
        t.querySelector("#iiPreview").innerHTML = g + '<div class="grid"><label>المورد<input id="iiSupplier" value="' + e(a.supplier) + '"></label><label>رقم الفاتورة<input id="iiNo" value="' + e(a.no) + '"></label><label>التاريخ<input id="iiDate" type="date" value="' + e(a.date) + '"></label></div>' + (a.prevBalance ? '<p class="note">الرصيد السابق المكتوب في الفاتورة: <b>' + i(a.prevBalance) + "</b> — للعرض فقط ولا يدخل في حساب المورد.</p>" : "") + n + '<div class="grid"><label>عدد البنود المطبوع (إن وجد)<input id="iiExpectedLines" inputmode="numeric" value="' + e(a.expectedLines??'') + '"></label><label>إجمالي الكمية المطبوع (إن وجد)<input id="iiExpectedQuantity" inputmode="numeric" value="' + e(a.expectedQuantity??'') + '"></label></div><p class="note">' + (a.pageCount ? "الصفحات: " + a.pageCount + " · " : "") + "البنود: " + a.lines.length + " · مجموع الكميات: " + a.lines.reduce((e, t) => e + (Number(t.qty) || 0), 0) + "</p><h3>بنود الفاتورة (" + a.lines.length + ')</h3><div id="iiLines">' + a.lines.map(m).join("") + '</div><button type="button" id="iiAdd">＋ إضافة بند</button><div id="iiTotals" class="ii-tot"><div class="ii-sum" style="grid-column:1/-1"><span>مجموع البنود</span><span id="iiSub"></span></div><label>الخصم (ر.س)<input id="iiDiscount" inputmode="decimal" value="' + ((a.discount || 0) / 100).toFixed(2) + '"></label><label>الرسوم الإضافية (ر.س)<input id="iiExtra" inputmode="decimal" value="' + ((a.extra || 0) / 100).toFixed(2) + '"></label><div class="ii-sum" style="grid-column:1/-1"><span>الإجمالي النهائي</span><span id="iiFinal"></span></div><label>المدفوع (ر.س)<input id="iiPaid" inputmode="decimal" placeholder="0.00" value="' + (a.paid ? (a.paid / 100).toFixed(2) : "") + '"></label><div class="ii-sum" style="align-self:end"><span>المتبقي</span><span id="iiRem"></span></div></div><div id="iiCheck" class="note"></div>' + (a.unread?.length ? "<details open><summary>بنود تحتاج مراجعة (" + a.unread.length + ')</summary><pre style="white-space:pre-wrap">' + e(a.unread.join("\n")) + "</pre></details>" : "") + '<label class="check"><input id="iiIssuesReviewed" type="checkbox">راجعت البنود غير الواضحة وفروق الأسعار والإجمالي، إن وجدت</label><label class="check"><input id="iiReviewed" type="checkbox">راجعت جميع البنود والكميات والإجمالي مع الفاتورة الأصلية</label><details class="ii-read-details"><summary>عرض النص المقروء</summary><label class="full">النص المقروء<textarea id="iiRaw" rows="4">' + e(a.raw) + "</textarea></label></details>", 
        w(t), t.querySelector("#iiSave").disabled = !1;
        for (const [e, i] of Object.entries(a._headerEdit || {})) "lines" !== e && t.querySelector("#" + e) && (t.querySelector("#" + e).value = i);
        (a.lines || []).forEach((e, i) => {
            for (const [a, n] of Object.entries(e._edit || {})) {
                const e = t.querySelector('[data-line="' + i + '"] [data-k="' + a + '"]');
                e && (e.value = n);
            }
        }), t.querySelectorAll(".ii-line").forEach(e => {
            for (const t of e.querySelectorAll("input[data-k]")) {
                if ("LABEL" === t.parentElement.tagName) continue;
                const e = {
                    name: "اسم الصنف",
                    sku: "كود المورد",
                    qty: "الكمية",
                    cost: "سعر الوحدة (ر.س)",
                    total: "الإجمالي (ر.س)"
                }[t.dataset.k], i = document.createElement("label");
                i.append(document.createTextNode(e)), t.before(i), i.append(t);
            }
        });
    }
    function b(e) {
        const t = e.querySelector("#iiPreview");
        t.oninput = i => {
            const r = i.target, o = e._parsed;
            if (void 0 !== r.dataset.i) {
                const e = +r.dataset.i, i = r.dataset.k, s = o.lines[e];
                if (!s || "total" === i) return;
                "qty" === i ? s.qty = Number(a(r.value)) : "cost" === i ? s.cost = n(r.value) : s[i] = r.value, 
                s.exact = !0;
                const l = t.querySelector('[data-line="' + e + '"] [data-k="total"]');
                l && (l.value = (s.qty * s.cost / 100).toFixed(2));
            } else "iiDiscount" === r.id ? o.discount = n(r.value) : "iiExtra" === r.id ? o.extra = n(r.value) : "iiPaid" === r.id && (o.paid = n(r.value));
            if (void 0 !== r.dataset.i) {
                const e = o.lines[Number(r.dataset.i)];
                e && (e._edit = e._edit || {}, e._edit[r.dataset.k] = r.value);
            }
            w(e), e._cacheDraft?.();
        }, t.onclick = t => {
            const i = p(e);
            e._parsed._headerEdit = i.edit;
            for (const [t, a] of [ [ "supplier", "iiSupplier" ], [ "no", "iiNo" ], [ "date", "iiDate" ], [ "raw", "iiRaw" ] ]) e._parsed[t] = i.edit[a] ?? e._parsed[t] ?? "";
            e._parsed.lines.forEach((e, t) => e._edit = i.edit.lines[t]);
            const a = e._parsed;
            if ("iiAdd" === t.target.id) return a.lines.push({
                name: "",
                sku: "",
                qty: 1,
                cost: 0,
                total: 0,
                exact: !0
            }), y(e), void b(e);
            const n = t.target.closest("[data-del]");
            n && (a.lines.splice(+n.dataset.del, 1), y(e), b(e), e._cacheDraft?.());
        };
    }
    async function x(e, t, i) {
        if (e._saving || e._draftSaving) return;
        const a = "string" == typeof t ? null : i || e.querySelector("#iiFile").files[0];
        if (!a && "string" != typeof t) return;
        if(a&&a!==e._aiRequestFile){e._aiRequestId=IdFactory.uuid();e._aiRequestFile=a;}
        e._readAbort?.abort();e._readAbort=new AbortController();
        e.querySelector('#iiRetryRead').hidden=true;e.querySelector('#iiLocalRead').hidden=true;
        e._chosenFile = a && a.size <= 15728640 ? a : null;
        const n = e._readToken = (e._readToken || 0) + 1;
        if (e.querySelector("#iiSave").disabled = !0, e._parsed = null, e._file = null, 
        e.querySelector("#iiPreview").innerHTML = "", a && a.size > 15728640) o("حجم الملف كبير؛ الحد الأقصى 15 ميجابايت."); else {
            e._parsed = null, e._file = null, e.querySelector("#iiPreview").innerHTML = "", 
            o("جارٍ قراءة الفاتورة...");
            try {
                let i;
                if (i = "string" == typeof t ? InvoiceDocument.parseText(t) : e.querySelector('#iiEngine').value==='ai' ? await (async()=>{o('جارٍ استخراج جميع بنود الفاتورة بالقراءة الذكية…');if(!window.StoreSync?.readInvoice)throw Error('حدّث جميع ملفات الموقع لتفعيل القراءة الذكية');return StoreSync.readInvoice(await aiFile(a),e._aiRequestId,{signal:e._readAbort.signal});})() : "application/pdf" === a.type || /\.pdf$/i.test(a.name) ? await async function(e) {
                    if (!window.pdfjsLib) try {
                        window.pdfjsLib = await (import("./vendor/pdf.min.mjs"));
                    } catch (e) {
                        throw Error("تعذر فتح ملف PDF؛ حدّث الصفحة وحاول مرة أخرى");
                    }
                    pdfjsLib.GlobalWorkerOptions.workerSrc = "js/vendor/pdf.worker.min.mjs";
                    const t = await pdfjsLib.getDocument({
                        data: await e.arrayBuffer(),
                        isEvalSupported: !1,
                        cMapUrl: "js/vendor/cmaps/",
                        cMapPacked: !0,
                        standardFontDataUrl: "js/vendor/standard_fonts/"
                    }).promise;
                    if (t.numPages > 100) throw Error("الحد الأقصى 100 صفحة في المستند؛ قسّم الملف أولًا");
                    const i = [];
                    try {
                        for (let e = 1; e <= t.numPages; e++) {
                            o("قراءة صفحة " + e + " من " + t.numPages);
                            const a = await t.getPage(e), n = a.getViewport({
                                scale: 1
                            }), r = await a.getTextContent(), s = [];
                            for (const e of r.items) {
                                const t = e.str.split(/\s+/).filter(Boolean);
                                let i = e.transform[4], a = n.height - e.transform[5], r = e.width / Math.max(1, t.length), o = e.height || 12;
                                for (const e of t) s.push({
                                    text: e,
                                    x0: i,
                                    x1: i + r,
                                    y0: a - o,
                                    y1: a
                                }), i += r;
                            }
                            let l = InvoiceReviewCore.parseWords(s, n.width, n.height);
                            l.raw = r.items.map(e => e.str + (e.hasEOL ? "\n" : " ")).join("");
                            const d = InvoiceDocument.parseText(l.raw);
                            if (l.date = d.date, l.no = d.no, !l.lines.length || s.length < 12) {
                                const t = a.getViewport({
                                    scale: 1500 / n.width
                                }), i = document.createElement("canvas");
                                if (i.width = Math.round(t.width), i.height = Math.round(t.height), await a.render({
                                    canvasContext: i.getContext("2d"),
                                    viewport: t
                                }).promise, l = await c(i), !l) throw Error("تعذر قراءة الصفحة " + e + "؛ حاول بصورة أو ملف أوضح");
                                l.raw = l.rawText || "";
                            }
                            l.lines.length || (l.warnings = [ ...l.warnings || [], "لم تُقرأ أصناف هذه الصفحة؛ راجعها وأضف الناقص يدويًا" ]), 
                            i.push(l);
                        }
                        return InvoiceDocument.combine(i);
                    } finally {
                        await t.destroy();
                    }
                }(a) : await async function(e) {
                    return c(await async function(e) {
                        let t;
                        try {
                            t = await createImageBitmap(e, {
                                imageOrientation: "from-image"
                            });
                        } catch (i) {
                            t = await createImageBitmap(e);
                        }
                        try {
                            const e = Math.min(1.5, 1500 / t.width), i = document.createElement("canvas");
                            i.width = Math.max(1, Math.round(t.width * e)), i.height = Math.max(1, Math.round(t.height * e));
                            const a = i.getContext("2d", {
                                willReadFrequently: !0
                            });
                            return a.fillStyle = "#fff", a.fillRect(0, 0, i.width, i.height), a.imageSmoothingQuality = "high", 
                            a.drawImage(t, 0, 0, i.width, i.height), i;
                        } finally {
                            t.close?.();
                        }
                    }(e));
                }(a), !i) throw Error("تعذر قراءة الفاتورة. تحقق من الاتصال واختر صورة أوضح، أو أدخل البنود يدويًا");
                if (a && !i.lines?.length) throw Error("لم يتم التعرف على أي بند؛ أعد القراءة بصورة أوضح أو استخدم القراءة المحلية. لم تُحفظ فاتورة فارغة");
                if (i.raw = i.raw || i.rawText || "", i.supplier = i.supplier || "", i.no = i.no || "", 
                i.readTotal = i.readTotal || i.finalTotal || 0, i.prevBalance = i.balance || 0, 
                i.date = i.date || r(), i.discount = i.discount || 0, i.extra = i.extra || 0, i.paid = 0, 
                i.warnings = i.warnings || [], i.lines.length || i.warnings.push("لم تُقرأ البنود تلقائيًا؛ أضفها يدويًا ولا تعتمد المستند ناقصًا"), 
                i.lines.some(e => !e.exact) && i.warnings.push("البنود غير المتطابقة تحتاج مراجعة الكمية وسعر الوحدة"), 
                n !== e._readToken || !e.open || e._saving || e._draftSaving) return;
                e._parsed = i, e._file = a, o("اكتملت القراءة: " + i.lines.length + " بند" + (i.pageCount ? " في " + i.pageCount + " صفحة" : "") + ". راجع البنود والإجمالي قبل الحفظ."), 
                y(e), b(e), e._cacheDraft?.();
            } catch (t) {
                if(t.resetRequest)e._aiRequestId=IdFactory.uuid();
                if(n===e._readToken&&e.open&&a){e.querySelector("#iiRetryRead").hidden=false;e.querySelector("#iiLocalRead").hidden=e.querySelector("#iiEngine").value!=="ai";}
                if (n === e._readToken && e.open) {
                    o(t.message); e.querySelector("#iiSave").disabled = true;
                    e.querySelector("#iiProgress")?.scrollIntoView({block:"center",behavior:"smooth"});
                }
            }
        }
    }
    function S() {
        const i = document.getElementById("purchasesView");
        if (!i) return;
        const a = i.querySelector("#puNew");
        if (a && !i.querySelector("#iiOpen")) {
            const e = document.createElement("button");
            e.id = "iiOpen", e.textContent = "استيراد فاتورة", a.after(e), e.onclick = u;
        }
        const n = t().invoiceDocs.filter(e => !e.purchaseId).slice().reverse(), r = '<h3>الفواتير المصورة والمحفوظة</h3><p class="note">بيانات الفواتير تتزامن بين الأجهزة. الصور المشتركة تُحمّل عند فتحها، والصور المحلية تنتظر رفعها من جهازها الأصلي.</p>' + (n.length ? '<div class="table-wrap"><table class="rp-table"><thead><tr><th>المورد</th><th>رقم الفاتورة</th><th>التاريخ</th><th>البنود</th><th>الصورة</th><th></th></tr></thead><tbody>' + n.slice(0, 100).map(t => "<tr><td>" + e(t.supplier || "—") + "</td><td>" + e(t.no || "—") + "</td><td>" + e(t.date) + "</td><td>" + t.lines.length + "</td><td>" + (t.fileStorage ? "مشتركة" : t.hasFile ? "بانتظار الرفع" : "بدون مرفق") + '</td><td><button data-ii-view="' + e(t.id) + '">استعراض</button></td></tr>').join("") + "</tbody></table></div>" : '<p class="note">لا توجد فواتير مصورة محفوظة.</p>');
        let o = i.querySelector("#iiDocs");
        o || (o = document.createElement("div"), o.id = "iiDocs", o.className = "panel", 
        i.append(o)), o.innerHTML = r;
    }
    if (document.addEventListener("click", a => {
        const n = a.target.closest("[data-ii-view]");
        n && async function(a) {
            const n = t().invoiceDocs.find(e => e.id === a);
            if (!n) return;
            let r = document.getElementById("invoiceDocView");
            r || (r = document.createElement("dialog"), r.id = "invoiceDocView", r.dataset.syncSafe = "true", 
            r.className = "lg-dialog", document.body.append(r));
            const o = (n.lines || []).map(t => "<tr><td>" + e(t.name) + "</td><td>" + e(t.sku || "—") + "</td><td>" + (t.qty??'') + "</td><td>" + i(t.cost) + "</td></tr>").join("");
            r.innerHTML = '<div class="handle"></div><div class="dialoghead"><h2>فاتورة مستوردة</h2><button type="button" data-close="invoiceDocView">إغلاق</button></div><p class="note"><b>' + e(n.supplier || "بدون مورد") + "</b> · " + e(n.no || "بدون رقم") + " · " + e(n.date) + '</p><div class="table-wrap"><table class="rp-table"><thead><tr><th>الصنف</th><th>الكود</th><th>الكمية</th><th>التكلفة</th></tr></thead><tbody>' + o + "</tbody></table></div>" + (e => void 0 === e.total ? "" : '<div style="display:grid;gap:4px;margin:8px 0"><div>الإجمالي: <b>' + i(e.total) + "</b></div>" + (e.discount ? "<div>الخصم: <b>" + i(e.discount) + "</b></div>" : "") + (e.extra ? "<div>الإضافة: <b>" + i(e.extra) + "</b></div>" : "") + "<div>المدفوع: <b>" + i(e.paid || 0) + "</b></div><div>المتبقي: <b>" + i(void 0 !== e.remaining ? e.remaining : e.total - (e.paid || 0)) + "</b></div></div>")(n) + '<p class="note">هذه بيانات مستخرجة للمراجعة فقط ولم تُضَف للمخزون بعد. لتحديث الكمية والتكلفة فعليًا، افتح فاتورة شراء وأدخل البنود فيها.</p><div id="iiFileBox" class="note">جارٍ تحميل الملف الأصلي...</div><div class="footer"><button type="button" data-close="invoiceDocView">إغلاق</button>' + (window.LedgerUI && window.LedgerUI.openPurchase ? '<button type="button" class="primary" id="iiToPurchase">مطابقة الأصناف واعتماد الشراء</button>' : "") + "</div>", 
            r.showModal(), r.querySelector("#iiToPurchase") && (r.querySelector("#iiToPurchase").onclick = () => {
                r.close(), window.reviewImportedInvoice(n.id);
            });
            const s = r.querySelector("#iiFileBox");
            if (!n.hasFile && !n.fileData && !n.fileStorage) return void (s.textContent = "لا يوجد ملف مرفق بهذه الفاتورة.");
            let l;
            try {
                l = await InvoiceFiles.get(n);
            } catch (e) {
                return void (s.textContent = e.message);
            }
            if (!r.open) return;
            if (!l || !l.blob) return void (s.textContent = "الصورة لم تُرفع بعد. افتح الجهاز الذي رفع الفاتورة واختر «مشاركة صور هذا الجهاز» من المزامنة.");
            r._fileUrl && URL.revokeObjectURL(r._fileUrl);
            const d = URL.createObjectURL(l.blob);
            r._fileUrl = d, r.addEventListener("close", () => {
                r._fileUrl && (URL.revokeObjectURL(r._fileUrl), r._fileUrl = null);
            }, {
                once: !0
            });
            const c = /^image\//.test(l.meta?.type || n.fileType || "");
            s.innerHTML = (c ? '<img style="max-width:100%;max-height:55vh;object-fit:contain" src="' + d + '">' : "<p>ملف PDF: " + e(l.meta?.name || n.fileName || "") + "</p>") + '<div class="actions" style="margin-top:10px"><a id="iiDownload" class="primary" download="' + e(l.meta?.name || n.fileName || "فاتورة-" + n.id + ".jpg") + '" href="' + d + '">⬇ تنزيل الملف الأصلي</a></div>';
        }(n.dataset.iiView);
    }), window.addEventListener("store:synced", S), window.addEventListener("invoice:files", S), 
    window.addEventListener("ledger:refresh", S), window.addEventListener("store:committed", S), 
    "function" == typeof window.tab) {
        const e = window.tab;
        window.tab = function(t) {
            e(t), "purchases" === t && S();
        };
    }
    window.InvoiceImport = {
        open: u,
        openDraft: async function(e) {
            const t = u();
            if (t && (function(e, t) {
                if (e.querySelector("#iiPaste").value = t.paste || "", e._parsed = t.parsed ? JSON.parse(JSON.stringify(t.parsed)) : null, 
                e._parsed) {
                    y(e), b(e);
                    for (const [i, a] of Object.entries(t.edit || {})) "lines" !== i && e.querySelector("#" + i) && (e.querySelector("#" + i).value = a);
                    (t.edit?.lines || []).forEach((t, i) => {
                        for (const [a, n] of Object.entries(t)) {
                            const t = e.querySelector('[data-line="' + i + '"] [data-k="' + a + '"]');
                            t && (t.value = n);
                        }
                    }), e.querySelector("#iiSave").disabled = !1;
                }
            }(t, e.payload), h(t, e), e.hasFile || e.fileStorage)) try {
                const i = await InvoiceFiles.get(e);
                if (!t.open || t._warehouseDraft.id !== e.id) return;
                i?.blob ? (t._file = i.blob, t._chosenFile = i.blob, t._storedFile = i.blob, t.querySelector("#iiProgress").textContent = "الملف الأصلي محفوظ: " + (e.fileName || "فاتورة")) : WarehouseDrafts.status(t, "بيانات المسودة متاحة؛ افتح الجهاز الأصلي لرفع المرفق.", !0);
            } catch (e) {
                WarehouseDrafts.status(t, e.message, !0);
            }
        },
        capture: p
    }, setTimeout(S, 500);
}();
