/*! Alabqari Store 18.11.0 | App code rights reserved for the project owner. */
/*! العبقري ستور — أقسام الأصناف (منتجات / قطع غيار) والتعديل الجماعي السريع. */
(function () {
  "use strict";

  /* ---------------- sections ---------------- */
  const SECTION_KEY = "alabqari-wh-section-v1";
  const PART_CATEGORY = /شاش|بطاري|مدخل|مداخل|خلفي|فلكس|آي سي|اي سي|ايسي|بورد|كاميرا|سماعة داخلية|سماعات داخلية|قطع غيار|قطع متنوعة|أدوات ومستهلكات|تاتش|لمس/;
  const LABELS = { products: "منتجات", parts: "قطع غيار" };

  const CatalogSections = {
    of(item) {
      if (!item) return "products";
      if (item.section === "parts" || item.section === "products") return item.section;
      const hasModel = item.model || (Array.isArray(item.models) && item.models.length) || item.grade;
      return hasModel || PART_CATEGORY.test(String(item.category || "")) ? "parts" : "products";
    },
    label: (section) => LABELS[section] || "كل الأصناف",
    saved() {
      try {
        const v = localStorage.getItem(SECTION_KEY);
        return v === "parts" || v === "products" ? v : "";
      } catch (e) {
        return "";
      }
    },
    save(v) {
      try {
        localStorage.setItem(SECTION_KEY, v === "parts" || v === "products" ? v : "");
      } catch (e) {}
    },
    // Short label for a spare part inside a device's part list: "شاشة · KBS · Hard OLED" (model left out).
    partLabel(it) {
      const name = String(it?.name || "");
      const head = name.split(" · ")[0];
      const type = (head.match(/^[\u0600-\u06FF\s]+/) || [""])[0].trim();
      const model = (Array.isArray(it.models) && it.models[0]) || it.model || "";
      if (!type || type === head.trim() || !model || !head.includes(model)) return "";
      const rest = name.split(" · ").slice(1).join(" · ");
      return rest ? type + " · " + rest : type;
    },
    // Returns a short warning when the selling price would lose money, otherwise "".
    priceIssue(it) {
      if (!it || it.trackStock === false) return "";
      if (!it.price) return /أدوات ومستهلكات/.test(String(it.category || "")) ? "" : "بدون سعر بيع";
      if (it.cost > 0 && it.price < it.cost) return "أقل من سعر البضاعة";
      if (it.cost > 0 && it.price === it.cost) return "بدون ربح";
      return "";
    },
    // Order by when the item was added (createdAt), keeping the stored order for equal or missing dates.
    byAdded(list, all, newestFirst = true) {
      const pos = new Map((all || list).map((it, i) => [it.id, i]));
      const time = (it) => {
        const t = Date.parse(it.createdAt || "");
        return Number.isFinite(t) ? t : 0;
      };
      const dir = newestFirst ? -1 : 1;
      return list.sort((a, b) => {
        const ta = time(a),
          tb = time(b);
        if (ta && tb && ta !== tb) return dir * (ta - tb);
        return dir * ((pos.get(a.id) ?? 0) - (pos.get(b.id) ?? 0));
      });
    },
  };
  window.CatalogSections = CatalogSections;

  /* ---------------- helpers ---------------- */
  const h = (v) => (typeof esc === "function" ? esc(v) : String(v ?? ""));
  const sar = (v) => (typeof money === "function" ? money(v) : (v / 100).toFixed(2));
  const digitsOnly = (v) =>
    String(v ?? "")
      .replace(/[٠-٩]/g, (d) => "٠١٢٣٤٥٦٧٨٩".indexOf(d))
      .replace(/[۰-۹]/g, (d) => "۰۱۲۳۴۵۶۷۸۹".indexOf(d))
      .replace(/٫/g, ".")
      .replace(/[,،\s]/g, "")
      .trim();
  function num(v, label) {
    const t = digitsOnly(v);
    if (!/^\d+(?:\.\d+)?$/.test(t)) throw Error("أدخل رقمًا صحيحًا في «" + label + "»");
    return Number(t);
  }
  // dir: 1 when the price is going up, -1 when going down, 0 for a fixed value.
  function roundPrice(halalas, mode, dir = 0) {
    const pick = (step, offset = 0) => {
      const x = (halalas + offset) / step;
      const n = dir > 0 ? Math.ceil(x - 1e-9) : dir < 0 ? Math.floor(x + 1e-9) : Math.round(x);
      return n * step - offset;
    };
    if (mode === "riyal") return Math.max(0, pick(100));
    if (mode === "five") return Math.max(500, pick(500));
    if (mode === "nine") return Math.max(900, pick(1000, 100));
    return Math.round(halalas);
  }
  function priceOp(op, value, current, cost) {
    switch (op) {
      case "set":
        return value * 100;
      case "inc%":
        return current * (1 + value / 100);
      case "dec%":
        return current * (1 - value / 100);
      case "inc":
        return current + value * 100;
      case "dec":
        return current - value * 100;
      case "margin":
        return cost * (1 + value / 100);
      default:
        return current;
    }
  }

  /* ---------------- quick bulk edit dialog ---------------- */
  const dialog = document.createElement("dialog");
  dialog.id = "catalogBulk";
  dialog.className = "catalog-bulk";
  document.addEventListener("DOMContentLoaded", () => document.body.append(dialog));
  if (document.body) document.body.append(dialog);

  let target = [],
    afterSave = null;

  function categories() {
    return [...new Set((db.inventory?.items || []).map((i) => String(i.category || "").trim()).filter(Boolean))].sort((a, b) =>
      a.localeCompare(b, "ar"),
    );
  }
  function suppliers() {
    return [...new Set((db.inventory?.items || []).map((i) => String(i.supplier || "").trim()).filter(Boolean))].sort((a, b) =>
      a.localeCompare(b, "ar"),
    );
  }

  function readForm() {
    const f = dialog.querySelector("form").elements;
    const out = {};
    const priceOpV = f.priceOp.value;
    if (priceOpV) {
      out.price = { op: priceOpV, value: num(f.priceValue.value, "سعر البيع"), round: f.priceRound.value };
      if ((priceOpV === "dec%" || priceOpV === "inc%" || priceOpV === "margin") && out.price.value > 1000)
        throw Error("النسبة كبيرة جدًا");
    }
    const costOpV = f.costOp.value;
    if (costOpV) out.cost = { op: costOpV, value: num(f.costValue.value, "تكلفة الشراء") };
    if (f.section.value) out.section = f.section.value;
    const cat = f.category.value.replace(/\s+/g, " ").trim();
    if (cat) out.category = cat.slice(0, 200);
    const sup = f.supplier.value.replace(/\s+/g, " ").trim();
    if (sup) out.supplier = sup.slice(0, 200);
    if (f.clearSupplier.checked) out.supplier = "";
    if (f.min.value.trim() !== "") {
      const v = num(f.min.value, "حد التنبيه");
      if (!Number.isSafeInteger(v)) throw Error("حد التنبيه عدد صحيح");
      out.min = v;
    }
    if (f.warranty.value.trim() !== "") {
      const v = num(f.warranty.value, "الضمان");
      if (!Number.isSafeInteger(v) || v > 3650) throw Error("مدة الضمان من صفر إلى 3650 يومًا");
      out.warrantyDays = v;
    }
    if (f.track.value) out.trackStock = f.track.value === "on";
    return out;
  }

  function computeChanges(spec) {
    const changes = [];
    for (const item of target) {
      const next = {};
      if (spec.price) {
        const raw = priceOp(spec.price.op, spec.price.value, item.price || 0, item.cost || 0);
        const dir = spec.price.op === "set" ? 0 : Math.sign(raw - (item.price || 0));
        next.price = Math.max(0, roundPrice(raw, spec.price.round, dir));
        if (spec.price.op === "margin" && !item.cost) delete next.price;
      }
      if (spec.cost) {
        const raw = priceOp(spec.cost.op, spec.cost.value, item.cost || 0, item.cost || 0);
        next.cost = Math.max(0, Math.round(raw));
      }
      for (const k of ["section", "category", "supplier", "min", "warrantyDays", "trackStock"])
        if (k in spec) next[k] = spec[k];
      const diff = Object.keys(next).filter((k) =>
        k === "section" ? CatalogSections.of(item) !== next[k] : (item[k] ?? "") !== next[k],
      );
      if (diff.length) changes.push({ item, next, diff });
    }
    return changes;
  }

  function preview() {
    const box = dialog.querySelector("#cbPreview");
    const err = dialog.querySelector("#cbError");
    err.textContent = "";
    let spec;
    try {
      spec = readForm();
    } catch (e) {
      box.innerHTML = "";
      err.textContent = e.message;
      return null;
    }
    if (!Object.keys(spec).length) {
      box.innerHTML = '<p class="note">اختر التغيير المطلوب، وتظهر لك معاينة قبل الحفظ.</p>';
      return null;
    }
    const changes = computeChanges(spec);
    const skippedMargin = spec.price?.op === "margin" ? target.filter((i) => !i.cost).length : 0;
    const sample = changes.slice(0, 6);
    box.innerHTML =
      '<p class="cb-summary"><b>' +
      changes.length +
      "</b> صنف سيتغير من أصل " +
      target.length +
      (skippedMargin ? " · " + skippedMargin + " بدون تكلفة لن يتغير سعرها" : "") +
      "</p>" +
      (sample.length
        ? '<ul class="cb-sample">' +
          sample
            .map(
              (c) =>
                "<li><b>" +
                h(c.item.name) +
                "</b>" +
                c.diff
                  .map((k) => {
                    const from = k === "section" ? LABELS[CatalogSections.of(c.item)] : c.item[k];
                    const to = k === "section" ? LABELS[c.next[k]] : c.next[k];
                    const fmt = (v) =>
                      k === "price" || k === "cost"
                        ? sar(v || 0)
                        : k === "trackStock"
                          ? v === false
                            ? "متوقف"
                            : "مفعّل"
                          : h(v === "" || v === undefined ? "—" : v);
                    return "<span>" + FIELD[k] + ": " + fmt(from) + " ← " + fmt(to) + "</span>";
                  })
                  .join("") +
                "</li>",
            )
            .join("") +
          (changes.length > sample.length ? "<li class=\"note\">و" + (changes.length - sample.length) + " صنف آخر…</li>" : "") +
          "</ul>"
        : '<p class="note">لا يوجد صنف يحتاج تغيير بهذه القيم.</p>');
    return { spec, changes };
  }
  const FIELD = {
    price: "سعر البيع",
    cost: "التكلفة",
    section: "القسم",
    category: "الفئة",
    supplier: "المورد",
    min: "حد التنبيه",
    warrantyDays: "الضمان (يوم)",
    trackStock: "تتبع الكمية",
  };

  async function save() {
    const p = preview();
    if (!p) return;
    if (!p.changes.length) return toast("لا توجد تغييرات للحفظ");
    const btn = dialog.querySelector("#cbSave");
    btn.disabled = true;
    try {
      const next = copy();
      const byId = new Map(next.inventory.items.map((i, idx) => [i.id, idx]));
      for (const c of p.changes) {
        const idx = byId.get(c.item.id);
        if (idx === undefined) throw Error("صنف حُذف أثناء التعديل؛ حدّث الصفحة");
        const it = next.inventory.items[idx];
        for (const k of c.diff) it[k] = c.next[k];
        if (c.diff.includes("min")) it.alertMode = "manual";
      }
      const ok = await commitTransaction(next, { reason: "تعديل جماعي سريع للأصناف" });
      if (ok === false) return;
      dialog.close();
      toast("تم تعديل " + p.changes.length + " صنف");
      window.dispatchEvent(new Event("inventory:bulk-saved"));
      afterSave && afterSave();
    } catch (e) {
      dialog.querySelector("#cbError").textContent = e.message;
    } finally {
      btn.disabled = false;
    }
  }

  function bulk(items, done, allShown) {
    if (typeof can === "function" && !can("warehouseEdit")) return toast("ما عندك صلاحية لتعديل المستودع");
    target = (items || []).filter((i) => i && i.active !== false);
    afterSave = done || null;
    if (!target.length) return toast("لا توجد أصناف للتعديل. غيّر البحث أو حدد أصنافًا.");
    const showCost = typeof can !== "function" || can("costs");
    dialog.innerHTML =
      '<form method="dialog" class="panel"><div class="dialoghead"><div><h2>تعديل سريع · ' +
      target.length +
      " صنف</h2><p class=\"note\">" +
      (allShown
        ? "سيطبق التعديل على كل الأصناف المعروضة حسب القسم والبحث والفلاتر الحالية."
        : "سيطبق التعديل على الأصناف المحددة فقط.") +
      ' اترك أي حقل فارغًا ليبقى بدون تغيير.</p></div><button type="button" data-cb-close>إغلاق</button></div>' +
      '<div class="cb-grid">' +
      '<fieldset class="cb-field cb-wide"><legend>سعر البيع</legend><div class="cb-row"><select name="priceOp"><option value="">بدون تغيير</option><option value="set">تعيين سعر ثابت (ر.س)</option><option value="inc%">زيادة بنسبة %</option><option value="dec%">تخفيض بنسبة %</option><option value="inc">زيادة مبلغ (ر.س)</option><option value="dec">تخفيض مبلغ (ر.س)</option>' +
      (showCost ? '<option value="margin">التكلفة + نسبة ربح %</option>' : "") +
      '</select><input name="priceValue" inputmode="decimal" placeholder="القيمة"><select name="priceRound" aria-label="التقريب"><option value="">بدون تقريب</option><option value="riyal">لأقرب ريال</option><option value="five">لأقرب 5 ريال</option><option value="nine">ينتهي بـ 9 (مثل 49)</option></select></div></fieldset>' +
      (showCost
        ? '<fieldset class="cb-field cb-wide"><legend>تكلفة الشراء</legend><div class="cb-row"><select name="costOp"><option value="">بدون تغيير</option><option value="set">تعيين تكلفة ثابتة (ر.س)</option><option value="inc%">زيادة بنسبة %</option><option value="dec%">تخفيض بنسبة %</option></select><input name="costValue" inputmode="decimal" placeholder="القيمة"></div></fieldset>'
        : '<input type="hidden" name="costOp" value=""><input type="hidden" name="costValue" value="">') +
      '<label class="cb-field">القسم<select name="section"><option value="">بدون تغيير</option><option value="products">نقل إلى المنتجات</option><option value="parts">نقل إلى قطع الغيار</option></select></label>' +
      '<label class="cb-field">الفئة<input name="category" list="cbCats" placeholder="بدون تغيير"></label>' +
      '<label class="cb-field">المورد<input name="supplier" list="cbSups" placeholder="بدون تغيير"><span class="check"><input type="checkbox" name="clearSupplier"> مسح المورد</span></label>' +
      '<label class="cb-field">حد التنبيه (إعادة الطلب)<input name="min" inputmode="numeric" placeholder="بدون تغيير"></label>' +
      '<label class="cb-field">مدة الضمان بالأيام<input name="warranty" inputmode="numeric" placeholder="بدون تغيير"><small>365 = سنة · 730 = سنتين</small></label>' +
      '<label class="cb-field">تتبع الكمية<select name="track"><option value="">بدون تغيير</option><option value="on">تفعيل</option><option value="off">إيقاف (خدمات وباقات)</option></select></label>' +
      "</div>" +
      '<datalist id="cbCats">' +
      categories().map((c) => '<option value="' + h(c) + '">').join("") +
      '</datalist><datalist id="cbSups">' +
      suppliers().map((c) => '<option value="' + h(c) + '">').join("") +
      "</datalist>" +
      '<div id="cbPreview" class="cb-preview"></div><p id="cbError" class="error" role="alert"></p>' +
      '<div class="footer"><button type="button" data-cb-close>إلغاء</button><button type="button" class="primary" id="cbSave">حفظ التعديل</button></div></form>';
    dialog.querySelectorAll("[data-cb-close]").forEach((b) => (b.onclick = () => dialog.close()));
    const form = dialog.querySelector("form");
    form.addEventListener("input", preview);
    form.addEventListener("change", preview);
    form.addEventListener("submit", (e) => e.preventDefault());
    dialog.querySelector("#cbSave").onclick = save;
    preview();
    dialog.showModal();
  }

  /* ---------------- barcode labels from the products page ---------------- */
  const labelDlg = document.createElement("dialog");
  labelDlg.id = "catalogLabels";
  labelDlg.className = "catalog-bulk";
  if (document.body) document.body.append(labelDlg);
  document.addEventListener("DOMContentLoaded", () => document.body.append(labelDlg));
  const printable = (code) => /^[\x20-\x7e]+$/.test(String(code || "")) && String(code).trim().length > 0;
  const labelCode = (it) => (printable(it.barcode) ? it.barcode : printable(it.sku) ? it.sku : "");

  function labels(items) {
    const list = (items || []).filter((i) => i && i.active !== false).slice(0, 300);
    if (!list.length) return toast("لا توجد أصناف للطباعة. غيّر البحث أو حدد أصنافًا.");
    const qty = new Map(list.map((i) => [i.id, 1]));
    const missing = list.filter((i) => !labelCode(i)).length;
    const draw = () => {
      const total = [...qty.values()].reduce((a, b) => a + b, 0);
      labelDlg.querySelector("#lbTotal").textContent = total + " ملصق";
      labelDlg.querySelector("#lbPrint").disabled = !total || total > 1000;
    };
    labelDlg.innerHTML =
      '<form method="dialog" class="panel"><div class="dialoghead"><div><h2>طباعة باركود · ' +
      list.length +
      " صنف</h2><p class=\"note\">حدد عدد الملصقات لكل صنف. المقاس والقالب من صفحة «إعدادات الباركود»." +
      (missing ? " " + missing + " صنف بدون باركود؛ يُنشأ له باركود تلقائي ويُحفظ عند الطباعة." : "") +
      '</p></div><button type="button" data-lb-close>إغلاق</button></div>' +
      '<div class="lb-quick"><button type="button" data-lb-set="one">ملصق واحد لكل صنف</button><button type="button" data-lb-set="stock">عدد الملصقات = الكمية في المخزون</button><button type="button" data-lb-set="zero">تصفير</button></div>' +
      '<div class="lb-list">' +
      list
        .map(
          (i) =>
            '<label class="lb-row"><span><b>' +
            h(i.name) +
            "</b><small>" +
            h(labelCode(i) || "باركود جديد") +
            " · " +
            sar(i.price || 0) +
            (i.trackStock === false ? "" : " · المخزون " + (i.stock || 0)) +
            '</small></span><input type="number" min="0" max="500" inputmode="numeric" data-lb-qty="' +
            h(i.id) +
            '" value="1"></label>',
        )
        .join("") +
      '</div><p id="lbErr" class="error" role="alert"></p><div class="footer"><span id="lbTotal" class="note"></span><button type="button" data-lb-close>إلغاء</button><button type="button" class="primary" id="lbPrint">طباعة</button></div></form>';
    labelDlg.querySelectorAll("[data-lb-close]").forEach((b) => (b.onclick = () => labelDlg.close()));
    labelDlg.querySelector(".lb-quick").onclick = (e) => {
      const mode = e.target.closest("[data-lb-set]")?.dataset.lbSet;
      if (!mode) return;
      for (const i of list)
        qty.set(i.id, mode === "one" ? 1 : mode === "zero" ? 0 : Math.min(500, Math.max(0, i.trackStock === false ? 1 : i.stock || 0)));
      labelDlg.querySelectorAll("[data-lb-qty]").forEach((el) => (el.value = qty.get(el.dataset.lbQty)));
      draw();
    };
    labelDlg.querySelector(".lb-list").oninput = (e) => {
      const id = e.target.dataset.lbQty;
      id && qty.set(id, Math.max(0, Math.min(500, Math.floor(Number(digitsOnly(e.target.value)) || 0))));
      draw();
    };
    labelDlg.querySelector("#lbPrint").onclick = async () => {
      const btn = labelDlg.querySelector("#lbPrint");
      const err = labelDlg.querySelector("#lbErr");
      err.textContent = "";
      btn.disabled = true;
      try {
        const chosen = list.filter((i) => qty.get(i.id) > 0);
        const next = copy();
        const used = new Set();
        let changed = false;
        const lines = [];
        for (const src of chosen) {
          const it = next.inventory.items.find((x) => x.id === src.id);
          if (!it) continue;
          let code = labelCode(it);
          if (!code) {
            do code = window.Receipts?.genCode ? Receipts.genCode() : "2" + String(Date.now()).slice(-10);
            while (used.has(code));
            it.barcode = code;
            changed = true;
          }
          used.add(code);
          lines.push({ name: it.name, price: it.price || 0, qty: qty.get(src.id), code });
        }
        if (changed) {
          const ok = await commitTransaction(next, { reason: "إنشاء باركود للأصناف" });
          if (ok === false) throw Error("لم يتم حفظ الباركود الجديد؛ حاول مرة ثانية");
        }
        labelDlg.close();
        const html = Receipts.labelsHtml(lines);
        await (window.PrintService ? PrintService.send(html, db.settings.printerLabel) : browserPrint(html));
      } catch (e) {
        err.textContent = e.message || "تعذرت الطباعة";
      } finally {
        btn.disabled = false;
      }
    };
    draw();
    labelDlg.showModal();
  }

  window.CatalogPro = { bulk, labels, roundPrice, priceOp, computeChanges: (items, spec) => ((target = items), computeChanges(spec)) };

  /* ---------------- navigation label ---------------- */
  function relabel() {
    document.querySelectorAll('[data-tab="inventory"]').forEach((b) => {
      if (!b.textContent.includes("المنتجات والمخزون")) return;
      // change only the text, keep the icon markup intact
      const walker = document.createTreeWalker(b, NodeFilter.SHOW_TEXT);
      let node;
      while ((node = walker.nextNode()))
        node.nodeValue.includes("المنتجات والمخزون") &&
          (node.nodeValue = node.nodeValue.replace("المنتجات والمخزون", "المنتجات وقطع الغيار"));
      b.setAttribute("aria-label", "المنتجات وقطع الغيار");
    });
  }
  window.addEventListener("load", relabel);
  window.addEventListener("store:profile", () => setTimeout(relabel, 0));
  document.addEventListener("DOMContentLoaded", () => setTimeout(relabel, 0));
})();
