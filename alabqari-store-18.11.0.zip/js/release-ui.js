/*! Alabqari Store 18.9.7 | App code rights reserved for the project owner. */
/*! العبقري ستور — حقوق تطوير هذه النسخة محفوظة لصاحب المشروع. */
!function() {
    "use strict";
    const e = ReleaseCore, t = StoreData, o = esc, {dialog: r, addNav: n, makeView: a, registerTab: s} = LedgerUI, i = [ [ "customer", "اسم العميل" ], [ "phone", "رقم الجوال" ], [ "model", "الموديل" ], [ "issue", "العطل" ], [ "notes", "الملاحظات" ], [ "code", "رمز الباركود" ], [ "balance", "المتبقي" ], [ "date", "التاريخ" ] ], c = [ [ "standard", "اسم وباركود وسعر" ], [ "price", "السعر أولًا" ], [ "minimal", "مختصر" ], [ "shelf", "بطاقة الرف" ], [ "bordered", "إطار واضح" ], [ "split", "اسم وسعر جانبي" ] ], d = {
        standard: {
            width: 50,
            height: 25,
            fontSize: 9,
            padding: 1.5,
            barcodeHeight: 9,
            showName: !0,
            showPrice: !0,
            showCode: !0,
            showShop: !1
        },
        price: {
            width: 50,
            height: 30,
            fontSize: 10,
            padding: 1.5,
            barcodeHeight: 9,
            showName: !0,
            showPrice: !0,
            showCode: !0,
            showShop: !1
        },
        minimal: {
            width: 40,
            height: 20,
            fontSize: 8,
            padding: 1,
            barcodeHeight: 8,
            showName: !0,
            showPrice: !1,
            showCode: !0,
            showShop: !1
        },
        shelf: {
            width: 80,
            height: 35,
            fontSize: 12,
            padding: 2,
            barcodeHeight: 10,
            showName: !0,
            showPrice: !0,
            showCode: !0,
            showShop: !0
        },
        bordered: {
            width: 60,
            height: 30,
            fontSize: 10,
            padding: 2,
            barcodeHeight: 9,
            showName: !0,
            showPrice: !0,
            showCode: !0,
            showShop: !0
        },
        split: {
            width: 70,
            height: 30,
            fontSize: 10,
            padding: 1.5,
            barcodeHeight: 10,
            showName: !0,
            showPrice: !0,
            showCode: !0,
            showShop: !1
        }
    };
    function l(e) {
        if (!can(e)) throw Error("هذا الإجراء يحتاج صلاحية المدير أو صلاحية مخصصة للموظف");
    }
    function p(e, t, o = "application/json") {
        const r = new Blob([ t ], {
            type: o
        }), n = URL.createObjectURL(r), a = document.createElement("a");
        a.href = n, a.download = e, document.body.append(a), a.click(), a.remove(), setTimeout(() => URL.revokeObjectURL(n), 3e4);
    }
    function u(e, t) {
        $(e).textContent = t.message || String(t);
    }
    function h() {
        const t = e.activeShift(db);
        $("posShiftStatus") && ($("posShiftStatus").textContent = t ? "الصندوق مفتوح · رصيد الافتتاح " + money(t.opening) : "الصندوق مغلق"), 
        $("posOpenDrawer") && ($("posOpenDrawer").hidden = !!t, $("posOpenDrawer").disabled = !can("openDrawer")), 
        $("posDone") && ($("posDone").textContent = t ? "إتمام البيع" : "افتح الصندوق لإتمام البيع");
    }
    function m() {
        try {
            if (l("openDrawer"), e.activeShift(db)) return void toast("الصندوق مفتوح بالفعل");
            const o = r("cashDrawerDialog", "فتح صندوق الكاشير", '<p>أدخل النقد الموجود فعلًا في الصندوق عند بداية الوردية. يمكنك إدخال صفر.</p><form id="cashDrawerForm"><label>رصيد الافتتاح (ر.س)<input id="drawerOpening" inputmode="decimal" autocomplete="off" placeholder="0.00" value="0"></label><p class="error" id="drawerError" role="alert"></p><div class="footer"><button type="button" data-close="cashDrawerDialog">لاحقًا</button><button type="submit" class="primary">فتح الصندوق</button></div></form>');
            o.querySelector("form").onsubmit = async r => {
                r.preventDefault();
                try {
                    l("openDrawer");
                    const r = e.openShift(db, e.money($("drawerOpening").value.trim()||"0"), currentStaffLabel(), IdFactory.uuid(), (new Date).toISOString());
                    t.validate(r), await commitTransaction(r) && (o.close(), h(), toast("تم فتح الصندوق"));
                } catch (r) {
                    u("drawerError", r);
                }
            }, o.showModal(), $("drawerOpening").select();
        } catch (e) {
            toast(e.message);
        }
    }
    function b() {
        h(), setTimeout(() => {
            "pos" !== document.body.dataset.screen || e.activeShift(db) || !$("authGate").classList.contains("hidden") || document.querySelector("dialog[open]") || (can("openDrawer") ? m() : $("posErr") && ($("posErr").textContent = "الصندوق مغلق؛ يحتاج مستخدمًا لديه صلاحية فتح الصندوق"));
        }, 0);
    }
    function y() {
        document.querySelectorAll('main>section[id$="View"]').forEach(e => e.hidden = "barcodeSettingsView" !== e.id), 
        document.body.dataset.screen = "barcodeSettings", $("title").textContent = "إعدادات الباركود", 
        $("new").hidden = !0;
        const e = a("barcodeSettings");
        if (e.hidden = !1, !can("accounts")) return void (e.innerHTML = '<div class="panel">إعدادات الباركود تحتاج صلاحية الإدارة.</div>');
        const o = t.clone(db.settings), r = FlexCore.printing(db.settings), n = r.labels;
        let s = db.settings.labelFields;
        if (!Array.isArray(s)) try {
            s = JSON.parse(localStorage.getItem("alabqari-label-fields"));
        } catch (e) {}
        s = Array.isArray(s) ? s : i.map(([e]) => e);
        const p = (e, t, o, r, a) => "<label>" + t + '<input name="' + e + '" type="number" value="' + n[e] + '" min="' + o + '" max="' + r + '" step="' + a + '" required></label>';
        e.innerHTML = '<div class="panel"><div class="pro-panel-head"><div><h2>إعدادات الباركود</h2><p class="note">احفظ الاختيارات هنا مرة واحدة. الطباعة تستخدمها مباشرة.</p></div><button type="button" data-tab="settings">الإعدادات</button></div></div><div class="flex-print-grid"><form class="panel" id="barcodeSettingsForm"><h3>باركود المنتجات</h3><label>القالب<select name="style">' + c.map(([e, t]) => '<option value="' + e + '" ' + (n.style === e ? "selected" : "") + ">" + t + "</option>").join("") + '</select></label><button type="button" id="barcodePreset">تطبيق مقاس القالب المقترح</button><div class="grid">' + p("width", "العرض (مم)", 25, 120, .5) + p("height", "الطول (مم)", 15, 200, .5) + p("fontSize", "حجم الخط", 6, 14, .5) + p("padding", "الهامش الداخلي (مم)", .5, 4, .5) + p("barcodeHeight", "ارتفاع الباركود (مم)", 5, 25, .5) + '</div><div class="flex-checks">' + [ [ "showName", "اسم المنتج" ], [ "showPrice", "السعر" ], [ "showCode", "رقم الباركود" ], [ "showShop", "اسم المحل" ] ].map(([e, t]) => '<label class="check"><input name="' + e + '" type="checkbox" ' + (n[e] ? "checked" : "") + ">" + t + "</label>").join("") + '</div><h3>ملصق جهاز الصيانة</h3><label>تصميم ملصق الجهاز<select name="repairStyle">' + [ [ "informative", "تفصيلي" ], [ "receipt", "بطاقة إيصال" ], [ "compact", "مختصر" ] ].map(([e, t]) => '<option value="' + e + '" ' + (db.settings.labelStyle === e ? "selected" : "") + ">" + t + "</option>").join("") + '</select></label><div class="flex-checks">' + i.map(([e, t]) => '<label class="check"><input name="field_' + e + '" type="checkbox" ' + (s.includes(e) ? "checked" : "") + ">" + t + "</label>").join("") + '</div><p class="note">مقاس ملصق الصيانة 50 × 25 مم. اختر الحقول الضرورية حتى تبقى واضحة.</p><p class="error" id="barcodeError" role="alert"></p><div class="footer"><button type="button" id="barcodePreviewButton">تحديث المعاينة</button><button type="submit" class="primary">حفظ إعدادات الباركود</button></div></form><div class="panel"><h3>معاينة المنتج</h3><iframe id="barcodePreview" title="معاينة الباركود" sandbox="allow-same-origin"></iframe><p class="note">اضبط الطابعة على نفس المقاس، والطباعة بنسبة 100%.</p></div></div>';
        const h = $("barcodeSettingsForm"), m = () => {
            const e = {
                ...r.labels
            };
            for (const t of [ "width", "height", "fontSize", "padding", "barcodeHeight" ]) e[t] = Number(h.elements[t].value);
            e.style = h.elements.style.value;
            for (const t of [ "showName", "showPrice", "showCode", "showShop" ]) e[t] = h.elements[t].checked;
            const t = {
                ...r,
                labels: e
            };
            return FlexCore.validatePrinting(t), t;
        }, b = () => {
            try {
                $("barcodePreview").srcdoc = Receipts.labelsHtml([ {
                    name: "شاشة جوال أصلية",
                    code: "2001234567",
                    price: 15e3,
                    qty: 1
                } ], {
                    ...db.settings,
                    printing: m()
                }), $("barcodeError").textContent = "";
            } catch (e) {
                u("barcodeError", e);
            }
        };
        h.oninput = () => {
            h.dataset.syncDraft = "true", b();
        }, $("barcodePreviewButton").onclick = b, $("barcodePreset").onclick = () => {
            const e = d[h.elements.style.value];
            for (const t of [ "width", "height", "fontSize", "padding", "barcodeHeight" ]) h.elements[t].value = e[t];
            for (const t of [ "showName", "showPrice", "showCode", "showShop" ]) h.elements[t].checked = e[t];
            h.dataset.syncDraft = "true", b();
        }, h.onsubmit = async e => {
            e.preventDefault();
            try {
                if (l("accounts"), !t.equal(o, db.settings)) throw Error("تغيرت الإعدادات أثناء التحرير؛ افتح الصفحة من جديد");
                const e = copy();
                e.settings.printing = m(), e.settings.labelStyle = h.elements.repairStyle.value, 
                e.settings.labelFields = i.filter(([e]) => h.elements["field_" + e].checked).map(([e]) => e), 
                await commitTransaction(e) && (delete h.dataset.syncDraft, toast("تم حفظ الباركود؛ الطباعة تستخدم الاختيارات المحفوظة"), 
                y());
            } catch (e) {
                u("barcodeError", e);
            }
        }, b();
    }
    n("barcodeSettings", "إعدادات الباركود", "الباركود"), s("barcodeSettings", "إعدادات الباركود", y);
    const f = window.settings;
    function w() {
        try {
            l("resetAccounting");
            const o = copy(), n = PlatformCore.financialReport(o), a = r("accountingResetDialog", "بدء الحساب الفعلي", '<p class="error">سيتم حذف سجلات التجربة المالية من النسخة الحالية وبدء فترة حساب جديدة.</p><div class="pro-shift-summary"><div>الطلبات <strong>' + o.orders.length + "</strong></div><div>المبيعات <strong>" + money(n.netSales) + "</strong></div><div>المقبوض <strong>" + money(n.received) + '</strong></div></div><p>يشمل المبيعات والصيانة والمدفوعات والمرتجعات والمشتريات والمصروفات والورديات والجرد التجريبي والأرشيف المالي. المنتجات وكمياتها الحالية والعملاء والصلاحيات محفوظة.</p><p>حدّث جميع الأجهزة إلى 18.9.7 أولًا. الأجهزة التي تحمل بيانات قديمة ستحتاج استقبال السحابة قبل العمل.</p><button type="button" id="resetBackup">تنزيل النسخة الكاملة أولًا</button><label class="check"><input type="checkbox" id="resetBackupConfirmed">حفظت ملف النسخة الاحتياطية عندي</label><label>اكتب «تصفير» للتأكيد<input id="resetConfirm" autocomplete="off"></label><p class="error" id="resetError" role="alert"></p><div class="footer"><button type="button" data-close="accountingResetDialog">إلغاء</button><button type="button" class="danger" id="resetExecute" disabled>تصفير وبدء الحساب الفعلي</button></div>');
            let s = !1;
            $("resetBackup").onclick = async () => {
                s = !1, $("resetBackup").disabled = !0, i();
                try {
                    if (!window.BackupFiles?.buildComplete) throw Error("تعذر تحميل النسخ الاحتياطي؛ أعد فتح التطبيق");
                    const e = await BackupFiles.buildComplete(o);
                    p("alabqari-before-reset-" + (new Date).toISOString().replace(/[:.]/g, "-") + ".json", JSON.stringify(e, null, 2)), 
                    s = !0, $("resetError").textContent = "";
                } catch (e) {
                    u("resetError", e);
                } finally {
                    $("resetBackup").disabled = !1, i();
                }
            };
            const i = () => $("resetExecute").disabled = !(s && $("resetBackupConfirmed").checked && "تصفير" === $("resetConfirm").value.trim());
            a.oninput = i, $("resetExecute").onclick = async () => {
                try {
                    if (l("resetAccounting"), !s || !$("resetBackupConfirmed").checked || "تصفير" !== $("resetConfirm").value.trim()) throw Error("نزّل النسخة وأكد الحفظ والتصفير");
                    if (!t.equal(t.clean(o), t.clean(db))) throw Error("تغيرت البيانات؛ افتح نافذة التصفير مجددًا لتنزيل نسخة حديثة");
                    if (db._sync?.bound && window.StoreSync?.status().pending) throw Error("المزامنة لم تكتمل. أغلق النافذة، أكمل المزامنة، ثم ابدأ التصفير");
                    const r = e.resetAccounting(o, {
                        id: IdFactory.uuid(),
                        date: (new Date).toISOString(),
                        staff: currentStaffLabel()
                    });
                    t.validate(r), window.Recovery?.capture && await Recovery.capture("قبل بدء الحساب الفعلي", !0), 
                    await commitTransaction(r) && (a.close(), render(), window.POS?.refresh(), settings(), 
                    toast("بدأ الحساب الفعلي؛ أرقام وتقارير المبيعات صفر"), window.StoreSync?.sync());
                } catch (e) {
                    u("resetError", e);
                }
            }, a.showModal();
        } catch (e) {
            toast(e.message);
        }
    }
    function v() {
        try {
            if (!can("warehouseEdit") || !can("productImport")) throw Error("الاستيراد يحتاج صلاحية المخزون واستيراد المنتجات");
            const n = r("productImportDialog", "استيراد المنتجات بالكامل", '<p class="note">اختر Excel (.xlsx) أو CSV أو JSON. يستورد الاسم والكود والباركود والكمية وحد النقص وسعر البيع والتكلفة والتصنيف والموديل والمورد وخيارات المخزون والضمان. الحقول غير الموجودة في الملف تبقى كما هي عند التحديث. لا يتغير شيء قبل مراجعة واعتماد الدفعة.</p><div class="pro-actions"><button type="button" id="productTemplate">تنزيل نموذج CSV</button><button type="button" id="productExport">تصدير المنتجات بالكامل JSON</button></div><label>ملف المنتجات<input id="productImportFile" type="file" accept=".xlsx,.csv,.tsv,.json,text/csv,application/json,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"></label><label id="productSheetLabel" hidden>ورقة Excel<select id="productSheet"></select></label><label>طريقة الاستيراد<select id="productImportMode"><option value="update">إضافة الجديد وتحديث الموجود بالكود أو الباركود أو المعرف</option><option value="add">إضافة منتجات جديدة فقط</option></select></label><p class="note">الكمية في الملف هي الرصيد النهائي، وليست كمية إضافية. الكود والباركود يطابقان حرفيًا؛ احفظ أعمدة الباركود في Excel كنص لحفظ الأصفار الأولى.</p><div id="productImportSummary" aria-live="polite"></div><p class="error" id="productImportError" role="alert"></p><div id="productImportPreview"></div><div class="footer"><button type="button" data-close="productImportDialog">إلغاء</button><button type="button" class="primary" id="productImportApply" disabled>اعتماد جميع المنتجات</button></div>');
            n._fileRead = (n._fileRead || 0) + 1, n._saving = !1, n.addEventListener("cancel", e => {
                n._saving && e.preventDefault();
            });
            let a = null, s = null, i = null;
            $("productTemplate").onclick = () => {
                p("alabqari-products-template.csv", "\ufeff" + [ Object.keys(e.columns).map(t => e.columns[t].find(e => /[\u0621-\u064a]/.test(e)) || t), [ "", "شاشة تجريبية", "SCREEN001", "2000000001", "10", "2", "100.00", "60.00", "شاشات", "iPhone 13", "iPhone 13|iPhone 14", "أصلي", "مورد مثال", "", "iOS", "", "قطعة", "", "نعم", "لا", "30", "نعم" ] ].map(e => e.map(t.csvCell).join(",")).join("\r\n"), "text/csv;charset=utf-8");
            }, $("productExport").onclick = () => p("alabqari-products-" + (new Date).toISOString().slice(0, 10) + ".json", JSON.stringify({
                version: "18.9.7",
                moneyUnit: "halala",
                items: db.inventory.items
            }, null, 2));
            const c = () => {
                try {
                    a = e.products(s.sheets ? s.sheets[Number($("productSheet").value)].rows : s.rows, {
                        halalas: s.halalas
                    }), i = copy();
                    let r = null;
                    a.errors.length || (r = e.importProducts(i, a.rows, {
                        mode: $("productImportMode").value,
                        uuid: IdFactory.uuid,
                        date: (new Date).toISOString()
                    })), r && t.validate(r.state), $("productImportSummary").textContent = a.count + " صف · " + (r ? r.added + " جديد · " + r.updated + " تحديث" : a.errors.length + " صف يحتاج إصلاح"), 
                    $("productImportError").textContent = a.errors.map(e => "الصف " + e.row + ": " + e.message).slice(0, 20).join("\n"), 
                    $("productImportPreview").innerHTML = '<div class="table-wrap"><table class="rp-table"><thead><tr><th>الصف</th><th>المنتج</th><th>الكود</th><th>الباركود</th><th>الرصيد</th><th>سعر البيع</th><th>التكلفة</th></tr></thead><tbody>' + a.rows.slice(0, 150).map(e => "<tr><td>" + e._row + "</td><td>" + o(e.name) + "</td><td>" + o(e.sku || "") + "</td><td>" + o(e.barcode || "") + "</td><td>" + o(e.stock ?? "يبقى كما هو") + "</td><td>" + o(void 0 === e.price ? "يبقى كما هو" : money(e.price)) + "</td><td>" + o(void 0 === e.cost ? "يبقى كما هو" : money(e.cost)) + "</td></tr>").join("") + "</tbody></table></div>" + (a.count > 150 ? "<p>تعرض المعاينة أول 150 صفًا. الاعتماد يشمل جميع " + a.count + " صفًا.</p>" : ""), 
                    $("productImportApply").disabled = !!a.errors.length || !a.rows.length;
                } catch (e) {
                    $("productImportApply").disabled = !0, u("productImportError", e);
                }
            };
            $("productImportFile").onchange = async () => {
                const e = n._fileRead = (n._fileRead || 0) + 1;
                try {
                    $("productImportApply").disabled = !0, $("productImportSummary").textContent = "جارٍ قراءة الملف…";
                    const t = await ProductFiles.read($("productImportFile").files[0]);
                    if (e !== n._fileRead || !n.open) return;
                    s = t, $("productSheetLabel").hidden = !s.sheets, s.sheets && ($("productSheet").innerHTML = s.sheets.map((e, t) => '<option value="' + t + '">' + o(e.name) + " · " + (e.rows.length - 1) + " صف</option>").join("")), 
                    c();
                } catch (t) {
                    if (e !== n._fileRead || !n.open) return;
                    $("productImportSummary").textContent = "", u("productImportError", t);
                }
            }, $("productSheet").onchange = $("productImportMode").onchange = () => {
                s && c();
            }, $("productImportApply").onclick = async () => {
                if (!n._saving) {
                    n._saving = !0, window.WarehouseDrafts?.setBusy(n, !0);
                    try {
                        if (!can("warehouseEdit") || !can("productImport")) throw Error("ما عندك صلاحية الاستيراد");
                        if (!a || a.errors.length || !a.rows.length) throw Error("أصلح الملف قبل الاعتماد");
                        if (!t.equal(i.inventory.items, t.clone(db.inventory.items)) || !t.equal(i.inventory.moves, t.clone(db.inventory.moves))) throw Error("تغيرت المنتجات أثناء المراجعة؛ أعد اختيار الملف لمراجعة الأرصدة الحالية");
                        const o = e.importProducts(db, a.rows, {
                            mode: $("productImportMode").value,
                            uuid: IdFactory.uuid,
                            date: (new Date).toISOString()
                        });
                        t.validate(o.state), await commitTransaction(o.state) && (n.close(), renderInventory(), 
                        window.POS?.refresh(), toast("تم الاستيراد: " + o.added + " جديد و" + o.updated + " تحديث"));
                    } catch (e) {
                        u("productImportError", e);
                    } finally {
                        window.WarehouseDrafts?.setBusy(n, !1), n._saving = !1;
                    }
                }
            }, n.showModal();
        } catch (e) {
            toast(e.message);
        }
    }
    function g(n) {
        try {
            if (l("externalDeliver"), !e.activeShift(db)) return void m();
            const a = db.orders.find(e => e.id === n);
            if (!a) throw Error("الفاتورة غير موجودة");
            const s = {
                id: n,
                order: t.clone(a)
            }, i = total(a) - a.paid, c = a.devices.some(e => !OrderActionsCore.done(e) && "جاهز للاستلام" !== e.status), d = r("cashierDeliveryDialog", "تسليم وسداد كامل · #" + invoiceNo(n), "<p>" + o(a.name) + " · المتبقي المطلوب " + money(i) + '</p><p class="note">يسجّل المبلغ المتبقي مرة واحدة، ويحفظ التسليم وتاريخ بدء الضمان. المدفوع سابقًا محفوظ.</p><label>طريقة الدفع<select id="settleMethod"><option value="نقدًا">كاش</option><option value="شبكة">شبكة</option><option value="تحويل">تحويل</option></select></label>' + (c ? '<label class="check"><input type="checkbox" id="settleReady">راجعت الأجهزة وأؤكد أنها جاهزة للتسليم</label>' : "") + '<p class="error" id="settleError" role="alert"></p><div class="footer"><button type="button" data-close="cashierDeliveryDialog">إلغاء</button><button type="button" class="primary" id="settleExecute">تأكيد التسليم والسداد الكامل</button></div>');
            let p = !1;
            $("settleExecute").onclick = async () => {
                if (!p) {
                    p = !0, $("settleExecute").disabled = !0;
                    try {
                        if (l("externalDeliver"), !e.activeShift(db)) throw Error("الصندوق أُغلق؛ افتحه قبل التحصيل");
                        const o = e.settle(db, s, {
                            id: IdFactory.uuid(),
                            date: (new Date).toISOString(),
                            staff: currentStaffLabel(),
                            method: $("settleMethod").value,
                            ready: !c || $("settleReady").checked
                        });
                        t.validate(o), await commitTransaction(o) && (d.close(), render(), tab("invoices"), 
                        "repair" === PlatformCore.kind(a) && Receipts.deliveryDone(db.orders.find(e => e.id === n)), 
                        toast("تم السداد والتسليم؛ التحصيل مضاف للصندوق والتقارير"));
                    } catch (e) {
                        u("settleError", e);
                    } finally {
                        p = !1, $("settleExecute").disabled = !1;
                    }
                }
            }, d.showModal();
        } catch (e) {
            toast(e.message);
        }
    }
    function S() {
        const e = $("inventoryView");
        if (!e || e.hidden || e.querySelector("#productImportOpen")) return;
        const t = document.createElement("button");
        t.id = "productImportOpen", t.type = "button", t.textContent = "استيراد المنتجات بالكامل", 
        t.onclick = v, t.disabled = !can("warehouseEdit") || !can("productImport"), (e.querySelector(".lg-head,.warehouse-toolbar,.pro-panel-head") || e).prepend(t);
    }
    window.settings = function() {
        f(), function() {
            const t = $("settingsView");
            if (!t) return;
            if (t.querySelector("#releaseSettings")?.remove(), !can("accounts")) {
                const e = t.querySelector("#settingsForm");
                if (e) {
                    for (const t of e.elements) t.disabled = !0;
                    const t = document.createElement("p");
                    t.className = "note", t.textContent = "تعديل إعدادات المحل يتطلب صلاحية الإدارة.", 
                    e.prepend(t);
                }
                return;
            }
            const o = e.cashier(db.settings), r = document.createElement("div");
            r.id = "releaseSettings", r.className = "panel", r.innerHTML = '<h2>تشغيل الكاشير</h2><form id="cashierSettingsForm"><div class="grid"><label>ظهور المنتجات<select name="catalogMode"><option value="disabled">غير مفعّل · البحث والباركود فقط</option><option value="button">زر يعرض ويخفي المنتجات</option><option value="always">المنتجات ظاهرة دائمًا</option></select></label><label>طريقة عرض المنتجات<select name="catalogLayout"><option value="grid">بطاقات</option><option value="list">قائمة</option></select></label></div><div class="footer"><button type="submit" class="primary">حفظ خيارات الكاشير</button></div><p class="error" id="cashierSettingsError"></p></form><div class="pro-actions"><button type="button" data-tab="barcodeSettings">إعدادات الباركود</button><button type="button" data-tab="printStudio">قوالب الفواتير</button><button type="button" id="settingsProductImport">استيراد المنتجات</button></div>' + (can("resetAccounting") ? '<hr><h3>بدء الحساب الفعلي</h3><p class="note">تصفير أرقام الطلبات والمبيعات والمقبوض والتقارير وبيانات التجربة المالية، مع حفظ المنتجات والكميات الحالية والعملاء والإعدادات. تُنزّل نسخة كاملة قبل التنفيذ.</p><button type="button" class="danger" id="accountingResetOpen">تصفير بيانات التجربة</button>' : ""), 
            t.prepend(r);
            const n = $("cashierSettingsForm");
            n.elements.catalogMode.value = o.catalogMode, n.elements.catalogLayout.value = o.catalogLayout, 
            n.oninput = () => n.dataset.syncDraft = "true", n.onsubmit = async e => {
                e.preventDefault();
                try {
                    l("accounts");
                    const e = copy();
                    e.settings.cashier = {
                        catalogMode: n.elements.catalogMode.value,
                        catalogLayout: n.elements.catalogLayout.value
                    }, await commitTransaction(e) && (delete n.dataset.syncDraft, window.POS?.refresh(), 
                    toast("تم حفظ خيارات الكاشير"));
                } catch (e) {
                    u("cashierSettingsError", e);
                }
            }, $("settingsProductImport").onclick = v, $("accountingResetOpen")?.addEventListener("click", w);
            for (const e of [ "labelStyle" ]) t.querySelector("#settingsForm")?.elements.namedItem(e)?.closest("label")?.setAttribute("hidden", "");
        }();
    }, document.addEventListener("click", e => {
        const t = e.target.closest("[data-settle]");
        t && g(Number(t.dataset.settle)), e.target.closest('[data-tab="inventory"]') && setTimeout(S, 0);
    });
    const E = window.tab;
    window.tab = function(e) {
        E(e), "inventory" === e && S(), "pos" === e && h();
    };
    for (const e of [ "store:committed", "store:synced", "ledger:refresh" ]) window.addEventListener(e, () => {
        h(), S(), "store:synced" === e && "pos" === document.body.dataset.screen && (window.POS?.refresh(), 
        b());
    });
    let k = !1, I = 0, x = "";
    new MutationObserver(() => {
        const e = !!document.querySelector("dialog[open]");
        e && !k ? (k = !0, I = window.scrollY, x = document.body.getAttribute("style") || "", 
        document.body.style.position = "fixed", document.body.style.top = -I + "px", document.body.style.left = "0", 
        document.body.style.right = "0", document.body.style.width = "100%", document.body.classList.add("modal-locked"), 
        document.documentElement.classList.add("modal-locked")) : !e && k && (k = !1, document.body.setAttribute("style", x), 
        document.body.classList.remove("modal-locked"), document.documentElement.classList.remove("modal-locked"), 
        window.scrollTo(0, I));
    }).observe(document.body, {
        subtree: !0,
        attributes: !0,
        attributeFilter: [ "open" ],
        childList: !0
    }), document.addEventListener("touchmove", e => {
        k && !e.target.closest("dialog[open]") && e.preventDefault();
    }, {
        passive: !1
    }), window.ReleaseUI = {
        openDrawer: m,
        cashierEntered: b,
        shiftStatus: h,
        barcodeSettings: y,
        productImport: v,
        accountingReset: w,
        settle: g
    };
}();
