/*! Alabqari Store 18.9.7 | Customer name and mobile lookup. */
(function (root) {
  'use strict';
  const CASH_PHONE = '966500000000';
  function digits(value) {
    return String(value ?? '').replace(/[٠-٩]/g, ch => String('٠١٢٣٤٥٦٧٨٩'.indexOf(ch)))
      .replace(/[۰-۹]/g, ch => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(ch)));
  }
  function text(value) {
    return digits(value).normalize('NFKC').toLowerCase()
      .replace(/[\u0610-\u061a\u064b-\u065f\u0670\u06d6-\u06ed\u0640\u200e\u200f\u202a-\u202e\u2066-\u2069]/g, '')
      .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/\s+/g, ' ').trim();
  }
  function phone(value) {
    let result = digits(value).replace(/[^0-9]/g, '');
    if (result.startsWith('00966')) result = result.slice(2);
    if (/^05\d{8}$/.test(result)) result = '966' + result.slice(1);
    else if (/^5\d{8}$/.test(result)) result = '966' + result;
    return /^9665\d{8}$/.test(result) && result !== CASH_PHONE ? result : '';
  }
  function matches(customer, query) {
    const name = text(customer?.name);
    const canonical = phone(customer?.phone);
    const forms = canonical ? [canonical, '00' + canonical, '0' + canonical.slice(3), canonical.slice(3)] : [];
    const needle = text(query);
    if (!needle) return true;
    // Treat a formatted telephone number as one query, rather than loose digits.
    if (/^[\d\s+().-]+$/.test(needle)) {
      const compact = needle.replace(/[^0-9]/g, '');
      return !!compact && forms.some(value => value.includes(compact));
    }
    return needle.split(' ').every(part => name.includes(part) || (/^\d+$/.test(part) && forms.some(value => value.includes(part))));
  }
  function rows(database) {
    const customers = new Map();
    const add = (item, preferred) => {
      const mobile = phone(item?.phone);
      const name = String(item?.name ?? '').trim();
      if (!mobile || !name) return;
      const previous = customers.get(mobile);
      if (!previous || preferred || String(item.updated || item.created || '') > previous.updated) {
        customers.set(mobile, {name, phone: mobile, updated: String(item.updated || item.created || '')});
      }
    };
    for (const order of [...(database?.orders || []), ...(database?.settings?.platform?.financialArchive || [])]) add(order, false);
    for (const customer of Object.values(database?.settings?.customerDirectory || {})) add(customer, true);
    return Array.from(customers.values()).sort((a, b) => a.name.localeCompare(b.name, 'ar') || a.phone.localeCompare(b.phone));
  }
  function search(database, query, limit = 8) {
    if (!text(query)) return {rows: [], total: 0};
    const found = rows(database).filter(customer => matches(customer, query));
    return {rows: found.slice(0, Math.max(1, Math.min(50, limit))), total: found.length};
  }
  const api = Object.freeze({digits, text, phone, matches, rows, search});
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.CustomerSearchCore = api;
})(typeof window === 'undefined' ? globalThis : window);
