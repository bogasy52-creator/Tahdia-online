/*! Alabqari Store 18.11.0 | App code rights reserved for the project owner. */
/*! العبقري ستور — ربط طابعة الفواتير وطابعة الباركود للطباعة المباشرة عبر QZ Tray. */
(function () {
  "use strict";
  const CERT = "alabqari-qz-cert-v1",
    KEY = "alabqari-qz-key-v1",
    MODE = "alabqari-print-mode";
  const ls = {
    get: (k) => {
      try {
        return localStorage.getItem(k) || "";
      } catch (e) {
        return "";
      }
    },
    set: (k, v) => {
      try {
        v ? localStorage.setItem(k, v) : localStorage.removeItem(k);
      } catch (e) {}
    },
  };
  const h = (v) => (typeof esc === "function" ? esc(v) : String(v ?? ""));
  const desktop = () => !/Android|iPhone|iPad|iPod/i.test(navigator.userAgent);

  /* ---------- signing (removes the QZ "allow" pop-ups) ---------- */
  function pemBody(pem) {
    return atob(
      String(pem)
        .replace(/-----[^-]+-----/g, "")
        .replace(/\s+/g, ""),
    );
  }
  const bytes = (bin) => Uint8Array.from(bin, (c) => c.charCodeAt(0));
  function derLen(n) {
    if (n < 128) return [n];
    const out = [];
    while (n) out.unshift(n & 255), (n >>= 8);
    return [128 | out.length, ...out];
  }
  // PKCS#1 "RSA PRIVATE KEY" → PKCS#8 so WebCrypto can import it
  function pkcs1to8(pkcs1) {
    const algo = [0x30, 0x0d, 0x06, 0x09, 0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01, 0x01, 0x05, 0x00];
    const octet = [0x04, ...derLen(pkcs1.length), ...pkcs1];
    const body = [0x02, 0x01, 0x00, ...algo, ...octet];
    return new Uint8Array([0x30, ...derLen(body.length), ...body]);
  }
  let keyPromise = null;
  function signingKey() {
    if (keyPromise) return keyPromise;
    const pem = ls.get(KEY);
    if (!pem) return Promise.resolve(null);
    let der = bytes(pemBody(pem));
    if (/BEGIN RSA PRIVATE KEY/.test(pem)) der = pkcs1to8(der);
    keyPromise = crypto.subtle
      .importKey("pkcs8", der, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-512" }, false, ["sign"])
      .catch((e) => {
        keyPromise = null;
        throw Error("ملف المفتاح غير صالح");
      });
    return keyPromise;
  }
  async function sign(text) {
    const key = await signingKey();
    const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(text));
    let bin = "";
    new Uint8Array(sig).forEach((b) => (bin += String.fromCharCode(b)));
    return btoa(bin);
  }
  async function secure(qz) {
    if (!qz || qz.__alabqariSecured) return;
    const cert = ls.get(CERT);
    if (!cert || !ls.get(KEY) || !crypto?.subtle) return;
    qz.security.setCertificatePromise((resolve) => resolve(cert));
    qz.security.setSignatureAlgorithm && qz.security.setSignatureAlgorithm("SHA512");
    qz.security.setSignaturePromise((toSign) => (resolve, reject) => sign(toSign).then(resolve, reject));
    qz.__alabqariSecured = true;
  }

  /* ---------- setup dialog ---------- */
  const dlg = document.createElement("dialog");
  dlg.id = "printerSetup";
  dlg.className = "catalog-bulk printer-setup";
  document.body.append(dlg);

  function sampleInvoice() {
    const w = (window.PrintLayout && PrintLayout.layout?.().width) || 72;
    return (
      '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>@page{size:80mm 60mm;margin:0}body{margin:0;width:' +
      w +
      'mm;font:13px Tahoma,Arial,sans-serif;text-align:center;padding:4mm}h2{margin:0 0 2mm}</style></head><body><h2>' +
      h(db.settings.shop || "العبقري ستور") +
      "</h2><p>تجربة طابعة الفواتير</p><p>" +
      new Date().toLocaleString("ar-SA-u-nu-latn") +
      "</p><p>✓ الطباعة المباشرة تعمل</p></body></html>"
    );
  }
  function sampleLabel() {
    return Receipts.labelsHtml([{ name: "تجربة ملصق باركود", code: "2000000000017", price: 1000, qty: 1 }]);
  }

  async function render() {
    const mode = window.PrintService?.mode?.() || "browser";
    const hasCert = !!(ls.get(CERT) && ls.get(KEY));
    dlg.innerHTML =
      '<div class="panel"><div class="dialoghead"><div><h2>ربط الطابعات مباشرة</h2><p class="note">الفواتير تطلع على طابعة الفواتير، والباركود على طابعة الباركود، بدون نافذة الطباعة. يحتاج برنامج QZ Tray المجاني على كمبيوتر الكاشير مرة وحدة.</p></div><button type="button" data-ps-close>إغلاق</button></div>' +
      (desktop()
        ? ""
        : '<p class="error">الطباعة المباشرة تشتغل من كمبيوتر ويندوز أو ماك. على الجوال تفتح نافذة الطباعة العادية.</p>') +
      '<ol class="ps-steps">' +
      '<li><b>ثبّت QZ Tray</b> من موقع qz.io/download وشغّله (يطلع شعاره جنب الساعة).<div class="ps-row"><span id="psStatus" class="ps-status">لم يُفحص</span><button type="button" id="psCheck">فحص الاتصال</button></div></li>' +
      '<li><b>شيل نافذة «السماح» عند كل طباعة:</b> من أيقونة QZ Tray اختر Advanced ثم Site Manager، اضغط + ثم Create New ووافق على الخيارات. بيطلع لك مجلد «QZ Tray Demo Cert» على سطح المكتب. ارفع الملفين اللي فيه هنا:<div class="ps-row"><label class="rw-file ps-file"><input type="file" id="psFiles" multiple accept=".txt,.pem,.crt,.key"><span>' +
      (hasCert ? "✓ الشهادة محفوظة على هذا الجهاز · استبدال" : "رفع digital-certificate.txt و private-key.pem") +
      "</span></label>" +
      (hasCert ? '<button type="button" id="psClearCert">حذف الشهادة</button>' : "") +
      "</div></li>" +
      '<li><b>اختر كل طابعة لشغلها:</b><div class="ps-grid"><label>طابعة الفواتير<select id="psInvoice"></select></label><label>طابعة الباركود<select id="psLabel"></select></label></div><div class="ps-row"><button type="button" id="psFind">تحديث قائمة الطابعات</button><button type="button" id="psTestInvoice">تجربة فاتورة</button><button type="button" id="psTestLabel">تجربة باركود</button></div></li>' +
      "</ol>" +
      '<label class="check ps-toggle"><input type="checkbox" id="psAuto"' +
      ("auto" === mode ? " checked" : "") +
      "> الطباعة المباشرة مفعّلة على هذا الجهاز</label>" +
      '<p class="note">إذا QZ Tray مقفل أو الطابعة مفصولة، البرنامج يفتح نافذة الطباعة العادية بدال ما توقف الفاتورة.</p>' +
      '<p id="psError" class="error" role="alert"></p><div class="footer"><button type="button" data-ps-close>إلغاء</button><button type="button" class="primary" id="psSave">حفظ</button></div></div>';
    dlg.querySelectorAll("[data-ps-close]").forEach((b) => (b.onclick = () => dlg.close()));
    fillPrinters([]);
    dlg.querySelector("#psCheck").onclick = () => connect(true);
    dlg.querySelector("#psFind").onclick = () => connect(true);
    dlg.querySelector("#psFiles").onchange = loadFiles;
    dlg.querySelector("#psClearCert") &&
      (dlg.querySelector("#psClearCert").onclick = () => {
        ls.set(CERT, "");
        ls.set(KEY, "");
        keyPromise = null;
        window.qz && (window.qz.__alabqariSecured = false);
        toast("حُذفت الشهادة من هذا الجهاز");
        render();
      });
    dlg.querySelector("#psTestInvoice").onclick = () => test("invoice");
    dlg.querySelector("#psTestLabel").onclick = () => test("label");
    dlg.querySelector("#psSave").onclick = save;
  }

  function fillPrinters(list) {
    const pick = (id, current) => {
      const el = dlg.querySelector(id);
      const names = [...new Set([current, ...list].filter(Boolean))];
      el.innerHTML =
        '<option value="">— اختر —</option>' +
        names.map((n) => '<option value="' + h(n) + '"' + (n === current ? " selected" : "") + ">" + h(n) + (list.length && !list.includes(n) ? " (غير موجودة)" : "") + "</option>").join("");
    };
    pick("#psInvoice", db.settings.printerInvoice || "");
    pick("#psLabel", db.settings.printerLabel || "");
  }

  async function connect(showErrors) {
    const st = dlg.querySelector("#psStatus");
    const err = dlg.querySelector("#psError");
    st && ((st.textContent = "جاري الاتصال…"), (st.className = "ps-status"));
    err && (err.textContent = "");
    try {
      const qz = await window.PrinterBridge.qz();
      const list = await qz.printers.find();
      st && ((st.textContent = "متصل ✓ · " + list.length + " طابعة"), (st.className = "ps-status ok"));
      dlg.open && fillPrinters(Array.isArray(list) ? list : [list]);
      return true;
    } catch (e) {
      st && ((st.textContent = "غير متصل"), (st.className = "ps-status bad"));
      showErrors &&
        err &&
        (err.textContent =
          "ما قدرت أتصل بـ QZ Tray. تأكد إنه مثبت وشغّال، وإذا طلع لك سؤال «السماح» اضغط Allow. (" + (e.message || e) + ")");
      return false;
    }
  }

  async function loadFiles(e) {
    const err = dlg.querySelector("#psError");
    err.textContent = "";
    try {
      let cert = "",
        key = "";
      for (const f of e.target.files) {
        if (f.size > 20000) throw Error("الملف " + f.name + " كبير؛ تأكد إنه ملف الشهادة");
        const t = await f.text();
        /BEGIN CERTIFICATE/.test(t) && (cert = t.trim());
        /PRIVATE KEY/.test(t) && (key = t.trim());
      }
      if (!cert && !ls.get(CERT)) throw Error("ما لقيت ملف الشهادة digital-certificate.txt");
      if (!key && !ls.get(KEY)) throw Error("ما لقيت ملف المفتاح private-key.pem");
      cert && ls.set(CERT, cert);
      if (key) {
        ls.set(KEY, key);
        keyPromise = null;
        await signingKey();
      }
      window.qz && (window.qz.__alabqariSecured = false);
      try {
        window.qz?.websocket?.isActive() && (await window.qz.websocket.disconnect());
      } catch (x) {}
      toast("حُفظت الشهادة على هذا الجهاز");
      await render();
      connect(true);
    } catch (x) {
      err.textContent = x.message;
    }
  }

  async function test(kind) {
    const err = dlg.querySelector("#psError");
    err.textContent = "";
    const name = dlg.querySelector(kind === "label" ? "#psLabel" : "#psInvoice").value;
    if (!name) return (err.textContent = "اختر الطابعة أولًا");
    const prevMode = ls.get(MODE);
    ls.set(MODE, "auto"); // the test always tries the direct route
    try {
      const res = await window.autoPrinterPrint(name, kind === "label" ? sampleLabel() : sampleInvoice());
      if (res?.status === "sent") toast("أُرسلت التجربة إلى " + name);
      else if (res?.status === "browser") err.textContent = "الطباعة المباشرة تشتغل من الكمبيوتر فقط";
      else err.textContent = res?.message || "تعذرت التجربة";
    } catch (e) {
      err.textContent = e.message;
    } finally {
      ls.set(MODE, prevMode);
    }
  }

  async function save() {
    const err = dlg.querySelector("#psError");
    const inv = dlg.querySelector("#psInvoice").value;
    const lab = dlg.querySelector("#psLabel").value;
    const auto = dlg.querySelector("#psAuto").checked;
    if (auto && (!inv || !lab)) return (err.textContent = "اختر طابعة الفواتير وطابعة الباركود قبل تفعيل الطباعة المباشرة");
    try {
      if (inv !== (db.settings.printerInvoice || "") || lab !== (db.settings.printerLabel || "")) {
        const next = copy();
        next.settings.printerInvoice = inv;
        next.settings.printerLabel = lab;
        const ok = await commitTransaction(next, { reason: "ربط الطابعات" });
        if (ok === false) return;
      }
      ls.set(MODE, auto ? "auto" : "browser");
      const sel = document.getElementById("devicePrintMode");
      sel && (sel.value = auto ? "auto" : "browser");
      dlg.close();
      toast(auto ? "الطباعة المباشرة مفعّلة على هذا الجهاز" : "تم الحفظ");
    } catch (e) {
      err.textContent = e.message;
    }
  }

  async function open() {
    await render();
    dlg.showModal();
    desktop() && connect(false);
  }

  /* ---------- entry points ---------- */
  function addButton() {
    const sel = document.getElementById("devicePrintMode");
    const box = sel?.closest(".panel") || sel?.parentElement?.parentElement;
    if (!box || box.querySelector("#psOpen")) return;
    const b = document.createElement("button");
    b.type = "button";
    b.id = "psOpen";
    b.className = "primary";
    b.textContent = "ربط الطابعات مباشرة (فاتورة + باركود)";
    b.onclick = open;
    (box.querySelector(".pro-actions") || box).prepend(b);
  }
  const prevTab = window.tab;
  window.tab = function (t) {
    prevTab.apply(this, arguments);
    ("settings" === t || "printStudio" === t || "barcodeSettings" === t) && setTimeout(addButton, 0);
  };

  // warm-up: connect in the background so the first invoice prints without waiting
  window.addEventListener("load", () => {
    if (!desktop() || window.PrintService?.mode?.() !== "auto") return;
    setTimeout(() => window.PrinterBridge?.qz().catch(() => {}), 2500);
  });

  window.PrinterSetup = { secure, open, sign };
})();
