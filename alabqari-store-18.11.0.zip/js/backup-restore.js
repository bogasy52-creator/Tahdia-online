/*! Alabqari Store 18.9.7 | App code rights reserved for the project owner. */
/*! العبقري ستور — حقوق تطوير هذه النسخة محفوظة لصاحب المشروع. */
!function() {
    "use strict";
    const e = StoreData;
    function t(e, t) {
        const o = document.createElement("a");
        o.href = URL.createObjectURL(new Blob([ JSON.stringify(e, null, 2) ], {
            type: "application/json"
        })), o.download = t + "-" + (new Date).toISOString().replace(/[:.]/g, "-") + ".json", 
        o.click(), setTimeout(() => URL.revokeObjectURL(o.href), 1e3);
    }
    async function o() {
        return new Promise((e, t) => {
            const o = indexedDB.open("alabqari-invoice-files", 1);
            o.onupgradeneeded = () => {
                o.result.objectStoreNames.contains("files") || o.result.createObjectStore("files");
            }, o.onsuccess = () => e(o.result), o.onerror = () => t(o.error);
        });
    }
    async function n(t = db) {
        const n = e.clean(t), r = await o();
        let a;
        try {
            a = await new Promise((e, t) => {
                const o = r.transaction("files", "readonly"), n = o.objectStore("files"), a = [], i = n.openCursor();
                i.onsuccess = () => {
                    const e = i.result;
                    e && (a.push({
                        id: e.key,
                        ...e.value
                    }), e.continue());
                }, o.oncomplete = () => e(a), o.onerror = () => t(o.error), o.onabort = () => t(o.error || Error("تعذر قراءة المرفقات"));
            });
        } finally {
            r.close();
        }
        const i = new Set(a.map(e => e.id));
        for (const e of [ ...n.inventory?.invoiceDocs || [], ...(n.inventory?.drafts || []).filter(e => "import" === e.kind && "active" === e.status) ]) {
            if (!(e.hasFile || e.fileData || e.fileStorage) || i.has(e.id)) continue;
            const t = await InvoiceFiles.get(e);
            if (!t?.blob) throw Error("صورة الفاتورة «" + (e.no || e.id) + "» غير موجودة على هذا الجهاز ولم تُرفع؛ نزّل النسخة من الجهاز الذي أضافها");
            a.push({
                id: e.id,
                ...t
            }), i.add(e.id);
        }
        n._localAttachments = [];
        for (const e of a) {
            const t = await new Promise((t, o) => {
                const n = new FileReader;
                n.onload = () => t(n.result), n.onerror = () => o(n.error), n.readAsDataURL(e.blob);
            });
            n._localAttachments.push({
                id: e.id,
                meta: e.meta,
                data: t
            });
        }
        return n;
    }
    async function r() {
        const e = document.getElementById("completeBackup");
        e && (e.disabled = !0);
        try {
            return t(await n(), "alabqari-complete-backup"), localStorage.setItem("alabqari-last-complete-backup",new Date().toISOString()), toast("تم تجهيز النسخة الشاملة مع صور الفواتير المحفوظة والمشتركة"), 
            !0;
        } catch (e) {
            return toast("تعذر تجهيز النسخة الشاملة: " + e.message), !1;
        } finally {
            e && (e.disabled = !1);
        }
    }
    const a = window.settings;
    window.settings = function() {
        if (a(), !document.getElementById("completeBackup")) {
            const e = document.createElement("button");
            e.id = "completeBackup", e.type = "button", e.textContent = "تنزيل نسخة شاملة مع صور الفواتير", 
            e.onclick = r, document.getElementById("backup").after(e);
        }
        const n = document.getElementById("settingsView");
        if (!n || n.querySelector("#restorePanel")) return;
        const i = document.createElement("div");
        i.id = "restorePanel", i.className = "panel", i.style.marginTop = "18px", i.innerHTML = '<h2>استرجاع نسخة احتياطية أو أرشيف</h2><p class="note">اختر ملف JSON: نسخة احتياطية كاملة (تستبدل بيانات هذا الجهاز) أو ملف أرشيف طلبات (يضيف الطلبات الناقصة فقط). يظهر لك عدد الطلبات والعملاء والمخزون قبل التنفيذ لتعرف إن كان أقل أو أكثر. الملف يعمل على أي جهاز، حتى بدون إنترنت.</p><input id="restoreFile" type="file" accept="application/json,.json">', 
        n.append(i);
        const c = document.getElementById("restore");
        c && (c.closest("label").hidden = !0), i.querySelector("input").onchange = async n => {
            const r = n.target.files[0];
            n.target.value = "", await async function(n) {
                if (!n) return;
                let r, a;
                try {
                    a = await n.text();
                } catch (e) {
                    return void toast("تعذر قراءة الملف");
                }
                try {
                    const t = JSON.parse(a);
                    if (window.Archive && Archive.isArchive(t)) return async function(t, o) {
                        let n;
                        try {
                            n = Archive.apply(e.clean(db), Archive.parse(t));
                        } catch (e) {
                            return void toast("تعذر استرجاع الأرشيف: " + e.message);
                        }
                        if (!n.added) return void toast("كل طلبات هذا الأرشيف موجودة أصلًا على هذا الجهاز.");
                        const r = "سيتم إضافة " + n.added + " طلب من الأرشيف «" + o + "»" + (n.already ? " (" + n.already + " موجودة أصلًا وتُتجاهل)" : "") + ". المخزون والمشتريات لا تتغير." + (n.droppedParts ? "\nتنبيه: " + n.droppedParts + " قطعة في هذه الطلبات لم تعد موجودة في المستودع وستُهمل منها." : "") + "\n\n" + e.compareText(e.clean(db), n.state, "هذا الجهاز") + "\n\nمتابعة؟";
                        await askConfirm(r) && commit(n.state) && (render(), "function" == typeof window.renderInventory && window.renderInventory(), 
                        toast("تمت إضافة " + n.added + " طلب من الأرشيف."));
                    }(a, n.name);
                } catch (e) {}
                try {
                    r = e.parseBackup(a, defaults);
                } catch (e) {
                    return void toast("تعذر قراءة الملف: " + e.message);
                }
                const i = r._localAttachments || [];
                if (!Array.isArray(i)) return void toast("قائمة المرفقات غير صالحة");
                delete r._localAttachments;
                const c = e.clean(db);
                if (await askConfirm((window.StoreSync?.secureMode?.() ? "سيتم استبدال بيانات المحل على جميع الأجهزة بمحتوى الملف «" : "سيتم استبدال بيانات هذا الجهاز بمحتوى الملف «") + n.name + "». تُحفظ نسخة من بيانات الجهاز الحالية أولًا.\n\n" + e.compareText(c, r, "هذا الجهاز") + "\n\nمتابعة؟")) try {
                    if (window.StoreSync?.secureMode?.()) {
                        if (![ "owner", "manager" ].includes(StoreSync.secureProfile()?.role)) throw Error("الاستعادة تتطلب حساب الإدارة");
                        if (StoreSync.status().pending) throw Error("زامن تعديلات هذا الجهاز أولًا قبل الاستعادة المركزية");
                    }
                    await Recovery.captureState(db, "قبل استعادة ملف", !0), t(c, "alabqari-before-restore"), 
                    db._sync && db._sync.bound && (r._sync = {
                        bound: db._sync.bound
                    }), await async function(e) {
                        if (!e.length) return;
                        const t = [], n = new Set;
                        for (const o of e) {
                            if ("string" != typeof o.id || "string" != typeof o.data || !/^data:[^,]*;base64,/.test(o.data)) throw Error("مرفق غير صالح");
                            if (n.has(o.id)) throw Error("مرفق مكرر في ملف الاستعادة");
                            n.add(o.id);
                            const e = o.data.indexOf(","), r = atob(o.data.slice(e + 1));
                            t.push({
                                id: o.id,
                                meta: o.meta || {},
                                blob: new Blob([ Uint8Array.from(r, e => e.charCodeAt(0)) ], {
                                    type: o.meta?.type || "application/octet-stream"
                                })
                            });
                        }
                        if (window.StoreSync?.secureMode?.()) for (const e of t) {
                            const t = [ ...r.inventory?.invoiceDocs || [], ...(r.inventory?.drafts || []).filter(e => "import" === e.kind && "active" === e.status) ].find(t => t.id === e.id);
                            if (!t) continue;
                            const o = await InvoiceFiles.hash(e.blob), n = t.fileStorage?.type || e.meta.type || e.blob.type, a = t.fileStorage || FlexCore.reference(StoreSync.shop(), t.id, o, e.blob.size, n);
                            if (FlexCore.validateReference(a, t.id, StoreSync.shop()), a.sha256 !== o || a.size !== e.blob.size) throw Error("صورة الفاتورة في النسخة لا تطابق بصمتها");
                            await StoreSync.storage.upload(a, e.blob), t.fileStorage = a, t.hasFile = !0, delete t.fileData;
                        }
                        const a = await o();
                        try {
                            await new Promise((e, o) => {
                                const n = a.transaction("files", "readwrite");
                                for (const {id: e, ...o} of t) n.objectStore("files").put(o, e);
                                n.oncomplete = e, n.onerror = () => o(n.error), n.onabort = () => o(n.error || Error("تعذر حفظ المرفقات"));
                            });
                        } finally {
                            a.close();
                        }
                    }(i), window.StoreSync?.secureMode?.() ? (await commitTransaction(r, {
                        restore: !0,
                        reason: "استعادة ملف"
                    }) === true ? toast("تمت استعادة المحل مركزيًا، وحُفظت نسخة أمان قبل الاستعادة") : (()=>{throw Error("لم يتأكد حفظ الاستعادة؛ لم تُعلن العملية ناجحة");})()) : (applySyncedState(r), 
                    toast("تم الاسترجاع على هذا الجهاز. افتح المزامنة لمشاركة النسخة."));
                } catch (e) {
                    toast("لم يتم الاسترجاع: " + ("QuotaExceededError" === e.name ? "لا توجد مساحة لحفظ نسخة الأمان" : e.message));
                }
            }(r);
        };
    }, window.BackupFiles = {
        exportComplete: r,
        buildComplete: n
    };
}();
