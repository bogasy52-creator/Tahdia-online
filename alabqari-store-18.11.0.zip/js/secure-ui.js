/*! Alabqari Store 18.9.7 | App code rights reserved for the project owner. */
/*! العبقري ستور — حقوق تطوير هذه النسخة محفوظة لصاحب المشروع. */
!function() {
    "use strict";
    const e = esc, {dialog: r, makeView: t, addNav: o, registerTab: n} = LedgerUI, s = () => window.StoreSync?.secureMode?.(), c = {
        owner: "مالك",
        manager: "مدير",
        cashier: "كاشير",
        technician: "فني صيانة",
        inventory: "مسؤول مخزون",
        accountant: "محاسب"
    };
    function a() {
        if (!s()) return void StoreSync.open();
        const t = StoreSync.secureProfile(), o = r("secureAccount", "حساب الموظف", '<div class="panel"><h3>' + e(t?.name || "جارٍ التحقق") + "</h3><p>" + e(c[t?.role] || "") + '</p><p class="pro-note">صلاحيات هذا الحساب يتحقق منها الخادم عند الحفظ. تبديل الموظف يحتاج الدخول بحسابه المستقل.</p></div><div class="footer">' + ("owner" === t?.role ? '<button id="secureMembersOpen">إدارة الموظفين</button>' : "") + '<button id="secureLogout">تسجيل الخروج</button></div>');
        o.querySelector("#secureMembersOpen")?.addEventListener("click", () => {
            o.close(), tab("serverMembers");
        }), o.querySelector("#secureLogout").onclick = async () => {
            await StoreSync.logout() && o.close();
        }, o.showModal();
    }

    const employeeSwitches=[['priceOverride','تغيير سعر البيع'],['belowCost','البيع دون التكلفة'],['freeSale','البيع المجاني'],['discount','الخصم'],['returnSales','استرجاع المبيعات'],['openDrawer','فتح الصندوق'],['resetAccounting','تصفير بيانات التجربة']];
    function drawPermissions(overrides={}){
        const role=$('secureMemberRole').value,box=$('secureMemberPermissions');
        if(!['manager','cashier'].includes(role)){box.innerHTML='<p class="note">'+(role==='owner'?'المالك يحتفظ بالصلاحيات الكاملة.':'صلاحيات هذا الحساب تتبع الدور المختار.')+'</p>';return;}
        const defaults={priceOverride:role==='manager',belowCost:role==='manager',freeSale:role==='manager',discount:true,returnSales:true,openDrawer:true,resetAccounting:role==='manager'};
        box.innerHTML='<h3>تخصيص عمليات هذا الموظف</h3><div class="grid">'+employeeSwitches.filter(([key])=>key!=='resetAccounting'||role==='manager').map(([key,title])=>'<label class="check"><input type="checkbox" data-employee-permission="'+key+'" '+((overrides[key]??defaults[key])?'checked':'')+'>'+esc(title)+'</label>').join('')+'</div><label>أقصى خصم (%)<input id="employeeDiscountLimit" type="number" min="0" max="100" step="0.5" value="'+esc(overrides.maxDiscountPercent??100)+'"></label><p class="note">يحفظ الخادم هذه القيود ويتحقق منها عند البيع، حتى إذا تغيرت الواجهة.</p>';
    }
    function collectPermissions(){
        if(!['manager','cashier'].includes($('secureMemberRole').value))return {};
        const values=Object.fromEntries([...document.querySelectorAll('[data-employee-permission]')].map(input=>[input.dataset.employeePermission,input.checked]));
        const raw=$('employeeDiscountLimit').value.trim(),limit=Number(raw);
        if(!raw||!Number.isFinite(limit)||limit<0||limit>100)throw Error('حد الخصم من صفر إلى 100');
        values.maxDiscountPercent=limit;return values;
    }
    let i = 0;
    async function d() {
        const r = ++i, o = t("serverMembers");
        if (o.hidden = !1, s() && can("members")) {
            o.innerHTML = '<div class="ops-page-title"><div><div class="pro-eyebrow">حسابات مستقلة</div><h2>الموظفون والصلاحيات</h2><p>اربط حساب الموظف الموجود لدى مزود الدخول وحدد دوره في المحل.</p></div></div><div class="panel"><p class="pro-note">أنشئ حسابًا مستقلًا لكل موظف في إعدادات Supabase Auth، ثم انسخ معرّف المستخدم UUID إلى هنا. لا توجد كلمة مرور افتراضية، وإيقاف العضوية يمنع طلباته التالية.</p><div id="secureMembersList">جارٍ القراءة…</div></div><div class="panel"><h3>إضافة أو تحديث عضوية</h3><form id="secureMemberForm"><div class="final-filters"><label>معرّف حساب الدخول<input id="secureMemberId" maxlength="36" required placeholder="UUID"></label><label>اسم الموظف<input id="secureMemberName" maxlength="100" required></label><label>الدور<select id="secureMemberRole">' + Object.entries(c).map(([e, r]) => '<option value="' + e + '">' + r + "</option>").join("") + '</select></label></div><label class="check"><input id="secureMemberActive" type="checkbox" checked>عضوية فعالة</label><div id="secureMemberPermissions" class="panel"></div><p class="error" id="secureMemberError"></p><div class="footer"><button class="primary">حفظ العضوية</button></div></form></div>', 
            $("secureMemberRole").value = "cashier";
            drawPermissions();$("secureMemberRole").onchange=()=>drawPermissions();
            try {
                const t = await StoreSync.api("/api/members", void 0, "GET");
                if (r !== i) return;
                $("secureMembersList").innerHTML = '<div class="final-notices">' + t.rows.map(r => '<div class="pro-list-row"><span><b>' + e(r.name) + "</b><small>" + e(c[r.role]) + " · " + (r.active ? "فعال" : "موقوف") + '</small></span><button data-member-edit="' + e(r.id) + '">تعديل</button></div>').join("") + "</div>", 
                $("secureMembersList").querySelectorAll("[data-member-edit]").forEach(e => e.onclick = () => {
                    const r = t.rows.find(r => r.id === e.dataset.memberEdit);
                    $("secureMemberId").value = r.id, $("secureMemberName").value = r.name, $("secureMemberRole").value = r.role, 
                    $("secureMemberActive").checked = r.active;drawPermissions(r.overrides||{});$("secureMemberName").focus();
                }), $("secureMemberForm").onsubmit = async e => {
                    e.preventDefault();
                    const r = e.target.querySelector("button");
                    r.disabled = !0;
                    try {
                        await StoreSync.api("/api/members", {
                            id: $("secureMemberId").value.trim(),
                            name: $("secureMemberName").value.trim(),
                            role: $("secureMemberRole").value,
                            active: $("secureMemberActive").checked,
                            permissions:collectPermissions()
                        }), toast("تم حفظ العضوية"), d();
                    } catch (e) {
                        $("secureMemberError").textContent = e.message, r.disabled = !1;
                    }
                };
            } catch (e) {
                r === i && ($("secureMembersList").textContent = e.message);
            }
        } else o.innerHTML = '<div class="panel">إدارة حسابات الخادم تتطلب حساب المالك.</div>';
    }
    s() && (o("serverMembers", "حسابات الموظفين", "الموظفون"), n("serverMembers", "حسابات الموظفين", d), 
    document.querySelector('.appbar-mobile [data-tab="serverMembers"]')?.remove());
    const l = window.settings;
    window.settings = function() {
        if (l(), !s()) return;
        const r = StoreSync.secureProfile(), t = document.createElement("div");
        if (t.className = "panel", t.innerHTML = "<h2>الحساب على الخادم</h2><p>" + e(r?.name || "جارٍ التحقق") + " · " + e(c[r?.role] || "") + '</p><button id="secureAccountOpen">حساب الموظف</button> <button id="systemStatusOpen">حالة النظام</button>', 
        "owner" === r?.role && (t.innerHTML += ' <button data-go="serverMembers">إدارة الموظفين</button>'), 
        $("settingsView").prepend(t), t.querySelector("#secureAccountOpen").onclick = a, t.querySelector("#systemStatusOpen").onclick=()=>SystemStatus.open(), 
        ![ "owner", "manager" ].includes(r?.role)) for (const e of document.querySelectorAll("#settingsForm input,#settingsForm select,#settingsForm textarea,#settingsForm button.primary")) e.disabled = !0;
        const o = $("backup"), n = $("completeBackup"), i = $("restorePanel");
        can("backups") || (o && (o.hidden = !0), n && (n.hidden = !0), i && (i.hidden = !0)), 
        i && can("backups") && (i.querySelector("input").disabled = ![ "owner", "manager" ].includes(r?.role), 
        i.querySelector("p").textContent = "استعادة ملف JSON بواسطة المالك أو المدير تستعيد المحل مركزيًا، وتُحفظ نسخة أمان قبل التنفيذ. يمكنك أيضًا اختيار نسخة مركزية من قسم النسخ والاستعادة.");
    };
    const u = window.edit, m = {
        orders: "repairDesk",
        profits: "profits",
        purchaseRequests: "purchases",
        purchases: "purchases",
        inventory: "warehouseEdit",
        accounts: "accounts",
        dailyClose: "accounts",
        recoveryHub: "backups",
        serverMembers: "members",
        pos: "directSale",
        quotes: "directSale"
    }, b = () => "inventory" === StoreSync.secureProfile()?.role ? "inventory" : "accountant" === StoreSync.secureProfile()?.role ? "accounts" : "orders";
    function p() {
        if (!s()) return;
        const e = StoreSync.secureProfile(), r = $("staffSwitchOpen");
        r && (r.textContent = "حساب: " + currentStaffLabel());
        const t = m;
        for (const [e, r] of Object.entries(t)) document.querySelectorAll('aside nav [data-tab="' + e + '"],.appbar-mobile [data-tab="' + e + '"]').forEach(e => e.hidden = !can(r));
        const o = document.body.dataset.screen;
        e && t[o] && !can(t[o]) && v(b()), "technician" === e?.role && ($("new").hidden = !0), 
        document.querySelectorAll("[data-delexp],#expForm button").forEach(e => e.disabled = !can("expenses"));
    }
    window.edit = function(e) {
        if (s()) {
            const r = StoreSync.secureProfile();
            if (!(r?.permissions.orders || e && r?.permissions.costs)) return void toast("هذا الحساب لا يفتح محرر طلبات الصيانة");
            if (!e && "technician" === r.role) return void toast("استلام طلب جديد يحتاج حساب الكاشير");
        }
        if (u(e), s() && [ "technician", "accountant" ].includes(StoreSync.secureProfile()?.role)) {
            for (const e of document.querySelectorAll("#name,#phone,#paid,[data-field=price],[data-field=warranty]")) e.disabled = !0;
            for (const e of document.querySelectorAll('[data-field=status] option[value="تم التسليم"]')) e.disabled = !0;
        } else for (const e of document.querySelectorAll("#name,#phone,#paid,[data-field=price]")) e.disabled = !1;
        s() && "accountant" === StoreSync.secureProfile()?.role && setTimeout(() => {
            for (const e of document.querySelectorAll("#name,#phone,#paid,#consent,[data-field], [data-part-item],[data-part-qty],[data-no-parts],[data-add-part],[data-remove-part],[data-chip-item],[data-repair-tech],[data-repair-due]")) e.disabled = !0;
        }, 0);
    };
    const v = window.tab;
    window.tab = function(e) {
        s() && StoreSync.secureProfile() && m[e] && !can(m[e]) && (toast("هذه الشاشة تتطلب صلاحية إضافية"), 
        e = b()), v(e), "serverMembers" === e && (document.querySelectorAll('main>section[id$="View"]').forEach(e => e.hidden = "serverMembersView" !== e.id), 
        document.body.dataset.screen = e, $("new").hidden = !0, $("quickNew") && ($("quickNew").hidden = !0)), 
        p();
    }, window.addEventListener("store:profile", p), window.addEventListener("ledger:refresh", p), 
    p(), window.SecureUI = {
        account: a,
        members: d
    };
}();
