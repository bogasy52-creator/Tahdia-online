import test from 'node:test';import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';
const css=async name=>readFile(new URL('../public/assets/css/'+name,import.meta.url),'utf8');
test('the live hint can never stretch over the arena and the survivors counter stays on one line',async()=>{
  const source=await css('arena-v23.css'),bundle=await css('app-serpent.css');
  const rule=source.match(/\.serpent-page \.arena-live-hint\{([^}]*)\}/g)?.at(-1)||'';
  assert.match(rule,/bottom:auto!important/);assert.match(rule,/height:auto!important/);assert.match(rule,/top:calc\(108px/);
  assert.match(source,/\.serpent-page \.hud-clock b\{[^}]*white-space:nowrap[^}]*direction:ltr/);
  assert.ok(bundle.endsWith('/* assets/css/arena-v23.css */\n'+source),'app-serpent.css must end with the exact arena-v23.css source');
});
