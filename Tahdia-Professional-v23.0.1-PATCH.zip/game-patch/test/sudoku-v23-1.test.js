import test from 'node:test';import assert from 'node:assert/strict';
import {createSudoku,moveSudoku,restoreSudoku,sudokuStars,SUDOKU_TIERS} from '../public/assets/js/engines/sudoku-engine.js';
import {solveSudoku} from '../public/assets/js/engines/sudoku-core.js';
const solved=state=>solveSudoku(state.initial).solution;
const wrongValue=(state,i)=>[1,2,3,4,5,6,7,8,9].find(v=>v!==solved(state)[i]);
function finish(state){const sol=solved(state);for(let i=0;i<81;i++)if(!state.initial[i]&&state.board[i]!==sol[i])state=moveSudoku(state,{cell:i,value:sol[i]}).state;return state;}
test('daily puzzles follow a weekly ladder from an easy Saturday to a master Friday',()=>{
  const tierOf=day=>SUDOKU_TIERS[createSudoku(1,day).tier];
  assert.deepEqual(['2026-10-17','2026-10-11','2026-10-12','2026-10-13','2026-10-14','2026-10-15','2026-10-16'].map(tierOf),['بداية هادئة','تركيز','تركيز','تفكير عميق','تفكير عميق','خبير','تحدي الماستر']);
  assert.deepEqual(createSudoku(1,'2026-10-18').initial,createSudoku(1,'2026-10-18').initial,'same date, same puzzle');
  assert.throws(()=>createSudoku(1,'2026-13-45'),/invalid_stage/);
});
test('wrong entries are counted by the engine, hints never are, and replaying the log reproduces the count',()=>{
  let state=createSudoku(1);const empty=state.initial.findIndex(v=>!v);
  state=moveSudoku(state,{cell:empty,value:wrongValue(state,empty)}).state;assert.equal(state.mistakes,1);
  state=moveSudoku(state,{undo:true}).state;assert.equal(state.mistakes,1,'undo does not refund a mistake');
  state=moveSudoku(state,{hint:true}).state;assert.equal(state.mistakes,1,'a hint is never a mistake');
  state=moveSudoku(state,{cell:empty,value:0}).state||state;
  const replay=restoreSudoku({engineVersion:state.engineVersion,game:'sudoku',level:1,daily:'',log:state.log});assert.equal(replay.mistakes,1);
});
test('three stars need a clean solve; one mistake or one hint costs a star; more costs two',()=>{
  const clean=finish(createSudoku(1));assert.equal(clean.mistakes,0);assert.equal(sudokuStars(clean),3);
  let one=createSudoku(1);const e=one.initial.findIndex(v=>!v);one=moveSudoku(one,{cell:e,value:wrongValue(one,e)}).state;one=finish(one);
  assert.equal(one.mistakes,1);assert.equal(sudokuStars(one),2);
  let many=createSudoku(1);const cells=many.initial.map((v,i)=>v?-1:i).filter(i=>i>=0).slice(0,3);
  for(const c of cells)many=moveSudoku(many,{cell:c,value:wrongValue(many,c)}).state;many=finish(many);
  assert.equal(many.mistakes,3);assert.equal(sudokuStars(many),1);
});
