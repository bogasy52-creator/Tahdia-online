import test from 'node:test';import assert from 'node:assert/strict';import {readFile,readdir} from 'node:fs/promises';
const text=async path=>readFile(new URL('../'+path,import.meta.url),'utf8');
const pkg=JSON.parse(await text('package.json')),version=pkg.version;
test('the version shown to players, the server, the cache name and every asset link all match package.json',async()=>{
  const home=await text('public/index.html');
  assert.match(home,new RegExp('<footer class="bs-footer">[^<]*الإصدار '+version.replaceAll('.','\\.')+'</footer>'),'footer on the home page must show '+version);
  assert.match(await text('src/index.js'),new RegExp("const RELEASE='"+version.replaceAll('.','\\.')+"';"),'server release constant');
  assert.match(await text('public/service-worker.js'),new RegExp("const CACHE_NAME = 'busraj-games-v50-release-"+version.replaceAll('.','-')+"';"),'service worker cache name');
  assert.equal(JSON.parse(await text('package-lock.json')).version,version);
  const stale=[];
  for(const dir of ['public','public/assets/js']){
    for(const name of await readdir(new URL('../'+dir+'/',import.meta.url))){
      if(!/\.(?:html|js)$/.test(name))continue;
      const body=await text(dir+'/'+name);
      for(const [,found] of body.matchAll(/\?v=(\d+\.\d+\.\d+)/g))if(found!==version)stale.push(dir+'/'+name+' → '+found);
    }
  }
  assert.deepEqual([...new Set(stale)],[],'asset links with another version');
});
