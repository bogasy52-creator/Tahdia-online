// Usage: node scripts/bump-version.mjs 23.1.0
// Rewrites the release number everywhere it is hard-coded (footer, server, ?v= links, cache name, tests and verifiers).
// Afterwards run: node scripts/build-offline.mjs && node scripts/build-styles.mjs && npm test
import {readFile,writeFile,readdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=fileURLToPath(new URL('../',import.meta.url)),next=process.argv[2];
if(!/^\d+\.\d+\.\d+$/.test(next||''))throw Error('Usage: node scripts/bump-version.mjs MAJOR.MINOR.PATCH');
const previous=JSON.parse(await readFile(path.join(root,'package.json'),'utf8')).version;
if(previous===next)throw Error('Version is already '+next);
const dotted=new RegExp('(?<![\\d.])'+previous.replaceAll('.','\\.')+'(?![\\d])','g'),dashed=new RegExp('release-'+previous.replaceAll('.','-'),'g');
const skipDir=new Set(['node_modules','.git','.wrangler']),skipFile=/^(?:SHA256SUMS\.txt|patch-manifest\.json)$|^(?:RELEASE|VERIFIED|CHANGED_FILES|AI_IMAGES)/;
let changed=0;
async function walk(dir){for(const entry of await readdir(dir,{withFileTypes:true})){
  const full=path.join(dir,entry.name);
  if(entry.isDirectory()){if(!skipDir.has(entry.name))await walk(full);continue;}
  if(skipFile.test(entry.name)||!/\.(?:js|mjs|html|css|json|txt|md)$/.test(entry.name))continue;
  const body=await readFile(full,'utf8'),updated=body.replace(dotted,next).replace(dashed,'release-'+next.replaceAll('.','-'));
  if(updated!==body){await writeFile(full,updated);changed++;}
}}
await walk(root);
console.log('Version '+previous+' -> '+next+' in '+changed+' files. Now rebuild the offline manifest and style bundles.');
