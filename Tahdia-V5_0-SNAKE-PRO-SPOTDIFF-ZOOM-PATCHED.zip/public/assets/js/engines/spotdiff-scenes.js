// Shared "spot the differences" data — real photos from the project's own
// photo library (public/assets/quiz_photos), never generated art.
// Only pure, DOM-free helpers live here so this same file can be imported
// by the Cloudflare Worker (server, no canvas) and by the browser (client,
// which does the actual canvas drawing/pixel work in spotdiff.html).

export const PHOTO_BANK = [
  "assets/spot_difference_photos/astronaut.webp",
  "assets/spot_difference_photos/astronaut_glove.webp",
  "assets/spot_difference_photos/astronaut_helmet.webp",
  "assets/spot_difference_photos/astronaut_suit.webp",
  "assets/spot_difference_photos/brick.webp",
  "assets/spot_difference_photos/brick_close.webp",
  "assets/spot_difference_photos/camera.webp",
  "assets/spot_difference_photos/camera_lens.webp",
  "assets/spot_difference_photos/camera_tripod.webp",
  "assets/spot_difference_photos/cat.webp",
  "assets/spot_difference_photos/cat_ear.webp",
  "assets/spot_difference_photos/cat_eye.webp",
  "assets/spot_difference_photos/cat_nose.webp",
  "assets/spot_difference_photos/cell.webp",
  "assets/spot_difference_photos/cell_detail.webp",
  "assets/spot_difference_photos/cheetah.webp",
  "assets/spot_difference_photos/cheetah_eye.webp",
  "assets/spot_difference_photos/cheetah_spots.webp",
  "assets/spot_difference_photos/china_detail.webp",
  "assets/spot_difference_photos/china_roof.webp",
  "assets/spot_difference_photos/china_temple.webp",
  "assets/spot_difference_photos/clock.webp",
  "assets/spot_difference_photos/coffee.webp",
  "assets/spot_difference_photos/coffee_rim.webp",
  "assets/spot_difference_photos/coffee_spoon.webp",
  "assets/spot_difference_photos/coins.webp",
  "assets/spot_difference_photos/coins_close.webp",
  "assets/spot_difference_photos/coins_edge.webp",
  "assets/spot_difference_photos/eiffel.webp",
  "assets/spot_difference_photos/eiffel_close.webp",
  "assets/spot_difference_photos/eiffel_lattice.webp",
  "assets/spot_difference_photos/flower.webp",
  "assets/spot_difference_photos/flower_center.webp",
  "assets/spot_difference_photos/flower_petals.webp",
  "assets/spot_difference_photos/grass.webp",
  "assets/spot_difference_photos/grass_blades.webp",
  "assets/spot_difference_photos/gravel.webp",
  "assets/spot_difference_photos/gravel_detail.webp",
  "assets/spot_difference_photos/hubble.webp",
  "assets/spot_difference_photos/hubble_field.webp",
  "assets/spot_difference_photos/ihc.webp",
  "assets/spot_difference_photos/ihc_cells.webp",
  "assets/spot_difference_photos/lion.webp",
  "assets/spot_difference_photos/lion_eye.webp",
  "assets/spot_difference_photos/lion_mane.webp",
  "assets/spot_difference_photos/moon.webp",
  "assets/spot_difference_photos/moon_craters.webp",
  "assets/spot_difference_photos/moon_surface.webp",
  "assets/spot_difference_photos/motorcycle.webp",
  "assets/spot_difference_photos/motorcycle_engine.webp",
  "assets/spot_difference_photos/motorcycle_headlight.webp",
  "assets/spot_difference_photos/motorcycle_wheel.webp",
  "assets/spot_difference_photos/retina.webp",
  "assets/spot_difference_photos/retina_optic.webp",
  "assets/spot_difference_photos/retina_vessels.webp",
  "assets/spot_difference_photos/rocket.webp",
  "assets/spot_difference_photos/rocket_body.webp",
  "assets/spot_difference_photos/rocket_launchpad.webp",
];

export function pickPhoto(exclude = []) {
  const pool = PHOTO_BANK.filter((p) => !exclude.includes(p));
  const list = pool.length ? pool : PHOTO_BANK;
  return list[Math.floor(Math.random() * list.length)];
}

// Deterministic sector placement — always returns exactly `count` points
// with guaranteed minimum separation (no rejection sampling, so it can
// never fall short or leave two points overlapping, unlike naive random
// placement + retry). Percentage space (0-100); r is also in percentage
// of the canvas's shorter side.
export function generateDiffPoints(count = 5, margin = 14, rMin = 7, rMax = 13) {
  const cols = Math.ceil(Math.sqrt(count * 1.3));
  const rows = Math.ceil(count / cols);
  const cellW = (100 - margin * 2) / cols;
  const cellH = (100 - margin * 2) / rows;
  const r = Math.max(rMin, Math.min(rMax, Math.min(cellW, cellH) * 0.28));
  const pad = r + 2;
  const cells = [];
  for (let ry = 0; ry < rows; ry++) for (let cx = 0; cx < cols; cx++) cells.push([cx, ry]);
  for (let i = cells.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [cells[i], cells[j]] = [cells[j], cells[i]];
  }
  return cells.slice(0, count).map(([cx, cy], i) => {
    const baseX = margin + cx * cellW, baseY = margin + cy * cellH;
    const jitterW = Math.max(0, cellW - pad * 2), jitterH = Math.max(0, cellH - pad * 2);
    const x = baseX + pad + Math.random() * jitterW;
    const y = baseY + pad + Math.random() * jitterH;
    return { id: `d${i}`, x: Math.round(x * 10) / 10, y: Math.round(y * 10) / 10, r: Math.round(r * 10) / 10 };
  });
}

// Difficulty presets shared by server (validates/generates rounds) and
// client (renders the picker + labels). Easy = fewer, bigger, more time.
// Hard = more, smaller, less time.
export const DIFFICULTIES = {
  easy:   { key: "easy",   label: "سهل",   icon: "🙂", count: 4, margin: 15, rMin: 10, rMax: 15, duration: 90_000 },
  medium: { key: "medium", label: "متوسط", icon: "😐", count: 5, margin: 14, rMin: 7,  rMax: 13, duration: 75_000 },
  hard:   { key: "hard",   label: "صعب",   icon: "🔥", count: 6, margin: 12, rMin: 5,  rMax: 9,  duration: 60_000 },
};

export function diffPointsForDifficulty(key) {
  const d = DIFFICULTIES[key] || DIFFICULTIES.medium;
  return { points: generateDiffPoints(d.count, d.margin, d.rMin, d.rMax), duration: d.duration, key: d.key };
}
