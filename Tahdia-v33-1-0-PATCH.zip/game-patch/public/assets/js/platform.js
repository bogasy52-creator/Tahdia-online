window.BS_UUID=()=>{if(typeof crypto.randomUUID==='function')return crypto.randomUUID();const b=crypto.getRandomValues(new Uint8Array(16));b[6]=(b[6]&15)|64;b[8]=(b[8]&63)|128;const h=Array.from(b,v=>v.toString(16).padStart(2,'0')).join('');return `${h.slice(0,8)}-${h.slice(8,12)}-${h.slice(12,16)}-${h.slice(16,20)}-${h.slice(20)}`;};
(() => {
  // Prevent accidental long-press/drag selection on game labels. Do not cancel
  // pointer/touch starts: game drags, scrolling, native inputs and zoom need them.
  const gamePages=new Set(['online','local','baloot','quiz','snakes','jackaroo','zahra','dice','serpent','sudoku','jewels','journey','paths','paths-online','picture','memory','reaction','logic','puzzle','accuracy','party']);
  const gamePath=location.pathname.replace(/^\/+|\/+$/g,'').replace(/\.html$/,'');
  {
    document.body.classList.add('bs-game-interaction-v34');
    // tahdia-premium-v25.js adds the same guard on every page; add it once.
    if(!window.__BS_NO_SELECT__){
      window.__BS_NO_SELECT__=true;
      const editable=target=>{const el=target&&target.nodeType===3?target.parentElement:target;return el?.closest?.('input,textarea,select,[contenteditable]:not([contenteditable="false"]),[data-selectable]');};
      document.addEventListener('selectstart',event=>{if(!editable(event.target))event.preventDefault();});
      document.addEventListener('contextmenu',event=>{if(!editable(event.target)&&event.pointerType==='touch')event.preventDefault();});
    }
  }

  let deferredInstall=null;
  window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstall=e});
  const toast=(text)=>{let el=document.querySelector('.bs-toast');if(!el){el=document.createElement('div');el.className='bs-toast';document.body.appendChild(el)}el.textContent=text;el.classList.add('show');clearTimeout(toast._t);toast._t=setTimeout(()=>el.classList.remove('show'),2200)};
  async function install(){if(window.matchMedia?.('(display-mode: standalone)').matches)return toast('بوسراج مثبت بالفعل');if(deferredInstall){deferredInstall.prompt();try{await deferredInstall.userChoice}catch{}deferredInstall=null;return}const ios=/iphone|ipad|ipod/i.test(navigator.userAgent);toast(ios?'في Safari: مشاركة ← إضافة إلى الشاشة الرئيسية':'من قائمة المتصفح اختر تثبيت التطبيق')}
  function buildSettings(){if(document.querySelector('#bsSettings'))return;const s=window.BS_AUDIO?.getSettings?.()||{muted:false,effects:true,timer:true,haptics:true,volume:.72};const m=document.createElement('div');m.id='bsSettings';m.className='bs-modal';m.innerHTML=`<section class="bs-panel bs-settings" role="dialog" aria-modal="true" aria-label="إعدادات الصوت"><div style="display:flex;align-items:center;justify-content:space-between;gap:10px"><div><h2>إعدادات اللعب</h2><div style="color:var(--bs-muted);font-size:12px">الصوت والاهتزاز محفوظة تلقائيًا</div></div><button class="bs-icon-btn" data-close aria-label="إغلاق">✕</button></div><div class="row"><span><b>المؤثرات</b><small>حركة، نرد، بطاقات ونتائج</small></span><button class="bs-switch ${s.effects?'on':''}" data-key="effects" aria-label="تبديل المؤثرات"><i></i></button></div><div class="row"><span><b>نبض المؤقت</b><small>صوت الوقت والعد التنازلي</small></span><button class="bs-switch ${s.timer?'on':''}" data-key="timer" aria-label="تبديل المؤقت"><i></i></button></div><div class="row"><span><b>الاهتزاز</b><small>استجابة لمسية على الجوال</small></span><button class="bs-switch ${s.haptics?'on':''}" data-key="haptics" aria-label="تبديل الاهتزاز"><i></i></button></div><div class="row"><span><b>مستوى الصوت</b></span><input class="bs-range" data-volume type="range" min="0" max="1" step="0.05" value="${s.volume}"></div></section>`;document.body.appendChild(m);m.addEventListener('click',e=>{if(e.target===m||e.target.closest('[data-close]'))m.classList.remove('open');const sw=e.target.closest('.bs-switch[data-key]');if(sw){const key=sw.dataset.key;const cur=window.BS_AUDIO.getSettings()[key];window.BS_AUDIO.update({[key]:!cur});sw.classList.toggle('on',!cur);window.BS_AUDIO.play('click')}});m.querySelector('[data-volume]').addEventListener('input',e=>window.BS_AUDIO.update({volume:Number(e.target.value)}))}
  function syncMute(){const muted=window.BS_AUDIO?.getSettings?.().muted;document.querySelectorAll('[data-audio-toggle]').forEach(b=>{if(b.dataset.audioIcon==='vector')b.dataset.muted=String(!!muted);else b.textContent=muted?'🔇':'🔊';b.setAttribute('aria-label',muted?'تشغيل الصوت':'كتم الصوت')})}
  document.addEventListener('click',e=>{const installBtn=e.target.closest('[data-install]');if(installBtn)install();const audio=e.target.closest('[data-audio-toggle]');if(audio){window.BS_AUDIO?.toggleMuted();syncMute()}const settings=e.target.closest('[data-settings-open]');if(settings){buildSettings();document.querySelector('#bsSettings').classList.add('open');document.dispatchEvent(new Event('bs-ui-overlay'))}});
  window.addEventListener('bs-audio-change',syncMute);syncMute();
  if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('/service-worker.js',{updateViaCache:'none'}).catch(()=>{}));
  window.BS_PLATFORM={toast,install,openSettings:()=>{buildSettings();document.querySelector('#bsSettings').classList.add('open');document.dispatchEvent(new Event('bs-ui-overlay'))}};
})();
