(() => {
  const STORAGE_KEY = 'bs_social_session';
  const PROFILE_KEY = 'bs_social_profile';
  const state = { token: '', profile: null, dashboard: null, socket: null, reconnectTimer: null, reconnectAttempt: 0, manualClose: false };
  const events = new EventTarget();
  let pickerEpoch = 0, closeFriendPicker = null;

  function readStorage(key) { try { return localStorage.getItem(key) || ''; } catch { return ''; } }
  function writeStorage(key, value) { try { if (value) localStorage.setItem(key, value); else localStorage.removeItem(key); } catch {} }
  function parseJson(value, fallback = null) { try { return JSON.parse(value); } catch { return fallback; } }
  function toast(message) { if (window.BS_PLATFORM?.toast) window.BS_PLATFORM.toast(message); else console.info(message); }
  function token() { if (!state.token) state.token = readStorage(STORAGE_KEY); return state.token; }
  function cachedProfile() {
    if (!state.profile) state.profile = parseJson(readStorage(PROFILE_KEY));
    return state.profile;
  }
  function setSession(nextToken, profile) {
    ++pickerEpoch; closeFriendPicker?.();
    state.token = String(nextToken || '');
    state.profile = profile || null;
    state.dashboard = null;
    writeStorage(STORAGE_KEY, state.token);
    writeStorage(PROFILE_KEY, state.profile ? JSON.stringify(state.profile) : '');
    decorate();
    window.dispatchEvent(new CustomEvent('bs-social-session'));
  }

  async function api(path, options = {}) {
    const headers = new Headers(options.headers || {});
    if (options.body && !headers.has('content-type')) headers.set('content-type', 'application/json');
    const session = token();
    if (session) headers.set('authorization', `Bearer ${session}`);
    const response = await fetch(path, { ...options, headers, cache: 'no-store' });
    const data = await response.json().catch(() => ({}));
    if (response.status === 401 && path !== '/api/social/login' && token() === session) {
      setSession('', null);
      closeRealtime();
    }
    if (!response.ok || data.ok === false) {
      const error = new Error(data.error || 'تعذر تنفيذ الطلب');
      error.status = response.status;
      throw error;
    }
    return data;
  }

  async function signup({ username, displayName, password }) {
    const data = await api('/api/social/signup', { method: 'POST', body: JSON.stringify({ username, displayName, password }) });
    setSession(data.token, data.profile);
    connectRealtime();
    return data;
  }
  async function login({ username, password }) {
    const data = await api('/api/social/login', { method: 'POST', body: JSON.stringify({ username, password }) });
    setSession(data.token, data.profile);
    connectRealtime();
    return data;
  }
  async function logout() {
    try { if (token()) await api('/api/social/logout', { method: 'POST' }); } catch {}
    closeRealtime();
    setSession('', null);
    state.dashboard = null;
  }
  async function me(force = false) {
    if (!token()) return null;
    if (state.dashboard && !force) return state.dashboard;
    const session = token(), data = await api('/api/social/me');
    if (token() !== session) throw new Error('تغير الحساب؛ افتح قائمة الأصدقاء من جديد.');
    state.dashboard = data;
    state.profile = data.profile;
    writeStorage(PROFILE_KEY, JSON.stringify(data.profile || null));
    decorate(data);
    return data;
  }
  async function user(username) { return api(`/api/social/users/${encodeURIComponent(String(username || '').trim())}`); }
  async function requestFriend(username) { const data = await api('/api/social/friends/request', { method: 'POST', body: JSON.stringify({ username }) }); state.dashboard = null; return data; }
  async function respondFriend(username, accept) { const data = await api('/api/social/friends/respond', { method: 'POST', body: JSON.stringify({ username, accept }) }); state.dashboard = null; return data; }
  async function removeFriend(username) { const data = await api(`/api/social/friends/${encodeURIComponent(username)}`, { method: 'DELETE' }); state.dashboard = null; return data; }
  async function block(username) { const data = await api('/api/social/block', { method: 'POST', body: JSON.stringify({ username }) }); state.dashboard = null; return data; }
  async function unblock(username) { const data = await api('/api/social/unblock', { method: 'POST', body: JSON.stringify({ username }) }); state.dashboard = null; return data; }
  async function settings(values) { const data = await api('/api/social/settings', { method: 'POST', body: JSON.stringify(values) }); state.dashboard = null; return data; }
  async function invite(username, game, roomCode) { return api('/api/social/invites', { method: 'POST', body: JSON.stringify({ username, game, roomCode }) }); }
  async function readNotifications(ids = []) { const data = await api('/api/social/notifications/read', { method: 'POST', body: JSON.stringify({ ids }) }); state.dashboard = null; return data; }

  function emit(type, detail) { events.dispatchEvent(new CustomEvent(type, { detail })); }

  function showIncomingInvite(notification) {
    if (!notification?.joinPath || Date.now() >= Number(notification.expiresAt || 0)) return;
    let wrap = document.querySelector('#bsSocialInvite');
    if (!wrap) {
      wrap = document.createElement('div');
      wrap.id = 'bsSocialInvite';
      wrap.className = 'bs-social-invite-card';
      document.body.appendChild(wrap);
    }
    wrap.innerHTML = '';
    const title = document.createElement('b');
    title.textContent = `🎮 دعوة من ${notification.from?.displayName || notification.from?.username || 'صديق'}`;
    const sub = document.createElement('span');
    const labels = { quiz: 'تحدي العباقرة', picture: 'سباق الصور', jackaroo: 'جاكارو', snakes: 'الثعبان', zahra: 'الزهرة', serpent: 'حلبة الثعبان', sudoku: 'سودوكو', paths: 'توصيل الأرقام', accuracy: 'التصويب', dice: 'النرد', journey: 'رحلة النجوم', local: 'العباقرة المحلي', logic: 'المنطق', memory: 'الذاكرة', puzzle: 'ترتيب الأرقام', reaction: 'سرعة الاستجابة' };
    sub.textContent = notification.roomCode ? `${labels[notification.game] || notification.game} • الغرفة ${notification.roomCode}` : `تحدٍ جديد • ${labels[notification.game] || notification.game}`;
    const actions = document.createElement('div');
    actions.className = 'bs-social-invite-actions';
    const join = document.createElement('a');
    join.className = 'bs-btn gold'; join.textContent = 'انضم الآن'; join.href = notification.joinPath;
    const close = document.createElement('button');
    close.className = 'bs-btn'; close.textContent = 'لاحقًا'; close.type = 'button'; close.onclick = () => wrap.remove();
    actions.append(join, close); wrap.append(title, sub, actions);
  }

  function handleMessage(raw) {
    let message; try { message = JSON.parse(raw); } catch { return; }
    if (message.type === 'social_welcome') {
      state.profile = message.profile || state.profile;
      if (state.profile) writeStorage(PROFILE_KEY, JSON.stringify(state.profile));
      decorate(); emit('connected', message); return;
    }
    if (message.type === 'notification') {
      state.dashboard = null;
      const n = message.notification;
      if (n?.type === 'game_invite') showIncomingInvite(n);
      else if (n?.type === 'friend_request') toast(`👥 طلب صداقة من ${n.from?.displayName || n.from?.username || 'لاعب'}`);
      else if (n?.type === 'friend_accepted') toast(`✅ تم قبول طلب الصداقة`);
      decorate({ unread: Number(document.querySelector('[data-social-badge]')?.textContent || 0) + 1 });
      emit('notification', n); return;
    }
    if (message.type === 'friend_presence') { state.dashboard = null; emit('presence', message.friend); return; }
    if (message.type === 'pong') emit('pong', message);
  }

  function connectRealtime() {
    if (!token() || typeof WebSocket === 'undefined') return;
    state.manualClose = false;
    clearTimeout(state.reconnectTimer);
    if (state.socket && state.socket.readyState <= 1) return;
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${proto}//${location.host}/api/social/ws`, ['busraj-social-v1', `st.${token()}`]);
    state.socket = ws;
    ws.onopen = () => { state.reconnectAttempt = 0; emit('connection', { online: true }); };
    ws.onmessage = (event) => handleMessage(event.data);
    ws.onerror = () => emit('connection', { online: false, error: true });
    ws.onclose = (event) => {
      if (state.socket === ws) state.socket = null;
      emit('connection', { online: false, code: event.code });
      if (!state.manualClose && token() && event.code !== 4001) {
        const delay = Math.min(8000, 800 * (2 ** Math.min(4, state.reconnectAttempt++)));
        state.reconnectTimer = setTimeout(connectRealtime, delay);
      }
    };
  }
  function closeRealtime() {
    state.manualClose = true;
    clearTimeout(state.reconnectTimer);
    try { state.socket?.close(1000, 'logout'); } catch {}
    state.socket = null;
  }

  function decorate(data = state.dashboard) {
    const profile = data?.profile || cachedProfile();
    const unread = Number(data?.unread || 0);
    document.querySelectorAll('[data-social-name]').forEach((el) => { el.textContent = profile?.displayName || 'حسابي'; });
    document.querySelectorAll('[data-social-open]').forEach((el) => {
      el.setAttribute('href', profile ? '/social' : '/social?auth=1');
      el.setAttribute('title', profile ? `@${profile.username}` : 'تسجيل الدخول');
    });
    document.querySelectorAll('[data-social-badge]').forEach((el) => {
      el.textContent = unread > 99 ? '99+' : String(unread || '');
      el.classList.toggle('hidden', !unread);
    });
  }

  async function openInvitePicker({ game, roomCode } = {}) {
    closeFriendPicker?.();
    const epoch = ++pickerEpoch, session = token(), source = document.activeElement;
    if (!session) {
      toast('سجّل الدخول أولًا لإرسال دعوة لصديق');
      location.href = `/social?auth=1&next=${encodeURIComponent(location.pathname + location.search)}`;
      return;
    }
    let data;
    try { data = await me(true); } catch (error) { if (epoch === pickerEpoch) toast(error.message); return; }
    if (epoch !== pickerEpoch || session !== token()) return;
    const friends = [...(data?.friends || [])].filter(friend => typeof friend.username === 'string' && friend.username)
      .sort((a, b) => Number(b.online) - Number(a.online) || String(a.displayName || a.username).localeCompare(String(b.displayName || b.username), 'ar'));
    document.getElementById('bsInviteFriendsModal')?.remove();
    const modal = document.createElement('dialog');
    modal.id = 'bsInviteFriendsModal'; modal.className = 'bs-modal bs-friend-dialog';
    modal.setAttribute('aria-labelledby', 'bsFriendInviteTitle'); modal.setAttribute('aria-modal', 'true');
    const panel = document.createElement('section'); panel.className = 'bs-panel bs-social-picker';
    const head = document.createElement('header'); head.className = 'bs-social-picker-head';
    const copy = document.createElement('div'), title = document.createElement('h2'), note = document.createElement('p');
    title.id = 'bsFriendInviteTitle'; title.textContent = 'اختَر صديقك. وابدأ التحدّي.';
    note.textContent = roomCode ? `دعوة إلى الغرفة ${roomCode}` : 'تحدٍ مباشر من داخل اللعبة'; copy.append(title, note);
    const close = document.createElement('button'); close.type = 'button'; close.className = 'bs-icon-btn';
    close.textContent = '×'; close.setAttribute('aria-label', 'إغلاق قائمة الأصدقاء'); head.append(copy, close);
    const search = document.createElement('input'); search.id = 'bsInviteFriendSearch'; search.type = 'search';
    search.placeholder = 'ابحث عن صديق بالاسم…'; search.autocomplete = 'off'; search.setAttribute('aria-label', 'ابحث في أصدقائك');
    const count = document.createElement('small'); count.className = 'bs-picker-count'; count.setAttribute('role', 'status');
    const list = document.createElement('div'); list.className = 'bs-social-picker-list'; list.setAttribute('aria-label', 'أصدقاؤك');
    const status = document.createElement('p'); status.id = 'bsInvitePickerStatus'; status.setAttribute('role', 'status'); status.setAttribute('aria-live', 'polite');
    const empty = document.createElement('p'); empty.className = 'bs-social-empty';
    const normalize = value => String(value).normalize('NFKC').replace(/[\u064B-\u065F\u0670\u0640]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').trim().toLowerCase();
    const rows = [];
    let closed = false;
    for (const friend of friends) {
      const row = document.createElement('div'); row.className = 'bs-social-picker-row'; row.dataset.online = String(Boolean(friend.online));
      const avatar = document.createElement('span'); avatar.className = 'bs-friend-avatar'; avatar.setAttribute('aria-hidden', 'true');
      const displayName = friend.displayName || friend.username; avatar.textContent = [...displayName][0];
      const who = document.createElement('div'); who.className = 'bs-friend-copy';
      const name = document.createElement('b'); name.textContent = displayName;
      const user = document.createElement('small'); user.textContent = `@${friend.username} · ${friend.online ? 'متصل الآن' : 'غير متصل'}`; who.append(name, user);
      const send = document.createElement('button'); send.type = 'button'; send.className = 'bs-btn cyan'; send.textContent = 'دعوة';
      send.setAttribute('aria-label', 'دعوة ' + displayName);
      send.onclick = async () => {
        if (closed || send.disabled || session !== token()) return;
        send.disabled = true; send.textContent = 'نرسل الدعوة…'; status.textContent = '';
        try {
          await invite(friend.username, game, roomCode);
          if (closed || session !== token()) return;
          send.textContent = 'تم الإرسال ✓'; status.dataset.tone = 'success'; status.textContent = 'تم إرسال الدعوة إلى ' + displayName;
        } catch (error) {
          if (closed || session !== token()) return;
          send.disabled = false; send.textContent = 'أعد المحاولة'; status.dataset.tone = 'error'; status.textContent = error.message || 'لم تُرسل الدعوة؛ حاول مرة أخرى.';
        }
      };
      row.append(avatar, who, send); list.appendChild(row); rows.push({ row, text: normalize(displayName + ' ' + friend.username) });
    }
    function filterFriends() {
      const query = normalize(search.value || ''); let visible = 0;
      for (const item of rows) { item.row.hidden = !item.text.includes(query); if (!item.row.hidden) visible++; }
      count.textContent = visible + ' أصدقاء' + (query ? ' مطابقين للبحث' : '');
      empty.hidden = visible > 0;
      empty.textContent = friends.length ? 'ما لقينا صديقًا بهذا الاسم. جرّب اسمًا آخر.' : 'قائمتك تبدأ بصديق. أضفه من صفحة الأصدقاء ثم ارجع للدعوة.';
    }
    search.addEventListener('input', filterFriends); filterFriends();
    const footer = document.createElement('a'); footer.href = '/social'; footer.className = 'bs-social-picker-footer'; footer.textContent = 'إضافة وإدارة الأصدقاء ←';
    panel.append(head, search, count, list, empty, status, footer); modal.appendChild(panel);
    (document.fullscreenElement || document.body).appendChild(modal);
    const background = [...document.querySelectorAll('main,.mobile-dock,.hub-rail,#bsGameCommand')]
      .filter(element => !element.contains(modal)).map(element => [element, element.inert]);
    function dismiss() {
      if (closed) return; closed = true; ++pickerEpoch;
      if (modal.open && typeof modal.close === 'function') modal.close();
      modal.remove(); background.forEach(([element, inert]) => { element.inert = inert; });
      document.body.classList.remove('bs-friend-picker-open');
      if (closeFriendPicker === dismiss) closeFriendPicker = null;
      if (source?.isConnected) source.focus?.();
    }
    closeFriendPicker = dismiss; close.onclick = dismiss;
    modal.addEventListener('cancel', event => { event.preventDefault(); dismiss(); });
    modal.addEventListener('close', dismiss);
    modal.addEventListener('click', event => { if (event.target === modal) dismiss(); });
    modal.addEventListener('keydown', event => {
      event.stopPropagation();
      if (event.key === 'Escape') { event.preventDefault(); dismiss(); return; }
      if (event.key !== 'Tab') return;
      const controls = [...modal.querySelectorAll('button,input,a[href]')].filter(el => !el.disabled && !el.hidden && !el.closest('[hidden]'));
      const first = controls[0], last = controls.at(-1), focused = document.activeElement;
      if (!controls.includes(focused) || !event.shiftKey && focused === last) { event.preventDefault(); first?.focus(); }
      else if (event.shiftKey && focused === first) { event.preventDefault(); last?.focus(); }
    });
    background.forEach(([element]) => { element.inert = true; }); document.body.classList.add('bs-friend-picker-open');
    try { modal.showModal(); } catch { modal.setAttribute('open', ''); }
    modal.classList.add('open'); search.focus(); document.dispatchEvent(new Event('bs-ui-overlay'));
  }

  const apiPublic = {
    version: '26.0.0',
    signup, login, logout, me, user, requestFriend, respondFriend, removeFriend, block, unblock,
    settings, invite, readNotifications, connectRealtime, closeRealtime, openInvitePicker,
    isLoggedIn: () => Boolean(token()), profile: () => cachedProfile(), events,
  };
  window.BS_SOCIAL = apiPublic;
  decorate();
  if (token()) {
    connectRealtime();
    window.addEventListener('load', () => me(true).catch(() => {}), { once: true });
  }
})();
