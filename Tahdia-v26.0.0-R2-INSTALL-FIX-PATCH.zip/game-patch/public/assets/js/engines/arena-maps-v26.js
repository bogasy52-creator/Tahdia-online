// Shared map identities travel with the room and its authoritative snapshots.
export const ARENA_MAPS=Object.freeze([
 Object.freeze({id:'reactor',name:'المفاعل',detail:'حلقات طاقة وكنز دائري',kind:'hex',base:'#101d30',panels:['#142338','#16263c','#15243a'],edge:'#80cfd2',spark:'#8be9ec',treasure:'شحنة المفاعل'}),
 Object.freeze({id:'aurora',name:'بحيرة الشفق',detail:'تموجات زرقاء وشلال نجوم',kind:'water',base:'#101d2b',panels:['#152a3b','#183044','#162b40'],edge:'#aa9bf4',spark:'#b9d9ff',treasure:'نجوم الشفق'}),
 Object.freeze({id:'volcano',name:'قلب البركان',detail:'صخور داكنة وشقوق متوهجة',kind:'lava',base:'#241d25',panels:['#30232b','#34272d','#2c232c'],edge:'#efaa79',spark:'#ffbd86',treasure:'جواهر البركان'}),
 Object.freeze({id:'palace',name:'قصر الهيبة',detail:'أرضية ملكية وخزائن ذهبية',kind:'royal',base:'#201e32',panels:['#2b2740','#302b44','#28253b'],edge:'#e6c681',spark:'#f8de9f',treasure:'خزينة القصر'})
]);
export const arenaMapId=id=>ARENA_MAPS.some(map=>map.id===id)?id:'reactor';
export const arenaMap=id=>ARENA_MAPS.find(map=>map.id===id)||ARENA_MAPS[0];
export function treasurePoint(mapId,index){
 const a=index*(Math.PI*2)/12;
 if(mapId==='aurora')return {x:(index-5.5)*11,y:Math.sin(index*.8)*33};
 if(mapId==='volcano')return {x:Math.cos(a)*(24+index*3),y:Math.sin(a)*(24+index*3)};
 if(mapId==='palace'){const side=Math.floor(index/3),t=(index%3)/3;return [{x:-48+t*96,y:-48},{x:48,y:-48+t*96},{x:48-t*96,y:48},{x:-48,y:48-t*96}][side];}
 return {x:Math.cos(a)*55,y:Math.sin(a)*55};
}
