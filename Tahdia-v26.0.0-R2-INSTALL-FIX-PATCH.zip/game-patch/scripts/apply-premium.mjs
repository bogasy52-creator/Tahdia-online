import {readdir,readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';import{fileURLToPath}from'node:url';
const root=fileURLToPath(new URL('../public/',import.meta.url));
let count=0;const css='<link rel="stylesheet" href="/assets/css/tahdia-premium-v25.css?v=26.0.0">';
const js='<script src="/assets/js/tahdia-premium-v25.js?v=26.0.0"></script>';
const changed=new Set(['arcade-games','journey-ui','paths-online-v24','picture-ui','play-feedback-v24-1','serpent-ui','serpent-art-v16','cosmetic-art','profile-core','social-client','sudoku-online','sudoku-ui','home-v19','shop']);
const gamePages=new Set(['accuracy','dice','jackaroo','journey','local','logic','memory','online','paths-online','picture','puzzle','quiz','reaction','serpent','snakes','sudoku','zahra'].map(name=>name+'.html'));
for(const name of await readdir(root)){
 if(!name.endsWith('.html')||['offline.html','admin.html'].includes(name))continue;
 const target=path.join(root,name);const raw=await readFile(target,'utf8');let next=raw;
 next=next.replace(/<link\b[^>]*href=["']\/?assets\/css\/tahdia-premium-v25\.css[^"']*["'][^>]*>/g,'');
 next=next.replace(/<script\b[^>]*src=["']\/?assets\/js\/tahdia-premium-v25\.js[^"']*["'][^>]*><\/script>/g,'');
 if(gamePages.has(name)&&!next.includes('src="assets/js/play-feedback-v24-1.js')&&!next.includes('src="/assets/js/play-feedback-v24-1.js'))next=next.replace(/<\/body>/i,'<script src="/assets/js/play-feedback-v24-1.js?v=26.0.0"></script></body>');
 next=next.replace(/الإصدار \d+\.\d+\.\d+/g,'الإصدار 26.0.0').replace(/المقتنيات والمكافآت · \d+\.\d+\.\d+/g,'المقتنيات والمكافآت · 26.0.0');
 next=next.replace(/<\/head>/i,css+'</head>').replace(/<\/body>/i,js+'</body>');
 next=next.replace(/(assets\/js\/)([a-z0-9-]+)(\.js\?v=)[\d.]+/g,(all,prefix,file,suffix)=>changed.has(file)?prefix+file+suffix+'26.0.0':all);
 if(next!==raw){await writeFile(target,next);count++;}
}
console.log('Tahdia 26 active on '+count+' route(s).');
