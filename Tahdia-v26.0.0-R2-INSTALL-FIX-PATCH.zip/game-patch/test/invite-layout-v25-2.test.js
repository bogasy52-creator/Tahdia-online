import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {transform} from 'esbuild';
import {createDOM} from './dom-harness.mjs';

const friends=[{username:'ahmad',displayName:'أحْمَد',online:true},{username:'sarah',displayName:'سارة',online:false}];
class Events {addEventListener(){} dispatchEvent(){return true;}}
async function social(options={}) {
 const h=await createDOM(options.page||'index.html',{EventTarget:Events});
 h.storage.set('bs_social_session','test-session');h.context.location.pathname='/quiz';
 const requests=[];let send=options.send||(()=>({ok:true}));
 h.context.fetch=async(url,init={})=>{requests.push({url,init});if(url==='/api/social/me')return Response.json({ok:true,profile:{username:'me',displayName:'أنا'},friends:options.friends||friends});if(url==='/api/social/invites')return Response.json(await send(init));return Response.json({ok:true});};
 if(options.fallback){const create=h.doc.createElement;h.doc.createElement=tag=>{const el=create(tag);if(tag==='dialog')el.showModal=undefined;return el;};}
 await h.runFile('assets/js/social-client.js');
 return {...h,requests,open:()=>h.context.BS_SOCIAL.openInvitePicker({game:'sudoku',roomCode:'123456'}),$:id=>h.doc.getElementById(id),setSend:fn=>{send=fn;}};
}
function key(target,key,extra={}){const event={type:'keydown',key,preventDefault(){this.defaultPrevented=true},stopPropagation(){},...extra};target.dispatchEvent(event);return event;}

test('friend picker uses a native modal above navigation and restores focus and prior inert state',async()=>{
 const h=await social(),source=h.$('homeQuickPlay'),main=h.doc.querySelector('main'),dock=h.doc.querySelector('.mobile-dock');main.inert=false;dock.inert=true;source.focus();
 await h.open();const modal=h.$('bsInviteFriendsModal');assert.equal(modal.tagName,'DIALOG');assert.equal(modal.open,true);assert.equal(main.inert,true);assert.equal(h.doc.activeElement.id,'bsInviteFriendSearch');
 assert.equal(modal.getAttribute('aria-modal'),'true');assert.equal(h.doc.querySelectorAll('#bsInviteFriendsModal').length,1);
 key(modal,'Escape');assert.equal(h.$('bsInviteFriendsModal'),null);assert.equal(main.inert,false);assert.equal(dock.inert,true);assert.equal(h.doc.activeElement,source);assert.equal(h.doc.body.classList.contains('bs-friend-picker-open'),false);
});
test('older browsers get an open fallback with the same close and focus trap',async()=>{
 const h=await social({fallback:true});await h.open();const modal=h.$('bsInviteFriendsModal');assert.equal(modal.getAttribute('open'),'');assert.equal(h.doc.body.classList.contains('bs-friend-picker-open'),true);
 const controls=modal.querySelectorAll('button,input,a[href]'),last=controls.at(-1);last.focus();assert.equal(key(modal,'Tab').defaultPrevented,true);assert.equal(h.doc.activeElement,controls[0]);
 controls[0].focus();key(modal,'Tab',{shiftKey:true});assert.equal(h.doc.activeElement,last);
 modal.dispatchEvent({type:'click',target:modal});assert.equal(h.$('bsInviteFriendsModal'),null);
});
test('Arabic friend search handles diacritics, empty matches and clearing without HTML injection',async()=>{
 const h=await social({friends:[...friends,{username:'safe',displayName:'<img src=x onerror=alert(1)>',online:false}]});await h.open();
 const search=h.$('bsInviteFriendSearch'),rows=h.doc.querySelectorAll('.bs-social-picker-row');search.value='احمد';search.dispatchEvent({type:'input'});assert.equal(rows.filter(row=>!row.hidden).length,1);assert.match(rows.find(row=>!row.hidden).textContent,/أحْمَد/);
 search.value='غير موجود';search.dispatchEvent({type:'input'});assert.equal(rows.filter(row=>!row.hidden).length,0);assert.equal(h.doc.querySelector('.bs-social-empty').hidden,false);
 search.value='';search.dispatchEvent({type:'input'});assert.equal(rows.filter(row=>!row.hidden).length,3);assert.equal(h.$('bsInviteFriendsModal').querySelector('img'),null);
});
test('invite sends once on double click and reports success inside the dialog',async()=>{
 let resolve;const h=await social({send:()=>new Promise(r=>{resolve=r;})});await h.open();const send=h.doc.querySelector('.bs-social-picker-row button');const first=send.onclick();await send.onclick();assert.equal(h.requests.filter(r=>r.url==='/api/social/invites').length,1);resolve({ok:true});await first;
 assert.equal(send.disabled,true);assert.equal(h.$('bsInvitePickerStatus').dataset.tone,'success');const payload=JSON.parse(h.requests.find(r=>r.url==='/api/social/invites').init.body);assert.deepEqual(payload,{username:'ahmad',game:'sudoku',roomCode:'123456'});
});
test('failed invite is visible and can be retried without closing the picker',async()=>{
 const h=await social({send:()=>{throw new Error('انقطع الاتصال');}});await h.open();const send=h.doc.querySelector('.bs-social-picker-row button');await send.onclick();assert.equal(send.disabled,false);assert.match(h.$('bsInvitePickerStatus').textContent,/انقطع الاتصال/);h.setSend(()=>({ok:true}));await send.onclick();assert.equal(send.disabled,true);assert.equal(h.$('bsInvitePickerStatus').dataset.tone,'success');
});
test('session logout closes a picker and prevents a stale invite response from updating it',async()=>{
 let resolve;const h=await social({send:()=>new Promise(r=>{resolve=r;})});await h.open();const send=h.doc.querySelector('.bs-social-picker-row button'),pending=send.onclick();await h.context.BS_SOCIAL.logout();assert.equal(h.$('bsInviteFriendsModal'),null);resolve({ok:true});await pending;assert.equal(h.$('bsInviteFriendsModal'),null);assert.equal(h.doc.querySelector('main').inert,undefined);
});
test('latest picker request wins when friend-list responses arrive out of order',async()=>{
 const h=await social(),pending=[];h.context.fetch=()=>new Promise(resolve=>pending.push(resolve));const a=h.open(),b=h.open();pending[1](Response.json({ok:true,profile:{username:'me'},friends:[friends[1]]}));await b;pending[0](Response.json({ok:true,profile:{username:'me'},friends:[friends[0]]}));await a;
 assert.equal(h.doc.querySelectorAll('#bsInviteFriendsModal').length,1);assert.match(h.$('bsInviteFriendsModal').textContent,/سارة/);assert.doesNotMatch(h.$('bsInviteFriendsModal').textContent,/أحْمَد/);
});
test('fullscreen dialog is attached inside the fullscreen host without inerting its ancestor',async()=>{
 const h=await social(),host=h.doc.querySelector('main');h.doc.fullscreenElement=host;await h.open();assert.equal(h.$('bsInviteFriendsModal').parentElement,host);assert.notEqual(host.inert,true);assert.equal(h.doc.activeElement.id,'bsInviteFriendSearch');
});
test('no-friends and unauthenticated paths remain usable',async()=>{
 const h=await social({friends:[]});await h.open();assert.match(h.doc.querySelector('.bs-social-empty').textContent,/أضفه/);assert.equal(h.doc.querySelector('.bs-social-picker-footer').href,'/social');key(h.$('bsInviteFriendsModal'),'Escape');await h.context.BS_SOCIAL.logout();await h.open();assert.match(h.context.location.href,/^\/social\?auth=1&next=/);assert.equal(h.$('bsInviteFriendsModal'),null);
});
test('layout stylesheet parses and safeguards safe areas, scrolling and overlay order',async()=>{
 const css=await readFile(new URL('../public/assets/css/tahdia-premium-v25.css',import.meta.url),'utf8');const parsed=await transform(css,{loader:'css',minify:true});assert.equal(parsed.warnings.length,0);
 assert.match(css,/--bs-layer-dock:1000;--bs-layer-modal:16000;--bs-layer-invite:17000/);assert.match(css,/#bsInviteFriendsModal::backdrop/);assert.match(css,/safe-area-inset-bottom/);assert.match(css,/#bsInviteFriendsModal \.bs-social-picker-list\{overflow:auto/);
 assert.match(css,/:not\(\[open\]\)>:not\(summary\)\{display:none!important\}/);
 const fx=await readFile(new URL('../public/assets/js/play-feedback-v24-1.js',import.meta.url),'utf8');assert.match(fx,/social-client\.js\?v=26\.0\.0/);assert.doesNotMatch(fx,/social-client\.js\?v=25\.0\.0/);
});
test('home has one library entry per game and keeps useful sections folded, not deleted',async()=>{
 const h=await createDOM('index.html'),cards=h.doc.querySelectorAll('.home-game');assert.equal(cards.length,16);assert.equal(new Set(cards.map(c=>c.getAttribute('href'))).size,16);assert.equal(h.doc.querySelector('.spotlight-grid'),null);assert.equal(h.doc.querySelector('.hub-intro'),null);const ids=h.doc.querySelectorAll('[id]').map(el=>el.id);assert.equal(ids.length,new Set(ids).size);assert.ok(h.doc.querySelector('#homeRoomEntry #homeRoomJoin'));assert.ok(h.doc.querySelector('.hub-progress-fold #profile'));
});
