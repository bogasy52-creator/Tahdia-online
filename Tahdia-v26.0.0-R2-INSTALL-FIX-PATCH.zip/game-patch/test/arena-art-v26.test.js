import test from 'node:test';
import assert from 'node:assert/strict';
import {arenaEnergySprite,arenaFoodSprite,paintArenaFood,paintArenaFloor} from '../public/assets/js/arena-art-v23.js';

test('energy art is cached, supports the fruit option and does not mutate authoritative food',t=>{
 const previous=globalThis.document;let canvases=0;const draws=[];const context=new Proxy({createRadialGradient:()=>({addColorStop(){}}),drawImage:(...args)=>draws.push(args)},{get:(target,key)=>key in target?target[key]:()=>{}});
 globalThis.document={createElement:tag=>{assert.equal(tag,'canvas');canvases++;return {width:0,height:0,getContext:()=>context};}};t.after(()=>{globalThis.document=previous;});
 const orb=arenaEnergySprite('apple');assert.equal(orb.width,96);assert.equal(arenaEnergySprite('apple'),orb);assert.equal(canvases,1);
 const food={x:100,y:200,kind:'apple',radius:6,value:2},before=JSON.stringify(food);for(let i=0;i<1000;i++)paintArenaFood(context,food,i*16,false,'energy');assert.equal(canvases,1);assert.equal(draws.length,1000);assert.ok(draws.every(args=>args.slice(1).every(Number.isFinite)));assert.equal(JSON.stringify(food),before);
 paintArenaFood(context,food,0,true,'fruits');assert.equal(draws.at(-1)[0],arenaFoodSprite('apple'));assert.equal(canvases,2);assert.notEqual(draws.at(-1)[0],orb);
});
test('new floor stays bounded to the viewport tiles and preserves game dimensions',()=>{
 let panels=0;const fills=[];const context=new Proxy({fillRect:(...args)=>fills.push({color:context.fillStyle,args}),closePath:()=>panels++},{get:(target,key)=>key in target?target[key]:()=>{}});
 const game={width:1400,height:1400},before=JSON.stringify(game);paintArenaFloor(context,game,{minX:300,minY:300,maxX:700,maxY:700},.8);assert.equal(fills[0].color,'#101d30');assert.ok(panels<50);assert.equal(JSON.stringify(game),before);
});
