import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {createDOM} from './dom-harness.mjs';
import {ArenaGestures} from '../public/assets/js/arena-gestures.js';

test('each game guide uses a modal and restores prior inert state and focus',async()=>{
 for(const page of ['sudoku','serpent','paths-online','quiz','journey']){
  const h=await createDOM(page+'.html');await h.runFile('assets/js/play-feedback-v24-1.js');const source=h.doc.querySelector('.bs-command-help'),main=h.doc.querySelector('main');main.inert=false;source.focus();source.onclick();const modal=h.doc.getElementById('bsGameHelp');assert.equal(modal.tagName,'DIALOG');assert.equal(modal.open,true);assert.equal(modal.querySelectorAll('li').length,3);assert.equal(main.inert,true);assert.equal(h.doc.activeElement.className,'bs-guide-done');modal.dispatchEvent({type:'keydown',key:'Escape',preventDefault(){},stopPropagation(){}});assert.equal(h.doc.getElementById('bsGameHelp'),null);assert.equal(main.inert,false);assert.equal(h.doc.activeElement,source);
 }
});
test('game guide fallback is usable without showModal and traps Tab',async()=>{
 const h=await createDOM('sudoku.html'),create=h.doc.createElement;h.doc.createElement=tag=>{const el=create(tag);if(tag==='dialog')el.showModal=undefined;return el;};await h.runFile('assets/js/play-feedback-v24-1.js');h.doc.querySelector('.bs-command-help').onclick();const modal=h.doc.getElementById('bsGameHelp'),buttons=modal.querySelectorAll('button');assert.equal(modal.getAttribute('open'),'');modal.dispatchEvent({type:'keydown',key:'Tab',preventDefault(){},stopPropagation(){}});assert.equal(h.doc.activeElement,buttons[0]);buttons[0].onclick();assert.equal(h.doc.getElementById('bsGameHelp'),null);
});
test('touch sensitivity has distinct controlled dead zones and clamps malformed preferences',()=>{
 const counts=[];for(const sensitivity of [.75,1,1.5]){let count=0;const g=new ArenaGestures({mode:'floating',sensitivity,steer:()=>count++});g.start({pointerId:1,clientX:100,clientY:100},{left:0,top:0,width:390,height:844});g.move({pointerId:1,clientX:104,clientY:100});counts.push(count);g.setSensitivity(Infinity);assert.equal(g.sensitivity,1);g.setSensitivity(99);assert.equal(g.sensitivity,1.6);g.setSensitivity(-5);assert.equal(g.sensitivity,.7);}assert.deepEqual(counts,[0,0,1]);
});
test('preview converts listening host arguments without treating them as Wrangler upstreams',async()=>{
 const source=(await readFile(new URL('../scripts/dev-preview.mjs',import.meta.url),'utf8')).replace(/^import .*?;\n/,'');
 for(const host of [['--host','0.0.0.0'],['--host=0.0.0.0']]){const calls=[];vm.runInNewContext(source,{spawn:(...args)=>{calls.push(args);return {on(){},kill(){}};},process:{argv:['node','script',...host,'--port','4173','--strictPort'],platform:'linux',on(){}},console});assert.equal(calls[0][0],'wrangler');const args=Array.from(calls[0][1]);assert.ok(args.includes('--ip')||args.includes('--ip=0.0.0.0'));assert.ok(!args.includes('--host'));assert.ok(!args.includes('--strictPort'));}
});
test('all supported game pages include one feedback entrypoint, including the quiz hub',async()=>{
 for(const name of ['accuracy','dice','jackaroo','journey','local','logic','memory','online','paths-online','picture','puzzle','quiz','reaction','serpent','snakes','sudoku','zahra']){const html=await readFile(new URL('../public/'+name+'.html',import.meta.url),'utf8');assert.equal([...html.matchAll(/src="\/?assets\/js\/play-feedback-v24-1\.js\?v=26\.0\.0"/g)].length,1,name);}
});
