import test from 'node:test';
import assert from 'node:assert/strict';
import {createDOM} from './dom-harness.mjs';
import {Career} from '../src/career/core.js';
async function store(){const h=await createDOM('shop.html');h.storage.set('busraj-career-v6',JSON.stringify(Career.normalize({coins:2000})));await h.runFile('assets/js/profile-core.js');await h.runFile('assets/js/career-client.js');await h.context.BS_CAREER.refresh();const mounted=[];h.context.BS_COSMETIC_ART={mount(el,item,options){const canvas=h.doc.createElement('canvas');canvas.dataset.skin=item.id;el.appendChild(canvas);mounted.push({item:item.id,options});return canvas;}};await h.runFile('assets/js/shop.js');return {...h,mounted,$:id=>h.doc.getElementById(id)};}
test('the featured collection switches between six real catalogue appearances',async()=>{
 const h=await store(),buttons=h.$('featureSkins').querySelectorAll('button');assert.equal(buttons.length,6);for(const button of buttons){button.onclick();assert.equal(h.$('vaultFeatureArt').querySelector('canvas').dataset.skin,button.dataset.featureItem);assert.equal(button.getAttribute('aria-pressed'),'true');assert.equal(buttons.filter(b=>b.getAttribute('aria-pressed')==='true').length,1);assert.equal(h.$('vaultFeatureArt').querySelectorAll('canvas').length,1);}assert.ok(h.doc.querySelector('.store-side-v16').contains(h.$('storeViews')));assert.ok(h.doc.querySelector('.store-main-v16').contains(h.$('storeGrid')));
});
test('product inspector mounts real live art and accessible rotate and zoom controls',async()=>{
 const h=await store();h.doc.querySelector('[data-item="snake-plasma"] .item-inspect').onclick();const canvas=h.$('itemArt').querySelector('canvas'),buttons=h.$('itemArt').querySelectorAll('button');assert.equal(canvas.dataset.skin,'snake-plasma');assert.equal(buttons.length,5);assert.ok(buttons.every(b=>b.getAttribute('aria-label')));buttons[1].onclick();assert.match(canvas.style.transform,/rotate\(15deg\)/);for(let i=0;i<20;i++)buttons[3].onclick();assert.match(canvas.style.transform,/scale\(1.6\)/);buttons[4].onclick();assert.match(canvas.style.transform,/rotate\(0deg\) scale\(1\)/);assert.ok(h.mounted.some(x=>x.item==='snake-plasma'&&x.options.live));
});
test('checkout failure is visible inside the modal and removing an item preserves focus',async()=>{
 const h=await store();for(const id of ['pawn-jade','dice-copper'])h.doc.querySelector('[data-item="'+id+'"] .cart-add-v15').onclick();h.$('cartOpen').onclick();const before=h.context.BS_CAREER.get().coins;h.context.BS_CAREER.cart=async()=>{throw Error('checkout_conflict');};await h.$('cartCheckout').onclick();assert.match(h.$('cartError').textContent,/تغيّرت اختيارات/);assert.equal(h.doc.querySelector('main').inert,true);assert.equal(h.context.BS_CAREER.get().coins,before);const remove=h.$('cartItems').querySelector('.cart-remove-v15');remove.focus();remove.onclick();assert.equal(h.doc.activeElement.className,'cart-remove-v15');assert.equal(h.$('cartCount').textContent,'1');
});
test('closed studio does not animate and toggling it keeps one preview with the selected skin',async()=>{
 const h=await store(),studio=h.$('storeStudio');assert.equal(h.mounted.find(x=>x.options.width===840).options.live,false);
 studio.open=true;studio.dispatchEvent({type:'toggle'});assert.equal(h.mounted.at(-1).options.live,true);assert.equal(h.$('vaultFeatureArt').querySelectorAll('canvas').length,1);
 studio.open=false;studio.dispatchEvent({type:'toggle'});assert.equal(h.mounted.at(-1).options.live,false);assert.equal(h.$('vaultFeatureArt').querySelectorAll('canvas').length,1);
});
test('all item categories remain accessible through the compact type filter',async()=>{
 const h=await store(),select=h.$('storeType');assert.equal(h.$('storeTabs').querySelectorAll('button').length,4);
 for(const type of ['snake','character','dice','pawn','board','table','trail','victory','title']){select.value=type;select.dispatchEvent({type:'change',target:select});const cards=h.$('storeGrid').querySelectorAll('[data-item]');assert.ok(cards.length>0,type);assert.ok(cards.every(card=>h.context.BS_CAREER.catalog.find(i=>i.id===card.dataset.item).type===type),type);assert.equal(select.value,type);}
 h.$('storeReset').onclick();assert.equal(select.value,'all');assert.ok(h.$('storeGrid').querySelectorAll('[data-item]').length>20);assert.equal(h.doc.querySelector('.store-card-more-v17'),null);
 const ids=h.doc.querySelectorAll('[id]').map(el=>el.id);assert.equal(ids.length,new Set(ids).size);
});
