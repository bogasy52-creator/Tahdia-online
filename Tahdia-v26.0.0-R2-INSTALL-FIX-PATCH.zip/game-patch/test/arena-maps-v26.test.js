import test from 'node:test';
import assert from 'node:assert/strict';
import {ARENA_MAPS,arenaMapId,treasurePoint} from '../public/assets/js/engines/arena-maps-v26.js';
import {createSerpentGame,stepSerpent,serpentSnapshot} from '../public/assets/js/engines/serpent-engine.js';
import {paintArenaFloor,paintArenaAtmosphere} from '../public/assets/js/arena-art-v23.js';
test('four maps keep their identities in authoritative snapshots and their treasure layouts are distinct and bounded',()=>{
 const shapes=[];
 for(const map of ARENA_MAPS){const g=createSerpentGame([{id:'a'}],{collisionMode:'arena-v23',mapId:map.id,seed:44,foodCount:0});assert.equal(serpentSnapshot(g).mapId,map.id);g.elapsed=15;g.nextTreasureAt=15;stepSerpent(g,1/60);assert.equal(g.events.filter(e=>e.type==='treasure').length,1);assert.equal(g.food.filter(f=>f.kind==='gem').length,4);assert.equal(g.food.filter(f=>f.kind==='star').length,8);const points=Array.from({length:12},(_,i)=>treasurePoint(map.id,i));assert.ok(points.every(p=>Math.hypot(p.x,p.y)<80));shapes.push(JSON.stringify(points));}
 assert.equal(new Set(shapes).size,4);assert.equal(arenaMapId('forged'),'reactor');
});
test('map art has bounded particles, respects reduced motion and never changes simulation state',()=>{
 let particles=0;const ctx=new Proxy({fill:()=>particles++},{get:(o,k)=>k in o?o[k]:()=>{}}),bounds={minX:0,minY:0,maxX:1400,maxY:1400};
 for(const map of ARENA_MAPS){const g={width:1400,height:1400,mapId:map.id,elapsed:12},before=JSON.stringify(g);paintArenaFloor(ctx,g,bounds,.8);particles=0;paintArenaAtmosphere(ctx,g,bounds,false,10000);assert.ok(particles<=24);particles=0;paintArenaAtmosphere(ctx,g,bounds,true,24);assert.equal(particles,0);paintArenaAtmosphere(ctx,g,bounds,false,0);assert.equal(particles,0);assert.equal(JSON.stringify(g),before);}
});
test('the larger manager appearance grants no simulation size, speed, mass or score advantage',()=>{
 const a=createSerpentGame([{id:'a',skin:'snake-sovereign'}],{collisionMode:'arena-v23',seed:71}),b=createSerpentGame([{id:'a',skin:'snake-wild'}],{collisionMode:'arena-v23',seed:71});
 for(let i=0;i<500;i++){stepSerpent(a,1/60);stepSerpent(b,1/60);}const clean=g=>{const s=structuredClone(g);for(const snake of s.snakes)delete snake.skin;return s;};assert.deepEqual(clean(a),clean(b));
});
