import test from 'node:test';
import assert from 'node:assert/strict';
import {createDOM} from './dom-harness.mjs';
import * as engine from '../public/assets/js/engines/baloot-engine.js';
import * as talk from '../public/assets/js/engines/baloot-talk.js';
import {BalootVoice} from '../public/assets/js/baloot-voice.js';

async function table(voice=BalootVoice){
  const h=await createDOM('baloot.html');
  h.context.BS_CARDS={DECKS:{'deck-classic':{}},url:card=>'/cards/'+card+'.svg'};
  h.context.BS_GAME_MENU={mount:()=>({menu(){},setMode(){}})};
  await h.runFile('assets/js/baloot-table.js',{...engine,...talk,BalootVoice:voice});
  // MiniElement does not reflect the native boolean hidden attribute.
  h.doc.getElementById('talkSheet').hidden=true;
  h.doc.getElementById('talkBtn').click();return h;
}
test('pending human recordings are accurately represented in the table controls',async()=>{
  const pending={getStatus:()=>({...BalootVoice.getStatus(),available:false,state:'awaiting-recordings'}),unlock(){}};
  const h=await table(pending),get=id=>h.doc.getElementById(id);
  assert.equal(get('talkSheet').hidden,false);assert.equal(get('voiceToggle').disabled,true);
  assert.equal(get('voiceToggle').getAttribute('aria-pressed'),'false');
  assert.equal(get('voicePreview').disabled,true);assert.equal(get('voiceReplay').disabled,true);
  assert.match(get('voiceNote').textContent,/التسجيلات البشرية/);
  assert.equal(get('voiceNote').getAttribute('role'),'status');
});
test('voice controls react to playback, replay availability and global mute without rebuilding phrase buttons',async()=>{
  let state={available:true,enabled:true,state:'ready',last:null,lastText:null},previews=0,replays=0,stops=0;
  const voice={enabled:true,getStatus:()=>state,unlock(){},preview(){previews++;},replay(){replays++;},stop(){stops++;},setEnabled(on){this.enabled=on;state={...state,enabled:on,state:on?'ready':'disabled'};}};
  const h=await table(voice),get=id=>h.doc.getElementById(id),first=get('talkGrid').children[0];
  assert.equal(get('voicePreview').disabled,false);assert.equal(get('voiceReplay').disabled,true);
  get('voicePreview').click();assert.equal(previews,1);
  const update=next=>{state={...state,...next};h.context.dispatchEvent({type:'bs-baloot-voice-change'});};
  update({last:'pass',lastText:'بس.',state:'playing'});assert.equal(get('voiceReplay').disabled,true);
  update({state:'ready'});assert.equal(get('voiceReplay').disabled,false);get('voiceReplay').click();assert.equal(replays,1);
  assert.equal(get('voiceLast').textContent,'آخر نداء: بس.');
  update({state:'muted'});assert.equal(get('voicePreview').disabled,true);assert.equal(get('voiceReplay').disabled,true);
  assert.equal(get('talkGrid').children[0],first,'status updates preserve phrase focus');
  get('leaveLobby').click();assert.equal(stops,1);assert.equal(get('talkSheet').hidden,true);
});
