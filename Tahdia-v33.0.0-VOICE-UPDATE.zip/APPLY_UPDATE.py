#!/usr/bin/env python3
"""Preview/apply this sparse update. Every old and new byte is checked before writing."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import tempfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def regular_path(root, relative):
    pure = PurePosixPath(relative)
    if pure.is_absolute() or not pure.parts or any(part in (".", "..") for part in pure.parts) or "\\" in relative:
        raise ValueError("Unsafe patch path: " + relative)
    target = root.joinpath(*pure.parts)
    for path in (target, *target.parents):
        if path == root.parent:
            break
        if path.is_symlink():
            raise ValueError("Symbolic links are not patch targets: " + relative)
    if target.exists() and not target.is_file():
        raise ValueError("Patch target is not a regular file: " + relative)
    return target


def atomic_write(path, data, mode):
    temp = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as handle:
            temp = Path(handle.name)
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temp, mode)
        os.replace(temp, path)
    finally:
        if temp is not None:
            temp.unlink(missing_ok=True)


def apply(root, bundle, mutate):
    root = root.absolute()
    if root.is_symlink():
        raise ValueError("Select the real project directory")
    manifest = json.loads((bundle / "patch-manifest.json").read_text())
    if manifest.get("format") != "busraj-sparse-patch-v1":
        raise ValueError("Unknown patch format")
    version = json.loads((root / "package.json").read_text())["version"]
    if version not in manifest["supported_versions"]:
        raise ValueError("This patch does not support project version " + str(version))
    for required in ("src/index.js", "public/index.html", "wrangler.jsonc"):
        if not regular_path(root, required).is_file():
            raise ValueError("Select tahadi-alabaqera-online-pro-fixed, not its parent directory")
    changes, names = [], set()
    for row in manifest["files"]:
        name = row["path"]
        if name in names:
            raise ValueError("Duplicate patch path: " + name)
        names.add(name)
        payload = regular_path(bundle / "game-patch", name).read_bytes()
        if digest(payload) != row["sha256"] or len(payload) != row["size_bytes"]:
            raise ValueError("Corrupt update payload: " + name)
        target = regular_path(root, name)
        before = target.read_bytes() if target.exists() else None
        old_hash = digest(before) if before is not None else None
        if old_hash == row["sha256"]:
            continue
        if old_hash not in row["previous_sha256"]:
            raise ValueError("Source has changed: " + name + ". No files were replaced; obtain an update for this source.")
        changes.append((target, before, payload, stat.S_IMODE(target.stat().st_mode) if target.exists() else 0o644))
    if not mutate:
        return {"verified": True, "applied": False, "files_to_change": len(changes), "version": version}
    installed, created = [], []
    try:
        for target, before, payload, mode in changes:
            # Recheck immediately before replacement; do not overwrite concurrent work.
            current = target.read_bytes() if target.exists() else None
            if current != before:
                raise ValueError("Project changed while applying: " + str(target.relative_to(root)))
            absent, parent = [], target.parent
            while not parent.exists():
                absent.append(parent)
                parent = parent.parent
            for directory in reversed(absent):
                directory.mkdir()
                created.append(directory)
            atomic_write(target, payload, mode)
            installed.append((target, before, mode))
    except Exception:
        for target, before, mode in reversed(installed):
            if before is None:
                target.unlink(missing_ok=True)
            else:
                atomic_write(target, before, mode)
        for directory in reversed(created):
            try:
                directory.rmdir()
            except OSError:
                pass
        raise
    return {"verified": True, "applied": True, "changed": len(changes), "version": version,
            "human_recordings_included": False, "hosting_configuration_changed": False}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True, type=Path)
    parser.add_argument("--apply", action="store_true", help="Apply after checking every file; otherwise preview only")
    args = parser.parse_args()
    try:
        print(json.dumps(apply(args.project, Path(__file__).resolve().parent, args.apply), indent=2))
    except (OSError, ValueError, KeyError) as error:
        print("Update refused: " + str(error), file=sys.stderr)
        sys.exit(1)
