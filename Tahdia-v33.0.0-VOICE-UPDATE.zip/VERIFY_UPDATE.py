"""Installer checks use temporary minimal projects, never the user's working source."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

SPEC = importlib.util.spec_from_file_location("installer", Path(__file__).with_name("APPLY_UPDATE.py"))
INSTALLER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(INSTALLER)


class InstallerTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="tahdia-update-check-")
        self.root, self.bundle = [Path(self.temp.name) / name for name in ("project", "bundle")]
        for name, data in {"package.json": b'{"version":"33.0.0"}', "src/index.js": b"original server",
                           "public/index.html": b"original home", "wrangler.jsonc": b"owner hosting config"}.items():
            file = self.root / name
            file.parent.mkdir(parents=True, exist_ok=True)
            file.write_bytes(data)
        rows = []
        for name, data in {"src/index.js": b"updated server", "public/voice-ready.js": b"new voice module"}.items():
            file = self.bundle / "game-patch" / name
            file.parent.mkdir(parents=True, exist_ok=True)
            file.write_bytes(data)
            old = self.root / name
            rows.append({"path": name, "sha256": hashlib.sha256(data).hexdigest(), "size_bytes": len(data),
                         "previous_sha256": [hashlib.sha256(old.read_bytes()).hexdigest() if old.exists() else None]})
        self.manifest = {"format": "busraj-sparse-patch-v1", "supported_versions": ["33.0.0"], "files": rows}
        self.save_manifest()

    def tearDown(self):
        self.temp.cleanup()

    def save_manifest(self):
        (self.bundle / "patch-manifest.json").write_text(json.dumps(self.manifest))

    def test_preview_changes_nothing(self):
        result = INSTALLER.apply(self.root, self.bundle, False)
        self.assertEqual(result["files_to_change"], 2)
        self.assertEqual((self.root / "src/index.js").read_bytes(), b"original server")
        self.assertFalse((self.root / "public/voice-ready.js").exists())

    def test_apply_is_repeatable_and_preserves_hosting(self):
        INSTALLER.apply(self.root, self.bundle, True)
        self.assertEqual(INSTALLER.apply(self.root, self.bundle, True)["changed"], 0)
        self.assertEqual((self.root / "wrangler.jsonc").read_bytes(), b"owner hosting config")

    def test_changed_source_is_refused_before_writing(self):
        (self.root / "src/index.js").write_bytes(b"owner edits")
        with self.assertRaisesRegex(ValueError, "Source has changed"):
            INSTALLER.apply(self.root, self.bundle, True)
        self.assertFalse((self.root / "public/voice-ready.js").exists())
        self.assertEqual((self.root / "src/index.js").read_bytes(), b"owner edits")

    def test_corrupt_payload_is_refused_before_writing(self):
        (self.bundle / "game-patch/public/voice-ready.js").write_bytes(b"corrupt")
        with self.assertRaisesRegex(ValueError, "Corrupt update"):
            INSTALLER.apply(self.root, self.bundle, True)
        self.assertEqual((self.root / "src/index.js").read_bytes(), b"original server")

    def test_mid_install_failure_rolls_back_every_changed_file(self):
        original = INSTALLER.atomic_write
        calls = 0
        def fail_second(*args):
            nonlocal calls
            calls += 1
            if calls == 2:
                raise OSError("injected write failure")
            original(*args)
        with patch.object(INSTALLER, "atomic_write", fail_second):
            with self.assertRaisesRegex(OSError, "injected"):
                INSTALLER.apply(self.root, self.bundle, True)
        self.assertEqual((self.root / "src/index.js").read_bytes(), b"original server")
        self.assertFalse((self.root / "public/voice-ready.js").exists())

    def test_paths_outside_project_are_refused(self):
        self.manifest["files"][0]["path"] = "../outside.js"
        self.save_manifest()
        with self.assertRaisesRegex(ValueError, "Unsafe patch path"):
            INSTALLER.apply(self.root, self.bundle, True)
        self.assertFalse((self.root.parent / "outside.js").exists())


if __name__ == "__main__":
    unittest.main()
