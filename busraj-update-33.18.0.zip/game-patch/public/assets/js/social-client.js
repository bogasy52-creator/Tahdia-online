(() => {
  const STORAGE_KEY = 'bs_social_session';
  const PROFILE_KEY = 'bs_social_profile';
  const SEEN_INVITES_KEY = 'bs_seen_invites_v25_2';
  const INBOX_INTERVAL_MS = 30000;
  const state = { token: '', profile: null, dashboard: null, socket: null, reconnectTimer: null, reconnectAttempt: 0, manualClose: false, heartbeat:null, welcomeTimer:null, lastMessageAt:0 };
  const events = new EventTarget();
  let inboxTimer = null;
  let inboxPending = null;
  let inviteExpiryTimer=null;
  // 33.10.7: an invitation used to show once, at the bottom, and was gone. Now every pending one waits
  // in an inbox: a red count on the friends button of every page, and a list on the home page.
  const pendingInvites = new Map();
  let friendRequests = [];
  let inboxTicker = null;
  const INBOX_STYLE = `
#bsSocialInvite.bs-social-invite-card{top:calc(10px + env(safe-area-inset-top))!important;bottom:auto!important;left:50%!important;right:auto!important;translate:-50% 0;z-index:13000!important;border:2px solid #ef4444!important;background:linear-gradient(180deg,#3a111b,#1a0a12)!important;box-shadow:0 0 0 4px rgba(239,68,68,.25),0 18px 40px rgba(0,0,0,.55)!important;animation:bsInviteIn .45s cubic-bezier(.2,1.4,.4,1)}
#bsSocialInvite.bs-social-invite-card .bs-btn.gold{background:#ef4444!important;border-color:#ef4444!important;color:#fff!important}
#bsSocialInvite.bs-social-invite-card b{color:#fff!important;font-size:17px}
@keyframes bsInviteIn{from{transform:translateY(-24px) scale(.96);opacity:0}to{transform:none;opacity:1}}
[data-bs-invite-anchor]{position:relative}
.bs-invite-badge{position:absolute;top:-6px;inset-inline-end:-6px;min-width:20px;height:20px;padding:0 5px;border-radius:99px;background:#ef4444;color:#fff;border:2px solid #0b0d1c;font:800 11px/16px system-ui,sans-serif;text-align:center;box-shadow:0 0 0 3px rgba(239,68,68,.25);animation:bsInvitePulse 1.6s ease-in-out infinite;pointer-events:none}
.bs-invite-badge[hidden]{display:none}
@keyframes bsInvitePulse{50%{box-shadow:0 0 0 7px rgba(239,68,68,0)}}
.bs-invite-inbox{margin:12px auto;padding:14px;max-width:760px;border:2px solid #ef4444;border-radius:20px;background:linear-gradient(180deg,rgba(239,68,68,.16),rgba(239,68,68,.05));color:#fff}
.bs-invite-inbox[hidden]{display:none}
.bs-invite-inbox h2{display:flex;align-items:center;gap:10px;margin:0 0 10px;font-size:18px}
.bs-invite-inbox h2 i{font-style:normal;min-width:26px;height:26px;padding:0 7px;border-radius:99px;background:#ef4444;color:#fff;font-size:14px;line-height:26px;text-align:center}
.bs-invite-row{display:flex;align-items:center;gap:10px;padding:10px;border-radius:14px;background:rgba(10,12,26,.72);border:1px solid rgba(239,68,68,.45)}
.bs-invite-row+.bs-invite-row{margin-top:8px}
.bs-invite-row>div:first-child{flex:1;min-width:0}
.bs-invite-row b{display:block;font-size:15px}
.bs-invite-row span{display:block;font-size:13px;opacity:.8}
.bs-invite-row .bs-invite-actions{display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end}
.bs-invite-row .bs-btn{min-height:38px;padding:0 14px;text-decoration:none;display:inline-grid;place-items:center}
.bs-invite-row .bs-invite-join{background:#ef4444;border-color:#ef4444;color:#fff}`;
  const INBOX_ANCHORS = '[data-social-open], a.bs-icon-btn[href="./"], a.bs-icon-btn[href="/"], a[aria-label="الرئيسية"], a[aria-label="الرجوع للرئيسية"]';
  function inviteStyle() {
    if (!document.head || typeof document.getElementById !== 'function' || document.getElementById('bsInviteInboxStyle')) return;
    const style = document.createElement('style'); style.id = 'bsInviteInboxStyle'; style.textContent = INBOX_STYLE; document.head.appendChild(style);
  }
  const seenInvites = new Set();
  function seenKey() { return `${SEEN_INVITES_KEY}:${cachedProfile()?.username || token().split('.')[0] || 'guest'}`; }
  function loadSeen() {
    seenInvites.clear();
    try { for (const id of JSON.parse(localStorage.getItem(seenKey()) || '[]')) seenInvites.add(String(id)); } catch {}
  }
  function rememberInvite(id) {
    if (!id) return;
    seenInvites.add(String(id));
    const recent = [...seenInvites].slice(-80);
    try { localStorage.setItem(seenKey(), JSON.stringify(recent)); } catch {}
  }
  function inviteOpen(n) { return n?.type === 'game_invite' && !n.read && n.joinPath && INVITE_PATH.test(n.joinPath) && Number(n.expiresAt || 0) > Date.now(); }
  function trackInvite(n) { if (inviteOpen(n)) { pendingInvites.set(String(n.id || n.createdAt), n); renderInbox(); } }
  function dropInvites(ids = []) {
    if (!ids.length) pendingInvites.clear(); else for (const id of ids) pendingInvites.delete(String(id));
    renderInbox();
  }
  function openInvites() {
    for (const [id, n] of pendingInvites) if (!inviteOpen(n)) pendingInvites.delete(id);
    return [...pendingInvites.values()].sort((a, b) => Number(b.createdAt || 0) - Number(a.createdAt || 0));
  }
  function timeLeft(n) { const s = Math.max(0, Math.round((Number(n.expiresAt || 0) - Date.now()) / 1000)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }
  function inboxButton(label, className, action) { const b = document.createElement('button'); b.type = 'button'; b.className = 'bs-btn ' + className; b.textContent = label; b.onclick = action; return b; }
  // the inbox is a convenience: whatever a page lacks, it never stops invitations or the rest of the client
  function renderInbox() { try { drawInbox(); } catch {} }
  function drawInbox() {
    inviteStyle();
    const signed = Boolean(token());
    const invites = signed ? openInvites() : [], requests = signed ? friendRequests : [];
    const count = invites.length + requests.length;
    // the friends button on the home page, and the home button on every game page (the list is there)
    document.querySelectorAll(INBOX_ANCHORS).forEach((el) => {
      let badge = el.querySelector(':scope > .bs-invite-badge');
      if (!badge) {
        if (!count) return;
        el.setAttribute('data-bs-invite-anchor', ''); el.dataset.bsLabel = el.getAttribute('aria-label') || '';
        badge = document.createElement('span'); badge.className = 'bs-invite-badge'; badge.setAttribute('aria-hidden', 'true'); el.appendChild(badge);
      }
      badge.textContent = count > 9 ? '9+' : String(count); badge.hidden = !count;
      const base = el.dataset.bsLabel || '';
      if (count) el.setAttribute('aria-label', `${base ? base + ' — ' : ''}عندك ${count} ${count === 1 ? 'دعوة' : 'دعوات'}`); else if (base) el.setAttribute('aria-label', base); else el.removeAttribute('aria-label');
    });
    document.querySelectorAll('[data-invite-list]').forEach((box) => {
      box.hidden = !count; box.replaceChildren();
      if (!count) return;
      const head = document.createElement('h2'), num = document.createElement('i');
      num.textContent = String(count); head.append(num, document.createTextNode(count === 1 ? 'عندك دعوة' : 'عندك دعوات'));
      box.appendChild(head);
      for (const n of invites) {
        const row = document.createElement('div'), copy = document.createElement('div'), title = document.createElement('b'), sub = document.createElement('span'), actions = document.createElement('div');
        row.className = 'bs-invite-row'; actions.className = 'bs-invite-actions';
        title.textContent = `🎮 ${n.from?.displayName || n.from?.username || 'صديق'} يدعوك`;
        sub.textContent = `${gameLabel(n.game)}${n.roomCode ? ' · الغرفة ' + n.roomCode : ''} · باقي ${timeLeft(n)}`;
        const join = document.createElement('a'); join.className = 'bs-btn bs-invite-join'; join.textContent = 'انضم'; join.href = n.joinPath;
        join.addEventListener('click', () => { if (n.id) readNotifications([n.id]).catch(() => {}); });
        actions.append(join, inboxButton('تجاهل', '', () => { if (n.id) readNotifications([n.id]).catch(() => {}); dropInvites([n.id]); }));
        copy.append(title, sub); row.append(copy, actions); box.appendChild(row);
      }
      for (const r of requests) {
        const row = document.createElement('div'), copy = document.createElement('div'), title = document.createElement('b'), sub = document.createElement('span'), actions = document.createElement('div');
        row.className = 'bs-invite-row'; actions.className = 'bs-invite-actions';
        title.textContent = `👥 ${r.displayName || r.username} يبي يصير صديقك`; sub.textContent = 'طلب صداقة';
        const answer = (accept) => async () => { try { await respondFriend(r.username, accept); friendRequests = friendRequests.filter((x) => x.username !== r.username); renderInbox(); toast(accept ? '✅ صرتوا أصدقاء' : 'تم رفض الطلب'); } catch (error) { toast(error.message); } };
        actions.append(inboxButton('قبول', 'bs-invite-join', answer(true)), inboxButton('رفض', '', answer(false)));
        copy.append(title, sub); row.append(copy, actions); box.appendChild(row);
      }
    });
    clearInterval(inboxTicker); inboxTicker = invites.length ? setInterval(renderInbox, 15000) : null;
  }
  function syncInbox(data) {
    if (!data || !Array.isArray(data.notifications) || !token()) return;
    pendingInvites.clear();
    for (const n of data.notifications) if (inviteOpen(n)) pendingInvites.set(String(n.id || n.createdAt), n);
    friendRequests = Array.isArray(data.incoming) ? data.incoming.filter((r) => r && r.username) : [];
    renderInbox();
    const latest = [...data.notifications]
      .filter(n => n?.type === 'game_invite' && !n.read && n.joinPath && Number(n.expiresAt || 0) > Date.now())
      .sort((a, b) => Number(b.createdAt || 0) - Number(a.createdAt || 0))
      .find(n => !seenInvites.has(String(n.id)));
    if (latest) showIncomingInvite(latest);
  }
  function refreshInbox() {
    if (!token() || document.hidden) return Promise.resolve(null);
    if (!inboxPending) { const request=me(true).catch(() => null).finally(() => { if(inboxPending===request)inboxPending=null; }); inboxPending=request; }
    return inboxPending;
  }
  function startInbox() {
    clearInterval(inboxTimer);
    if (!token()) return;
    loadSeen();
    inboxTimer = setInterval(()=>{if(state.socket?.readyState!==1)refreshInbox();}, INBOX_INTERVAL_MS);
    refreshInbox();
  }
  function stopInbox() { clearInterval(inboxTimer); inboxTimer = null; inboxPending = null; }
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshInbox(); });
  window.addEventListener('online', refreshInbox);
  window.addEventListener('focus', refreshInbox);


  function readStorage(key) { try { return localStorage.getItem(key) || ''; } catch { return ''; } }
  // another tab signed out (or into another account) while a request was on its way
  function signedOutElsewhere(session) { try { return localStorage.getItem(STORAGE_KEY) !== session; } catch { return false; } }
  function writeStorage(key, value) { try { if (value) localStorage.setItem(key, value); else localStorage.removeItem(key); } catch {} }
  function parseJson(value, fallback = null) { try { return JSON.parse(value); } catch { return fallback; } }
  function toast(message) { if (window.BS_PLATFORM?.toast) window.BS_PLATFORM.toast(message); else console.info(message); }
  function token() { if (!state.token) state.token = readStorage(STORAGE_KEY); return state.token; }
  function cachedProfile() {
    if (!state.profile) state.profile = parseJson(readStorage(PROFILE_KEY));
    return state.profile;
  }
  function setSession(nextToken, profile) {
    const changed=state.token!==String(nextToken||'');
    if(changed){closeRealtime();state.reconnectAttempt=0;state.dashboard=null;inboxPending=null;clearTimeout(inviteExpiryTimer);document.querySelector('#bsSocialInvite')?.remove();pendingInvites.clear();friendRequests=[];}
    state.token = String(nextToken || '');
    state.profile = profile || null;
    writeStorage(STORAGE_KEY, state.token);
    writeStorage(PROFILE_KEY, state.profile ? JSON.stringify(state.profile) : '');
    if (state.token) startInbox(); else stopInbox();
    decorate();
    renderInbox();
    window.dispatchEvent(new CustomEvent('bs-social-session'));
  }

  async function api(path, options = {}) {
    const headers = new Headers(options.headers || {});
    if (options.body && !headers.has('content-type')) headers.set('content-type', 'application/json');
    const session = token();
    if (session) headers.set('authorization', `Bearer ${session}`);
    const deadline=typeof AbortSignal!=='undefined'&&AbortSignal.timeout?AbortSignal.timeout(10000):undefined;
    let response;try{response=await fetch(path,{...options,headers,cache:'no-store',signal:options.signal||deadline});}catch(error){throw new Error(error.name==='TimeoutError'||error.name==='AbortError'?'انتهت مهلة الاتصال. أعد المحاولة.':'تعذر الوصول للخادم. تحقق من اتصالك.');}
    const data = await response.json().catch(() => ({}));
    if (response.status === 401 && session===token() && path !== '/api/social/login') {
      setSession('', null);
      closeRealtime();
    }
    if (!response.ok || data.ok === false) {
      const error = new Error(data.error || 'تعذر تنفيذ الطلب');
      error.status = response.status;
      throw error;
    }
    return data;
  }

  async function signup({ username, displayName, password }) {
    const data = await api('/api/social/signup', { method: 'POST', body: JSON.stringify({ username, displayName, password }) });
    setSession(data.token, data.profile);
    connectRealtime();
    return data;
  }
  async function login({ username, password }) {
    const data = await api('/api/social/login', { method: 'POST', body: JSON.stringify({ username, password }) });
    setSession(data.token, data.profile);
    connectRealtime();
    return data;
  }
  async function logout() {
    try { if (token()) await api('/api/social/logout', { method: 'POST' }); } catch {}
    closeRealtime();
    setSession('', null);
    state.dashboard = null;
  }
  async function me(force = false) {
    if (!token()) return null;
    if (state.dashboard && !force) return state.dashboard;
    const session=token();
    const data = await api('/api/social/me');
    if(session!==token()||signedOutElsewhere(session)||data.profile?.username!==session.split('.')[0])return null;
    state.dashboard = data;
    state.profile = data.profile;
    writeStorage(PROFILE_KEY, JSON.stringify(data.profile || null));
    decorate(data);
    syncInbox(data);
    return data;
  }
  async function user(username) { return api(`/api/social/users/${encodeURIComponent(String(username || '').trim())}`); }
  async function requestFriend(username) { const data = await api('/api/social/friends/request', { method: 'POST', body: JSON.stringify({ username }) }); state.dashboard = null; return data; }
  async function respondFriend(username, accept) { const data = await api('/api/social/friends/respond', { method: 'POST', body: JSON.stringify({ username, accept }) }); state.dashboard = null; return data; }
  async function removeFriend(username) { const data = await api(`/api/social/friends/${encodeURIComponent(username)}`, { method: 'DELETE' }); state.dashboard = null; return data; }
  async function block(username) { const data = await api('/api/social/block', { method: 'POST', body: JSON.stringify({ username }) }); state.dashboard = null; return data; }
  async function unblock(username) { const data = await api('/api/social/unblock', { method: 'POST', body: JSON.stringify({ username }) }); state.dashboard = null; return data; }
  async function settings(values) { const data = await api('/api/social/settings', { method: 'POST', body: JSON.stringify(values) }); state.dashboard = null; return data; }
  async function invite(username, game, roomCode, variant) { return api('/api/social/invites', { method: 'POST', body: JSON.stringify({ username, game, roomCode, ...(game === 'journey' && variant ? { variant } : {}) }) }); }
  async function readNotifications(ids = []) { dropInvites(ids); const data = await api('/api/social/notifications/read', { method: 'POST', body: JSON.stringify({ ids }),keepalive:true }); state.dashboard = null; return data; }

  function emit(type, detail) { events.dispatchEvent(new CustomEvent(type, { detail })); }

  // 33.6.0: every game that has rooms opens from an invitation — the challenge games (focus, cipher,
  // wordbomb, chaos) were missing here, so their invitations reached the phone and were dropped.
  const GAME_LABELS = Object.freeze({ party: 'غرفة الأصدقاء', quiz: 'تحدي العباقرة', picture: 'سباق الصور', jackaroo: 'جاكارو', baloot: 'بلوت', snakes: 'الثعابين والسلالم', zahra: 'لودو', serpent: 'حلبة الثعابين', sudoku: 'سودوكو', paths: 'توصيل الأرقام', dice: 'تحدي النرد', journey: 'رحلة النجوم', local: 'تحدي الأسئلة', logic: 'تحدي المنطق', memory: 'تحدي الذاكرة', puzzle: 'ترتيب الأرقام', reaction: 'مواجهة التركيز', focus: 'مواجهة التركيز', cipher: 'ساحة الشفرات', wordbomb: 'صيد الكلمات', chaos: 'سباق الفوضى', ludo: 'لودو', tanks: 'معركة الدبابات', hockey: 'الهوكي', billiards: 'البلياردو', carrom: 'الكيرم', pegs: 'سر الألوان', jewels: 'ماستر الجواهر' });
  // 33.10.7: the newer table games (tanks … pegs) send their rooms too; their invitations were dropped here
  const INVITE_PATH = /^(?:\/(?:party|online|picture|jackaroo|baloot|snakes|zahra|ludo|serpent|sudoku|paths-online|dice|journey|local|logic|memory|puzzle|reaction|focus|cipher|wordbomb|chaos|tanks|hockey|billiards|carrom|pegs|jewels)(?:\?room=\d{6})?|\/journey\?game=(?:paths|jewels))$/;
  const gameLabel = (game) => GAME_LABELS[game] || String(game || 'لعبة');

  function showIncomingInvite(notification) {
    if (!notification?.joinPath || Date.now() >= Number(notification.expiresAt || 0)) return;
    if (!INVITE_PATH.test(notification.joinPath)) return;
    if (notification.id && seenInvites.has(String(notification.id))) return;
    rememberInvite(notification.id);clearTimeout(inviteExpiryTimer);inviteStyle();trackInvite(notification);
    let wrap = document.querySelector('#bsSocialInvite');
    if (!wrap) {
      wrap = document.createElement('div');
      wrap.id = 'bsSocialInvite';
      wrap.className = 'bs-social-invite-card';
    }
    const host = document.fullscreenElement || document.body;
    if (wrap.parentElement !== host) host.appendChild(wrap);
    wrap.innerHTML = '';
    const title = document.createElement('b');
    title.textContent = `🎮 دعوة من ${notification.from?.displayName || notification.from?.username || 'صديق'}`;
    const sub = document.createElement('span');
    const labels = GAME_LABELS;
    sub.textContent = notification.roomCode ? `${labels[notification.game] || notification.game} • الغرفة ${notification.roomCode}` : `تحدٍ جديد • ${labels[notification.game] || notification.game}`;
    const actions = document.createElement('div');
    actions.className = 'bs-social-invite-actions';
    const join = document.createElement('a');
    join.className = 'bs-btn gold'; join.textContent = 'انضم الآن'; join.href = notification.joinPath;
    const close = document.createElement('button');
    close.className = 'bs-btn'; close.textContent = 'لاحقًا'; close.type = 'button'; close.onclick = () => { wrap.remove(); };
    join.addEventListener('click', () => { if (notification.id) readNotifications([notification.id]).catch(() => {}); });
    actions.append(join, close); wrap.append(title, sub, actions);
    wrap.setAttribute('role','status');
    inviteExpiryTimer=setTimeout(()=>wrap.remove(),Math.max(1,Math.min(15000,Number(notification.expiresAt)-Date.now())));
  }

  function handleMessage(raw) {
    let message; try { message = JSON.parse(raw); } catch { return; }
    if (message.type === 'social_welcome') {
      state.profile = message.profile || state.profile;
      if (state.profile) writeStorage(PROFILE_KEY, JSON.stringify(state.profile));
      decorate(); emit('connected', message); return;
    }
    if (message.type === 'notification') {
      state.dashboard = null;
      const n = message.notification;
      if (n?.type === 'game_invite') { trackInvite(n); showIncomingInvite(n); }
      else if (n?.type === 'friend_request') { toast(`👥 طلب صداقة من ${n.from?.displayName || n.from?.username || 'لاعب'}`); me(true).catch(() => {}); }
      else if (n?.type === 'friend_accepted') toast(`✅ تم قبول طلب الصداقة`);
      decorate({ unread: Number(document.querySelector('[data-social-badge]')?.textContent || 0) + 1 });
      emit('notification', n); return;
    }
    if (message.type === 'friend_presence') { state.dashboard = null; emit('presence', message.friend); return; }
    if (message.type === 'pong') emit('pong', message);
  }

  function clearSocketTimers(){clearInterval(state.heartbeat);clearTimeout(state.welcomeTimer);state.heartbeat=null;state.welcomeTimer=null;}
  function scheduleRealtime(){
    clearTimeout(state.reconnectTimer);
    if(state.manualClose||!token())return;
    const delay=Math.min(15000,800*(2**Math.min(5,state.reconnectAttempt++)))+Math.floor(Math.random()*300);
    state.reconnectTimer=setTimeout(connectRealtime,delay);
  }
  function recoverRealtime(ws){
    if(state.socket!==ws||state.manualClose||!token())return;
    state.socket=null;clearSocketTimers();ws.onopen=ws.onclose=ws.onerror=ws.onmessage=null;try{ws.close(4000,'resync');}catch{}
    emit('connection',{online:false});refreshInbox();scheduleRealtime();
  }
  function connectRealtime() {
    if (!token() || typeof WebSocket === 'undefined') return;
    state.manualClose = false;
    clearTimeout(state.reconnectTimer);
    if (state.socket && state.socket.readyState <= 1) return;
    clearSocketTimers();
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    let ws;try{ws = new WebSocket(`${proto}//${location.host}/api/social/ws`, ['busraj-social-v1', `st.${token()}`]);}catch{scheduleRealtime();return;}
    state.socket = ws;state.lastMessageAt=Date.now();
    state.welcomeTimer=setTimeout(()=>{if(state.socket===ws)recoverRealtime(ws);},12000);
    ws.onopen = () => {
      if(state.socket!==ws)return;
      state.lastMessageAt=Date.now();refreshInbox();
      state.heartbeat=setInterval(()=>{
        if(state.socket!==ws||document.hidden)return;
        if(Date.now()-state.lastMessageAt>60000){recoverRealtime(ws);return;}
        if(ws.readyState===1)try{ws.send(JSON.stringify({type:'ping'}));}catch{recoverRealtime(ws);}
      },25000);
    };
    ws.onmessage = (event) => {
      if(state.socket!==ws)return;
      let data;try{data=JSON.parse(event.data);}catch{return;}
      state.lastMessageAt=Date.now();
      if(data.type==='social_welcome'){clearTimeout(state.welcomeTimer);state.reconnectAttempt=0;emit('connection',{online:true});}
      handleMessage(event.data);
    };
    ws.onerror = () => {if(state.socket===ws)emit('connection', { online: false, error: true });};
    ws.onclose = (event) => {
      if(state.socket!==ws)return;
      state.socket=null;clearSocketTimers();
      emit('connection', { online: false, code: event.code });
      if (!state.manualClose && token() && ![4001,1008].includes(event.code)) {refreshInbox();scheduleRealtime();}
    };
  }
  function closeRealtime() {
    state.manualClose = true;clearSocketTimers();
    clearTimeout(state.reconnectTimer);
    const ws=state.socket;state.socket=null;
    if(ws){ws.onclose=ws.onmessage=ws.onerror=ws.onopen=null;try{ws.close(1000,'logout');}catch{}}
  }
  function restoreRealtime(){
    if(!token())return;
    if(state.socket?.readyState===1){
      if(Date.now()-state.lastMessageAt>45000){recoverRealtime(state.socket);}
      else try{state.socket.send(JSON.stringify({type:'ping'}));}catch{state.socket.close();}
    }else connectRealtime();
    refreshInbox();
  }
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)restoreRealtime();});
  window.addEventListener('online',restoreRealtime);
  window.addEventListener('pageshow',restoreRealtime);
  window.addEventListener('storage',event=>{
    if(event.key!==STORAGE_KEY)return;
    setSession(readStorage(STORAGE_KEY),parseJson(readStorage(PROFILE_KEY)));
    if(token())connectRealtime();
  });

  // 32.0.1: signed in, every "your name" field of a game shows the account's
  // name and is locked there; the rooms use the account name anyway.
  const ACCOUNT_NAME_HINT = 'هذا اسم حسابك ويظهر لكل اللاعبين. تغيّره من «تعديل الاسم» في الرئيسية.';
  let accountHintAt = 0;
  function accountName(profile = cachedProfile()) { return token() ? String(profile?.displayName || '').trim() : ''; }
  function bindAccountNames(profile) {
    const name = accountName(profile);
    // 33.9.8: signed in, the field is not asked at all: the account's name is used and the field hides
    document.querySelectorAll('input[data-account-name]').forEach((el) => {
      const box = el.closest('label,.bs-name-field');
      if (box && box.querySelectorAll('input').length === 1) box.style.display = name ? 'none' : '';
      if (name) {
        if (!el.classList.contains('bs-account-name')) el.dataset.guestName = el.value;
        el.value = name.slice(0, el.maxLength > 0 ? el.maxLength : 24);
        el.readOnly = true;
        el.classList.add('bs-account-name');
        el.title = ACCOUNT_NAME_HINT;
        if (!el.dataset.accountHint) {
          el.dataset.accountHint = '1';
          el.addEventListener('focus', () => { if (!el.readOnly || Date.now() - accountHintAt < 4000) return; accountHintAt = Date.now(); toast(ACCOUNT_NAME_HINT); });
        }
      } else if (el.classList.contains('bs-account-name')) {
        el.readOnly = false;
        el.classList.remove('bs-account-name');
        el.removeAttribute('title');
        el.value = el.dataset.guestName ?? el.defaultValue;
        delete el.dataset.guestName;
      }
    });
  }

  function decorate(data = state.dashboard) {
    const profile = data?.profile || cachedProfile();
    const unread = Number(data?.unread || 0);
    bindAccountNames(profile);
    document.querySelectorAll('[data-social-name]').forEach((el) => { el.textContent = profile?.displayName || 'حسابي'; });
    document.querySelectorAll('[data-social-open]').forEach((el) => {
      el.setAttribute('href', profile ? '/social' : '/social?auth=1');
      el.setAttribute('title', profile ? `@${profile.username}` : 'تسجيل الدخول');
    });
    document.querySelectorAll('[data-social-badge]').forEach((el) => {
      el.textContent = unread > 99 ? '99+' : String(unread || '');
      el.classList.toggle('hidden', !unread);
    });
  }

  async function openInvitePicker({ game, roomCode, variant, title:gameTitle, roundClosed, share } = {}) {
    if (!token()) {
      toast('سجّل الدخول أولًا لإرسال دعوة لصديق');
      setTimeout(() => { location.href = `/social?next=${encodeURIComponent(location.pathname + location.search)}`; }, 650);
      return;
    }
    const openedSession=token(),source=document.activeElement;let data;
    try { data = await me(true); } catch (error) { toast(error.message); return; }
    if(!data||openedSession!==token())return;
    const friends = [...(data.friends || [])].sort((a, b) => Number(b.online) - Number(a.online) || String(a.displayName).localeCompare(String(b.displayName), 'ar'));
    let modal = document.querySelector('#bsInviteFriendsModal');
    if (!modal) {
      modal = document.createElement('div'); modal.id = 'bsInviteFriendsModal'; modal.className = 'bs-modal';
    }
    const parent=document.fullscreenElement||document.querySelector('body.serpent-active #arenaPlay')||document.body;if(modal.parentElement!==parent)parent.appendChild(modal);
    modal.innerHTML = '';
    const panel = document.createElement('section'); panel.className = 'bs-panel bs-social-picker';panel.setAttribute('role','dialog');panel.setAttribute('aria-modal','true');panel.setAttribute('aria-label','دعوة صديق لهذه اللعبة');
    const head = document.createElement('div'); head.className = 'bs-social-picker-head';
    const copy = document.createElement('div'); const title = document.createElement('h2'); title.textContent = 'دعوة صديق · '+(gameTitle||'اللعبة الحالية'); const note = document.createElement('small'); note.textContent = roomCode ? `يدخل صديقك إلى غرفتك ${roomCode}` : roundClosed?'الجولة بدأت؛ الدعوة لتحدٍ جديد في نفس اللعبة':'يفتح صديقك نفس اللعبة مباشرة'; copy.append(title, note);
    const dismiss=()=>{modal.classList.remove('open');source?.focus?.();};const close = document.createElement('button'); close.type = 'button'; close.className = 'bs-icon-btn'; close.textContent = '✕';close.setAttribute('aria-label','إغلاق دعوة الأصدقاء');close.onclick=dismiss;
    head.append(copy, close); panel.appendChild(head);
    const list = document.createElement('div'); list.className = 'bs-social-picker-list';
    if (!friends.length) {
      const empty = document.createElement('div'); empty.className = 'bs-social-empty'; empty.textContent = 'ما عندك أصدقاء بعد. أضف صديقًا من صفحة الأصدقاء.'; list.appendChild(empty);
    }
    for (const friend of friends) {
      const row = document.createElement('div'); row.className = 'bs-social-picker-row';
      const who = document.createElement('div'); const name = document.createElement('b'); name.textContent = `${friend.online ? '🟢' : '⚫'} ${friend.displayName}`; const user = document.createElement('small'); user.textContent = `@${friend.username}`; who.append(name, user);
      const send = document.createElement('button'); send.type = 'button'; send.className = 'bs-btn cyan'; send.textContent = 'دعوة';
      send.onclick = async () => {if(openedSession!==token()){toast('تغيّر الحساب؛ افتح قائمة الأصدقاء مجددًا');dismiss();return;} send.disabled = true; try { await invite(friend.username, game, roomCode, variant); send.textContent = 'أُرسلت ✓'; toast(friend.online?`أُرسلت الدعوة إلى ${friend.displayName}`:`حُفظت الدعوة لدى ${friend.displayName} وستظهر عند اتصاله`); } catch (error) { send.disabled = false; toast(error.message); } };
      row.append(who, send); list.appendChild(row);
    }
    panel.appendChild(list);
    if(typeof share==='function'){const button=document.createElement('button');button.type='button';button.className='bs-btn';button.textContent='مشاركة رابط اللعبة';button.onclick=share;panel.append(button);}
    const footer = document.createElement('a'); footer.href = '/social'; footer.className = 'bs-social-picker-footer'; footer.textContent = 'إدارة الأصدقاء ←'; panel.appendChild(footer);
    modal.appendChild(panel); modal.classList.add('open');
    modal.onclick = (event) => { if (event.target === modal) dismiss(); };
    panel.onkeydown=event=>{if(event.key==='Escape'){event.preventDefault();dismiss();}if(event.key==='Tab'){const controls=[...panel.querySelectorAll('button,a,input')].filter(n=>!n.disabled),first=controls[0],last=controls.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}};close.focus();
  }

  // 33.9.4: pictures and reports
  async function setPhoto(photo) { const data = await api('/api/social/photo', { method: 'POST', body: JSON.stringify({ photo }) }); state.dashboard = null; try { const p = cachedProfile(); if (p) { p.photo = data.photo || null; writeStorage(PROFILE_KEY, JSON.stringify(p)); } } catch {} window.dispatchEvent(new CustomEvent('bs-photo-change', { detail: data.photo || null })); if (data.paid) window.BS_CAREER?.refresh?.()?.catch?.(() => {}); return data; }
  async function reportPhoto(username) { return api('/api/social/report', { method: 'POST', body: JSON.stringify({ username }) }); }
  async function moderation(username, action) { return username ? api('/api/social/moderation', { method: 'POST', body: JSON.stringify({ username, action }) }) : api('/api/social/moderation'); }
  const apiPublic = {
    version: '25.3.0',
    recoveryCodes:password=>api('/api/social/recovery/codes',{method:'POST',body:JSON.stringify({password})}),recoveryStatus:()=>api('/api/social/recovery/status',{method:'POST',body:'{}'}),recover:body=>api('/api/social/recovery/reset',{method:'POST',body:JSON.stringify(body)}),
    signup, login, logout, me, user, requestFriend, respondFriend, removeFriend, block, unblock,
    settings, invite, readNotifications, connectRealtime, closeRealtime, openInvitePicker,
    invites: () => openInvites(), isLoggedIn: () => Boolean(token()), profile: () => (token() ? cachedProfile() : null), events,
    accountName: () => accountName(), gameLabel, setPhoto, reportPhoto, moderation,
  };
  window.BS_SOCIAL = apiPublic;
  decorate();
  // pages fill their name fields while they load; lock them again after that
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => { decorate(); renderInbox(); });
  else renderInbox();
  if (token()) {
    startInbox();
    connectRealtime();
  }
})();
