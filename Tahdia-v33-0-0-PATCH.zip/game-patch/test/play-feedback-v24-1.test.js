import test from 'node:test';import assert from 'node:assert/strict';import {createDOM} from './dom-harness.mjs';
async function setup(reduce=false){const h=await createDOM('sudoku.html',{matchMedia:()=>({matches:reduce})});await h.runFile('assets/js/play-feedback-v24-1.js');return h;}
test('success particles are bounded and expire without modifying a Sudoku value',async()=>{
 const h=await setup(),cell=h.doc.createElement('button');cell.textContent='7';cell.getBoundingClientRect=()=>({left:20,top:50,width:40,height:40});h.doc.body.appendChild(cell);
 for(let i=0;i<20;i++)h.context.BS_GAME_FX.cell(cell,'right');const layer=h.doc.querySelector('.bs-fx-layer');assert.ok(layer.children.length<=28);assert.equal(cell.textContent,'7');for(const timer of [...h.timers.values()])timer.fn();assert.equal(layer.children.length,0);assert.equal(cell.classList.contains('bs-fx-right'),false);
});
test('reduced motion keeps a visible cell highlight without flying particles',async()=>{
 const h=await setup(true),cell=h.doc.createElement('button');h.doc.body.appendChild(cell);h.context.BS_GAME_FX.cell(cell,'right');assert.equal(cell.classList.contains('bs-fx-right'),true);assert.equal(h.doc.querySelectorAll('.bs-fx-dot').length,0);
});
test('completed Sudoku units highlight and path effects use the top-layer game dialog',async()=>{
 const h=await setup(),dialog=h.doc.createElement('dialog');dialog.setAttribute('open','');h.doc.body.appendChild(dialog);const cells=Array.from({length:81},()=>({el:h.doc.createElement('button')})),board=Array(81).fill(0);for(let i=0;i<9;i++)board[i]=i+1;h.context.BS_GAME_FX.sudoku(cells,board,8,'right');assert.equal(cells.filter(c=>c.el.classList.contains('bs-fx-unit')).length,9);
 const canvas=h.doc.createElement('canvas');canvas.getBoundingClientRect=()=>({left:20,top:30,width:300,height:300});dialog.appendChild(canvas);h.context.BS_GAME_FX.path(canvas,{size:5},[0,1,6],0);assert.equal(h.doc.querySelector('.bs-fx-layer').parentNode,dialog);assert.equal(dialog.querySelectorAll('polyline').length,1);
});
test('room invitations preserve a direct path and discard secret query parameters',async()=>{
 const h=await setup();h.context.location.href='https://game.test/paths-online?room=123456&token=private&hostKey=private';h.context.BS_INVITES.set({game:'paths',code:'123456',joinable:true});const data=h.context.BS_INVITES.data();assert.equal(data.url,'https://game.test/paths-online?room=123456');assert.equal(data.joinable,true);h.context.BS_INVITES.share();assert.ok(h.doc.getElementById('bsInvitePanel'));const labels=h.doc.getElementById('bsInvitePanel').querySelectorAll('button').map(b=>b.textContent);assert.ok(labels.includes('نسخ الرابط'));assert.ok(labels.includes('مشاركة عبر واتساب والتطبيقات'));
});
test('every game command opens the friend picker directly for its own game',async()=>{const h=await setup(),bar=h.doc.getElementById('bsGameCommand'),calls=[];assert.ok(bar);assert.equal(bar.querySelector('.bs-command-back').textContent.includes('رجوع'),true);h.context.BS_SOCIAL.openInvitePicker=async data=>calls.push(data);await bar.querySelector('[data-command-invite]').onclick();assert.equal(calls.length,1);assert.equal(calls[0].game,'sudoku');assert.equal(h.doc.getElementById('bsInvitePanel'),null);});
test('winner celebration prints the winner name and duplicate state updates do not replay it',async()=>{const h=await setup();h.context.BS_GAME_FX.celebrate('البطل سالم',{key:'round-7'});const first=h.doc.getElementById('bsVictory');assert.ok(first.textContent.includes('البطل سالم'));assert.ok(h.doc.querySelectorAll('.bs-victory-confetti').length<=46);h.context.BS_GAME_FX.celebrate('البطل سالم',{key:'round-7'});assert.equal(h.doc.getElementById('bsVictory'),first);});
test('32.1.0: feedback never reacts to its own badges (the freeze after a wrong move)',async()=>{
 const {MiniElement}=await import('./dom-harness.mjs');let callback=null;class Observer{constructor(fn){callback=fn}observe(){}}
 const h=await createDOM('sudoku.html',{MutationObserver:Observer,Element:MiniElement});await h.runFile('assets/js/play-feedback-v24-1.js');assert.ok(callback,'the page watches for marked cells');
 const cell=h.doc.createElement('button');cell.className='is-wrong';cell.getBoundingClientRect=()=>({left:10,top:10,width:30,height:30});h.doc.body.appendChild(cell);
 callback([{target:cell,addedNodes:[]}]);const layer=h.doc.querySelector('.bs-fx-layer');assert.ok(layer,'the wrong move shows its effect');
 const size=()=>layer.querySelectorAll('*').length,before=size();
 for(let i=0;i<40;i++)callback([{target:layer,addedNodes:[...layer.children]},...layer.querySelectorAll('*').map(node=>({target:node,addedNodes:[]}))]);
 assert.equal(size(),before,'our own badges add nothing more');
});
test('32.1.0: inside a party round the game bar leads back to the party',async()=>{
 const h=await createDOM('sudoku.html',{BS_PARTY_LINK:Object.freeze({party:'111111',room:'222222',back:'/party?room=111111',name:'نورة'})});await h.runFile('assets/js/play-feedback-v24-1.js');
 const bar=h.doc.getElementById('bsGameCommand'),back=bar.querySelector('.bs-command-back');assert.match(back.textContent,/الجمعة/);assert.equal(back.getAttribute('aria-label'),'ارجع لغرفة الجمعة');
 assert.equal(bar.querySelector('.bs-command-invite').hidden,true,'a party room is not shared with others');back.onclick();assert.equal(h.context.location.href,'/party?room=111111');
 const plain=await setup();assert.match(plain.doc.getElementById('bsGameCommand').querySelector('.bs-command-back').textContent,/رجوع/);
});
