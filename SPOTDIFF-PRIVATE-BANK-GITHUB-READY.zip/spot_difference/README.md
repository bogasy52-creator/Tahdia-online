# Spot Difference Bank

Structure:
spot_difference/
  level_xxx/
    original.png
    modified.png
    answer.json

Each level is isolated and ready for GitHub assets.
