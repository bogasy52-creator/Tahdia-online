/* Tahdia v25.4.0 — distinct local arenas, collectible food, physical obstacles.
 * Multiplayer physics/cosmetics remain server-authoritative and unchanged.
 */
export const SERPENT_WORLDS = Object.freeze({
 classic:Object.freeze({id:'classic',name:'الحلبة الأصلية',width:1400,height:1400,foodCount:260,obstacles:0,description:'حلبة سريعة بدون حواجز، مناسبة للتدريب والمواجهات.'}),
 neon:Object.freeze({id:'neon',name:'مدينة النيون',width:2000,height:2000,foodCount:335,obstacles:22,description:'أبراج مضيئة صغيرة، وممرات واسعة للالتفاف والمطاردة.'}),
 forest:Object.freeze({id:'forest',name:'غابة البرق',width:2400,height:2400,foodCount:350,obstacles:30,description:'أكبر خريطة: صخور صغيرة ومناطق طاقة وأكل غني.'}),
 crystals:Object.freeze({id:'crystals',name:'ساحة البلورات',width:2200,height:2200,foodCount:345,obstacles:26,description:'بلورات ملونة صغيرة واندفاعات كنوز متكررة.'})
});
const clamp=(n,a,b)=>Math.min(b,Math.max(a,n));
function rnd(state){state.seed=(Math.imul(state.seed,1664525)+1013904223)>>>0;return state.seed/4294967296;}
function compactObstacles(game,preset){
 const state={seed:((Number(game.seed)||1234567)^(preset.width*73)^(preset.height*113))>>>0},result=[];
 for(let i=0,tries=0;i<preset.obstacles&&tries<preset.obstacles*40;tries++){
  const x=80+rnd(state)*(game.width-160),y=80+rnd(state)*(game.height-160),radius=19+Math.floor(rnd(state)*16);
  if(game.snakes?.some(s=>Math.hypot(s.x-x,s.y-y)<175))continue;
  if(result.some(o=>Math.hypot(o.x-x,o.y-y)<o.radius+radius+130))continue;
  result.push({x:Math.round(x),y:Math.round(y),radius,style:i%3});i++;
 }
 return result;
}
function moveFoodOffWalls(game,world){
 for(const piece of game.food||[]){
  const o=world.obstacles.find(w=>Math.hypot((piece.x||0)-w.x,(piece.y||0)-w.y)<w.radius+14);
  if(!o)continue;
  const a=((Number(String(piece.id).replace(/\D/g,''))||7)*2.399963229728653)% (Math.PI*2);
  const r=o.radius+25;piece.x=clamp(o.x+Math.cos(a)*r,22,game.width-22);piece.y=clamp(o.y+Math.sin(a)*r,22,game.height-22);
 }
}
function upgradeFood(game,world,force=false){
 if(!force&&game.elapsed<world.nextFoodUpgrade)return;
 world.nextFoodUpgrade=game.elapsed+1.5;
 const frenzy=world.frenzy,challenge=world.challenge==='treasure';
 const odds=frenzy?.5:challenge?.36:world.id==='crystals'?.25:.16;
 for(const piece of game.food||[]){
  if(piece.worldEnhanced)continue;
  const n=(Math.imul((Number(String(piece.id).replace(/\D/g,''))||0)+19,2654435761)>>>0)%997/997;
  if(n<odds){piece.kind=n<odds*.35?'relic':n<odds*.72?'prism':'nova';piece.value=frenzy?8:challenge?7:world.id==='crystals'?6:5;piece.radius=6+Math.sqrt(piece.value);}
  else if(world.id!=='classic'){
   const types=world.id==='neon'?['orb','spark','bolt','orb']:world.id==='forest'?['seed','nectar','berry','seed']:['shard','prism','shard','orb'];
   piece.kind=types[Math.floor(n*97)%types.length];piece.radius=world.id==='crystals'?8:7;
  }
  piece.worldEnhanced=true;
 }
 moveFoodOffWalls(game,world);
}
export function ownerAllowed(access,catalog=[]){
 // Read from the existing server-backed account entitlement; never use an input name or URL flag.
 return access?.role==='owner'&&Array.isArray(catalog);
}
export function setupSerpentWorld(game,id,options={}){
 const p=SERPENT_WORLDS[id]||SERPENT_WORLDS.classic;
 if(!game||!Array.isArray(game.snakes)||!Array.isArray(game.food))throw new TypeError('Invalid serpent game');
 const world={id:p.id,name:p.name,challenge:options.challenge||'survival',difficulty:options.difficulty||game.difficulty,obstacles:compactObstacles(game,p),nextFoodUpgrade:0,frenzy:false,lastFrenzyCycle:-1,ownerSnakeId:options.ownerAllowed===true?options.ownerSnakeId:null,ownerBadge:options.ownerAllowed===true&&!!options.ownerSnakeId,lastEvent:'',lastEventAt:-100};
 game.world=world;
 if(world.ownerBadge){const snake=game.snakes.find(s=>s.id===world.ownerSnakeId&&!s.bot);if(snake)snake.mass=Math.max(Number(snake.mass)||30,36);}
 if(world.difficulty==='legendary')for(const s of game.snakes)if(s.bot)s.mass=Math.max(44,Number(s.mass)||0);
 upgradeFood(game,world,true);return world;
}
export function advanceSerpentWorld(game){
 const w=game?.world;if(!w||game.status!=='playing')return [];
 const events=[],seconds=Number(game.elapsed)||0,cycle=Math.floor(seconds/35),within=seconds%35;
 const active=w.id!=='classic'&&within>=18&&within<27;
 if(active&&!w.frenzy){w.lastFrenzyCycle=cycle;w.lastEvent='⚡ مطر الكنوز — أكل نادر وطاقة مضاعفة';w.lastEventAt=seconds;}
 w.frenzy=active;upgradeFood(game,w);
 for(const snake of game.snakes){
  if(!snake.alive)continue;
  // A small obstacle blocks passage, but knocks the snake aside instead of instant death.
  const o=w.obstacles.find(o=>Math.hypot(snake.x-o.x,snake.y-o.y)<o.radius+14);
  if(o){const a=Math.atan2(snake.y-o.y,snake.x-o.x)||0,r=o.radius+15;
   const x=clamp(o.x+Math.cos(a)*r,24,game.width-24),y=clamp(o.y+Math.sin(a)*r,24,game.height-24),dx=x-snake.x,dy=y-snake.y;
   snake.x=x;snake.y=y;if(Array.isArray(snake.segments))for(const part of snake.segments){part.x+=dx;part.y+=dy;}
   if(seconds>=(snake.worldBumpReady||0)){
    snake.worldBumpReady=seconds+1.6;snake.mass=Math.max(16,(Number(snake.mass)||24)-1.5);
    snake.targetAngle=a+.2;snake.nextThinkAt=seconds+.4;
    events.push({type:'bump',id:snake.id});if(!snake.bot){w.lastEvent='انتبه! اصطدمت بحاجز وخسرت طاقة بسيطة';w.lastEventAt=seconds;}
   }
  }
  if(w.difficulty==='legendary'&&snake.bot){
   if(seconds-(snake.worldLastChase||0)>.33){snake.worldLastChase=seconds;
    const humans=game.snakes.filter(s=>s.alive&&!s.bot),nearest=humans.map(h=>({h,d:Math.hypot(h.x-snake.x,h.y-snake.y)})).sort((a,b)=>a.d-b.d)[0];
    if(nearest&&nearest.d<460){snake.targetAngle=Math.atan2(nearest.h.y-snake.y,nearest.h.x-snake.x);snake.nextThinkAt=seconds+.3;}
   }
  }
 }
 return events;
}
const PALETTES={
 neon:{base:'#071522',tile:'#0c2636',line:'#0f7281',accent:'#48e6e3',second:'#e663ec'},
 forest:{base:'#10271f',tile:'#193c2d',line:'#386a4b',accent:'#a8ef84',second:'#e6b55a'},
 crystals:{base:'#19152e',tile:'#292047',line:'#59437f',accent:'#c49dff',second:'#67edff'}
};
function tinyHash(x,y){let z=Math.imul(x+7817,374761393)+Math.imul(y+3989,668265263);z=Math.imul(z^(z>>>13),1274126177);return (z^(z>>>16))>>>0;}
function landmark(c,x,y,w,world){
 const p=PALETTES[world.id],t=world.id;
 c.save();c.translate(x,y);
 if(t==='neon'){
  c.strokeStyle=p.accent+'6a';c.lineWidth=2;c.beginPath();c.moveTo(-w*.48,0);c.lineTo(-w*.3,0);c.lineTo(-w*.2,-w*.17);c.lineTo(w*.12,-w*.17);c.lineTo(w*.18,0);c.lineTo(w*.48,0);c.stroke();
  c.fillStyle=p.second+'80';c.fillRect(-w*.22,-w*.22,w*.12,3);
 }else if(t==='forest'){
  c.strokeStyle='#86b37642';c.lineWidth=2;c.beginPath();c.arc(0,0,w*.28,0,Math.PI*1.3);c.stroke();
  c.fillStyle='#71bd7139';for(let k=0;k<3;k++){c.beginPath();c.ellipse((k-1)*w*.15,((k%2)-.5)*w*.12,w*.11,w*.035,k*.8,0,Math.PI*2);c.fill();}
 }else{
  c.strokeStyle=p.accent+'42';c.lineWidth=2;c.beginPath();c.moveTo(0,-w*.25);c.lineTo(w*.22,0);c.lineTo(0,w*.25);c.lineTo(-w*.22,0);c.closePath();c.stroke();
  c.beginPath();c.moveTo(0,-w*.25);c.lineTo(0,w*.25);c.moveTo(-w*.22,0);c.lineTo(w*.22,0);c.stroke();
 }
 c.restore();
}
function paintObstacle(c,o,id,now,animate){
 const p=PALETTES[id],r=o.radius;
 if(!p)return;
 c.save();c.translate(o.x,o.y);
 c.fillStyle='#03090fcc';c.beginPath();c.ellipse(5,r*.65,r*1.45,r*.85,-.2,0,Math.PI*2);c.fill();
 if(id==='neon'){
  const grad=c.createLinearGradient(-r,-r,r,r);grad.addColorStop(0,'#3b577b');grad.addColorStop(.55,'#112a42');grad.addColorStop(1,'#071526');
  c.fillStyle=grad;c.strokeStyle=o.style===1?'#ed66e3':'#51e8e9';c.lineWidth=3;
  c.beginPath();c.moveTo(-r*.95,-r*.67);c.lineTo(0,-r*1.18);c.lineTo(r*.93,-r*.65);c.lineTo(r*.95,r*.65);c.lineTo(0,r*1.12);c.lineTo(-r*.95,r*.65);c.closePath();c.fill();c.stroke();
  c.fillStyle='#69f0e6';c.fillRect(-r*.65,-r*.19,r*1.3,3);c.fillStyle='#f5c779';c.fillRect(-r*.46,r*.36,r*.92,3);
 }else if(id==='forest'){
  c.fillStyle='#152e26';c.strokeStyle='#a1c88b';c.lineWidth=2.6;
  c.beginPath();for(let i=0;i<7;i++){const a=i*Math.PI*2/7,rr=r*(i%2?.9:1.09),x=Math.cos(a)*rr,y=Math.sin(a)*rr;i?c.lineTo(x,y):c.moveTo(x,y);}c.closePath();c.fill();c.stroke();
  c.fillStyle='#40654d';c.beginPath();c.moveTo(-r*.8,-r*.25);c.lineTo(-r*.12,-r*.87);c.lineTo(r*.55,-r*.44);c.lineTo(r*.65,r*.19);c.lineTo(-r*.26,r*.1);c.closePath();c.fill();
  c.strokeStyle='#7caa7a';c.lineWidth=2;c.beginPath();c.moveTo(-r*.35,-r*.55);c.lineTo(-r*.1,-r*.05);c.lineTo(r*.55,r*.4);c.stroke();
  for(let k=0;k<3;k++){c.fillStyle='#94d96c';c.beginPath();c.arc(-r*.6+k*r*.58,-r*.6+(k%2)*r*.26,r*.12,0,Math.PI*2);c.fill();}
 }else{
  c.shadowColor='#af8aff';c.shadowBlur=animate?12:4;c.strokeStyle='#e0b7ff';c.lineWidth=3;
  c.fillStyle='#554489';c.beginPath();c.moveTo(0,-r*1.24);c.lineTo(r*.96,-r*.36);c.lineTo(r*.74,r*.78);c.lineTo(-r*.72,r*.83);c.lineTo(-r*.92,-r*.34);c.closePath();c.fill();c.stroke();
  c.shadowBlur=0;c.fillStyle='#a788e7';c.beginPath();c.moveTo(0,-r*1.24);c.lineTo(r*.3,-r*.22);c.lineTo(0,r*.68);c.lineTo(-r*.38,-r*.18);c.closePath();c.fill();
  c.strokeStyle='#f8dfff';c.lineWidth=1.7;c.beginPath();c.moveTo(0,-r*1.2);c.lineTo(0,r*.7);c.moveTo(-r*.89,-r*.35);c.lineTo(r*.9,-r*.35);c.stroke();
 }
 c.restore();
}
// Draw in the renderer's existing world coordinate system BEFORE food and snakes.
// Bounds-culling keeps mobile GPU work limited to the visible camera viewport.
export function paintSerpentWorldFloor(ctx,g,view,zoom=1,now=0,reduced=false){
 const w=g?.world;if(!w||w.id==='classic')return false;
 const p=PALETTES[w.id];if(!p)return false;
 const {minX,minY,maxX,maxY}=view;
 const x0=Math.max(0,minX-5),y0=Math.max(0,minY-5),x1=Math.min(g.width,maxX+5),y1=Math.min(g.height,maxY+5);
 ctx.fillStyle=p.base;ctx.fillRect(x0,y0,Math.max(0,x1-x0),Math.max(0,y1-y0));
 // The 3 biomes have visibly different background architecture.
 const cell=w.id==='neon'?180:w.id==='forest'?226:210;
 const fromX=Math.max(0,Math.floor(minX/cell)-1),toX=Math.min(Math.ceil(g.width/cell),Math.ceil(maxX/cell)+1);
 const fromY=Math.max(0,Math.floor(minY/cell)-1),toY=Math.min(Math.ceil(g.height/cell),Math.ceil(maxY/cell)+1);
 for(let iy=fromY;iy<=toY;iy++)for(let ix=fromX;ix<=toX;ix++){
  const x=ix*cell,y=iy*cell,h=tinyHash(ix,iy);
  if(w.id==='neon'){
   ctx.fillStyle=h%2?'#0c2539':'#0b2134';ctx.fillRect(x+5,y+5,cell-10,cell-10);
   ctx.strokeStyle=h%3?'#1b6d8870':'#bf59c14d';ctx.lineWidth=2.2;ctx.strokeRect(x+10,y+10,cell-20,cell-20);
   ctx.fillStyle=p.line+'40';ctx.fillRect(x+20,y+20,cell*.32,3);ctx.fillRect(x+20,y+25,3,cell*.19);
  }else if(w.id==='forest'){
   ctx.fillStyle=h%2?'#193a2d':'#18372a';ctx.beginPath();ctx.arc(x+cell*.52,y+cell*.48,cell*.64,0,Math.PI*2);ctx.fill();
   ctx.strokeStyle='#83b97826';ctx.lineWidth=3;ctx.beginPath();ctx.arc(x+cell*.52,y+cell*.48,cell*.51,.2,Math.PI*1.67);ctx.stroke();
  }else{
   ctx.fillStyle=h%2?'#272040':'#2b234a';ctx.beginPath();ctx.moveTo(x+cell*.5,y+12);ctx.lineTo(x+cell-12,y+cell*.5);ctx.lineTo(x+cell*.5,y+cell-12);ctx.lineTo(x+12,y+cell*.5);ctx.closePath();ctx.fill();
   ctx.strokeStyle='#ba92f852';ctx.lineWidth=2;ctx.stroke();
  }
  if(h%3!==0)landmark(ctx,x+cell*.5,y+cell*.5,cell*.5,w);
 }
 // Big independent landmarks create distinguishable districts on all three maps.
 ctx.save();ctx.translate(g.width/2,g.height/2);ctx.lineWidth=4;
 ctx.strokeStyle=p.accent+'70';ctx.beginPath();ctx.arc(0,0,155,0,Math.PI*2);ctx.stroke();
 ctx.strokeStyle=p.second+'70';ctx.beginPath();ctx.arc(0,0,172,0,Math.PI*2);ctx.stroke();
 for(let i=0;i<8;i++){const a=i*Math.PI/4;ctx.fillStyle=p.accent+'75';ctx.beginPath();ctx.arc(Math.cos(a)*164,Math.sin(a)*164,5,0,Math.PI*2);ctx.fill();}
 ctx.restore();
 // Authentic collidable obstacles on the map, not a decorative overlay.
 for(const o of w.obstacles){if(o.x+o.radius*2<minX||o.x-o.radius*2>maxX||o.y+o.radius*2<minY||o.y-o.radius*2>maxY)continue;paintObstacle(ctx,o,w.id,now,!reduced);}
 ctx.lineWidth=18;ctx.strokeStyle='#020912';ctx.strokeRect(6,6,g.width-12,g.height-12);
 ctx.lineWidth=3/zoom;ctx.strokeStyle=p.accent;ctx.strokeRect(15,15,g.width-30,g.height-30);
 if(w.frenzy){ctx.lineWidth=4/zoom;ctx.strokeStyle=p.second+'bc';ctx.strokeRect(23,23,g.width-46,g.height-46);}
 return true;
}
// Legacy exported entry point, intentionally no longer paints over snakes.
export function drawSerpentWorld(renderer){return Boolean(renderer?.game?.world);}
