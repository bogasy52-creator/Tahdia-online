/* V25.4 — actual owner-only on-canvas character, not a crown added to a stock skin.
 * Pure visual rendering; entitlement is decided by game.world.ownerSnakeId from the
 * account's verified owner access. Does not change multiplayer hitboxes.
 */
const PI=Math.PI,TAU=PI*2;
const sample=(points,limit=140)=>{
 const arr=(points||[]).filter(p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.y));
 if(arr.length<=limit)return arr;
 return Array.from({length:limit},(_,i)=>arr[Math.round(i*(arr.length-1)/(limit-1))]);
};
function strokePath(c,pts){c.beginPath();pts.forEach((p,i)=>i?c.lineTo(p.x,p.y):c.moveTo(p.x,p.y));}
function jewel(c,x,y,r,fill='#51e8dd'){
 c.fillStyle=fill;c.strokeStyle='#fce2a1';c.lineWidth=Math.max(1,r*.22);
 c.beginPath();c.moveTo(x,y-r);c.lineTo(x+r*.76,y);c.lineTo(x,y+r);c.lineTo(x-r*.76,y);c.closePath();c.fill();c.stroke();
 c.fillStyle='#ffffffaf';c.beginPath();c.arc(x-r*.2,y-r*.3,r*.18,0,TAU);c.fill();
}
export function paintRoyalSnake(c,points,angle,radius,{now=0,reducedMotion=false,quality='high'}={}){
 const pts=sample(points,quality==='fast'?52:quality==='balanced'?85:145);
 if(pts.length<2)return;
 const r=Math.max(8,Math.min(65,radius*1.42)),head=pts[0],animated=!reducedMotion;
 c.save();c.lineCap='round';c.lineJoin='round';
 // Thick, tapered velvet-black body with a luminous gold rim and genuine scales.
 const n=pts.length,tail=Math.max(2,Math.round(n*.70));
 for(let i=n-1;i>=tail;i--){const a=pts[i],b=pts[i-1],w=r*(.15+.85*(n-i)/(n-tail));
  c.strokeStyle='#d6a84c';c.lineWidth=2*w+4;c.beginPath();c.moveTo(a.x,a.y);c.lineTo(b.x,b.y);c.stroke();
  c.strokeStyle='#111923';c.lineWidth=2*w;c.stroke();}
 const trunk=pts.slice(0,tail+1);strokePath(c,trunk);c.strokeStyle='#c38d35';c.lineWidth=r*2+6;c.stroke();
 strokePath(c,trunk);c.strokeStyle='#050a12';c.lineWidth=r*2+2;c.stroke();
 strokePath(c,trunk);c.strokeStyle='#182532';c.lineWidth=r*1.75;c.stroke();
 strokePath(c,trunk);c.strokeStyle='#454034';c.lineWidth=r*.55;c.stroke();
 // Gold plates are placed across the actual path, not a stretched static texture.
 const step=quality==='fast'?6:quality==='balanced'?4:3;
 for(let i=step;i<n-3;i+=step){
  const a=pts[i-1],b=pts[i+1],dx=a.x-b.x,dy=a.y-b.y,len=Math.hypot(dx,dy)||1;
  const ux=dx/len,uy=dy/len,nx=-uy,ny=ux,t=i/(n-1),w=r*Math.pow(1-t,.6);
  if(w<3)continue;
  c.save();c.translate(pts[i].x,pts[i].y);c.rotate(Math.atan2(uy,ux));
  c.fillStyle=i%2?'#121923':'#202731';c.strokeStyle=i%2?'#a87931':'#e6bb60';c.lineWidth=Math.max(.8,w*.09);
  c.beginPath();c.moveTo(-w*.65,-w*.62);c.quadraticCurveTo(w*.1,-w*.97,w*.78,-w*.56);c.lineTo(w*.95,0);c.lineTo(w*.78,w*.56);c.quadraticCurveTo(0,w*.93,-w*.65,w*.62);c.closePath();c.fill();c.stroke();
  c.fillStyle='#ddbb6d';c.globalAlpha=.55;c.beginPath();c.ellipse(-w*.1,-w*.33,w*.37,w*.07,-.2,0,TAU);c.fill();
  // Small dorsal spikes make the character recognizable even at mobile zoom.
  if(i%(step*3)===0){c.globalAlpha=1;c.fillStyle='#d6ab56';c.strokeStyle='#433024';c.lineWidth=1;
   for(const side of [-1,1]){c.beginPath();c.moveTo(-w*.35,side*w*.8);c.lineTo(0,side*w*1.45);c.lineTo(w*.55,side*w*.8);c.closePath();c.fill();c.stroke();}}
  if(i%(step*6)===0){c.globalAlpha=1;jewel(c,w*.12,0,Math.max(2,w*.23));}
  c.restore();
 }
 // The snake's head is uniquely sculpted: jaw, armored temples, glowing eyes,
 // long muzzle, two forward tusks and a low royal tiara integrated into it.
 c.translate(head.x,head.y);c.rotate(Number.isFinite(angle)?angle:0);
 if(animated){c.shadowColor='#ffc965';c.shadowBlur=r*.6;}else c.shadowBlur=0;
 c.fillStyle='#bc8d3e';c.beginPath();c.ellipse(-r*.1,0,r*1.36,r*1.04,0,0,TAU);c.fill();
 c.shadowBlur=0;c.fillStyle='#091018';c.beginPath();c.ellipse(-r*.05,0,r*1.3,r*.98,0,0,TAU);c.fill();
 c.fillStyle='#26333b';c.beginPath();c.moveTo(-r*.55,-r*.85);c.quadraticCurveTo(r*.1,-r*1.04,r*.65,-r*.55);c.lineTo(r*1.4,-r*.42);c.quadraticCurveTo(r*1.65,0,r*1.4,r*.42);c.lineTo(r*.65,r*.55);c.quadraticCurveTo(r*.1,r*1.04,-r*.55,r*.85);c.closePath();c.fill();
 c.strokeStyle='#f2c570';c.lineWidth=r*.13;c.stroke();
 // Armored dorsal plates, face mask and forehead emerald.
 c.fillStyle='#060b12';c.beginPath();c.moveTo(-r*.7,-r*.4);c.lineTo(r*.15,-r*.76);c.lineTo(r*.85,-r*.38);c.lineTo(r*1.35,0);c.lineTo(r*.85,r*.38);c.lineTo(r*.15,r*.76);c.lineTo(-r*.7,r*.4);c.closePath();c.fill();
 c.strokeStyle='#a87431';c.lineWidth=r*.11;c.stroke();
 // Eyes are real features on the skin, not floating stickers.
 for(const side of [-1,1]){
  c.fillStyle='#dba84a';c.beginPath();c.moveTo(-r*.05,side*r*.46);c.lineTo(r*.72,side*r*.62);c.lineTo(r*.93,side*r*.32);c.closePath();c.fill();
  c.fillStyle='#75ffcb';c.beginPath();c.ellipse(r*.47,side*r*.45,r*.25,r*.15,side*.35,0,TAU);c.fill();
  c.fillStyle='#08121b';c.beginPath();c.ellipse(r*.52,side*r*.45,r*.065,r*.14,side*.35,0,TAU);c.fill();
  c.fillStyle='#fff9cc';c.beginPath();c.arc(r*.36,side*r*.4,r*.045,0,TAU);c.fill();
  c.fillStyle='#e2c789';c.beginPath();c.moveTo(r*1.19,side*r*.33);c.lineTo(r*1.64,side*r*.54);c.lineTo(r*1.48,side*r*.12);c.closePath();c.fill();
  c.fillStyle='#060a10';c.beginPath();c.ellipse(r*1.2,side*r*.21,r*.085,r*.065,0,0,TAU);c.fill();
 }
 // Compact 3D-looking crown is part of the head (orientation follows rotation).
 c.fillStyle='#e8b655';c.strokeStyle='#7c4c21';c.lineWidth=r*.09;
 c.beginPath();c.moveTo(-r*.66,-r*.67);c.lineTo(-r*.9,-r*1.45);c.lineTo(-r*.45,-r*1.18);c.lineTo(-r*.18,-r*1.8);c.lineTo(r*.08,-r*1.15);c.lineTo(r*.5,-r*1.5);c.lineTo(r*.42,-r*.62);c.closePath();c.fill();c.stroke();
 jewel(c,-r*.15,-r*1.13,r*.2,'#74ffdd');
 c.restore();
}
export function paintRoyalPreview(canvas,{time=0}={}){
 const c=canvas?.getContext?.('2d');if(!c)return;
 const W=canvas.width,H=canvas.height;c.clearRect(0,0,W,H);
 const grad=c.createLinearGradient(0,0,W,H);grad.addColorStop(0,'#091827');grad.addColorStop(1,'#231a16');c.fillStyle=grad;c.fillRect(0,0,W,H);
 for(let i=0;i<25;i++){const x=(i*127+91)%W,y=(i*89+22)%H;c.fillStyle='#e8b96033';c.beginPath();c.arc(x,y,i%3+1,0,TAU);c.fill();}
 const pts=Array.from({length:100},(_,i)=>{const t=i/99;return{x:W*.72-t*W*.59,y:H*.47+Math.sin(t*7.5+time*.65)*H*.24+ t*H*.07};});
 const theta=Math.atan2(pts[0].y-pts[1].y,pts[0].x-pts[1].x);
 paintRoyalSnake(c,pts,theta,Math.max(8,Math.min(W,H)*.056),{now:time*1000,reducedMotion:!time});
}
