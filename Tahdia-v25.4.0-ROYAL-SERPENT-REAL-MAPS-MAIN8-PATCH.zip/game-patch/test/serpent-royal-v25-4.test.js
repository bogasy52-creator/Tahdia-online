import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {paintRoyalSnake,paintRoyalPreview} from '../public/assets/js/serpent-royal-v25-4.js';
import {SERPENT_WORLDS,setupSerpentWorld,paintSerpentWorldFloor} from '../public/assets/js/serpent-worlds-v25-2.js';
function fakeCanvas(){const calls={};const c=new Proxy({},{get(obj,key){if(key in obj)return obj[key];if(key==='createLinearGradient'||key==='createRadialGradient')return ()=>({addColorStop(){}});if(key==='getContext')return ()=>c;return (...args)=>{calls[key]=(calls[key]||0)+1;};},set(obj,key,value){obj[key]=value;return true;}});return {c,calls};}
test('royal drawing has authentic armor, head and repeated gold scales rather than a crown over regular skin',()=>{
 const {c,calls}=fakeCanvas(),parts=Array.from({length:100},(_,i)=>({x:550-i*4,y:240+Math.sin(i/8)*25}));
 assert.doesNotThrow(()=>paintRoyalSnake(c,parts,.2,14,{reducedMotion:true,quality:'high'}));
 assert.ok(calls.stroke>80,'many actual gold outlined body segments');assert.ok(calls.fill>60,'plates and face fully drawn');assert.ok(calls.ellipse>2,'face and eyes');
});
test('royal portrait draws the same owner skin function for the real selection card',()=>{
 const {c,calls}=fakeCanvas();const canvas={width:520,height:265,getContext:()=>c};
 assert.doesNotThrow(()=>paintRoyalPreview(canvas));assert.ok(calls.stroke>80);assert.ok(calls.fill>60);
});
test('owner card only uses account entitlement and renderer substitutes a full character for local owners',async()=>{
 const html=await readFile(new URL('../public/serpent.html',import.meta.url),'utf8');
 const ui=await readFile(new URL('../public/assets/js/serpent-ui.js',import.meta.url),'utf8');
 const renderer=await readFile(new URL('../public/assets/js/serpent-renderer.js',import.meta.url),'utf8');
 assert.match(html,/id="arenaOwnerCard" class="arena-owner-card hidden"/);
 assert.match(html,/id="arenaOwnerSkin" type="checkbox"/);
 assert.match(ui,/ownerAllowed\(window\.BS_CAREER\?\.access\?\.\(\)/);
 assert.match(renderer,/if\(royal\)paintRoyalSnake/);
 assert.match(renderer,/else window\.BS_COSMETIC_ART\.body/);
 assert.match(renderer,/paintSerpentWorldFloor\(ctx,g,/);
});
test('each biome paints its own base before actual collidable obstacles',()=>{
 for(const kind of ['neon','forest','crystals']){
  const p=SERPENT_WORLDS[kind];const g={width:p.width,height:p.height,seed:45,status:'playing',elapsed:0,difficulty:'easy',snakes:[{id:'p',x:150,y:150,alive:true,bot:false,mass:24,segments:[]}],food:[]};
  setupSerpentWorld(g,kind);const {c,calls}=fakeCanvas();
  assert.equal(paintSerpentWorldFloor(c,g,{minX:20,minY:20,maxX:350,maxY:400},1,0,true),true);
  assert.ok(calls.fillRect>0&&calls.stroke>0,kind);
 }
});
