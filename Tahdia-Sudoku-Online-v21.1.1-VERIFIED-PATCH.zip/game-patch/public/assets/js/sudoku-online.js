/* Progressive realtime Sudoku. A disconnected player can resume with their room token. */
(()=>{
'use strict';
const $=id=>document.getElementById(id),tiers=['مبتدئ','متوسط','متقدم','خبير','ماستر'];
let ws=null,code='',state=null,retryTimer=null,retryMs=700,offset=0,selected=0,pencil=false,
    notes=Array(81).fill(0),history=[],cells=[],numberButtons=[],closing=false,lastAccount=null,pendingMove=null;
const storage=(key)=>{try{return localStorage.getItem(key);}catch{return null;}};
const put=(key,value)=>{try{localStorage.setItem(key,value);}catch{}};
const urlRoom=(c,suffix='')=>'/api/sudoku/rooms/'+c+suffix;
function message(s,target='soMoveMessage'){ $(target).textContent=s; if(target==='soMoveMessage')$('soRoomMessage').textContent=s; }
function getName(){return $('soName').value.trim().slice(0,20)||storage('sudoku-online-name')||'لاعب';}
function getToken(){return storage('sudoku-online-token:'+code);}
function hide(el,yes){$(el).hidden=Boolean(yes);}
function send(type,more={}) {if(!ws||ws.readyState!==WebSocket.OPEN){message('انقطع الاتصال؛ سيتم استكمال اللعب تلقائيًا.');return false;}ws.send(JSON.stringify({type,...more}));return true;}
function setCode(c){code=c;pendingMove=null;history=[];notes=Array(81).fill(0);hide('soEntry',true);hide('soRoom',false);$('soRoomCode').textContent=c;window.history.replaceState(null,'','/sudoku-online?room='+c);}
function enterLobby(){hide('soLobby',false);hide('soGame',true);hide('soFinished',true);}
function renderPlayers(id='soLobbyPlayers') {
 const node=$(id);node.replaceChildren();for(const p of state.players){const li=document.createElement('li');if(!p.connected)li.classList.add('so-offline');
 const who=document.createElement('span');who.textContent=p.name+(p.id===state.playerId?' (أنت)':'')+(p.role==='host'?' ★':'');
 const extra=document.createElement('small');extra.textContent=p.connected?'متصل':'غير متصل';li.append(who,extra);node.append(li);}
}
function formatTime(ms){const sec=Math.max(0,Math.ceil(ms/1000));return String(Math.floor(sec/60)).padStart(2,'0')+':'+String(sec%60).padStart(2,'0');}
function serverNow(){return Date.now()+offset;}
function tick(){if(!state)return;
 if(state.status==='countdown'){$('soCountdown').textContent='تبدأ الجولة بعد '+Math.max(0,Math.ceil((state.startAt-serverNow())/1000))+' ثانية';}
 if(state.status==='playing'){$('soTime').textContent=formatTime(state.endsAt-serverNow());}
}
function ensureBoard(){if(cells.length)return;const box=$('soBoard');box.replaceChildren();
 cells=Array.from({length:81},(_,i)=>{const b=document.createElement('button');b.type='button';b.className='sudoku-cell';b.setAttribute('role','gridcell');b.setAttribute('aria-rowindex',Math.floor(i/9)+1);b.setAttribute('aria-colindex',i%9+1);b.addEventListener('click',()=>choose(i));b.addEventListener('keydown',e=>key(e,i));
 const value=document.createElement('span'),pencilGrid=document.createElement('span');pencilGrid.className='sudoku-notes-grid';b.append(value,pencilGrid);box.append(b);return{b,value,pencilGrid,mask:-1};});
 const pad=$('soPad');pad.replaceChildren();numberButtons=Array.from({length:9},(_,i)=>{const b=document.createElement('button');b.type='button';b.textContent=i+1;b.addEventListener('click',()=>enter(i+1));pad.append(b);return b;});
}
function peers(i,j){return Math.floor(i/9)===Math.floor(j/9)||i%9===j%9||(Math.floor(i/27)===Math.floor(j/27)&&Math.floor(i%9/3)===Math.floor(j%9/3));}
function choose(i){selected=i;paint();cells[i]?.b.focus();}
function paint(){if(!state||!Array.isArray(state.board))return;ensureBoard();const board=state.board,locked=state.status!=='playing'||state.won;
 for(let i=0;i<81;i++){const b=cells[i].b,v=board[i],r=Math.floor(i/9),c=i%9,mask=v?0:notes[i];
 b.className='sudoku-cell'+(state.initial[i]?' given':'')+(c===2||c===5?' block-right':'')+(r===2||r===5?' block-bottom':'')+(i===selected?' selected':'')+(i!==selected&&peers(i,selected)?' peer':'')+(board[selected]&&v===board[selected]?' same':'');
 b.setAttribute('aria-selected',String(i===selected));b.setAttribute('aria-readonly',String(Boolean(state.initial[i])));b.setAttribute('aria-label','صف '+(r+1)+' عمود '+(c+1)+(v?' رقم '+v:' فارغة'));
 b.tabIndex=i===selected?0:-1;cells[i].value.textContent=v||'';b.disabled=locked;
 if(mask!==cells[i].mask){cells[i].mask=mask;cells[i].pencilGrid.replaceChildren();if(mask)for(let n=1;n<=9;n++){let s=document.createElement('span');s.textContent=mask&(1<<(n-1))?n:'';cells[i].pencilGrid.append(s);}}
 }
 numberButtons.forEach(b=>{b.disabled=locked;});$('soErase').disabled=locked;$('soUndo').disabled=locked;
 $('soFilled').textContent=(board.filter(Boolean).length-state.initial.filter(Boolean).length)+' / '+(81-state.initial.filter(Boolean).length);
}
function renderScores(id='soScores'){const node=$(id);node.replaceChildren();for(const p of state.players){const li=document.createElement('li');if(!p.connected)li.classList.add('so-offline');if(p.id===state.playerId)li.classList.add('so-me');
 const name=document.createElement('span');name.textContent=p.rank+'. '+p.name+(p.id===state.playerId?' · أنت':'');
 const info=document.createElement('strong');info.textContent=p.finishedAt?'✓ مكتمل':p.filled+' / '+p.total;li.append(name,info);node.append(li);}}
function render(){if(!state)return;offset=state.serverNow-Date.now();hide('soEntry',true);hide('soRoom',false);$('soRoomCode').textContent=state.code;
 $('soStatus').textContent=state.status==='lobby'?'بانتظار بداية المنافسة · '+tiers[state.difficulty]:state.status==='countdown'?'العد التنازلي بدأ · '+tiers[state.difficulty]:state.status==='playing'?'المنافسة جارية · '+tiers[state.difficulty]:'انتهت المباراة · '+tiers[state.difficulty];
 if(state.status==='lobby'||state.status==='countdown'){enterLobby();$('soCount').textContent=state.players.length+' / '+state.playerLimit;renderPlayers();$('soLobbyDifficulty').value=String(state.difficulty);$('soLobbyDifficulty').disabled=state.role!=='host'||state.status!=='lobby';
 hide('soStart',state.role!=='host'||state.status!=='lobby');$('soLobbyHelp').textContent=state.status==='lobby'?'المضيف يبدأ العد عند جاهزية الجميع. بعد الضغط يتبقى 20 ثانية للدخول.':'بدأ العد؛ يمكن للآخرين دخول الغرفة خلال 20 ثانية ما دامت هناك أماكن متاحة. لا يمكن تغيير الصعوبة.';
 $('soCountdown').textContent=state.status==='lobby'?'بانتظار بدء المضيف':'يبدأ خلال 20 ثانية';tick();return;}
 hide('soLobby',true);hide('soGame',state.status==='finished');hide('soFinished',state.status!=='finished');
 paint();renderScores();tick();
 if(state.won)message('أحسنت! تم اعتماد حلك من الخادم. انتظر اكتمال المنافسة.');
 if(state.status==='finished'){$('soWinner').textContent=state.winnerId===state.playerId?'أنت الفائز! 🏆':state.winnerId?'الفائز: '+(state.players.find(p=>p.id===state.winnerId)?.name||'لاعب'):'انتهى وقت المنافسة';
 $('soFinishCopy').textContent='النتيجة محسوبة على الخادم وفق الحل الكامل، وليس عدد الأرقام فقط.';renderScores('soFinalScores');}
}
function enter(n){if(!state||state.status!=='playing'||state.won)return;if(pendingMove)return message('جار اعتماد حركتك السابقة...');if(state.initial[selected])return message('هذه خانة ثابتة لا يمكن تغييرها.');
 if(pencil&&n){if(state.board[selected])return message('امسح الرقم أولًا قبل كتابة الملاحظات.');notes[selected]^=1<<(n-1);paint();return;}
 if(!n&&notes[selected]&&!state.board[selected]){notes[selected]=0;paint();return;}
 if(n===state.board[selected])return;
 if(n&&state.board.some((v,i)=>i!==selected&&v===n&&peers(i,selected)))return message('هذا الرقم موجود في الصف أو العمود أو المربع؛ اختر غيره.');
 if(send('move',{cell:selected,value:n})){pendingMove={cell:selected,value:n,previous:state.board[selected]};message('جاري مراجعة الحركة...');}
}
function undo(){if(pendingMove)return message('جار اعتماد الحركة الحالية...');if(!history.length)return message('لا توجد حركة للتراجع عنها.');const old=history.at(-1);if(send('move',{cell:old.cell,value:old.value})){pendingMove={cell:old.cell,value:old.value,previous:state.board[old.cell],undo:true};}}
function key(e,i){const k=e.key,r=Math.floor(i/9),c=i%9;if(/^[1-9]$/.test(k)){e.preventDefault();enter(+k);return;}if(k==='Backspace'||k==='Delete'||k==='0'){e.preventDefault();enter(0);return;}
 if(k.toLowerCase()==='n'){e.preventDefault();$('soNotes').click();return;}if((e.ctrlKey||e.metaKey)&&k.toLowerCase()==='z'){e.preventDefault();undo();return;}
 let next;if(k==='ArrowLeft')next=r*9+Math.max(0,c-1);else if(k==='ArrowRight')next=r*9+Math.min(8,c+1);else if(k==='ArrowUp')next=Math.max(0,r-1)*9+c;else if(k==='ArrowDown')next=Math.min(8,r+1)*9+c;
 if(next!==undefined){e.preventDefault();choose(next);}}
function connect(){if(!code||closing)return;clearTimeout(retryTimer);const previous=ws;if(previous){try{previous.onclose=null;previous.close();}catch{}}
 const link=new URL(urlRoom(code,'/ws'),location.origin);link.protocol=link.protocol==='https:'?'wss:':'ws:';link.searchParams.set('name',getName());
 const protocols=['busraj-sudoku-v1'],acct=storage('bs_social_session'),rt=getToken(),hk=storage('sudoku-online-host:'+code);
 if(acct)protocols.push('st.'+acct);if(rt)protocols.push('rt.'+rt);if(hk)protocols.push('hk.'+hk);
 lastAccount=acct;message('جار الاتصال بالغرفة...');
 try{ws=new WebSocket(link,protocols);}catch{reconnect();return;}
 const current=ws;ws.onopen=()=>{if(current!==ws||closing)return;clearTimeout(retryTimer);retryMs=700;message('متصل بالخادم.');};
 ws.onmessage=e=>{if(current!==ws||closing)return;let data;try{data=JSON.parse(e.data);}catch{return;}
 if(data.type==='welcome'){pendingMove=null;put('sudoku-online-token:'+code,data.token);state=data.state;render();}
 else if(data.type==='state'){if(pendingMove&&data.state.board[pendingMove.cell]===pendingMove.value){if(pendingMove.undo)history.pop();else{history.push({cell:pendingMove.cell,value:pendingMove.previous});if(history.length>250)history.shift();}notes[pendingMove.cell]=0;pendingMove=null;}state=data.state;render();}
 else if(data.type==='error'){pendingMove=null;message(data.message||'حدث خطأ في الحركة');}};
 ws.onclose=()=>{if(current!==ws||closing)return;pendingMove=null;$('soStatus').textContent='الاتصال منقطع، نحاول الاستكمال...';reconnect();};
 ws.onerror=()=>{if(current===ws&&!closing)message('تحقق من تشغيل محرك الغرف على السيرفر.');};
}
function reconnect(){if(closing)return;clearTimeout(retryTimer);retryTimer=setTimeout(connect,retryMs);retryMs=Math.min(retryMs*1.5,10000);}
async function jsonRequest(path,options){const res=await fetch(path,{...options,headers:{'content-type':'application/json',...(options?.headers||{})}});const data=await res.json().catch(()=>({}));if(!res.ok)throw Error(data.error||'تعذر الاتصال بالخادم');return data;}
async function join(c){if(!/^\d{6}$/.test(c))return message('أدخل رمز الغرفة المكوّن من 6 أرقام.','soEntryMessage');
 try{const info=await jsonRequest(urlRoom(c,'/status'));if(!['lobby','countdown'].includes(info.status)&&!storage('sudoku-online-token:'+c))throw Error('بدأت المباراة، لا يمكن الانضمام الآن.');
 if(info.players>=info.playerLimit&&!storage('sudoku-online-token:'+c))throw Error('الغرفة ممتلئة.');put('sudoku-online-name',getName());closing=false;setCode(c);connect();}catch(err){message(err.message,'soEntryMessage');}}
$('soCreate').onclick=async()=>{const b=$('soCreate');b.disabled=true;message('جار تجهيز الغرفة...','soEntryMessage');
 try{put('sudoku-online-name',getName());const data=await jsonRequest('/api/sudoku/rooms',{method:'POST',body:JSON.stringify({playerLimit:Number($('soLimit').value),difficulty:Number($('soDifficulty').value)})});
 put('sudoku-online-host:'+data.code,data.hostKey);closing=false;setCode(data.code);connect();}catch(err){message(err.message,'soEntryMessage');}finally{b.disabled=false;}};
$('soJoin').onclick=()=>join($('soCode').value.trim());$('soCode').onkeydown=e=>{if(e.key==='Enter')join($('soCode').value.trim());};
$('soStart').onclick=()=>send('start');$('soLobbyDifficulty').onchange=()=>send('difficulty',{difficulty:Number($('soLobbyDifficulty').value)});
$('soShare').onclick=async()=>{const link=location.origin+'/sudoku-online?room='+code;try{await navigator.clipboard.writeText(link);message('نسخنا رابط الدعوة.');}catch{window.prompt('انسخ رابط الدعوة',link);}};
$('soLeave').onclick=()=>{closing=true;clearTimeout(retryTimer);ws?.close();state=null;window.history.replaceState(null,'','/sudoku-online');hide('soRoom',true);hide('soEntry',false);};
$('soNotes').onclick=()=>{pencil=!pencil;$('soNotes').setAttribute('aria-pressed',String(pencil));message(pencil?'القلم مفعّل: الأرقام ملاحظات فقط.':'الإدخال العادي مفعّل.');};
$('soErase').onclick=()=>enter(0);$('soUndo').onclick=undo;
window.addEventListener('storage',e=>{if(e.key==='bs_social_session'&&lastAccount!==storage('bs_social_session')){closing=true;clearTimeout(retryTimer);ws?.close();state=null;hide('soRoom',true);hide('soEntry',false);message('تغير الحساب؛ افتح الغرفة مجددًا.','soEntryMessage');}});
window.addEventListener('pagehide',()=>{closing=true;clearTimeout(retryTimer);ws?.close();});
setInterval(tick,250);$('soName').value=storage('sudoku-online-name')||'';
const params=new URLSearchParams(location.search),initial=params.get('room');if(/^\d{6}$/.test(initial||''))join(initial);
})();
