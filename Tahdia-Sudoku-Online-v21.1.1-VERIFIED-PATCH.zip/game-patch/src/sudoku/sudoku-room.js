/**
 * A competitive Sudoku Durable Object delegated through the existing ROOMS binding.
 * The server owns the grid, validates every move, and never sends the solution.
 * No Cloudflare migration or extra Durable Object binding is required.
 */
import {createSudoku} from '../../public/assets/js/engines/sudoku-engine.js';
import {solveSudoku, SUDOKU_PEERS} from '../../public/assets/js/engines/sudoku-core.js';

export const SUDOKU_ONLINE_PROTOCOL = 'busraj-sudoku-v1';
export const SUDOKU_LOBBY_MS = 20_000;
const GRACE_MS = 45_000;
const PLAY_MS = 45 * 60_000;
const ROOM_MS = 3 * 60 * 60_000;
const respond = (data, status=200) => Response.json(data,{status,headers:{'cache-control':'no-store'}});
const nameOf = (value) => String(value || 'لاعب').normalize('NFKC').trim().replace(/[<>\u0000-\u001f\u007f]/g,'').slice(0,20) || 'لاعب';
const secret = () => crypto.randomUUID().replaceAll('-','') + crypto.randomUUID().replaceAll('-','');
const send = (ws, data) => { try {ws.send(JSON.stringify(data));} catch {} };
const isWebSocket = (ws) => !ws.closed && (ws.readyState === undefined || ws.readyState === 1);
const tierLevel = tier => tier * 24 + 1 + (crypto.getRandomValues(new Uint32Array(1))[0] % 24);

export function legalSudokuOnlineMove(initial, board, cell, value) {
  if (!Array.isArray(initial) || !Array.isArray(board) || initial.length !== 81 || board.length !== 81 ||
      !Number.isInteger(cell) || cell < 0 || cell > 80 || !Number.isInteger(value) || value < 0 || value > 9 ||
      initial[cell] !== 0 || board[cell] === value) return false;
  // A placement with a repeated number is rejected, not merely painted red.
  return value === 0 || SUDOKU_PEERS[cell].every(i => board[i] !== value);
}

export class SudokuRoom {
  constructor(ctx,env) {
    this.ctx=ctx;
    this.env=env;
    this.room=null;
    this.ready=ctx.blockConcurrencyWhile(async()=>{
      this.room=await ctx.storage.get('sudokuRoom')||null;
      if(this.room)this.syncConnections();
    });
  }
  sockets() { return this.ctx.getWebSockets().filter(ws => {try{return ws.deserializeAttachment()?.sudoku === true && isWebSocket(ws);}catch{return false;}}); }
  socketPlayer(ws) {
    let att;try{att=ws.deserializeAttachment();}catch{return null;}
    const p=this.room?.players.find(x=>x.id===att?.playerId);
    return p?.connection===att?.connection?p:null;
  }
  syncConnections() {
    if(!this.room)return;
    const active=new Set(this.sockets().map(ws=>ws.deserializeAttachment().connection));
    for(const p of this.room.players)p.connected=Boolean(p.connection && active.has(p.connection));
  }
  async save() { if(this.room)await this.ctx.storage.put('sudokuRoom',this.room); }
  async schedule() {
    if(!this.room)return;
    const r=this.room,now=Date.now();
    const when=[r.expiresAt];
    if(r.status==='countdown')when.push(r.startAt);
    if(r.status==='playing')when.push(r.endsAt);
    if(r.status==='lobby')for(const p of r.players)if(!p.connected&&p.disconnectedAt)when.push(p.disconnectedAt+GRACE_MS);
    await this.ctx.storage.setAlarm(Math.max(now+100,Math.min(...when)));
  }
  trimLobby() {
    const r=this.room;if(!r||r.status!=='lobby')return false;
    const now=Date.now(),old=r.players.length;
    r.players=r.players.filter(p=>p.connected || !p.disconnectedAt || now-p.disconnectedAt<GRACE_MS);
    if(r.players.length&& !r.players.some(p=>p.role==='host'))r.players[0].role='host';
    return old!==r.players.length;
  }
  async advance() {
    const r=this.room;if(!r)return;
    const now=Date.now();let changed=false;
    if(r.status==='countdown'&&now>=r.startAt){r.status='playing';r.endsAt=r.startAt+PLAY_MS;changed=true;}
    if(r.status==='playing'&&(now>=r.endsAt || r.players.every(p=>p.finishedAt))){r.status='finished';r.finishedAt=now;changed=true;}
    if(changed){await this.save();this.broadcast();await this.schedule();}
  }
  publicState(p) {
    const r=this.room;
    const leaderboard=[...r.players].sort((a,b)=>{
      if(a.finishedAt&&b.finishedAt)return a.finishedAt-b.finishedAt||r.players.indexOf(a)-r.players.indexOf(b);
      if(a.finishedAt)return -1;if(b.finishedAt)return 1;
      return b.board.filter(Boolean).length-a.board.filter(Boolean).length || a.mistakes-b.mistakes;
    });
    return {
      code:r.code,status:r.status,playerLimit:r.playerLimit,difficulty:r.difficulty,level:r.level,
      initial:r.initial,board:p.board,playerId:p.id,role:p.role,
      startAt:r.startAt||null,endsAt:r.endsAt||null,serverNow:Date.now(),
      won:Boolean(p.finishedAt),moves:p.moves,mistakes:p.mistakes,
      players:leaderboard.map((x,i)=>({id:x.id,name:x.name,role:x.role,connected:x.connected,
        rank:i+1,filled:x.board.filter(Boolean).length-r.initial.filter(Boolean).length,
        total:81-r.initial.filter(Boolean).length,finishedAt:x.finishedAt||null,mistakes:x.mistakes})),
      winnerId:leaderboard.find(x=>x.finishedAt)?.id||null
    };
  }
  broadcast() {
    for(const ws of this.sockets()) {const p=this.socketPlayer(ws);if(p)send(ws,{type:'state',state:this.publicState(p)});}
  }
  error(ws,message) {send(ws,{type:'error',message});}
  async fetch(request) {
    await this.ready;
    const url=new URL(request.url);
    if(url.pathname==='/init'&&request.method==='POST') {
      const body=await request.json().catch(()=>({}));
      if(this.room&&this.room.expiresAt>Date.now())return respond({ok:false,error:'room_exists'},409);
      if(!/^\d{6}$/.test(body.code||'')||typeof body.hostKey!=='string'||body.hostKey.length<32 ||
         !Number.isInteger(body.playerLimit)||body.playerLimit<1||body.playerLimit>10 ||
         !Number.isInteger(body.difficulty)||body.difficulty<0||body.difficulty>4)
        return respond({ok:false,error:'إعدادات الغرفة غير صحيحة'},400);
      const level=tierLevel(body.difficulty),puzzle=createSudoku(level);
      const solved=solveSudoku(puzzle.initial);
      if(solved.count!==1||solved.limited)return respond({ok:false,error:'اللغز يحتاج مراجعة'},503);
      this.room={code:body.code,hostKey:body.hostKey,playerLimit:body.playerLimit,difficulty:body.difficulty,
        level,initial:puzzle.initial,solution:solved.solution,players:[],status:'lobby',startAt:null,
        endsAt:null,finishedAt:null,expiresAt:Date.now()+ROOM_MS};
      await this.save();await this.schedule();return respond({ok:true},201);
    }
    if(!this.room||this.room.expiresAt<=Date.now())return respond({ok:false,error:'الغرفة غير موجودة أو انتهت'},404);
    await this.advance();
    if(url.pathname==='/status')return respond({ok:true,status:this.room.status,playerLimit:this.room.playerLimit,players:this.room.players.length,difficulty:this.room.difficulty});
    if(url.pathname==='/ws')return this.connect(request,url);
    return respond({ok:false,error:'not_found'},404);
  }
  async connect(request,url) {
    if(request.headers.get('upgrade')?.toLowerCase()!=='websocket')return respond({ok:false,error:'WebSocket required'},426);
    const protocols=String(request.headers.get('sec-websocket-protocol')||'').split(',').map(s=>s.trim());
    if(!protocols.includes(SUDOKU_ONLINE_PROTOCOL))return respond({ok:false,error:'protocol_required'},426);
    const rt=protocols.find(x=>x.startsWith('rt.'))?.slice(3),hk=protocols.find(x=>x.startsWith('hk.'))?.slice(3),account=request.headers.get('x-bs-account')||null;
    const r=this.room;
    let p=rt?r.players.find(x=>x.token===rt):null;
    if(p&&p.username&&p.username!==account)return respond({ok:false,error:'سجّل الدخول بنفس الحساب لاستكمال اللعب'},403);
    if(!p&&hk===r.hostKey&&r.players.length===0){p=this.addPlayer(url.searchParams.get('name'),'host',account);}
    if(!p){
      if(r.status!=='lobby' && !(r.status==='countdown' && Date.now()<r.startAt))return respond({ok:false,error:'انتهى اللوبي؛ الدخول الجديد مغلق'},409);
      if(r.status==='lobby')this.trimLobby();
      if(!r.players.length)return respond({ok:false,error:'بانتظار المضيف ليدخل أولًا'},409);
      if(r.players.length>=r.playerLimit)return respond({ok:false,error:'الغرفة ممتلئة'},409);
      if(account&&r.players.some(x=>x.username===account))return respond({ok:false,error:'الحساب داخل الغرفة بالفعل'},409);
      p=this.addPlayer(url.searchParams.get('name'),'guest',account);
    }
    for(const old of this.sockets())try{if(old.deserializeAttachment()?.playerId===p.id)old.close(4001,'reconnected');}catch{}
    const pair=new WebSocketPair(),client=pair[0],server=pair[1];this.ctx.acceptWebSocket(server);
    p.connection=crypto.randomUUID();server.serializeAttachment({sudoku:true,playerId:p.id,connection:p.connection});
    p.connected=true;p.disconnectedAt=null;
    await this.save();await this.schedule();
    send(server,{type:'welcome',token:p.token,playerId:p.id,state:this.publicState(p)});this.broadcast();
    return new Response(null,{status:101,webSocket:client,headers:{'sec-websocket-protocol':SUDOKU_ONLINE_PROTOCOL}});
  }
  addPlayer(name,role,username) {
    const p={id:crypto.randomUUID(),name:nameOf(name),role,username,token:secret(),board:[...this.room.initial],moves:0,mistakes:0,finishedAt:null,connected:true,disconnectedAt:null,connection:null};
    this.room.players.push(p);return p;
  }
  async webSocketMessage(ws,raw) {
    await this.ready;if(!this.room)return;
    const p=this.socketPlayer(ws);if(!p)return;
    const rawText=typeof raw==='string'?raw:new TextDecoder().decode(raw);
    if(rawText.length>1024)return this.error(ws,'الرسالة طويلة جدًا');
    let msg;try{msg=JSON.parse(rawText);}catch{return this.error(ws,'رسالة غير صالحة');}
    if(!msg||typeof msg!=='object'||Array.isArray(msg))return this.error(ws,'رسالة غير صالحة');
    await this.advance();const r=this.room;
    if(msg.type==='start') {
      if(p.role!=='host'||r.status!=='lobby')return this.error(ws,'بدء اللوبي للمضيف فقط');
      r.status='countdown';r.startAt=Date.now()+SUDOKU_LOBBY_MS;
      await this.save();await this.schedule();this.broadcast();return;
    }
    if(msg.type==='difficulty') {
      if(p.role!=='host'||r.status!=='lobby'||!Number.isInteger(msg.difficulty)||msg.difficulty<0||msg.difficulty>4)
        return this.error(ws,'تغيير الصعوبة للمضيف قبل بدء العد فقط');
      const level=tierLevel(msg.difficulty),puzzle=createSudoku(level),solved=solveSudoku(puzzle.initial);
      if(solved.count!==1||solved.limited)return this.error(ws,'تعذر تجهيز اللغز');
      r.difficulty=msg.difficulty;r.level=level;r.initial=puzzle.initial;r.solution=solved.solution;
      for(const player of r.players){player.board=[...r.initial];player.moves=0;player.mistakes=0;}
      await this.save();this.broadcast();return;
    }
    if(msg.type==='move') {
      if(r.status!=='playing'||p.finishedAt)return this.error(ws,'انتظر بداية الجولة أو انتهى وقتك');
      const {cell,value}=msg;
      if(!legalSudokuOnlineMove(r.initial,p.board,cell,value)){
        p.mistakes=Math.min(999,p.mistakes+1);await this.save();this.error(ws,'الرقم غير صحيح هنا أو يتكرر في الصف أو العمود أو المربع');this.broadcast();return;
      }
      if(p.moves>=3000)return this.error(ws,'تجاوزت حد الإدخالات لهذه الجولة');
      p.board[cell]=value;p.moves++;
      if(p.board.every((x,i)=>x===r.solution[i]))p.finishedAt=Date.now();
      if(r.players.every(x=>x.finishedAt)){r.status='finished';r.finishedAt=Date.now();}
      await this.save();await this.schedule();this.broadcast();return;
    }
    if(msg.type==='resync'){send(ws,{type:'state',state:this.publicState(p)});return;}
    this.error(ws,'أمر غير مدعوم');
  }
  async webSocketClose(ws) {
    await this.ready;const p=this.socketPlayer(ws);
    if(!p)return;
    p.connected=false;p.disconnectedAt=Date.now();await this.save();await this.schedule();this.broadcast();
  }
  async webSocketError(ws) {await this.webSocketClose(ws);}
  async alarm() {
    await this.ready;if(!this.room)return;
    if(Date.now()>=this.room.expiresAt){await this.ctx.storage.delete('sudokuRoom');this.room=null;for(const ws of this.sockets())try{ws.close(1001,'expired');}catch{}return;}
    this.syncConnections();if(this.trimLobby())await this.save();
    await this.advance();await this.schedule();this.broadcast();
  }
}
