import {boardGeometry,boardStonePosition} from './board-geometry-v29.js?v=33.9.10';
export const JACKAROO_STARTS=Object.freeze([0,13,26,39]);
// 33.6.0: the rooms deal a table of four on the big board; six seats keep thirteen. A game
// without `arm` is the old board.
// 33.7.0: the board of the picture: a seat's quarter is its house and holes 1 to 18 (19 places,
// the starts at 0, 19, 38, 57), and `home: 'fill'` — the four holes of the home lane are where
// the marbles end, one marble to a hole, as on a real board.
export const jackarooArm=seats=>seats===4?19:13;
/** Is this marble home: in its lane on a «fill» board, at the finish on the others. */
export const jackarooHome=(state,m)=>{const g=boardGeometry(state);return g.fill?m>=g.track:m===g.finish;};
const SUITS=['S','H','D','C'];const RANKS=['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
const clone=s=>structuredClone(s);export const cardRank=c=>String(c).replace(/[SHDC]$/,'');
export function createJackarooDeck(){return SUITS.flatMap(s=>RANKS.map(r=>r+s))}
export function shuffleJackarooDeck(deck=createJackarooDeck(),rng=Math.random){const a=[...deck];for(let i=a.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
// 33.9.0: everything goes to the right, as at a real table: the turn, the deal and the dealer
// (seat − 1 is the player on your right; the board itself is drawn as before)
export const jackarooNext=(state,seat,step=1)=>{const n=state.players.length;return((seat-step)%n+n)%n};
function dealBatch(state,size){if(state.deck.length<size*state.players.length){state.deck=shuffleJackarooDeck(createJackarooDeck());state.discard=[];state.dealer=jackarooNext(state,state.dealer)}state.hands=state.hands.map(()=>[]);for(let r=0;r<size;r++)for(let i=1;i<=state.players.length;i++){const p=jackarooNext(state,state.dealer,i);state.hands[p].push(state.deck.pop())}state.dealIndex=(state.dealIndex+1)%3}
export function createJackarooGame(names=['لاعب 1','لاعب 2','لاعب 3','لاعب 4'],options={}){if(!Array.isArray(names)||![4,6].includes(names.length))throw new Error('jackaroo_requires_4_or_6_players');const s={...([13,18,19].includes(options.arm)&&!(options.arm>13&&names.length!==4)?{arm:options.arm}:{}),...(options.home==='fill'&&options.arm===19&&names.length===4?{home:'fill'}:{}),players:names.map((n,id)=>({id,name:String(n||`لاعب ${id+1}`).slice(0,20),marbles:[-1,-1,-1,-1]})),hands:names.map(()=>[]),deck:options.deck?[...options.deck]:shuffleJackarooDeck(createJackarooDeck(),options.rng||Math.random),discard:[],dealer:options.dealer??0,dealIndex:0,turn:(options.dealer??0)+names.length-1,played:0,winnerTeam:null,lastEvent:null};s.turn%=names.length;dealBatch(s,4);return s}
export function globalJackarooPosition(player,progress,state=4){return boardStonePosition(player,progress,state)}
export const jackarooTeam=p=>p%2;
export function teamWinner(state){for(const team of[0,1])if(state.players.filter((_,i)=>i%2===team).every(p=>p.marbles.every(m=>jackarooHome(state,m))))return team;return null}
const ownerCandidates=(state,actor)=>{if(!state.players[actor].marbles.every(m=>jackarooHome(state,m)))return[actor];for(let n=2;n<state.players.length;n+=2){const mate=(actor+n)%state.players.length;if(!state.players[mate].marbles.every(m=>jackarooHome(state,m)))return[mate];}return[];};
function isSafeGlobal(state,global){return boardGeometry(state).safe.has(global)}
// Only a marble on its OWN starting hole is protected. Printed stars and a
// visiting marble on another player's start are ordinary track positions.
function isBaseProtected(state,owner,marble){return state.players[owner].marbles[marble]===0}
function occupancy(state,global,exclude=null){const out=[];state.players.forEach((p,pi)=>p.marbles.forEach((m,mi)=>{if(m>=0&&m<boardGeometry(state).track&&globalJackarooPosition(pi,m,state)===global&&!(exclude&&exclude[0]===pi&&exclude[1]===mi))out.push({player:pi,marble:mi,progress:m,protected:m===0,safe:isSafeGlobal(state,global)})}));return out}
// 33.9.0: a marble on its own start shuts the road — no marble (yours, your partner's or the
// others') passes it or stops on it, forward or backward, until it moves on
function trackPath(state,pos,steps,backward=false,allowHome=true){
 const g=boardGeometry(state),path=[];
 for(let k=1;k<=steps;k++){
  let rel=backward?pos-k:pos+k;
  if(!backward&&allowHome&&rel>=g.track)break;
  if(!backward&&allowHome&&g.fill&&pos<g.track-1&&rel===g.track-1)continue;
  rel=((rel%g.track)+g.track)%g.track;path.push(rel);
 }
 return path;
}
function roadShut(state,owner,marble,pos,steps,backward,allowHome=true){
 return trackPath(state,pos,steps,backward,allowHome).some(rel=>occupancy(state,globalJackarooPosition(owner,rel,state),[owner,marble]).some(o=>o.protected));
}
export function jackarooRoadShut(state,owner,marble,steps,backward=false){const pos=state.players[owner]?.marbles?.[marble];return Number.isInteger(pos)&&pos>=0&&pos<boardGeometry(state).track&&roadShut(state,owner,marble,pos,backward?steps:gateSteps(state,pos,steps),backward)}
// 33.9.12: protection belongs to the marble's own starting hole, not printed stars.
// 33.9.7: on the board of the picture a marble of yours goes from hole 17 straight into its home
// lane: hole 18 is not on your way in. Only a 5 from the other team (or a Jack swap) puts it on 18.
export function jackarooGateSteps(state,pos,steps,skip=true){return gateSteps(state,pos,steps,skip)}
function gateSteps(state,pos,steps,skip=true){const g=boardGeometry(state);return g.fill&&skip&&pos>=0&&pos<g.track-1&&pos+steps>=g.track-1?steps+1:steps}
/** Shared by legal moves and the board picker: an opposing five never enters home. */
export function jackarooMoveTarget(state,owner,marble,steps,backward=false,allowHome=true){
 const pos=state.players[owner].marbles[marble],g=boardGeometry(state);
 if(backward)return((pos-steps)%g.track+g.track)%g.track;
 const target=pos+gateSteps(state,pos,steps,allowHome);
 return allowHome?target:target%g.track;
}
function canMove(state,owner,marble,steps,backward=false,allowHome=true,king=false){
 const pos=state.players[owner].marbles[marble],g=boardGeometry(state);
 if(pos<0||pos>=g.finish||backward&&pos>=g.track)return false;
 const target=jackarooMoveTarget(state,owner,marble,steps,backward,allowHome);
 if(target>g.finish)return false;
 const distance=backward?steps:gateSteps(state,pos,steps,allowHome);
 if(pos<g.track){
  for(const rel of trackPath(state,pos,distance,backward,allowHome)){
   const occupants=occupancy(state,globalJackarooPosition(owner,rel,state),[owner,marble]);
   if(occupants.some(o=>o.protected||!king&&o.player===owner))return false;
  }
 }
 if(target>=g.track){
  if((g.fill||target!==g.finish)&&state.players[owner].marbles.some((m,i)=>i!==marble&&m===target))return false;
  if(state.players[owner].marbles.some((m,i)=>i!==marble&&m>=g.track&&m<g.finish&&m>pos&&m<target))return false;
 }
 return true;
}
function enterAllowed(state,owner){const g=boardGeometry(state).starts[owner],occ=occupancy(state,g);return !occ.some(o=>o.player===owner||o.protected)}
function standardMoveActions(state,actor,steps,backward=false,king=false){const out=[];for(const owner of ownerCandidates(state,actor))state.players[owner].marbles.forEach((_,marble)=>{if(canMove(state,owner,marble,steps,backward,true,king))out.push({type:'move',owner,marble,steps,backward})});return out}
function fiveActions(state,actor=state.turn){const out=[];state.players.forEach((p,owner)=>p.marbles.forEach((m,marble)=>{if(m<0||m>=boardGeometry(state).track)return;const own=jackarooTeam(owner)===jackarooTeam(actor);if(!own&&isBaseProtected(state,owner,marble))return;if(canMove(state,owner,marble,5,false,own))out.push({type:'moveAny5',owner,marble,steps:5})}));return out}
function sevenActions(state,actor){const out=standardMoveActions(state,actor,7,false);for(const owner of ownerCandidates(state,actor)){for(let a=0;a<4;a++)for(let b=0;b<4;b++){if(a===b)continue;for(let first=1;first<=6;first++){const second=7-first;if(!canMove(state,owner,a,first,false))continue;const temp=clone(state);applyMove(temp,owner,a,first,false,false);if(canMove(temp,owner,b,second,false))out.push({type:'split7',owner,first:{marble:a,steps:first},second:{marble:b,steps:second}})}}}return out}
function swapActions(state,actor){const out=[];for(const owner of ownerCandidates(state,actor)){state.players[owner].marbles.forEach((m,marble)=>{if(m<0||m>=boardGeometry(state).track||isBaseProtected(state,owner,marble))return;state.players.forEach((p,op)=>{if(op===owner)return;p.marbles.forEach((om,oi)=>{if(om<0||om>=boardGeometry(state).track||isBaseProtected(state,op,oi))return;out.push({type:'swap',owner,marble,otherOwner:op,otherMarble:oi})})})})}return out}
function cardActions(state,cardIndex,actor){const card=state.hands[actor]?.[cardIndex];if(!card)return[];const rank=cardRank(card);let out=[];if(rank==='A'||rank==='K'){for(const owner of ownerCandidates(state,actor)){if(enterAllowed(state,owner))state.players[owner].marbles.forEach((m,marble)=>{if(m===-1)out.push({type:'enter',owner,marble})})}const steps=rank==='A'?[1,11]:[13];for(const n of steps)out.push(...standardMoveActions(state,actor,n,false,rank==='K'))}else if(rank==='10'){out=standardMoveActions(state,actor,10,false);const target=jackarooNext(state,actor);if(state.hands[target]?.length)out.push({type:'burn',target});}else if(rank==='J')out=swapActions(state,actor);else if(rank==='7')out=sevenActions(state,actor);else if(rank==='5')out=fiveActions(state,actor);else{const n=rank==='Q'?12:Number(rank);if(Number.isFinite(n))out=standardMoveActions(state,actor,n,rank==='4')}return out}
export function getJackarooActions(state,cardIndex,actor=state.turn){
 if(!state.players[actor]||!Number.isInteger(cardIndex)||!state.hands[actor]?.[cardIndex])return[];
 if(state.burnPick)return actor===state.burnPick.target?[{type:'burnPick'}]:[];
 const actions=cardActions(state,cardIndex,actor);
 if(actions.length)return actions;
 // A player must use any playable card; a dead card is not a free pass.
 if(state.hands[actor].some((_,i)=>i!==cardIndex&&cardActions(state,i,actor).length))return[];
 return[{type:'discard'}];
}
function captureAt(state,owner,marble){const pos=state.players[owner].marbles[marble];if(pos<0||pos>=boardGeometry(state).track)return[];const g=globalJackarooPosition(owner,pos,state),captured=[];state.players.forEach((p,pi)=>{if(pi===owner)return;p.marbles.forEach((m,mi)=>{if(m>=0&&m<boardGeometry(state).track&&globalJackarooPosition(pi,m,state)===g&&m!==0){p.marbles[mi]=-1;captured.push({player:pi,marble:mi})}})});return captured}
function captureKingPath(state,owner,marble,from,steps){const captured=[];if(from<0||from>=boardGeometry(state).track)return captured;for(const rel of trackPath(state,from,steps)){const g=globalJackarooPosition(owner,rel,state);state.players.forEach((p,pi)=>p.marbles.forEach((m,mi)=>{if(pi===owner&&mi===marble)return;if(m>=0&&m<boardGeometry(state).track&&globalJackarooPosition(pi,m,state)===g&&!isBaseProtected(state,pi,mi)){p.marbles[mi]=-1;captured.push({player:pi,marble:mi})}}))}return captured}
function applyMove(state,owner,marble,steps,backward=false,king=false,skip=true){const from=state.players[owner].marbles[marble],to=jackarooMoveTarget(state,owner,marble,steps,backward,skip),distance=backward?steps:gateSteps(state,from,steps,skip);const pathCaptured=king?captureKingPath(state,owner,marble,from,distance):[];state.players[owner].marbles[marble]=to;const landingCaptured=captureAt(state,owner,marble);return{from,to,captured:[...pathCaptured,...landingCaptured]}}
function removeCardAndAdvance(state,actor,cardIndex){const [card]=state.hands[actor].splice(cardIndex,1);if(card)state.discard.push(card);state.played++;advanceTurn(state,actor,state.lastEvent?.type==='burn'?2:1)}
// 33.8.0: after a whole hand is burnt, the turn passes over a player with no cards left until the next deal (a burning ten skips the next player too)
function advanceTurn(state,actor,step=1){state.winnerTeam=teamWinner(state);if(state.winnerTeam!==null)return;if(state.hands.every(h=>h.length===0)){const sizes=[4,4,5];dealBatch(state,sizes[state.dealIndex])}const n=state.players.length;let next=jackarooNext(state,actor,step);for(let k=0;k<n&&!state.hands[next]?.length;k++)next=jackarooNext(state,next);state.turn=next}
/** True when no card in the hand can move anything: then the whole hand may be burnt at once. */
export function jackarooHandDead(state,actor=state.turn){const hand=state.hands[actor]||[];return hand.length>0&&hand.every((_,i)=>getJackarooActions(state,i,actor).every(a=>a.type==='discard'))}
/** 33.8.0: «احرق الورق كله» — every card of a hand that cannot move anything goes to the pile at once. */
export function burnJackarooHand(state,actor=state.turn){if(state.winnerTeam!==null)return state;if(actor!==state.turn)throw new Error('wrong_turn');if(!jackarooHandDead(state,actor))throw new Error('hand_can_move');const s=clone(state),cards=s.hands[actor].splice(0);s.discard.push(...cards);s.played+=cards.length;s.lastEvent={player:actor,card:cards.at(-1),action:{type:'burnAll'},burnt:cards.length};advanceTurn(s,actor);return s}
/** 33.9.2: a burning ten no longer burns a card of its own choosing: the player it hits (with more
    than one card) gets the turn to pick the card that burns ({type:'burnPick'}), and that is their turn. */
export function playJackarooAction(state,cardIndex,action,actor=state.turn){if(state.winnerTeam!==null)return state;if(actor!==state.turn)throw new Error('wrong_turn');const legal=getJackarooActions(state,cardIndex,actor);const sig=JSON.stringify(action);if(!legal.some(a=>JSON.stringify(a)===sig))throw new Error('illegal_jackaroo_action');if(action.type==='burnPick'){const s=clone(state),by=s.burnPick.by,[card]=s.hands[actor].splice(cardIndex,1);s.discard.push(card);s.played++;delete s.burnPick;s.lastEvent={player:actor,card,action:{type:'burnPick'},type:'burnPick',by};advanceTurn(s,actor);return s}const s=previewJackarooAction(state,action,state.hands[actor][cardIndex],actor);if(action.type==='burn'){if(s.hands[action.target].length>1){const [card]=s.hands[actor].splice(cardIndex,1);if(card)s.discard.push(card);s.played++;s.burnPick={target:action.target,by:actor};s.lastEvent.ask=true;s.turn=action.target;return s}const burned=s.hands[action.target].shift();s.discard.push(burned);s.lastEvent.burned=burned;}removeCardAndAdvance(s,actor,cardIndex);return s}

// Shares the exact public piece resolution with play, without consuming cards or dealing.
export function previewJackarooAction(state,action,card='',actor=state.turn){const s=clone(state);let event={player:actor,card,action};if(action.type==='burn'){event.target=action.target;}else if(action.type==='enter'){s.players[action.owner].marbles[action.marble]=0;event.captured=captureAt(s,action.owner,action.marble)}else if(action.type==='move'){event.move=applyMove(s,action.owner,action.marble,action.steps,action.backward,cardRank(event.card)==='K')}else if(action.type==='moveAny5'){event.move=applyMove(s,action.owner,action.marble,5,false,false,jackarooTeam(action.owner)===jackarooTeam(actor))}else if(action.type==='swap'){const a=s.players[action.owner].marbles[action.marble],b=s.players[action.otherOwner].marbles[action.otherMarble],ga=globalJackarooPosition(action.owner,a,s),gb=globalJackarooPosition(action.otherOwner,b,s);s.players[action.owner].marbles[action.marble]=(gb-boardGeometry(s).starts[action.owner]+boardGeometry(s).track)%boardGeometry(s).track;s.players[action.otherOwner].marbles[action.otherMarble]=(ga-boardGeometry(s).starts[action.otherOwner]+boardGeometry(s).track)%boardGeometry(s).track;event.swap=[ga,gb]}else if(action.type==='split7'){event.first=applyMove(s,action.owner,action.first.marble,action.first.steps,false,false);event.second=applyMove(s,action.owner,action.second.marble,action.second.steps,false,false)}event.type=action.type;s.lastEvent=event;return s;}
