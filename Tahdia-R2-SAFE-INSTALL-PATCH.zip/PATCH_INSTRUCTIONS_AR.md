# تركيب تحديث 26.0.0

1. خذ نسخة احتياطية من مستودعك.
2. ارفع ملف Tahdia-v26.0.0-R2-INSTALL-FIX-PATCH.zip كما هو إلى جذر المستودع، بجانب .github ومجلد tahadi-alabaqera-online-pro-fixed. لا ترفعه داخل مجلد المشروع ولا تفك ضغطه يدويًا.
3. لا ترفع معه ZIP آخر. شغّل Auto Update Game إذا لم يبدأ تلقائيًا، وانتظر نجاح خطوات التطبيق والفحص والنشر.
4. عند نجاح رفع الموقع بواسطة طريقة نشرك الحالية، أغلق صفحات اللعبة القديمة وافتح الموقع من جديد. هذا الملف لا ينشر Cloudflare من داخل المحادثة.
5. النسخ المدعومة هي 25.0.0 المطابقة لأرشيفك، و25.1.0 و25.2.0 السابقان، وإعادة التثبيت فوق 26.0.0 نفسه. رقم الإصدار وحده غير كافٍ؛ تُراجع بصمة كل ملف.
6. إذا ظهرت File changed outside the supported releases فلا تغيّر رقم الإصدار ولا تعطّل فحص البصمات. توقّف وأرسل نسخة المصدر الأحدث للدمج. الرفض يمنع مسح تعديلاتك، ولا يستبدل أي ملف قبل اكتمال التحقق.

يشمل الإصدار ترتيب الواجهة والمتجر وأدلة الألعاب وإصلاح اتصال سودوكو وتحكم الحلبة وكرات الطاقة، وأربع حلبات وثعبان المدير الحصري. يشمل الباتش التراكمي إصلاحات 25.1.0 و25.2.0 أيضًا. لا يحذف ألعابًا أو مقتنيات أو مكافآت ولا يستبدل إعدادات Worker أو ملفات GitHub أو CSS سودوكو المخصص. تفاصيل الإصدار وحدود الاختبار مرفقة أدناه في هذا الملف.


## تصحيح التثبيت R2

هذه الحزمة تضم تطوير v26 السابق كاملًا. كل ملفات كود اللعبة والأصول داخلها مطابقة بايتًا لباتش v26 السابق؛ لم يُحذف أي تطوير.

يحفظ الباتش ملفات ملاحظات الإصدارات الموجودة عندك كما هي، حتى إذا تغير نصها أو تنسيق أسطرها أو كانت مفقودة. لا يستبدل SHA256SUMS.txt القديم؛ سير GitHub الأصلي يعيد توليده بعد فحص الإصدار ثم يتحقق منه. تبقى بصمات ملفات التطبيق داخل patch-manifest.json مطابقة وفحصها إلزاميًا قبل أي استبدال.

ارفع هذه الحزمة وحدها بدل ZIP تحديث v26 السابق، ولا تغير package.json أو ملفات اللعبة يدويًا. إذا ظهر تعارض لاحق في ملف كود فعلي، يلزم دمج المصدر الأحدث؛ لا تتجاوز فحصه.

## تفاصيل تطوير v26

# تحديث 26.0.0

هذا إصدار تراكمي فوق ملفات 25.0.0 و25.1.0 و25.2.0 المطابقة للنسخ المرجعية. لا ينشر الموقع تلقائيًا من المحادثة.

## الواجهة واللعب

- نظام ألوان كحلي ونعناعي، نصوص أوضح، بطاقات ألعاب ومتجر مرتبة، وزر متابعة آخر لعبة في مكان ظاهر.
- شريط اللعبة يضم الرجوع، دعوة صديق، وقواعد مختصرة. أضيف دليل متاح بلوحة المفاتيح إلى صفحات الألعاب السبع عشرة، مع استعادة التركيز عند إغلاقه.
- حافظ الإصدار على دعوات الأصدقاء وتأثيرات الصح والغلط والتقدم واحتفال الفائز الموجودة في التحديثات السابقة. إصلاح تحميل خدمة الدعوات يتيح المحاولة مجددًا بعد فشل التحميل.
- إصلاح تجاوز قائمة مراحل سودوكو عرض الشاشة الصغيرة دون تغيير قياسات شبكة الأرقام أو ملفات CSS سودوكو المخصصة.
- حماية دخول غرف سودوكو من الضغط المتكرر والاستجابات المتأخرة؛ مهلة لطلبات HTTP ولتأكيد WebSocket، ومراقبة اتصال خامل وإعادة اتصال. لا تمسح اللقطة القديمة إدخالًا أحدث.
- تظل خمس أخطاء أونلاين سببًا للاستبعاد وفق قرار السيرفر. لا ينقل الإصدار سلطة النتيجة أو العملات إلى العميل.
- إدخال رمز توصيل الأرقام يقبل الأرقام العربية والفارسية ومفتاح Enter، مع منع تكرار الانضمام أثناء الطلب.

## حلبة الثعابين

- أرضية جديدة وأكل على شكل كرات طاقة مضيئة مخزنة رسوميًا مرة واحدة؛ تظل الفواكه والكنوز خيارًا يمكن اختياره وحفظه.
- تحكم لمس بحساسية هادئة أو متوازنة أو سريعة، مع حفظ التفضيلات. تجاهل زر الماوس الأيمن وإصلاح بدء اللعب محليًا في المتصفحات التي لا توفر randomUUID.
- أربع حلبات: المفاعل، بحيرة الشفق، قلب البركان، وقصر الهيبة. لكل حلبة تفاصيل أرضية، ألوان، جسيمات محيطة، واسم ونمط ظهور كنز مختلف. توقيت الكنز وعدد قطعه وقيمته متساوية.
- المضيف يختار الحلبة الخاصة قبل الجولة. تغييرها يلغي الجاهزية ويصل للجميع. السيرفر يختار حلبة المواجهة السريعة، ويحفظ الاختيار في اللقطات وإعادة الاتصال.
- «الهيبة الملكي» حصري لحساب المدير bosrag: درع كحلي وذهبي، رأس وتاج مرسومان، وحجم رسومي أكبر 12%. يتجهز عند وصوله للحساب أول مرة، ويمكن للمدير تبديله لاحقًا من مقتنياته. لا تزيد كتلته أو سرعته أو مدى اصطدامه بسبب الإطلالة.
- تأكدت اختبارات الشراء والتجهيز ومنح المقتنيات من منع نقل الإطلالة الحصرية إلى حساب عادي. الهوية تعتمد الحساب الموثق في السيرفر.
- تظل قواعد الرأس وأول أربع قطع، نهاية الذيل القاتلة، والدروبات الدفاعية والسرعة والمغناطيس كما هي.
- الجسيمات محدودة بـ24 في المنظور، وتتوقف في وضع الأداء السريع أو عند طلب تقليل الحركة. تبقى معالجة أجسام الثعابين الطويلة المحدودة والرسم المستمر الموجودة مسبقًا.

## حدود هذا الإصدار والتركيب

هذه تحسينات محددة فوق المشروع الحالي؛ لا يستبدل الإصدار محركات جميع الألعاب ولا يشكل نظامًا جديدًا لتوليد الصور بالذكاء الاصطناعي. ميزات الصورة والمراحل واللعب الموجودة تبقى ضمن المشروع.

الباتش أقل من 25 ميغابايت ويحتوي الملفات المتغيرة فقط. لا يشمل wrangler.jsonc أو .github أو ملفي public/assets/css/app-sudoku.css وpublic/assets/css/sudoku-v22.css. يفحص مثبت GitHub الأصلي بصمة الملفات قبل الاستبدال ويرفض التعارض كاملًا. لا تغيّر رقم الإصدار أو تتجاوز الحماية عند الرفض؛ يجب دمج نسخة المصدر الأحدث.

فحص الجوال هنا تم داخل إطارات متصفح بعرضي 320 و390 بكسل، وليس على جهاز iPhone فعلي. اختبارات workerd تشغّل سيرفرًا محليًا بقاعدة SQLite واتصالات WebSocket حقيقية؛ لا تقيس شبكة الجوال الإنتاجية.


SAFE compatibility patch for the supplied current repository. Existing differing files are preserved byte-for-byte. This does NOT merge R2 improvements into those conflicting files. Only identical or missing files are installed.
Preserved conflicting files: 80
package-lock.json
package.json
public/accuracy.html
public/assets/css/play-experience-v25.css
public/assets/css/tahdia-premium-v25.css
public/assets/js/arcade-games.js
public/assets/js/arena-art-v23.js
public/assets/js/arena-gestures.js
public/assets/js/cosmetic-art.js
public/assets/js/engines/serpent-engine.js
public/assets/js/journey-ui.js
public/assets/js/paths-online-v24.js
public/assets/js/picture-ui.js
public/assets/js/play-feedback-v24-1.js
public/assets/js/profile-core.js
public/assets/js/serpent-art-v16.js
public/assets/js/serpent-renderer.js
public/assets/js/serpent-ui.js
public/assets/js/shop.js
public/assets/js/social-client.js
public/assets/js/sudoku-online.js
public/assets/js/sudoku-ui.js
public/assets/js/tahdia-premium-v25.js
public/dice.html
public/index.html
public/jackaroo.html
public/journey.html
public/local.html
public/logic.html
public/memory.html
public/online.html
public/paths-online.html
public/picture.html
public/puzzle.html
public/quiz.html
public/reaction.html
public/serpent.html
public/service-worker.js
public/shop.html
public/snakes.html
public/social.html
public/sudoku.html
public/v5.html
public/zahra.html
scripts/apply-premium.mjs
scripts/build-offline.mjs
scripts/build-styles.mjs
scripts/dev-preview.mjs
scripts/verify-serpent-v23-runtime.mjs
scripts/verify-v7.mjs
src/index.js
src/serpent/serpent-room.js
src/social/account-policy.js
src/social/social-api.js
src/social/social-core.js
src/social/social-user.js
test/design-refresh.test.js
test/interface-v25-1.test.js
test/luxury-game-ui.test.js
test/mobile-board-ui.test.js
test/paths-ui-v24.test.js
test/premium-v25.test.js
test/quick-match-firestore.test.js
test/quiz-memory-premium.test.js
test/quiz-pro.test.js
test/release-3.2-redesign.test.js
test/release-generated-assets-v24.test.js
test/release-v25-cache-contract.test.js
test/serpent-mobile-hotfix.test.js
test/serpent-room.test.js
test/serpent-route.test.js
test/serpent-ui.test.js
test/snakes-premium-ui.test.js
test/store-admin-api.test.js
test/store-ui-runtime.test.js
test/sudoku-online-ui-v22.test.js
test/v14-game-lifecycle.test.js
test/v14-home-navigation.test.js
test/v16-serpent-art.test.js
test/v16-store-studio.test.js
