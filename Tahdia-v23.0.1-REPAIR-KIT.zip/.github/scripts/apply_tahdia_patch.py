#!/usr/bin/env python3
"""Safely apply an integrity-checked Tahdia sparse ZIP patch to the existing repo.

This is intended to be run inside a GitHub Actions checkout, not against an arbitrary
untrusted filesystem. It never creates a fresh project; it edits only manifest paths.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import sys
import tempfile
import zipfile

ARCHIVE_RE = re.compile(r"Tahdia-Professional-v(\d+)\.(\d+)\.(\d+)-PATCH\.zip\Z")
HEX_RE = re.compile(r"[0-9a-f]{64}\Z")
EXPECTED_FORMAT = "busraj-sparse-patch-v1"
EXPECTED_REPO = "tahadi-alabaqera-online-pro-fixed"
MAX_PAYLOAD_FILES = 1000
MAX_UNPACKED_BYTES = 200 * 1024 * 1024


class InstallError(Exception):
    pass


def require(condition: bool, reason: str):
    if not condition:
        raise InstallError(reason)


def relative_safe(name: str) -> Path:
    # Package paths are POSIX paths; reject traversal, absolute, drive, and odd separators.
    require(bool(name) and '\\' not in name and '\x00' not in name, f"Unsafe filename: {name!r}")
    p = PurePosixPath(name)
    require(not p.is_absolute() and all(x not in ('.', '..', '') for x in name.split('/')),
            f"Unsafe filename: {name!r}")
    require(not (p.parts and ':' in p.parts[0]), f"Unsafe filename: {name!r}")
    return Path(*p.parts)


def digest(blob: bytes) -> str:
    return hashlib.sha256(blob).hexdigest()


def root_candidates(repo: Path) -> list[Path]:
    # Project can be at repo root or under a project directory in older versions.
    candidates = [repo, repo/'game', repo/'app', repo/'game-patch', repo/'tahdia', repo/'web']
    for child in repo.iterdir():
        if child.is_dir() and not child.name.startswith('.') and child not in candidates:
            candidates.append(child)
    # Require both paths: a sparse package can never bootstrap a fresh app.
    return [c for c in candidates if (c/'package.json').is_file() and (c/'public'/'index.html').is_file()]


def resolve_root(repo: Path, requested: str) -> Path:
    if requested:
        root = (repo / relative_safe(requested)).resolve()
        require(root == repo or repo in root.parents, "Project folder is outside repository")
        require((root/'package.json').is_file() and (root/'public'/'index.html').is_file(),
                f"Not an existing game project: {root}")
        return root
    hits = root_candidates(repo)
    require(bool(hits), "No installed game found. Expected package.json AND public/index.html. "
                        "A sparse PATCH cannot install a project from scratch.")
    require(len(hits) == 1, "Multiple game folders: " + ', '.join(str(p.relative_to(repo)) for p in hits)
            + ". Pass --project-dir explicitly.")
    return hits[0].resolve()


def find_zip(repo: Path, chosen: str) -> Path | None:
    if chosen:
        rel = relative_safe(chosen)
        require(len(rel.parts) == 1, "ZIP must be at repository root")
        path = repo / rel
        require(path.is_file(), f"Patch not found: {path.name}")
        require(ARCHIVE_RE.fullmatch(path.name) is not None, "Unexpected ZIP name")
        return path
    zips = [(tuple(int(x) for x in m.groups()), file)
            for file in repo.glob('Tahdia-Professional-v*-PATCH.zip')
            if (m := ARCHIVE_RE.fullmatch(file.name)) and file.is_file()]
    if not zips:
        return None
    return max(zips, key=lambda item: item[0])[1]


def stage_patch(archive: Path, root: Path, repo: Path) -> list[str]:
    require(archive.is_file(), "Patch archive not found")
    with zipfile.ZipFile(archive) as z:
        require(z.testzip() is None, "Corrupted ZIP entry detected")
        require('patch-manifest.json' in z.namelist(), "Missing patch-manifest.json")
        manifest = json.loads(z.read('patch-manifest.json'))
        require(manifest.get('format') == EXPECTED_FORMAT, "Unsupported patch format")
        require(manifest.get('target') == EXPECTED_REPO, "Patch targets a different project")
        v = manifest.get('version')
        require(isinstance(v, str) and re.fullmatch(r'\d+\.\d+\.\d+', v), "Invalid patch version")
        require(archive.name == f'Tahdia-Professional-v{v}-PATCH.zip', "ZIP filename/version disagree")
        files = manifest.get('files')
        require(isinstance(files, list) and 0 < len(files) <= MAX_PAYLOAD_FILES, "Invalid file count")
        require(sum(f.file_size for f in z.infolist()) <= MAX_UNPACKED_BYTES, "Patch exceeds size limit")
        required_names = {'patch-manifest.json','PATCH_INSTRUCTIONS_AR.md'} | {
            'game-patch/' + item['path'] for item in files if isinstance(item, dict) and isinstance(item.get('path'), str)
        }
        actual_names = set(z.namelist())
        require(len(actual_names) == len(z.namelist()), "Duplicate ZIP filenames")
        require(actual_names == required_names, "Unexpected/missing archive entries: "
                + ', '.join(sorted(actual_names.symmetric_difference(required_names))[:8]))

        staged: list[tuple[Path, bytes]] = []
        unchanged = 0
        seen = set()
        for item in files:
            require(isinstance(item, dict), "Malformed manifest entry")
            name = item.get('path', '')
            require(isinstance(name, str), "Missing manifest path")
            rel = relative_safe(name)
            require(rel.as_posix() not in seen, f"Duplicate manifest path: {name}")
            seen.add(rel.as_posix())
            require(rel.parts[0] not in ('.github','.git'), f"Protected path: {name}")
            target = root / rel
            require(root == target.resolve() or root in target.resolve().parents, f"Path escapes project root: {name}")
            require(not target.is_dir(), f"Expected file, found directory: {name}")
            data = z.read('game-patch/' + name)
            required_sha = item.get('sha256')
            require(isinstance(required_sha, str) and HEX_RE.fullmatch(required_sha) is not None,
                    f"Invalid SHA256 entry: {name}")
            require(len(data) == item.get('size_bytes') and digest(data) == required_sha,
                    f"Corrupted payload: {name}")
            previous = item.get('previous_sha256', [])
            require(isinstance(previous, list), f"Invalid previous_sha256: {name}")
            if target.exists():
                require(target.is_file() and not target.is_symlink(), f"Unsafe existing file: {name}")
                have = digest(target.read_bytes())
                if have == required_sha:
                    unchanged += 1
                    continue
                require(have in previous, f"Existing file differs from supported versions: {name} "
                        f"(actual SHA256 {have}). Update aborted with no files changed.")
            else:
                require(None in previous, f"Missing baseline file that is required: {name}")
            staged.append((target, data))

    # All checks have passed. No partial updates on failed preflight.
    for target, data in staged:
        target.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=target.parent, prefix='.tahdia-', delete=False) as tmp:
            tmp.write(data)
            tmp_path = Path(tmp.name)
        try:
            if target.exists():
                tmp_path.chmod(target.stat().st_mode & 0o777)
            os.replace(tmp_path, target)
        finally:
            tmp_path.unlink(missing_ok=True)
    rels = [str(t.relative_to(repo)) for t, _ in staged]
    print(f"Verified {len(files)} payload files; updated {len(staged)}; unchanged {unchanged}; version {v}")
    for p in rels:
        print('UPDATED:', p)
    return rels


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--project-dir', default='')
    parser.add_argument('--zip', default='')
    parser.add_argument('--paths-output', type=Path, default=None)
    args = parser.parse_args()
    repo = args.repo.resolve()
    require((repo/'.git').exists(), "Run in the existing Git repository (not a new folder)")
    archive = find_zip(repo, args.zip)
    if archive is None:
        print('No patch ZIP in repository root; nothing to apply.')
        if args.paths_output:
            args.paths_output.write_text('', encoding='utf-8')
        return
    root = resolve_root(repo, args.project_dir)
    print('Existing project root:', root.relative_to(repo) or '.')
    print('Using patch archive:', archive.name)
    changes = stage_patch(archive, root, repo)
    if args.paths_output:
        args.paths_output.write_text(''.join(p + '\n' for p in changes), encoding='utf-8')


if __name__ == '__main__':
    try:
        main()
    except (InstallError, ValueError, KeyError, zipfile.BadZipFile) as err:
        print('PATCH INSTALL ERROR:', err, file=sys.stderr)
        sys.exit(1)
