/* Tahdia 33.9.0 — بلياردو (8-ball pool): the page.
   The table is drawn on a canvas from the same geometry the physics uses (pool-engine.js): walnut
   rails with brass sights, cloth under a lamp, leather pockets, and balls that roll — their numbers
   and stripes turn with the distance they travel. A shot is simulated once and played back at
   60 frames a second with its sounds; online, the server's shot replays here to the same end.
   Three ways to play: online (a person, or a computer player when nobody comes), against the
   computer, and two players on one phone. */
import { POOL, POCKETS, SHAPE, HEAD_X, FOOT, simulate, createPoolGame, playPoolShot, choosePoolShot, aimGuide, canPlace, nearestPlace, legalTargets, onEight, remaining, groupOf, GROUP_NAME } from '../engines/pool-engine.js?v=33.9.12-quality1';
import { createTable } from '../board-table-v33.js?v=33.11.4';

const { L, W, R } = POOL;
const RAIL = 9, CUSHION = 4;
const $ = (s) => document.querySelector(s);
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const reduced = () => matchMedia('(prefers-reduced-motion: reduce)').matches;
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const BALL = { 1: '#f4c21b', 2: '#1e4fd6', 3: '#d9262d', 4: '#5b2a8e', 5: '#f2791a', 6: '#13884a', 7: '#7d1f24', 8: '#141414' };
const colorOf = (n) => BALL[n > 8 ? n - 8 : n] || '#f7f4ec';
const SOLIDS = [1, 2, 3, 4, 5, 6, 7], STRIPES = [9, 10, 11, 12, 13, 14, 15];

/* ---------- sound: synthesised, so every click and drop is light and instant ---------- */
const Sound = (() => {
  let ctx = null, noise = null;
  const settings = () => window.BS_AUDIO?.getSettings?.() || { muted: false, effects: true, volume: 0.72 };
  const on = () => { const s = settings(); return !s.muted && s.effects !== false; };
  function ac() {
    if (!ctx) {
      const C = window.AudioContext || window.webkitAudioContext; if (!C) return null;
      try { ctx = new C(); } catch { return null; }
      const len = Math.floor(ctx.sampleRate * 0.6); noise = ctx.createBuffer(1, len, ctx.sampleRate);
      const d = noise.getChannelData(0); for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    return ctx;
  }
  function burst(freq, q, dur, gain, type = 'bandpass', delay = 0) {
    const c = ac(); if (!c) return;
    const t = c.currentTime + delay, src = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    src.buffer = noise; f.type = type; f.frequency.value = freq; f.Q.value = q;
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(Math.max(0.0002, gain * settings().volume), t + 0.004); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f).connect(g).connect(c.destination); src.start(t, Math.random() * 0.3); src.stop(t + dur + 0.02);
  }
  function ping(freq, dur, gain, delay = 0, end = null) {
    const c = ac(); if (!c) return;
    const t = c.currentTime + delay, o = c.createOscillator(), g = c.createGain();
    o.type = 'sine'; o.frequency.setValueAtTime(freq, t); if (end) o.frequency.exponentialRampToValueAtTime(end, t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(Math.max(0.0002, gain * settings().volume), t + 0.003); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(c.destination); o.start(t); o.stop(t + dur + 0.02);
  }
  return {
    unlock: () => { if (on()) ac(); },
    ball(speed) { if (!on()) return; const v = Math.min(1, speed / 420); burst(3300 + v * 900, 3, 0.05, 0.06 + v * 0.55); ping(1850 + v * 500, 0.04, 0.03 + v * 0.16); },
    rail(speed) { if (!on()) return; const v = Math.min(1, speed / 450); burst(380, 0.9, 0.11, 0.05 + v * 0.42, 'lowpass'); ping(120, 0.09, 0.03 + v * 0.12, 0, 80); },
    pocket() { if (!on()) return; ping(170, 0.2, 0.42, 0, 70); burst(700, 0.8, 0.12, 0.3, 'lowpass'); burst(260, 0.7, 0.4, 0.12, 'lowpass', 0.09); },
    cue(power) { window.dispatchEvent(new Event('bs-table-strike')); if (!on()) return; burst(1600, 1.2, 0.06, 0.18 + power * 0.42); ping(980, 0.035, 0.08 + power * 0.1); },
    foul() { if (!on()) return; ping(240, 0.2, 0.16, 0, 170); ping(180, 0.26, 0.14, 0.14, 120); },
    good() { if (!on()) return; ping(660, 0.1, 0.12); ping(990, 0.14, 0.1, 0.08); },
    win() { if (!on()) return; [523, 659, 784, 1046].forEach((f, i) => ping(f, 0.22, 0.13, i * 0.11)); },
  };
})();

/* ---------- 3D roll of each ball: an orientation (three axes) turned by the distance it rolls ---------- */
function freshAxes(rng = Math.random) {
  const a = rng() * Math.PI * 2, c = Math.cos(a), s = Math.sin(a);
  return { x: [c, s, 0], y: [-s, c, 0], z: [0, 0, 1], n: 0 };
}
function rollAxes(o, dx, dy) {
  const d = Math.sqrt(dx * dx + dy * dy); if (d < 1e-6) return;
  const ux = -dy / d, uy = dx / d, th = d / R, c = Math.cos(th), s = Math.sin(th);
  for (const v of [o.x, o.y, o.z]) {
    // Rodrigues about (ux, uy, 0)
    const cx = uy * v[2], cy = -ux * v[2], cz = ux * v[1] - uy * v[0], dot = ux * v[0] + uy * v[1];
    const nx = v[0] * c + cx * s + ux * dot * (1 - c), ny = v[1] * c + cy * s + uy * dot * (1 - c), nz = v[2] * c + cz * s;
    v[0] = nx; v[1] = ny; v[2] = nz;
  }
  if (++o.n % 24 === 0) {
    const n = (v) => { const l = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]) || 1; v[0] /= l; v[1] /= l; v[2] /= l; };
    n(o.x); const d1 = o.x[0] * o.z[0] + o.x[1] * o.z[1] + o.x[2] * o.z[2]; for (let i = 0; i < 3; i++) o.z[i] -= d1 * o.x[i]; n(o.z);
    o.y[0] = o.z[1] * o.x[2] - o.z[2] * o.x[1]; o.y[1] = o.z[2] * o.x[0] - o.z[0] * o.x[2]; o.y[2] = o.z[0] * o.x[1] - o.z[1] * o.x[0];
  }
}

/* ---------- the table view ---------- */
function roundRect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
class TableView {
  constructor(canvas) {
    this.canvas = canvas; this.g = canvas.getContext('2d'); this.table = document.createElement('canvas');
    this.balls = Array(16).fill(null); this.axes = new Map(); this.sinking = []; this.flash = []; this.previous = new Map();
    this.s = 1; this.dpr = 1; this.vertical = false; this.m = [1, 0, 0, 1, 0, 0];
  }
  fit(cssW, cssH, vertical, { focus = null, flip = false } = {}) {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    this.dpr = dpr; this.vertical = vertical; this.cssW = cssW; this.cssH = cssH;
    this.canvas.width = Math.max(2, Math.round(cssW * dpr)); this.canvas.height = Math.max(2, Math.round(cssH * dpr));
    // the part of the table to show (the whole table with its rails unless a cover asks for a close-up)
    const [fx0, fy0, fx1, fy1] = focus || [-RAIL - 4, -RAIL - 4, L + RAIL + 4, W + RAIL + 6], fw = fx1 - fx0, fh = fy1 - fy0;
    const sx = vertical ? fh : fw, sy = vertical ? fw : fh;
    const s = focus ? Math.max(this.canvas.width / sx, this.canvas.height / sy) : Math.min(this.canvas.width / sx, this.canvas.height / sy);
    this.s = s;
    const cx = (fx0 + fx1) / 2, cy = (fy0 + fy1) / 2;
    // the focus centre lands in the middle of the canvas
    this.flip = !vertical && flip;
    this.m = vertical ? [0, -s, s, 0, this.canvas.width / 2 - cy * s, this.canvas.height / 2 + cx * s] : this.flip ? [-s, 0, 0, -s, this.canvas.width / 2 + cx * s, this.canvas.height / 2 + cy * s] : [s, 0, 0, s, this.canvas.width / 2 - cx * s, this.canvas.height / 2 - cy * s];
    this.prerender();
  }
  toScreen(x, y) { const m = this.m; return [m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]]; }
  toWorld(px, py) { const m = this.m, s = this.s; return this.vertical ? [(m[5] - py) / s, (px - m[4]) / s] : this.flip ? [(m[4] - px) / s, (m[5] - py) / s] : [(px - m[4]) / s, (py - m[5]) / s]; }
  screenDir(vx, vy) { return this.vertical ? [vy, -vx] : this.flip ? [-vx, -vy] : [vx, vy]; }
  px(n) { return (n * this.dpr) / this.s; } // n css pixels in table centimetres
  axesOf(n) { if (!this.axes.has(n)) this.axes.set(n, freshAxes()); return this.axes.get(n); }

  prerender() {
    const c = this.table; c.width = this.canvas.width; c.height = this.canvas.height;
    const g = c.getContext('2d'); g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, c.width, c.height);
    const roomLight=g.createRadialGradient(c.width*.5,c.height*.4,0,c.width*.5,c.height*.5,Math.max(c.width,c.height)*.8);
    roomLight.addColorStop(0,'#24352e');roomLight.addColorStop(.7,'#101c1e');roomLight.addColorStop(1,'#070f14');g.fillStyle=roomLight;g.fillRect(0,0,c.width,c.height);
    g.save();g.translate(c.width/2,c.height/2);g.rotate(-.35);g.strokeStyle='#9c95770c';g.lineWidth=1;
    for(let x=-c.width;x<c.width;x+=34*this.dpr){g.beginPath();g.moveTo(x,-c.height);g.lineTo(x,c.height);g.stroke();}g.restore();
    for(const [drop,color]of[[8,'#070d12'],[5,'#15252a'],[2.7,'#ac9669']]){g.save();g.translate(0,drop*this.dpr);g.transform(...this.m);roundRect(g,-RAIL,-RAIL,L+2*RAIL,W+2*RAIL,7);g.fillStyle=color;g.fill();g.restore();}
    g.setTransform(...this.m);
    // the table's shadow on the floor
    g.save(); g.shadowColor = 'rgba(0,0,0,.65)'; g.shadowBlur = 34 * this.dpr; g.shadowOffsetY = 14 * this.dpr;
    roundRect(g, -RAIL, -RAIL, L + 2 * RAIL, W + 2 * RAIL, 7); g.fillStyle = '#3a1d0e'; g.fill(); g.restore();
    // walnut rails
    const wood = g.createLinearGradient(0, -RAIL, 0, W + RAIL);
    wood.addColorStop(0, '#526158'); wood.addColorStop(0.08, '#273c37'); wood.addColorStop(0.5, '#122b2a'); wood.addColorStop(0.92, '#273c37'); wood.addColorStop(1, '#526158');
    roundRect(g, -RAIL, -RAIL, L + 2 * RAIL, W + 2 * RAIL, 7); g.fillStyle = wood; g.fill();
    // grain
    g.save(); roundRect(g, -RAIL, -RAIL, L + 2 * RAIL, W + 2 * RAIL, 7); g.clip();
    let seed = 11; const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
    g.lineWidth = 0.18;
    for (let i = 0; i < 70; i++) {
      const horizontal = i % 2 === 0, off = rnd() * (RAIL - CUSHION - 1) + CUSHION + 0.5, far = rnd() < 0.5;
      g.strokeStyle = `rgba(${rnd() < 0.5 ? '255,214,170' : '20,8,2'},${0.05 + rnd() * 0.08})`;
      g.beginPath();
      if (horizontal) { const y = far ? W + off : -off; g.moveTo(-RAIL, y); for (let x = -RAIL; x <= L + RAIL; x += 12) g.lineTo(x, y + Math.sin(x * 0.05 + i) * 0.35); }
      else { const x = far ? L + off : -off; g.moveTo(x, -RAIL); for (let y = -RAIL; y <= W + RAIL; y += 10) g.lineTo(x + Math.sin(y * 0.07 + i) * 0.3, y); }
      g.stroke();
    }
    g.restore();
    // Cabinet joinery and two fine inlaid lines keep the rails substantial.
    for (const inset of [1.4, 2.0]) {
      roundRect(g,-RAIL+inset,-RAIL+inset,L+2*RAIL-2*inset,W+2*RAIL-2*inset,6-inset*.3);
      g.lineWidth=.16;g.strokeStyle=inset===1.4?'#d7bd8966':'#130e09aa';g.stroke();
    }
    const joints=[[-RAIL,-RAIL,-CUSHION,-CUSHION],[L+RAIL,-RAIL,L+CUSHION,-CUSHION],[-RAIL,W+RAIL,-CUSHION,W+CUSHION],[L+RAIL,W+RAIL,L+CUSHION,W+CUSHION]];
    for(const [x,y,xx,yy] of joints){g.beginPath();g.moveTo(x,y);g.lineTo(xx,yy);g.lineWidth=.25;g.strokeStyle='#120d0aaa';g.stroke();}
    // bevels
    g.lineWidth = this.px(1.2); g.strokeStyle = 'rgba(255,220,180,.28)'; roundRect(g, -RAIL + 0.6, -RAIL + 0.6, L + 2 * RAIL - 1.2, W + 2 * RAIL - 1.2, 6.4); g.stroke();
    g.strokeStyle = 'rgba(0,0,0,.45)'; g.strokeRect(-CUSHION - 0.4, -CUSHION - 0.4, L + 2 * CUSHION + 0.8, W + 2 * CUSHION + 0.8);
    // cloth on the cushions, then the bed under the lamp
    g.fillStyle = '#103e38'; g.fillRect(-CUSHION, -CUSHION, L + 2 * CUSHION, W + 2 * CUSHION);
    const bed = g.createRadialGradient(L / 2, W / 2, 6, L / 2, W / 2, L * 0.62);
    bed.addColorStop(0, '#3b8a70'); bed.addColorStop(0.5, '#206c59'); bed.addColorStop(1, '#0f3e38');
    g.fillStyle = bed; g.fillRect(0, 0, L, W);
    // 33.9.6: two lamps over the bed, and the edges falling into shade
    for (const lx of [L * 0.3, L * 0.7]) { const lamp = g.createRadialGradient(lx, W * .44, 2, lx, W * .44, W * .75); lamp.addColorStop(0, 'rgba(249,231,189,.15)'); lamp.addColorStop(1, 'rgba(226,244,239,0)'); g.fillStyle = lamp; g.fillRect(0, 0, L, W); }
    const shade = g.createLinearGradient(0, 0, 0, W); shade.addColorStop(0, 'rgba(0,0,0,.22)'); shade.addColorStop(0.12, 'rgba(0,0,0,0)'); shade.addColorStop(0.88, 'rgba(0,0,0,0)'); shade.addColorStop(1, 'rgba(0,0,0,.22)');
    g.fillStyle = shade; g.fillRect(0, 0, L, W);
    // the cushion noses: a lighter edge along each, angled into the pockets
    const { corner: CM, side: SM, jaw: J, sideJaw: [SJx, SJy] } = SHAPE, mid = L / 2, d = CUSHION, sx = (SJx * d) / SJy;
    const cush = [
      [[CM, 0], [mid - SM, 0], [mid - SM + sx, -d], [CM - d, -d]], [[mid + SM, 0], [L - CM, 0], [L - CM + d, -d], [mid + SM - sx, -d]],
      [[CM, W], [mid - SM, W], [mid - SM + sx, W + d], [CM - d, W + d]], [[mid + SM, W], [L - CM, W], [L - CM + d, W + d], [mid + SM - sx, W + d]],
      [[0, CM], [0, W - CM], [-d, W - CM + d], [-d, CM - d]], [[L, CM], [L, W - CM], [L + d, W - CM + d], [L + d, CM - d]],
    ];
    for (const poly of cush) {
      g.beginPath(); poly.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y))); g.closePath();
      const cy=poly.reduce((sum,p)=>sum+p[1],0)/poly.length,cx=poly.reduce((sum,p)=>sum+p[0],0)/poly.length;
      const vertical=Math.abs(poly[0][0]-poly[1][0])<.1;
      const bevel=vertical?g.createLinearGradient(cx-CUSHION/2,0,cx+CUSHION/2,0):g.createLinearGradient(0,cy-CUSHION/2,0,cy+CUSHION/2);
      bevel.addColorStop(0,'#123d35');bevel.addColorStop(.35,'#31735b');bevel.addColorStop(.65,'#27644f');bevel.addColorStop(1,'#0e352f');
      g.fillStyle = bevel; g.fill();
      g.beginPath(); g.moveTo(...poly[0]); g.lineTo(...poly[1]); g.lineWidth = this.px(1.4); g.strokeStyle = 'rgba(160,255,210,.16)'; g.stroke();
    }
    // the pockets: a hole under a leather liner, cut into rail and cushion
    const holes = [[-1.7, -1.7, 6.7], [mid, -4.4, 6.0], [L + 1.7, -1.7, 6.7], [-1.7, W + 1.7, 6.7], [mid, W + 4.4, 6.0], [L + 1.7, W + 1.7, 6.7]];
    // the lacquer: a long shine along each rail
    g.save(); roundRect(g, -RAIL, -RAIL, L + 2 * RAIL, W + 2 * RAIL, 7); g.clip();
    for (const [y0, y1] of [[-RAIL + 1.2, -RAIL + 3.2], [W + RAIL - 3.2, W + RAIL - 1.2]]) { const gl = g.createLinearGradient(0, y0, 0, y1); gl.addColorStop(0, 'rgba(255,230,200,0)'); gl.addColorStop(0.5, 'rgba(255,230,200,.22)'); gl.addColorStop(1, 'rgba(255,230,200,0)'); g.fillStyle = gl; g.fillRect(-RAIL, y0, L + 2 * RAIL, y1 - y0); }
    for (const [x0, x1] of [[-RAIL + 1.2, -RAIL + 3.2], [L + RAIL - 3.2, L + RAIL - 1.2]]) { const gl = g.createLinearGradient(x0, 0, x1, 0); gl.addColorStop(0, 'rgba(255,230,200,0)'); gl.addColorStop(0.5, 'rgba(255,230,200,.18)'); gl.addColorStop(1, 'rgba(255,230,200,0)'); g.fillStyle = gl; g.fillRect(x0, -RAIL, x1 - x0, W + 2 * RAIL); }
    g.restore();
    // chrome caps over the corners and the middles, where the pockets cut the rail
    const cap = (x, y, r) => {
      g.save();roundRect(g,-RAIL,-RAIL,L+2*RAIL,W+2*RAIL,7);g.clip();
      if(Math.abs(x-mid)<1){
        const bottom=y>W/2;g.translate(x,bottom?W:0);if(bottom)g.scale(1,-1);
        roundRect(g,-9.3,-RAIL+.7,18.6,RAIL+5.5,3);g.fillStyle='#1d2423';g.fill();g.lineWidth=.25;g.strokeStyle='#8e826944';g.stroke();
        roundRect(g,-8.6,-RAIL+1.6,17.2,RAIL+3.6,2.5);
      }else{
        const right=x>L/2,bottom=y>W/2;g.translate(right?L:0,bottom?W:0);g.scale(right?-1:1,bottom?-1:1);
        g.beginPath();g.moveTo(-RAIL+1,-RAIL+1);g.lineTo(7,-RAIL+1);g.lineTo(7,-3);g.lineTo(-3,7);g.lineTo(-RAIL+1,7);g.closePath();g.fillStyle='#222927';g.fill();g.lineWidth=.3;g.strokeStyle='#9c8c6f55';g.stroke();
        g.beginPath();g.moveTo(-RAIL+2.3,5);g.lineTo(-RAIL+2.3,-RAIL+2.3);g.lineTo(5,-RAIL+2.3);
      }
      g.lineWidth=.16;g.strokeStyle='#b5a48455';g.setLineDash([.45,.5]);g.stroke();g.restore();
    };
    for (const [x, y, r] of holes) cap(x, y, r + 1.65);
    for (const [x, y, r] of holes) {
      g.beginPath(); g.arc(x, y, r + .8, 0, Math.PI * 2); g.fillStyle = '#171b19'; g.fill();
      g.beginPath(); g.arc(x, y, r + .4, 0, Math.PI * 2); g.lineWidth = .55; g.strokeStyle = '#5d594c'; g.stroke();
      const hole = g.createRadialGradient(x, y, 0, x, y, r);
      hole.addColorStop(0, '#010303'); hole.addColorStop(0.75, '#070b0c'); hole.addColorStop(1, '#242a28');
      g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fillStyle = hole; g.fill();
    }
    void J;
    // brass sights on the rails
    const sight = (x, y) => { g.save(); g.translate(x, y); g.rotate(Math.PI / 4); g.fillStyle = '#d7d5c6'; g.shadowColor = 'rgba(0,0,0,.5)'; g.shadowBlur = 1 * this.dpr; g.fillRect(-.70,-.70,1.4,1.4);g.lineWidth=.1;g.strokeStyle='#f5eee0';g.strokeRect(-.70,-.70,1.4,1.4);g.restore(); };
    const rm = CUSHION + (RAIL - CUSHION) / 2;
    for (const k of [1, 2, 3, 5, 6, 7]) { sight((L * k) / 8, -rm); sight((L * k) / 8, W + rm); }
    for (const k of [1, 2, 3]) { sight(-rm, (W * k) / 4); sight(L + rm, (W * k) / 4); }
    // the head string and the spots
    g.strokeStyle = 'rgba(255,255,255,.1)'; g.lineWidth = this.px(1); g.beginPath(); g.moveTo(HEAD_X, 0); g.lineTo(HEAD_X, W); g.stroke();
    for (const [x, y] of [[HEAD_X, W / 2], FOOT]) { g.beginPath(); g.arc(x, y, 0.55, 0, Math.PI * 2); g.fillStyle = 'rgba(255,255,255,.4)'; g.fill(); }
    // cloth weave
    g.setTransform(1, 0, 0, 1, 0, 0);
    const [ax, ay] = this.toScreen(0, 0), [bx, by] = this.toScreen(L, W), x0 = Math.min(ax, bx), y0 = Math.min(ay, by), w = Math.abs(bx - ax), h = Math.abs(by - ay);
    const tile = document.createElement('canvas'); tile.width = tile.height = 48; const tg = tile.getContext('2d'), img = tg.createImageData(48, 48);
    let fibre=1807;
    for (let i = 0; i < img.data.length; i += 4) { fibre=(Math.imul(fibre,1664525)+1013904223)>>>0;const v=(fibre>>>24);img.data[i]=img.data[i+1]=img.data[i+2]=v;img.data[i+3]=7; }
    tg.putImageData(img, 0, 0);
    g.fillStyle = g.createPattern(tile, 'repeat'); g.fillRect(x0, y0, w, h);
    g.setTransform(...this.m);g.save();g.translate(L*.5,W*.73);if(this.vertical)g.rotate(Math.PI/2);
    g.textAlign='center';g.fillStyle='#eadab122';g.font='600 3.0px Arial,sans-serif';g.fillText('B O S R A J',0,0);g.font='1.35px Arial,sans-serif';g.fillText('T O U R N A M E N T   C L U B',0,3.5);g.restore();
  }

  /* one frame */
  draw({ aim = null, cue = null, placing = null, kitchen = false, guide = true, illegal = false, ghostOnly = false } = {}) {
    const g = this.g; g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, this.canvas.width, this.canvas.height);
    g.drawImage(this.table, 0, 0);
    if (kitchen) {
      g.setTransform(...this.m); g.fillStyle = 'rgba(255,255,255,.05)'; g.fillRect(0, 0, HEAD_X, W);
      g.strokeStyle = 'rgba(255,240,200,.45)'; g.lineWidth = this.px(1.5); g.setLineDash([this.px(6), this.px(5)]); g.beginPath(); g.moveTo(HEAD_X, 0); g.lineTo(HEAD_X, W); g.stroke(); g.setLineDash([]);
    }
    const now = performance.now();
    // pocket flashes
    g.setTransform(...this.m);
    this.flash = this.flash.filter((f) => now - f.t < 650);
    for (const f of this.flash) { const k = (now - f.t) / 650, p = POCKETS[f.p]; g.beginPath(); g.arc(p.x, p.y, 7 + k * 9, 0, Math.PI * 2); g.strokeStyle = `rgba(246,220,150,${0.75 * (1 - k)})`; g.lineWidth = this.px(3 * (1 - k) + 1); g.stroke(); }
    if (aim && guide && cue) this.drawGuide(aim, cue, illegal, ghostOnly);
    // balls: shadows first, then the balls
    const list = [];
    for (let n = 0; n < 16; n++) { const b = n === 0 && placing ? placing.at : this.balls[n]; if (b) list.push([n, b[0], b[1], 1, 1]); }
    this.sinking = this.sinking.filter((s) => now - s.t < 540);
    for (const s of this.sinking) { const k = Math.min(1, (now - s.t) / 540), p = POCKETS[s.p]; list.push([s.n, s.x + (p.x - s.x) * k, s.y + (p.y - s.y) * k, 1 - 0.72 * k, Math.max(0,1-k*k)]); }
    g.setTransform(1, 0, 0, 1, 0, 0);
    const [cxs, cys] = this.toScreen(L / 2, W / 2);
    for (const [, x, y, sc, al] of list) {
      const [X, Y] = this.toScreen(x, y), r = R * this.s * sc;
      let dx = X - cxs, dy = Y - cys; const dl = Math.sqrt(dx * dx + dy * dy) || 1; dx /= dl; dy /= dl;
      g.globalAlpha = 0.42 * al; g.fillStyle = '#000'; g.beginPath(); g.ellipse(X + dx * r * 0.28, Y + dy * r * 0.28 + r * 0.1, r * 1.05, r * 0.95, 0, 0, Math.PI * 2); g.fill();
    }
    g.globalAlpha = 1;
    // Motion streaks follow recorded displacement rather than predicting a shot.
    for(const [n,x,y]of list){const old=this.previous.get(n),point=this.toScreen(x,y);if(!reduced()&&old&&now-old.t<100&&Math.hypot(x-old.x,y-old.y)>R*.35){const from=this.toScreen(old.x,old.y),gradient=g.createLinearGradient(from[0],from[1],point[0],point[1]);gradient.addColorStop(0,'#ffffff00');gradient.addColorStop(1,n===0?'#fff0c03a':colorOf(n)+'35');g.strokeStyle=gradient;g.lineWidth=R*this.s*1.25;g.lineCap='round';g.beginPath();g.moveTo(from[0],from[1]);g.lineTo(point[0],point[1]);g.stroke();}this.previous.set(n,{x,y,t:now});}
    for (const [n, x, y, sc, al] of list) this.drawBall(n, x, y, sc, al);
    if (placing) this.drawPlacing(placing);
    if (aim && cue && aim.stick !== false) this.drawCue(cue, aim.dir, aim.pull || 0, aim.alpha ?? 1);
    if (this.loupe && aim && guide && cue && !ghostOnly) this.drawLoupe(cue, aim.dir);
  }

  // 33.9.6: while you aim, a round magnifier shows where the cue ball will touch, three times bigger
  drawLoupe(cue, dir) {
    const gd = aimGuide(this.balls, cue, dir), at = gd.kind === 'ball' ? gd.ghost : gd.at; if (!at) return;
    const g = this.g, [X, Y] = this.toScreen(at[0], at[1]), d = this.dpr, size = 64 * d, zoom = 3, src = size / zoom;
    const cw = this.canvas.width, ch = this.canvas.height, cx = cw / 2, cy = Y < ch * 0.35 ? ch - size * 0.62 - 10 * d : size * 0.62 + 6 * d;
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.save(); g.beginPath(); g.arc(cx, cy, size / 2, 0, Math.PI * 2); g.closePath(); g.fillStyle = '#0a2018'; g.fill(); g.clip();
    g.drawImage(this.canvas, X - src / 2, Y - src / 2, src, src, cx - size / 2, cy - size / 2, size, size);
    g.restore();
    g.beginPath(); g.arc(cx, cy, size / 2, 0, Math.PI * 2); g.lineWidth = 3 * d; g.strokeStyle = '#f6dc96'; g.stroke();
    g.beginPath(); g.moveTo(cx - 6 * d, cy); g.lineTo(cx + 6 * d, cy); g.moveTo(cx, cy - 6 * d); g.lineTo(cx, cy + 6 * d); g.lineWidth = 1 * d; g.strokeStyle = 'rgba(255,255,255,.6)'; g.stroke();
  }

  drawBall(n, x, y, scale = 1, alpha = 1) {
    const g = this.g, [X, Y] = this.toScreen(x, y), r = R * this.s * scale, o = this.axesOf(n);
    g.save(); g.globalAlpha = alpha;
    g.beginPath(); g.arc(X, Y, r, 0, Math.PI * 2);
    const stripe = n >= 9, base = n === 0 ? '#f6f3ea' : stripe ? '#f3efe4' : colorOf(n);
    g.fillStyle = base; g.fill(); g.clip();
    const proj = (v) => { const [sx, sy] = this.screenDir(v[0], v[1]); return [X + sx * r, Y + sy * r]; };
    if (stripe) {
      g.strokeStyle = colorOf(n); g.lineWidth = r * 1.1; g.lineCap = 'butt'; g.lineJoin = 'round'; g.beginPath();
      let pen = false;
      for (let k = 0; k <= 36; k++) {
        const a = (k / 36) * Math.PI * 2, c = Math.cos(a), s = Math.sin(a);
        const q = [c * o.x[0] + s * o.z[0], c * o.x[1] + s * o.z[1], c * o.x[2] + s * o.z[2]];
        if (q[2] > -0.25) { const [px, py] = proj(q); if (pen) g.lineTo(px, py); else g.moveTo(px, py); pen = true; } else pen = false;
      }
      g.stroke();
    }
    if (n === 0) {
      for (const sg of [1, -1]) { const p = [o.z[0] * sg, o.z[1] * sg, o.z[2] * sg]; if (p[2] <= 0) continue; const [px, py] = proj(p); g.beginPath(); g.arc(px, py, r * 0.13 * (0.4 + 0.6 * p[2]), 0, Math.PI * 2); g.fillStyle = '#d4313a'; g.fill(); }
    } else {
      // the number, on a white disc, on both sides
      for (const sg of [1, -1]) {
        const p = [o.z[0] * sg, o.z[1] * sg, o.z[2] * sg]; if (p[2] <= 0.04) continue;
        const [px, py] = proj(p), [rx, ry] = this.screenDir(p[0], p[1]), rad = Math.atan2(ry, rx), [ax, ay] = this.screenDir(o.x[0] * sg, o.x[1] * sg);
        g.save(); g.translate(px, py); g.rotate(rad); g.scale(Math.max(0.05, p[2]), 1); g.rotate(-rad);
        g.beginPath(); g.arc(0, 0, r * 0.5, 0, Math.PI * 2); g.fillStyle = '#fbf8ef'; g.fill();
        g.rotate(Math.atan2(ay, ax) + Math.PI / 2);
        g.fillStyle = '#151515'; g.font = `700 ${Math.round(r * (n > 9 ? 0.6 : 0.7))}px Tajawal, system-ui, sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle';
        g.fillText(String(n), 0, r * 0.04);
        g.restore();
      }
    }
    g.restore();
    // the lamp on the ball
    g.save(); g.globalAlpha = alpha;
    const shine = g.createRadialGradient(X - r * 0.34, Y - r * 0.4, r * 0.04, X - r * 0.1, Y - r * 0.12, r * 1.08);
    shine.addColorStop(0, 'rgba(255,255,255,.85)'); shine.addColorStop(0.16, 'rgba(255,255,255,.22)'); shine.addColorStop(0.5, 'rgba(255,255,255,0)'); shine.addColorStop(0.86, 'rgba(0,0,0,.18)'); shine.addColorStop(1, 'rgba(0,0,0,.42)');
    g.beginPath(); g.arc(X, Y, r, 0, Math.PI * 2); g.fillStyle = shine; g.fill();
    g.save();g.beginPath();g.arc(X,Y,r*.98,0,Math.PI*2);g.clip();g.translate(X,Y);g.rotate(-.35);
    for(const [xx,yy,w,h,a]of[[-.5,-.52,.72,.14,.63],[-.36,-.25,.53,.065,.28]]){roundRect(g,xx*r,yy*r,w*r,h*r,h*r*.3);g.fillStyle='rgba(255,252,226,'+a+')';g.fill();}g.restore();
    const bounce=g.createRadialGradient(X+r*.55,Y+r*.65,0,X+r*.55,Y+r*.65,r);bounce.addColorStop(0,'#70d9bc22');bounce.addColorStop(1,'#70d9bc00');g.beginPath();g.arc(X,Y,r,0,Math.PI*2);g.fillStyle=bounce;g.fill();
    // Broad ceiling-light reflections and a small warm bounce give resin depth.
    g.beginPath();g.ellipse(X-r*.25,Y-r*.40,r*.38,r*.14,-.35,0,Math.PI*2);g.fillStyle='rgba(255,255,255,.23)';g.fill();
    g.beginPath();g.arc(X+r*.15,Y+r*.16,r*.70,.22,1.85);g.strokeStyle='rgba(222,211,173,.18)';g.lineWidth=Math.max(.5,r*.10);g.stroke();
    g.restore();
  }

  drawGuide(aim, cue, illegal, ghostOnly) {
    const g = this.g; g.setTransform(...this.m);
    const gd = aimGuide(this.balls, cue, aim.dir), lw = this.px(1.7);
    g.lineCap = 'round'; g.lineWidth = lw;
    const line = (ax, ay, bx, by, alpha, dash = null) => { g.strokeStyle = `rgba(255,255,255,${alpha})`; g.setLineDash(dash || []); g.beginPath(); g.moveTo(ax, ay); g.lineTo(bx, by); g.stroke(); g.setLineDash([]); };
    if (gd.kind === 'ball') {
      const [gx, gy] = gd.ghost;
      if (!ghostOnly) line(cue[0], cue[1], gx, gy, 0.85);
      g.beginPath(); g.arc(gx, gy, R, 0, Math.PI * 2); g.strokeStyle = illegal ? 'rgba(255,110,95,.95)' : 'rgba(255,255,255,.9)'; g.lineWidth = lw; g.stroke();
      if (illegal) { const k = R * 0.55; line(gx - k, gy - k, gx + k, gy + k, 0); g.strokeStyle = 'rgba(255,110,95,.95)'; g.beginPath(); g.moveTo(gx - k, gy - k); g.lineTo(gx + k, gy + k); g.moveTo(gx + k, gy - k); g.lineTo(gx - k, gy + k); g.stroke(); return; }
      if (ghostOnly) return;
      const [ox, oy] = gd.objectDir, [bx, by] = gd.ball, len = 14 + gd.cut * 62;
      line(bx, by, bx + ox * len, by + oy * len, 0.9);
      const [tx, ty] = gd.cueDir, tl = 8 + (1 - gd.cut) * 34;
      if (tx || ty) line(gx, gy, gx + tx * tl, gy + ty * tl, 0.45, [this.px(4), this.px(4)]);
    } else {
      const [x, y] = gd.at;
      if (!ghostOnly) line(cue[0], cue[1], x, y, 0.8);
      g.beginPath(); g.arc(x, y, R, 0, Math.PI * 2); g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = lw; g.stroke();
      if (!ghostOnly) line(x, y, x + gd.bounce[0] * 16, y + gd.bounce[1] * 16, 0.35, [this.px(4), this.px(4)]);
    }
  }

  drawPlacing({ at, ok }) {
    const g = this.g, [X, Y] = this.toScreen(at[0], at[1]), r = R * this.s, t = performance.now() / 1000;
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.beginPath(); g.arc(X, Y, r * (1.75 + Math.sin(t * 4) * 0.12), 0, Math.PI * 2);
    g.strokeStyle = ok ? 'rgba(246,220,150,.95)' : 'rgba(255,100,90,.95)'; g.lineWidth = 2 * this.dpr; g.stroke();
    g.fillStyle = ok ? 'rgba(246,220,150,.95)' : 'rgba(255,100,90,.95)';
    for (let k = 0; k < 4; k++) {
      const a = (k * Math.PI) / 2, ex = X + Math.cos(a) * r * 2.35, ey = Y + Math.sin(a) * r * 2.35, s = r * 0.42;
      g.beginPath(); g.moveTo(ex + Math.cos(a) * s, ey + Math.sin(a) * s); g.lineTo(ex + Math.cos(a + 2.2) * s, ey + Math.sin(a + 2.2) * s); g.lineTo(ex + Math.cos(a - 2.2) * s, ey + Math.sin(a - 2.2) * s); g.closePath(); g.fill();
    }
  }

  drawCue(cue, dir, pull, alpha) {
    const g = this.g; g.setTransform(...this.m); g.globalAlpha = alpha;
    const [dx, dy] = dir, nx = -dy, ny = dx, gap = R + 0.9 + pull;
    const at = (d, w) => { const x = cue[0] - dx * (gap + d), y = cue[1] - dy * (gap + d); return [[x + nx * w, y + ny * w], [x - nx * w, y - ny * w]]; };
    const piece = (d0, d1, w0, w1, colors) => {
      const [a0, b0] = at(d0, w0), [a1, b1] = at(d1, w1);
      const grad = g.createLinearGradient(a0[0], a0[1], b0[0], b0[1]);
      colors.forEach((c, i) => grad.addColorStop(i / (colors.length - 1), c));
      g.beginPath(); g.moveTo(...a0); g.lineTo(...a1); g.lineTo(...b1); g.lineTo(...b0); g.closePath(); g.fillStyle = grad; g.fill();
    };
    // shadow
    g.save(); g.translate(1.6, 2.2); g.globalAlpha = alpha * 0.35;
    const [s0, t0] = at(0, 0.7), [s1, t1] = at(146, 1.5); g.beginPath(); g.moveTo(...s0); g.lineTo(...s1); g.lineTo(...t1); g.lineTo(...t0); g.closePath(); g.fillStyle = '#000'; g.fill(); g.restore();
    g.globalAlpha = alpha;
    const w = (d) => 0.62 + (d / 146) * 0.85;
    // 33.9.10: the cue you equipped in the shop
    const L = window.BS_LOOKS?.cue?.().look || { tip: ['#2c64c9', '#6aa4ff', '#2c64c9'], ferrule: ['#cfc8b6', '#fffdf6', '#cfc8b6'], shaft: ['#b98f55', '#f1d9a8', '#b98f55'], ring: ['#a8822e', '#f7df93', '#a8822e'], butt: ['#120a06', '#5a2f18', '#120a06'], end: ['#0b0705', '#2b170c', '#0b0705'] };
    if (L.glow) { g.shadowColor = L.glow; g.shadowBlur = 10 * (this.dpr || 1); }
    piece(0, 0.9, w(0), w(0.9), L.tip);
    piece(0.9, 3.2, w(0.9), w(3.2), L.ferrule);
    piece(3.2, 92, w(3.2), w(92), L.shaft);
    piece(92, 94, w(92), w(94), L.ring);
    piece(94, 128, w(94), w(128), L.butt);
    piece(128, 131, w(128), w(131), L.ring);
    piece(131, 146, w(131), w(146), L.end);
    g.shadowBlur = 0; g.shadowColor = 'transparent';
    g.globalAlpha = 1;
  }
}

/* ---------- the game ---------- */
const view = new TableView($('#biTable'));
const ctl = {
  mode: null, state: null, me: 0, level: 'medium', names: ['', ''], bots: [false, false],
  aim: { dir: [1, 0], spin: [0, 0] }, display: null, place: null, power: 0,
  busy: false, anim: null, shownSeq: 0, lastKey: '', pending: null, receipt: '', rewarded: false, remote: null, endShown: false,
};
let table = null, room = null, loopOn = false, dirty = true, ended = false;
const humanSeat = () => (ctl.mode === 'online' ? ctl.me : ctl.mode === 'ai' ? 0 : ctl.state?.turn ?? 0);
// whose turn it is by the rules (a person here), and whether that person can act right now
const humanTurn = () => { const s = ctl.state; if (!s || s.winner !== null) return false; return ctl.mode === 'two' || (ctl.mode === 'ai' ? s.turn === 0 : s.turn === ctl.me); };
const myTurn = () => humanTurn() && !replay.active && !ctl.busy && !ctl.anim && (ctl.mode !== 'online' || (room?.status === 'playing' && !table?.busy));
const cuePos = () => (ctl.state?.inHand && ctl.place ? ctl.place : ctl.state?.balls?.[0] || null);

function invalidate() { dirty = true; if (!loopOn) { loopOn = true; requestAnimationFrame(loop); } }
function loop(now) {
  const animating = stepAnimation(now);
  const placing = ctl.state?.inHand && myTurn() && ctl.place;
  if (dirty || animating || placing || view.sinking.length || view.flash.length) { dirty = false; render(); }
  updateClock();
  if (animating || placing || view.sinking.length || view.flash.length || ctl.display?.moving || ctl.remote || (ctl.mode === 'online' && room?.turnDeadline)) requestAnimationFrame(loop);
  else loopOn = false;
}

function render() {
  const s = ctl.state; if (!s) return;
  const mine = myTurn(), cue = ctl.display ? view.balls[0] : cuePos();
  let aim = null, illegal = false;
  if (ctl.display) aim = { dir: ctl.display.dir, pull: ctl.display.pull || 0 };
  else if (mine && cue) aim = { dir: ctl.aim.dir, pull: ctl.power * 30 };
  else if (ctl.remote && cue) aim = { dir: ctl.remote.dir, pull: (ctl.remote.power || 0) * 30, alpha: 0.85 };
  if (aim && mine && !ctl.display) {
    const gd = aimGuide(view.balls, cue, aim.dir);
    illegal = gd.kind === 'ball' && !legalTargets(s, s.turn).includes(gd.n);
  }
  const placing = s.inHand && mine && ctl.place ? { at: ctl.place, ok: canPlace(s, ctl.place[0], ctl.place[1]) } : null;
  const remotePlace = !mine && ctl.remote?.cue && s.inHand ? ctl.remote.cue : null;
  if (remotePlace) view.balls[0] = remotePlace;
  view.draw({ aim, cue: remotePlace || cue, placing, kitchen: s.inHand && s.kitchen && (mine || remotePlace), guide: Boolean(aim) && !ctl.anim && (mine || ctl.display?.guide), illegal, ghostOnly: Boolean(ctl.remote && !mine) });
  renderAimInfo();
}

/* ---------- shot playback ---------- */
function stepAnimation(now) {
  const a = ctl.anim; if (!a) return false;
  if (a.strike) {
    const k = Math.min(1, (now - a.start) / a.strike);
    ctl.display = { dir: a.shot.dir, pull: (1 - k) * a.pull - k * 1.2, guide: false };
    if (k < 1) return true;
    a.strike = 0; a.start = now; ctl.display = null; Sound.cue(a.power || 0.5);
  }
  const frames = a.sim.frames, fi = (now - a.start) / (1000 / 60), i0 = Math.floor(fi), k = fi - i0;
  const el = now - a.start;
  while (a.ei < a.sim.events.length && a.sim.events[a.ei].t <= el) {
    const e = a.sim.events[a.ei++];
    if (e.type === 'ball') Sound.ball(e.speed); else if (e.type === 'rail') Sound.rail(e.speed);
    else if (e.type === 'pocket') { Sound.pocket(); view.flash.push({ p: e.b, t: now }); try { window.BS_AUDIO?.vibrate?.(18); } catch {} }
  }
  const last = frames.length - 1, f0 = frames[Math.min(i0, last)], f1 = frames[Math.min(i0 + 1, last)];
  for (let n = 0; n < 16; n++) {
    const p0 = f0[n], p1 = f1[n], prev = view.balls[n];
    let pos = null;
    if (p0 && p1) pos = [p0[0] + (p1[0] - p0[0]) * k, p0[1] + (p1[1] - p0[1]) * k];
    else if (p0) pos = p0;
    if (!pos && prev) { const pe = a.sim.events.find((e) => e.type === 'pocket' && e.a === n); view.sinking.push({ n, x: prev[0], y: prev[1], p: pe ? pe.b : nearestPocket(prev), t: now }); }
    if (pos && prev) rollAxes(view.axesOf(n), pos[0] - prev[0], pos[1] - prev[1]);
    view.balls[n] = pos;
  }
  renderPocketTray();
  if (i0 >= last) { const done = a.done; ctl.anim = null; done(); return false; }
  return true;
}
const nearestPocket = (b) => { let best = 0, d = Infinity; POCKETS.forEach((p, i) => { const dd = (p.x - b[0]) ** 2 + (p.y - b[1]) ** 2; if (dd < d) { d = dd; best = i; } }); return best; };
/** Plays a shot (from its starting positions) and ends on `next`'s positions. */
function animateShot(shot, next, { pull = 0.4 } = {}) {
  closeReplay();
  const sim = simulate(shot.before, shot, { record: true });
  view.balls = shot.before.map((b) => (b ? b.slice() : null));
  return new Promise((resolve) => {
    const finish = () => { view.balls = next.balls.map((b) => (b ? b.slice() : null)); invalidate(); resolve(sim); };
    if (reduced() || document.hidden) { finish(); for (const e of sim.events) if (e.type === 'pocket') { Sound.pocket(); break; } return; }
    ctl.anim = { sim, shot, start: performance.now(), ei: 0, strike: 110, pull: Math.max(6, pull * 30), power: pull, done: finish };
    invalidate();
  });
}

/* Replay has a separate canvas, clock, positions and orientation state.
   It never calls playPoolShot or sends a room command. */
const replay={active:false,frame:0,view:null,sim:null,shot:null,elapsed:-450,last:0,speed:.5,seq:0,match:0,paused:false};
function fitReplay(){if(!replay.active)return;const box=$('#biReplayView').getBoundingClientRect();replay.view.fit(box.width||Math.min(innerWidth-36,880),box.height||Math.max(180,Math.min(440,innerHeight*.5)),false);}
function paintReplay(){
  if(!replay.active||!replay.sim)return;const frames=replay.sim.frames,last=frames.length-1,pos=Math.max(0,replay.elapsed)/(1000/60),index=Math.min(last,Math.floor(pos)),k=pos-Math.floor(pos),a=frames[index],b=frames[Math.min(last,index+1)];
  for(let n=0;n<16;n++){const previous=replay.view.balls[n],point=a[n]&&b[n]?[a[n][0]+(b[n][0]-a[n][0])*k,a[n][1]+(b[n][1]-a[n][1])*k]:a[n]?.slice()||null;if(point&&previous)rollAxes(replay.view.axesOf(n),point[0]-previous[0],point[1]-previous[1]);replay.view.balls[n]=point;}
  const aim=replay.elapsed<0?{dir:replay.shot.dir,pull:Math.max(0,-replay.elapsed/450)*15}:null;replay.view.draw({aim,cue:aim?replay.view.balls[0]:null,guide:false});
  const duration=last*(1000/60),elapsed=Math.max(0,Math.min(duration,replay.elapsed));$('#biReplaySeek').value=String(Math.round(duration?elapsed/duration*1000:0));$('#biReplayTime').textContent=(elapsed/1000).toFixed(1)+' / '+(duration/1000).toFixed(1)+' ث';$('#biReplayPlay').textContent=replay.paused?'تشغيل ▶':'إيقاف مؤقت Ⅱ';
}
function replayFrame(time){replay.frame=0;if(!replay.active||document.hidden)return;if(!replay.paused&&replay.last)replay.elapsed+=Math.min(80,Math.max(0,time-replay.last))*replay.speed;replay.last=time;paintReplay();if(replay.elapsed>=replay.sim.frames.length*(1000/60)){replay.paused=true;paintReplay();}if(!replay.paused)replay.frame=requestAnimationFrame(replayFrame);}
function scheduleReplay(){if(replay.active&&!replay.frame){replay.last=0;replay.frame=requestAnimationFrame(replayFrame);}}
function openReplay(){
  const s=ctl.state;if(!s?.shot||ctl.anim||ctl.pending||ctl.busy)return false;replay.shot=structuredClone(s.shot);replay.sim=simulate(replay.shot.before,replay.shot,{record:true});if(!replay.sim.frames.length)return false;replay.view||=new TableView($('#biReplayCanvas'));
  replay.view.balls=replay.shot.before.map(b=>b?.slice()||null);replay.view.axes.clear();replay.view.previous.clear();replay.seq=s.shot.seq;replay.match=room?.startedAt||0;replay.elapsed=-450;replay.paused=false;replay.speed=.5;replay.active=true;
  setPower(0);drag=null;$('#biReplaySheet').hidden=false;$('#biReplayNote').textContent=ctl.mode==='online'?'إعادة مشاهدة فقط · وقت المباراة الأونلاين مستمر':'إعادة مشاهدة فقط · النتيجة محفوظة';$('#biReplaySpeed').textContent='السرعة ×0.5';fitReplay();paintReplay();renderStatus();scheduleReplay();$('#biReplayClose').focus({preventScroll:true});return true;
}
function closeReplay(){if(!replay.active)return;replay.active=false;cancelAnimationFrame(replay.frame);replay.frame=0;replay.last=0;$('#biReplaySheet').hidden=true;if(ctl.state){renderStatus();invalidate();}$('#biTable').focus({preventScroll:true});}
$('#biReplay').addEventListener('click',openReplay);$('#biReplayClose').addEventListener('click',closeReplay);
$('#biReplaySpeed').addEventListener('click',()=>{replay.speed=replay.speed===.5?1:replay.speed===1?.25:.5;$('#biReplaySpeed').textContent='السرعة ×'+replay.speed;});
$('#biReplayRestart').addEventListener('click',()=>{replay.elapsed=-450;replay.paused=false;replay.view.previous.clear();scheduleReplay();});
$('#biReplayPlay').addEventListener('click',()=>{replay.paused=!replay.paused;if(!replay.paused&&replay.elapsed>=replay.sim.frames.length*(1000/60))replay.elapsed=-450;paintReplay();scheduleReplay();});
$('#biReplaySeek').addEventListener('input',()=>{replay.elapsed=Number($('#biReplaySeek').value)/1000*(replay.sim.frames.length-1)*(1000/60);replay.view.previous.clear();replay.last=0;paintReplay();});
$('#biReplaySheet').addEventListener('keydown',ev=>{if(ev.key==='Escape'){ev.preventDefault();ev.stopPropagation();closeReplay();}if(ev.key==='Tab'){const a=Array.from($('#biReplaySheet').querySelectorAll('button,input')).filter(el=>!el.disabled),first=a[0],last=a.at(-1);if(ev.shiftKey&&document.activeElement===first){ev.preventDefault();last.focus();}else if(!ev.shiftKey&&document.activeElement===last){ev.preventDefault();first.focus();}}});
window.addEventListener('resize',()=>{if(replay.active){fitReplay();paintReplay();}});document.addEventListener('visibilitychange',()=>{if(document.hidden)closeReplay();});

/* ---------- the plates, the status, the toast ---------- */
function seatOfPlate(i) { return ctl.mode === 'online' ? (i === 0 ? ctl.me : 1 - ctl.me) : i; }
function renderPlates() {
  const s = ctl.state; if (!s) return;
  for (let i = 0; i < 2; i++) {
    const seat = seatOfPlate(i), el = $('#plate' + i), p = s.players[seat] || {};
    el.classList.toggle('turn', s.winner === null && s.turn === seat);
    const name = ctl.names[seat] || p.name || 'لاعب';
    el.querySelector('.bi-who b').textContent = name;
    const tag = ctl.mode === 'ai' && seat === 1 ? { easy: 'سهل', medium: 'متوسط', hard: 'محترف' }[ctl.level] : (ctl.mode === 'online' && seat === ctl.me) || (ctl.mode === 'ai' && seat === 0) ? 'أنت' : '';
    el.querySelector('.bi-who small').textContent = tag;
    el.querySelector('.bi-face i').textContent = (name.trim()[0] || '؟');
    const rack = el.querySelector('.bi-rack');
    const list = p.group ? (p.group === 'solid' ? SOLIDS : STRIPES) : null;
    const eight = p.group && onEight(s, seat);
    rack.innerHTML = list ? list.map((n) => `<i class="${n > 8 ? 'stripe' : ''}${s.balls[n] ? '' : ' gone'}" style="--c:${colorOf(n)}"></i>`).join('') + (eight ? '<i class="eight"></i>' : '') : '<i class="open"></i>'.repeat(7);
    el.setAttribute('aria-label', name + (p.group ? '، ' + GROUP_NAME[p.group] + '، باقي ' + remaining(s, p.group).length : ''));
  }
}
function setStatus(html) { $('#biStatus').innerHTML = html; }
function renderStatus() {
  const s = ctl.state; if (!s) return;
  $('#biReplay').disabled=!s.shot||Boolean(ctl.anim||ctl.pending||ctl.busy);
  $('#game').classList.toggle('idle', !myTurn());
  $('#biPower').classList.toggle('off', !myTurn());
  for (const id of ['#biPower', '#biFine', '#biSpinBtn']) $(id).setAttribute('aria-disabled', String(!myTurn()));
  renderShotContext();renderPocketTray();
  // while the balls roll the old line would mislead; the toast says what happened when they stop
  if (s.winner !== null || ctl.anim || (ctl.busy && ctl.mode !== 'ai')) { setStatus(''); return; }
  const name = ctl.names[s.turn] || s.players[s.turn]?.name || 'لاعب';
  const mine = (ctl.mode === 'online' && s.turn === ctl.me) || (ctl.mode === 'ai' && s.turn === 0) || ctl.mode === 'two';
  const who = ctl.mode === 'two' ? 'دور ' + esc(name) : mine ? 'دورك' : 'دور ' + esc(name);
  let hint = '';
  if (mine) {
    if (s.inHand && s.kitchen) hint = 'حط البيضاء ورا الخط واكسر';
    else if (s.inHand) hint = 'البيضاء بيدك: حرّكها وين ما تبي';
    else if (onEight(s, s.turn)) hint = 'الآن الثمانية للفوز';
  } else if (ctl.mode === 'ai') hint = 'يفكر…';
  setStatus(`${who}${hint ? ' <small>· ' + hint + '</small>' : ''}`);
}
let toastTimer = 0;
function toast(html, kind = '', ms = 1900) {
  const t = $('#biToast'); t.innerHTML = html; t.className = 'bi-toast show ' + kind;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.className = 'bi-toast ' + kind; }, ms);
}
const FOUL = { scratch: 'البيضاء دخلت', no_hit: 'ما لمست ولا كرة', wrong_first: 'لمس كرة مو من كراته أول', eight_first: 'لمس الثمانية قبل وقتها', no_rail: 'ولا كرة وصلت الحافة', time: 'خلص الوقت' };
const FOUL_ME = { scratch: 'البيضاء دخلت', no_hit: 'ما لمست ولا كرة', wrong_first: 'لمست كرة مو من كراتك أول', eight_first: 'لمست الثمانية قبل وقتها', no_rail: 'ولا كرة وصلت الحافة', time: 'خلص وقتك' };
// Resolve the HUD from the actual table state; an opponent's cosmetic aim never changes it.
function renderPocketTray() {
  const box=$('#biPottedBalls');if(!box)return;const balls=ctl.anim?view.balls:ctl.state?.balls;
  if(!balls)return;const potted=Array.from({length:15},(_,i)=>i+1).filter(n=>!balls[n]);
  const key=potted.join(',');if(box.dataset.balls===key)return;box.dataset.balls=key;
  box.innerHTML=potted.length?potted.map(n=>'<i role="listitem" class="bi-collected-ball '+(n>8?'stripe':'')+'" style="--c:'+colorOf(n)+'" aria-label="الكرة '+n+' دخلت"><b>'+n+'</b></i>').join(''):'<span class="bi-tray-empty">الكرات المدخلة تظهر هنا</span>';
  $('#biPottedCount').textContent=potted.length+' / 15';
}
function renderShotContext() {
  const s = ctl.state; if (!s) return;
  const group = s.players[s.turn]?.group;
  $('#biTarget').textContent = s.phase === 'break' ? 'الكسر · خلف الخط' : onEight(s, s.turn) ? 'الهدف: 8' : group ? `${GROUP_NAME[group]} · باقي ${remaining(s, group).length}` : 'مفتوحة · 1–7 / 9–15';
  const el = $('#biShotInfo'), l = s.last;
  el.hidden = !l;
  if (!l) { el.textContent = ''; el.classList.remove('foul'); return; }
  const who = ctl.names[l.by] || s.players[l.by]?.name || 'لاعب';
  let result;
  if (l.foul) result = 'خطأ: ' + (FOUL[l.foul] || 'ضربة غير قانونية');
  else if (l.result === 'win') result = 'حسم المباراة بالثمانية';
  else if (l.result === 'loss') result = 'الثمانية دخلت قبل وقتها';
  else if (l.spotted) result = 'الثمانية عادت لمكانها بعد الكسر';
  else if (l.potted.length) result = 'دخلت ' + l.potted.join('، ') + (l.result === 'again' ? ' · يكمل دوره' : ' · انتقل الدور');
  else result = 'لم تدخل كرة · انتقل الدور';
  el.textContent = `${who}: ${result}`;
  el.classList.toggle('foul', Boolean(l.foul));
}
function renderAimInfo() {
  const s = ctl.state, el = $('#biAimInfo'); if (!s) return;
  const angle = Math.atan2(ctl.aim.dir[1], ctl.aim.dir[0]) * 180 / Math.PI;
  if (fine) { fine.paint(myTurn()); fine.value(`زاوية ${Math.round(angle)} درجة`, Math.round(angle)); }
  else { $('#biFine').setAttribute('aria-valuenow', angle.toFixed(1)); $('#biFine').setAttribute('aria-valuetext', `زاوية ${Math.round(angle)} درجة`); }
  if (!myTurn()) { el.textContent = ctl.anim || ctl.busy ? 'الضربة قيد التنفيذ…' : ''; el.classList.remove('warn'); return; }
  const cue = cuePos(); if (!cue) { el.textContent = 'ضع البيضاء أولًا'; return; }
  if (s.inHand && !canPlace(s, cue[0], cue[1])) { el.textContent = 'مكان البيضاء غير صالح'; el.classList.add('warn'); return; }
  const guide = aimGuide(s.balls, cue, ctl.aim.dir);
  const wrong = guide.kind === 'ball' && !legalTargets(s).includes(guide.n);
  el.classList.toggle('warn', wrong);
  el.textContent = guide.kind !== 'ball' ? 'التصويب: الحافة أولًا' : wrong ? `تنبيه: الكرة ${guide.n} ليست هدفك` : `اللمسة الأولى: ${guide.n} · هدف صحيح`;
}
function announce(s) {
  const l = s.last; if (!l) return;
  const key = l.seq + ':' + l.result + ':' + (l.foul || '') + ':' + s.turn; if (key === ctl.lastKey) return; ctl.lastKey = key;
  const byMe = ctl.mode !== 'two' && l.by === humanSeat(), name = (seat) => esc(ctl.names[seat] || s.players[seat]?.name || 'لاعب');
  // «لـ» before a name; «الكمبيوتر» → «للكمبيوتر»
  const toName = (seat) => { const n = name(seat); return n.startsWith('ال') ? 'لل' + n.slice(2) : 'لـ' + n; };
  const nextName = s.turn === humanSeat() && ctl.mode !== 'two' ? 'لك' : toName(s.turn);
  if (l.result === 'win' || l.result === 'loss') return;
  if (l.foul) { Sound.foul(); toast(`خطأ: ${byMe ? FOUL_ME[l.foul] : FOUL[l.foul]}<small>البيضاء ${nextName} وين ما ${s.turn === humanSeat() && ctl.mode !== 'two' ? 'تبي' : 'يبي'}</small>`, 'foul', 2300); return; }
  if (l.group) { Sound.good(); const g = s.players[l.by].group; toast(`${byMe ? 'كراتك' : 'كرات ' + name(l.by)}: ${GROUP_NAME[g]} ${g === 'solid' ? '(من 1 إلى 7)' : '(من 9 إلى 15)'}`, 'good', 2200); return; }
  if (l.spotted) { toast('الثمانية دخلت في الكسر ورجعت مكانها'); return; }
  if (l.result === 'again' && l.potted.length) { if (byMe || ctl.mode === 'two') Sound.good(); toast(byMe || ctl.mode === 'two' ? 'دخلت! كمّل' : `${name(l.by)} دخّل وكمّل`, 'good', 1200); return; }
  if (l.result === 'pass' && ctl.mode !== 'ai') toast('الدور ' + nextName, '', 1100);
}

/* ---------- the clock (online) ---------- */
function updateClock() {
  for (let i = 0; i < 2; i++) {
    const el = $('#plate' + i), ring = el.querySelector('.bi-ring');
    const seat = seatOfPlate(i), s = ctl.state;
    let frac = 0;
    if (ctl.mode === 'online' && room?.status === 'playing' && room.turnDeadline && s && s.turn === seat && s.winner === null && !ctl.bots[seat]) {
      const base = Number(room.serverNow) || Date.now(), got = Number(room.clientReceivedAt) || Date.now(), now = base + (Date.now() - got);
      const total = Number(room.turnTotal) || 35000; frac = Math.max(0, Math.min(1, (Number(room.turnDeadline) - now) / total));
    }
    ring.style.strokeDashoffset = String(125.7 * (1 - frac));
    el.classList.toggle('late', frac > 0 && frac < 0.25);
  }
}

/* ---------- aiming and shooting ---------- */
function defaultAim() {
  const s = ctl.state, cue = cuePos(); if (!s || !cue) return;
  const targets = legalTargets(s, s.turn).map((n) => s.balls[n]).filter(Boolean);
  if (s.phase === 'break') { const dx = FOOT[0] - cue[0], dy = FOOT[1] - cue[1], l = Math.hypot(dx, dy) || 1; ctl.aim.dir = [dx / l, dy / l]; return; }
  let best = null, bd = Infinity;
  for (const b of targets) { const d = Math.hypot(b[0] - cue[0], b[1] - cue[1]); if (d < bd && d > R) { bd = d; best = b; } }
  if (best) { const dx = best[0] - cue[0], dy = best[1] - cue[1], l = Math.hypot(dx, dy); ctl.aim.dir = [dx / l, dy / l]; }
}
function startPlacing() {
  const s = ctl.state; if (!s?.inHand) { ctl.place = null; return; }
  const was = s.balls[0];
  if (s.kitchen) ctl.place = canPlace(s, HEAD_X - 14, W / 2) ? [HEAD_X - 14, W / 2] : nearestPlace(s, HEAD_X - 14, W / 2);
  else ctl.place = was && canPlace(s, was[0], was[1]) ? was.slice() : nearestPlace(s, L * 0.25, W / 2);
}
function beginTurn() {
  ctl.power = 0; setPower(0); ctl.remote = null;
  if (ctl.state?.inHand) startPlacing(); else ctl.place = null;
  if (humanTurn()) defaultAim();
  renderPlates(); renderStatus(); invalidate();
}
function setPower(p) { ctl.power = p; const el = $('#biPower'); el.style.setProperty('--p', p.toFixed(3)); el.setAttribute('aria-valuenow', String(Math.round(p * 100))); el.setAttribute('aria-valuetext', Math.round(p * 100) + ' بالمئة'); el.classList.toggle('on', p > 0.02); el.querySelector('b').textContent = p > 0.02 ? Math.round(p * 100) + '% · أفلت' : 'اسحب وأفلت للضرب'; el.classList.toggle('hard', p >= 0.75); el.classList.toggle('far', p >= 0.45); }
let aimSent = 0, aimTimer = 0;
function shareAim() {
  if (ctl.mode !== 'online' || !myTurn()) return;
  const send = () => { aimSent = Date.now(); table?.send('pool_aim', { dir: ctl.aim.dir.map((v) => Math.round(v * 1000) / 1000), power: Math.round(ctl.power * 100) / 100, cue: ctl.state?.inHand && ctl.place ? ctl.place.map((v) => Math.round(v * 10) / 10) : null }); };
  clearTimeout(aimTimer);
  const gap = Date.now() - aimSent; if (gap > 260) send(); else aimTimer = setTimeout(send, 260 - gap);
}
async function shoot(power) {
  if (!myTurn() || power < 0.02) { setPower(0); invalidate(); return; }
  const s = ctl.state, seat = s.turn, input = { dir: ctl.aim.dir.slice(), power, spin: ctl.aim.spin.slice() };
  if (s.inHand) {
    if (!ctl.place || !canPlace(s, ctl.place[0], ctl.place[1])) { toast('ما تقدر تحط البيضاء هنا', 'foul'); setPower(0); invalidate(); return; }
    input.cue = ctl.place.slice();
  }
  Sound.unlock();
  let next;
  try { next = playPoolShot(s, seat, input); } catch { toast('الضربة ما تنفع، جرّب مرة ثانية', 'foul'); setPower(0); return; }
  setPower(0);
  if (ctl.mode === 'online') {
    if (!table?.send('pool_shot', { dir: input.dir, power: input.power, spin: input.spin, cue: input.cue })) { invalidate(); return; }
    ctl.busy = true; ctl.place = null; renderStatus();
    const pending = { seq: next.shots, prev: s, next };
    ctl.pending = pending;
    pending.done = animateShot(next.shot, next, { pull: power });
    pending.timer = setTimeout(() => { if (ctl.pending === pending) { revertPending('تأخر الاتصال بالطاولة'); } }, 20000);
    return;
  }
  ctl.busy = true; ctl.place = null; renderStatus();
  await animateShot(next.shot, next, { pull: power });
  ctl.state = next; ctl.busy = false;
  afterShot();
}
function revertPending(message) {
  const p = ctl.pending; if (!p) return;
  clearTimeout(p.timer); ctl.pending = null;
  if (ctl.anim) { const done = ctl.anim.done; ctl.anim = null; done(); }
  ctl.state = p.prev; view.balls = p.prev.balls.map((b) => (b ? b.slice() : null)); ctl.busy = false;
  toast(esc(message || 'ما وصلت الضربة'), 'foul'); beginTurn();
}
function afterShot() {
  const s = ctl.state;
  announce(s); renderPlates();
  if (s.winner !== null) { showEnd(); return; }
  beginTurn();
  if (ctl.mode === 'ai' && s.turn === 1) aiTurn();
}

/* ---------- the computer player (practice) ---------- */
async function aiTurn() {
  if (ctl.mode !== 'ai' || ctl.state?.turn !== 1 || ctl.state.winner !== null || ended) return;
  ctl.busy = true; renderStatus();
  const s = ctl.state;
  await wait(reduced() ? 120 : 520);
  if (ctl.mode !== 'ai' || ended) return;
  const shot = choosePoolShot(s, ctl.level, Math.random);
  // the player puts the cue ball down, turns the cue onto the line, draws it back, strikes
  if (shot.cue) await glide(s.balls[0] || [L * 0.25, W / 2], shot.cue, 420);
  const from = ctl.aim.dir.slice();
  await turnTo(from, shot.dir, reduced() ? 60 : 640);
  await pullBack(shot.power, reduced() ? 60 : 380);
  const next = playPoolShot(s, 1, shot);
  ctl.display = null;
  await animateShot(next.shot, next, { pull: shot.power });
  ctl.state = next; ctl.busy = false;
  afterShot();
}
function tween(ms, fn) { return new Promise((resolve) => { const t0 = performance.now(); const tick = (now) => { const k = Math.min(1, (now - t0) / ms); fn(k * k * (3 - 2 * k)); invalidate(); if (k < 1) requestAnimationFrame(tick); else resolve(); }; requestAnimationFrame(tick); }); }
function glide(from, to, ms) { return tween(ms, (k) => { view.balls[0] = [from[0] + (to[0] - from[0]) * k, from[1] + (to[1] - from[1]) * k]; }); }
function turnTo(a, b, ms) {
  const a0 = Math.atan2(a[1], a[0]); let d = Math.atan2(b[1], b[0]) - a0; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI;
  ctl.display = { dir: a.slice(), pull: 0, guide: true, moving: true };
  return tween(ms, (k) => { const t = a0 + d * k; ctl.display.dir = [Math.cos(t), Math.sin(t)]; }).then(() => { ctl.display.dir = b.slice(); ctl.aim.dir = b.slice(); });
}
function pullBack(power, ms) { return tween(ms, (k) => { if (ctl.display) ctl.display.pull = k * power * 30; }); }

/* ---------- input ---------- */
function canvasPoint(ev) { const r = view.canvas.getBoundingClientRect(); return view.toWorld((ev.clientX - r.left) * view.dpr, (ev.clientY - r.top) * view.dpr); }
// 33.10.3: a finger on the cloth turns the cue round the white ball (it never jumps to the touch);
// a tap on a ball lines it up for the pocket, a tap on the cloth aims at that spot.
const CUE = window.BS_CUE_CONTROLS || null;
const nearCueInHand = (x, y) => Boolean(ctl.state?.inHand && ctl.place && Math.hypot(x - ctl.place[0], y - ctl.place[1]) < R * 3.4);
let drag = null;
view.canvas.addEventListener('pointerdown', (ev) => {
  Sound.unlock();
  if (!myTurn()) return;
  const [x, y] = canvasPoint(ev), s = ctl.state;
  view.canvas.setPointerCapture?.(ev.pointerId);
  if (s.inHand && ctl.place && Math.hypot(x - ctl.place[0], y - ctl.place[1]) < R * 3.4) { drag = { kind: 'place', dx: ctl.place[0] - x, dy: ctl.place[1] - y }; return; }
  if (CUE) { try { view.canvas.releasePointerCapture?.(ev.pointerId); } catch {} return; } // turning is below
  drag = { kind: 'aim', x0: ev.clientX, y0: ev.clientY, wx: x, wy: y }; view.loupe = true; aimAt(x, y);
});
view.canvas.addEventListener('pointermove', (ev) => {
  if (!drag || !myTurn()) return;
  const [x, y] = canvasPoint(ev);
  if (drag.kind === 'place') {
    const s = ctl.state, kx = s.kitchen ? HEAD_X : L - R;
    ctl.place = [Math.max(R, Math.min(kx, x + drag.dx)), Math.max(R, Math.min(W - R, y + drag.dy))];
    shareAim(); invalidate();
  } else aimAt(x, y);
});
// 33.9.6: a tap on a ball aims to pot it in the pocket with the straightest line
function potAim(n) {
  const cue = cuePos(), b = view.balls[n]; if (!cue || !b) return false;
  let best = null;
  for (const p of POCKETS) {
    const px = p.x - b[0], py = p.y - b[1], pl = Math.hypot(px, py); if (pl < 1) continue;
    const ux = px / pl, uy = py / pl, gx = b[0] - ux * 2 * R, gy = b[1] - uy * 2 * R;
    const cx = gx - cue[0], cy = gy - cue[1], cl = Math.hypot(cx, cy); if (cl < R) continue;
    const cos = (cx * ux + cy * uy) / cl; if (cos < 0.2) continue;
    const score = cos - pl / 2000;
    if (!best || score > best.score) best = { score, dir: [cx / cl, cy / cl] };
  }
  if (!best) return false;
  ctl.aim.dir = best.dir; shareAim(); invalidate(); return true;
}
const endDrag = (ev) => {
  view.loupe = false;
  if (drag?.kind === 'aim' && ev && Math.hypot(ev.clientX - drag.x0, ev.clientY - drag.y0) < 8 && myTurn()) {
    let hit = -1, near = R * 1.9;
    for (let n = 1; n < 16; n++) { const b = view.balls[n]; if (!b) continue; const dd = Math.hypot(b[0] - drag.wx, b[1] - drag.wy); if (dd < near) { near = dd; hit = n; } }
    if (hit > 0) potAim(hit);
  }
  if (drag?.kind === 'place' && ctl.state?.inHand && ctl.place && !canPlace(ctl.state, ctl.place[0], ctl.place[1])) {
    const near = nearestPlace(ctl.state, ctl.place[0], ctl.place[1]); if (near) ctl.place = near;
  }
  drag = null; invalidate();
};
view.canvas.addEventListener('pointerup', endDrag); view.canvas.addEventListener('pointercancel', endDrag);
function aimAt(x, y) {
  const cue = cuePos(); if (!cue) return;
  const dx = x - cue[0], dy = y - cue[1], l = Math.hypot(dx, dy); if (l < R * 0.8) return;
  ctl.aim.dir = [dx / l, dy / l]; shareAim(); invalidate();
}
function rotateAim(a) { const [x, y] = ctl.aim.dir, c = Math.cos(a), s = Math.sin(a); const nx = x * c - y * s, ny = x * s + y * c, l = Math.hypot(nx, ny); ctl.aim.dir = [nx / l, ny / l]; shareAim(); invalidate(); }
const turning = CUE?.aimDrag(view.canvas, {
  can: () => myTurn() && !drag && Boolean(cuePos()),
  point: (ev) => { const [x, y] = canvasPoint(ev); return { x, y }; },
  center: () => { const [x, y] = cuePos(); return { x, y }; },
  get: () => Math.atan2(ctl.aim.dir[1], ctl.aim.dir[0]),
  set: (a) => { ctl.aim.dir = [Math.cos(a), Math.sin(a)]; shareAim(); invalidate(); },
  lever: 46,
  claim: (p) => !nearCueInHand(p.x, p.y),
  start: () => { view.loupe = true; invalidate(); },
  end: () => { view.loupe = false; invalidate(); },
  tap: (p) => {
    let hit = -1, near = R * 1.9;
    for (let n = 1; n < 16; n++) { const b = view.balls[n]; if (!b) continue; const dd = Math.hypot(b[0] - p.x, b[1] - p.y); if (dd < near) { near = dd; hit = n; } }
    if (!(hit > 0 && potAim(hit))) aimAt(p.x, p.y);
  },
});
const fine = CUE ? CUE.fineRuler($('#biFine'), { can: () => myTurn() && !turning?.active, rotate: rotateAim, perPx: 0.0011, nudge: 0.0026, label: 'تصويب دقيق', hint: 'دقّق' }) : null;
// fine aim (without the cue controls)
if (!fine) {
  const el = $('#biFine'); let last = null, off = 0;
  el.addEventListener('pointerdown', (ev) => { if (!myTurn()) return; last = ev.clientX; el.setPointerCapture?.(ev.pointerId); });
  el.addEventListener('pointermove', (ev) => { if (last === null || !myTurn()) return; const dx = ev.clientX - last; last = ev.clientX; off += dx; el.style.setProperty('--fine', off + 'px'); rotateAim(dx * 0.0011); });
  const up = () => { last = null; }; el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up);
  el.addEventListener('keydown', (ev) => { if (!myTurn()) return; if (ev.key === 'ArrowLeft' || ev.key === 'ArrowRight') { ev.preventDefault(); rotateAim((ev.key === 'ArrowRight' ? 1 : -1) * (ev.shiftKey ? 0.002 : 0.008)); } });
}
// power: pull the cue down, let go to strike
{
  // a groove under the table (pull the cue sideways) or a rail at the side (pull it down)
  const el = $('#biPower'); let from = null;
  el.addEventListener('pointerdown', (ev) => { Sound.unlock(); if (!myTurn()) return; from = [ev.clientX, ev.clientY]; el.setPointerCapture?.(ev.pointerId); });
  el.addEventListener('pointermove', (ev) => {
    if (from === null || !myTurn()) return;
    const r = el.getBoundingClientRect(), tall = r.height > r.width;
    // 33.9.6: pull it down (or sideways along the groove) — whichever you find easier
    const p = tall ? (ev.clientY - from[1]) / (r.height * 0.82) : Math.max(Math.abs(ev.clientX - from[0]) / (r.width * 0.8), (ev.clientY - from[1]) / 190);
    setPower(Math.max(0, Math.min(1, p))); shareAim(); invalidate();
  });
  const up = () => { if (from === null) return; from = null; shoot(ctl.power); };
  el.addEventListener('pointerup', up); el.addEventListener('pointercancel', () => { from = null; setPower(0); invalidate(); });
  el.addEventListener('keydown', (ev) => {
    if (!myTurn()) return;
    if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') { ev.preventDefault(); setPower(Math.max(0, Math.min(1, ctl.power + (ev.key === 'ArrowDown' ? 0.05 : -0.05)))); invalidate(); }
    else if (ev.key === 'Home' || ev.key === 'Escape') { ev.preventDefault(); setPower(0); invalidate(); }
    else if (ev.key === 'End') { ev.preventDefault(); setPower(1); invalidate(); }
    else if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); shoot(ctl.power); }
  });
}
view.canvas.addEventListener('keydown', (ev) => {
  if (!myTurn()) return;
  if (ev.key === 'ArrowLeft' || ev.key === 'ArrowRight') { ev.preventDefault(); rotateAim((ev.key === 'ArrowRight' ? 1 : -1) * (ev.shiftKey ? 0.002 : 0.012)); }
  else if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') { ev.preventDefault(); setPower(Math.max(0, Math.min(1, ctl.power + (ev.key === 'ArrowDown' ? 0.05 : -0.05)))); invalidate(); }
  else if (ev.key === 'Escape') { ev.preventDefault(); setPower(0); invalidate(); }
  else if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); shoot(ctl.power); }
});
// spin
{
  const sheet = $('#biSpinSheet'), ball = $('#biSpinBall'), btn = $('#biSpinBtn');
  const paint = () => { for (const el of [ball, btn]) { el.style.setProperty('--sx', ctl.aim.spin[0].toFixed(3)); el.style.setProperty('--sy', ctl.aim.spin[1].toFixed(3)); } ball.setAttribute('aria-valuenow', String(Math.round(ctl.aim.spin[1] * 100))); ball.setAttribute('aria-valuetext', `دوران جانبي ${Math.round(ctl.aim.spin[0] * 100)} بالمئة، علوي ${Math.round(ctl.aim.spin[1] * 100)} بالمئة`); };
  const setFrom = (ev) => { const r = ball.getBoundingClientRect(); let sx = ((ev.clientX - r.left) / r.width - 0.5) / 0.39, sy = -((ev.clientY - r.top) / r.height - 0.5) / 0.39; const l = Math.hypot(sx, sy); if (l > 1) { sx /= l; sy /= l; } ctl.aim.spin = [Math.round(sx * 100) / 100, Math.round(sy * 100) / 100]; paint(); };
  let on = false;
  btn.addEventListener('click', () => { if (!myTurn()) return; sheet.hidden = false; paint(); ball.focus(); });
  ball.addEventListener('pointerdown', (ev) => { on = true; ball.setPointerCapture?.(ev.pointerId); setFrom(ev); });
  ball.addEventListener('pointermove', (ev) => { if (on) setFrom(ev); });
  ball.addEventListener('pointerup', () => { on = false; });
  ball.addEventListener('pointercancel', () => { on = false; });
  ball.addEventListener('keydown', (ev) => { const k = { ArrowUp: [0, 0.1], ArrowDown: [0, -0.1], ArrowLeft: [-0.1, 0], ArrowRight: [0.1, 0] }[ev.key]; if (!k) return; ev.preventDefault(); let [sx, sy] = [ctl.aim.spin[0] + k[0], ctl.aim.spin[1] + k[1]]; const l = Math.hypot(sx, sy); if (l > 1) { sx /= l; sy /= l; } ctl.aim.spin = [Math.round(sx * 100) / 100, Math.round(sy * 100) / 100]; paint(); });
  $('#biSpinReset').addEventListener('click', () => { ctl.aim.spin = [0, 0]; paint(); });
  const close = () => { on = false; sheet.hidden = true; btn.focus(); };
  $('#biSpinDone').addEventListener('click', close);
  sheet.addEventListener('click', (ev) => { if (ev.target === sheet) close(); });
  sheet.addEventListener('keydown', (ev) => {
    if (ev.key === 'Escape') { ev.preventDefault(); close(); }
    else if (ev.key === 'Tab') {
      const first = ball, last = $('#biSpinDone');
      if (ev.shiftKey && document.activeElement === first) { ev.preventDefault(); last.focus(); }
      else if (!ev.shiftKey && document.activeElement === last) { ev.preventDefault(); first.focus(); }
    }
  });
  paint();
}

/* ---------- screens ---------- */
function fitTable() {
  const wrap = $('#biWrap'), r = wrap.getBoundingClientRect(); if (r.width < 10 || r.height < 10) return;
  view.canvas.style.width = r.width + 'px'; view.canvas.style.height = r.height + 'px';
  view.fit(r.width, r.height, r.height > r.width * 1.05);
  invalidate();
}
new ResizeObserver(() => { if (!$('#game').hidden) fitTable(); }).observe($('#biWrap'));
function largeTable(enabled,remember=false){
  $('#game').classList.toggle('bi-expanded',enabled);const button=$('#biExpand');button.setAttribute('aria-pressed',String(enabled));button.setAttribute('aria-label',enabled?'إظهار تفاصيل الطاولة':'تكبير مساحة الطاولة');button.textContent=enabled?'⤡':'⤢';
  if(remember)try{localStorage.setItem('bs_pool_large_table',enabled?'1':'0');}catch{}requestAnimationFrame(fitTable);
}
$('#biExpand').addEventListener('click',()=>largeTable(!$('#game').classList.contains('bi-expanded'),true));
function showGame() {
  let big=innerWidth<600;try{const stored=localStorage.getItem('bs_pool_large_table');if(stored!==null)big=stored==='1';}catch{}largeTable(big);
  if ($('#game').hidden) { $('#game').hidden = false; document.body.classList.add('bi-playing'); requestAnimationFrame(fitTable); }
  $('#biEnd').hidden = true;
}
function showMenu() {
  closeReplay();
  $('#game').hidden = true; $('#biEnd').hidden = true; $('#biSpinSheet').hidden = true; document.body.classList.remove('bi-playing');
  ctl.anim = null; ctl.display = null; ctl.busy = false; ended = true; drawHero();
}
function startLocal(mode) {
  closeReplay();
  ended = false; ctl.mode = mode; ctl.endShown = false; ctl.rewarded = false; ctl.receipt = 'billiards:' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  const me = window.BS_GAME_MENU?.playerName?.() || 'أنت';
  ctl.names = mode === 'ai' ? [me, 'الكمبيوتر'] : [$('#biName1').value.trim() || 'لاعب 1', $('#biName2').value.trim() || 'لاعب 2'];
  ctl.bots = mode === 'ai' ? [false, true] : [false, false];
  ctl.state = createPoolGame(ctl.names, { first: mode === 'ai' ? (Math.random() < 0.5 ? 0 : 1) : 0 });
  ctl.lastKey = ''; ctl.shownSeq = 0; view.axes.clear(); view.balls = ctl.state.balls.map((b) => (b ? b.slice() : null));
  showGame(); beginTurn();
  toast(ctl.state.turn === 0 || mode === 'two' ? (mode === 'two' ? 'يكسر ' + esc(ctl.names[0]) : 'أنت تكسر') : 'الكمبيوتر يكسر', '', 1300);
  if (mode === 'ai' && ctl.state.turn === 1) aiTurn();
}
function showEnd() {
  if (ctl.endShown) return; ctl.endShown = true;
  const s = ctl.state, l = s.last, w = s.winner, card = $('#biEnd .bi-sheet-card');
  const iWon = ctl.mode === 'two' ? true : w === humanSeat();
  const name = esc(ctl.names[w] || s.players[w]?.name || 'لاعب');
  $('#biEndTitle').innerHTML = ctl.mode === 'two' ? `${name} فاز` : iWon ? 'فزت!' : `${name} فاز`;
  const loser = esc(ctl.names[1 - w] || s.players[1 - w]?.name || '');
  $('#biEndText').innerHTML = l?.result === 'win' ? (ctl.mode === 'two' || !iWon ? `${name} نظّف كراته ودخّل الثمانية.` : 'نظّفت كراتك ودخّلت الثمانية.') : (l?.foul ? `الثمانية دخلت مع خطأ من ${loser}.` : `الثمانية دخلت قبل وقتها من ${loser}.`);
  const counts = s.shotsBySeat;
  $('#biEndStats').innerHTML = `<table class="bi-match-stats"><caption>ملخص المباراة · ${s.shots} ضربة</caption><thead><tr><th scope="col">اللاعب</th>${counts ? '<th scope="col">ضربات</th>' : ''}<th scope="col">أخطاء</th></tr></thead><tbody>${s.players.map((p, seat) => `<tr${seat === w ? ' class="winner"' : ''}><th scope="row">${esc(ctl.names[seat] || p.name)}</th>${counts ? `<td>${counts[seat]}</td>` : ''}<td>${s.fouls[seat]}</td></tr>`).join('')}</tbody></table>`;
  card.classList.toggle('won', iWon);
  $('#biAgain').textContent = ctl.mode === 'online' ? (room?.publicMatch ? 'مباراة جديدة' : room?.me?.role === 'host' ? 'جولة جديدة' : 'بانتظار المضيف') : 'مباراة جديدة';
  $('#biAgain').disabled = ctl.mode === 'online' && !room?.publicMatch && room?.me?.role !== 'host';
  setTimeout(() => { if (ctl.endShown) $('#biEnd').hidden = false; }, 700);
  if (iWon) Sound.win(); else Sound.foul();
  if (!ctl.rewarded) {
    ctl.rewarded = true;
    if (ctl.mode === 'online') window.BS_CAREER?.refresh?.()?.catch?.(() => {});
    else if (ctl.mode === 'ai') window.BS_CAREER?.record?.({ id: ctl.receipt, game: 'billiards', win: w === 0 })?.catch?.(() => {});
  }
}
$('#biAgain').addEventListener('click', () => { $('#biEnd').hidden = true; if (ctl.mode === 'online') table?.again(); else startLocal(ctl.mode); });
$('#biToMenu').addEventListener('click', () => { if (ctl.mode === 'online') table?.leave(); showMenu(); });
let exitArmed = 0;
$('#biExit').addEventListener('click', () => {
  const live = ctl.state && ctl.state.winner === null && ctl.state.shots > 0;
  if (live && Date.now() - exitArmed > 2500) { exitArmed = Date.now(); toast('اضغط ✕ مرة ثانية للخروج', '', 1600); return; }
  if (ctl.mode === 'online') table?.leave(); showMenu();
});

/* ---------- online: one table among the board tables ---------- */
async function apply(next, { animate }) {
  if(replay.active&&(next.state?.shot?.seq!==replay.seq||(next.startedAt||0)!==replay.match))closeReplay();
  room = next;
  const s = next.state; if (!s || s.game !== 'pool') return;
  if (ctl.mode !== 'online' || $('#game').hidden || ctl.match !== (next.startedAt || 0)) {
    ctl.match = next.startedAt || 0;
    ended = false; ctl.mode = 'online'; ctl.endShown = false; ctl.rewarded = false; ctl.shownSeq = s.shot ? s.shot.seq - (next.stepOf ? 1 : 0) : 0; ctl.lastKey = ''; view.axes.clear();
    ctl.state = s; view.balls = (s.shot && next.stepOf ? s.shot.before : s.balls).map((b) => (b ? b.slice() : null)); showGame();
  }
  ctl.me = next.me?.index ?? 0;
  ctl.names = [0, 1].map((i) => next.players?.find((p) => p.index === i)?.name || s.players[i]?.name || 'لاعب');
  ctl.bots = [0, 1].map((i) => Boolean(next.players?.find((p) => p.index === i)?.bot));
  if (s.shot && s.shot.seq > ctl.shownSeq) {
    if (ctl.pending && ctl.pending.seq === s.shot.seq) { clearTimeout(ctl.pending.timer); await ctl.pending.done; ctl.pending = null; }
    else if (animate && !document.hidden) { ctl.remote = null; ctl.busy = true; await animateShot(s.shot, s, { pull: 0.5 }); }
    ctl.shownSeq = s.shot.seq;
  }
  ctl.state = s; ctl.busy = Boolean(ctl.pending);
  if (!ctl.anim) view.balls = s.balls.map((b) => (b ? b.slice() : null));
  announce(s); renderPlates();
  if (s.winner !== null) { showEnd(); return; }
  if (!ctl.pending) beginTurn();
  // the room's step player is still finishing this state: look again once it has
  setTimeout(() => { renderStatus(); invalidate(); }, 0);
}
window.addEventListener('bs-pool-aim', (ev) => {
  const d = ev.detail, s = ctl.state; if (ctl.mode !== 'online' || !s || d.seat !== s.turn || d.seat === ctl.me || ctl.anim) return;
  ctl.remote = { dir: d.dir, power: d.power, cue: d.cue }; invalidate();
});
try {
  table = createTable({
    game: 'billiards',
    quickNote: 'طاولة لاثنين: نلقى لك منافس خلال ثواني.',
    roomNote: 'أنشئ غرفة وارسل الرمز لخويّك.',
    lobbyNote: (next, isPublic) => (isPublic ? 'تبدأ بعد العد.' : 'أرسل الرمز لخويّك. تبدأ إذا ضغطت «ابدأ».'),
    apply,
    onLobby: () => { if (!$('#game').hidden) showMenu(); setMode('online'); },
    onMenu: () => { if (!$('#game').hidden) showMenu(); },
    onStatus: () => {},
    onError: (message) => { if (ctl.pending) revertPending(message); else window.BS_PLATFORM?.toast?.(message); },
  });
} catch (error) { console.error('billiards online unavailable', error); }

/* ---------- the menu ---------- */
function setMode(mode) {
  for (const b of document.querySelectorAll('.bi-modes button')) b.setAttribute('aria-checked', String(b.dataset.mode === mode));
  for (const p of document.querySelectorAll('.bi-panel')) p.hidden = p.dataset.panel !== mode;
  try { localStorage.setItem('bs-billiards-mode', mode); } catch {}
}
for (const b of document.querySelectorAll('.bi-modes button')) b.addEventListener('click', () => setMode(b.dataset.mode));
function setLevel(v) { ctl.level = v; for (const b of document.querySelectorAll('#biLevel button')) b.setAttribute('aria-checked', String(b.dataset.v === v)); try { localStorage.setItem('bs-billiards-level', v); } catch {} }
for (const b of document.querySelectorAll('#biLevel button')) b.addEventListener('click', () => setLevel(b.dataset.v));
$('#biStartAi').addEventListener('click', () => { Sound.unlock(); startLocal('ai'); });
$('#biStartTwo').addEventListener('click', () => { Sound.unlock(); startLocal('two'); });
{
  let mode = 'online', level = 'medium';
  try { mode = localStorage.getItem('bs-billiards-mode') || 'online'; level = localStorage.getItem('bs-billiards-level') || 'medium'; } catch {}
  if (/[?&]room=\d{6}/.test(location.search)) mode = 'online';
  setMode(['online', 'ai', 'two'].includes(mode) ? mode : 'online'); setLevel(['easy', 'medium', 'hard'].includes(level) ? level : 'medium');
}
// sound buttons
function paintMute() { const muted = Boolean(window.BS_AUDIO?.getSettings?.().muted); for (const id of ['#biMute', '#biSound']) { const b = $(id); if (!b) continue; b.textContent = muted ? '🔇' : '🔊'; b.setAttribute('aria-pressed', String(muted)); } }
for (const id of ['#biMute', '#biSound']) $(id)?.addEventListener('click', () => { window.BS_AUDIO?.toggleMuted?.(); paintMute(); Sound.unlock(); });
paintMute();

/* ---------- the cover on the menu ---------- */
const hero = new TableView($('#biHero'));
function drawHero() {
  const c = $('#biHero'), w = c.clientWidth || 360, h = Math.round((w * 420) / 760);
  hero.fit(w, h, false, { focus: [100, 6, L + 12, W - 6], flip: true });
  let seed = 5; const rng = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
  const g = createPoolGame(['', ''], { rng });
  hero.balls = g.balls.map((b) => (b ? b.slice() : null)); hero.balls[0] = [138, W / 2 + 11];
  hero.axes.clear(); for (let n = 1; n < 16; n++) rollAxes(hero.axesOf(n), (rng() - 0.5) * 2.6, (rng() - 0.5) * 2.6);
  const dx = FOOT[0] - hero.balls[0][0], dy = FOOT[1] - hero.balls[0][1], l = Math.hypot(dx, dy);
  hero.draw({ aim: { dir: [dx / l, dy / l], pull: 7 }, cue: hero.balls[0], guide: true });
}
new ResizeObserver(() => { if ($('#game').hidden) drawHero(); }).observe($('#biHero'));
if (document.fonts?.ready) document.fonts.ready.then(() => { if ($('#game').hidden) drawHero(); });
drawHero();
document.addEventListener('visibilitychange', () => { if (!document.hidden) invalidate(); });
window.BS_BILLIARDS = {
  ctl, view, replay, openReplay, closeReplay, get room() { return room; }, startLocal, shoot, setPower, rotateAim, begin: beginTurn, drawHero, heroView: hero,
  rack: (seed) => { let x = seed || 5; const rng = () => { x = (x * 16807) % 2147483647; return x / 2147483647; }; return createPoolGame(['', ''], { rng }).balls.map((b) => (b ? b.slice() : null)); },
  tiltHero: (seed) => { let x = seed || 5; const rng = () => { x = (x * 16807) % 2147483647; return x / 2147483647; }; hero.axes.clear(); for (let n = 1; n < 16; n++) rollAxes(hero.axesOf(n), (rng() - 0.5) * 2.6, (rng() - 0.5) * 2.6); },
};
