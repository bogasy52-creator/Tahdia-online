import test from 'node:test';
import assert from 'node:assert/strict';
import { createDOM } from './dom-harness.mjs';

const flush = async () => { for (let i = 0; i < 16; i++) await Promise.resolve(); };

class FakeWS {
  constructor(url, protocols) { FakeWS.instances.push(this); this.url = url; this.protocols = protocols; this.sent = []; this.listeners = {}; }
  addEventListener(type, fn) { (this.listeners[type] ??= []).push(fn); }
  send(data) { this.sent.push(JSON.parse(data)); }
  close() {}
  emit(type, data) { for (const fn of this.listeners[type] || []) fn({ data: JSON.stringify(data) }); }
}
FakeWS.instances = [];

async function setup(fetchImpl) {
  FakeWS.instances = [];
  const h = await createDOM('sudoku.html', { WebSocket: FakeWS, fetch: fetchImpl, BS_PROFILE: { displayName: 'نورة' } });
  await h.runFile('assets/js/sudoku-online-ui.js');
  await flush();
  return h;
}

test('opening the panel, picking difficulty, and starting creates a room then connects a socket', async () => {
  let createdBody = null;
  const h = await setup(async (url, opts) => {
    createdBody = JSON.parse(opts.body);
    return { ok: true, json: async () => ({ ok: true, code: '482913', difficulty: 'hard', lobbyWaitMs: 20000 }) };
  });
  h.doc.getElementById('sudokuOnlineOpen').click();
  assert.equal(h.doc.getElementById('sudokuOnline').hidden, false, 'لازم اللوحة تنفتح');

  h.doc.querySelector('#sudokuOnlineDiff button[data-diff="hard"]').click();
  h.doc.getElementById('sudokuOnlineStart').click();
  await flush();

  assert.equal(createdBody.difficulty, 'hard', 'لازم يرسل الصعوبة المختارة فعليًا بطلب الإنشاء');
  assert.equal(FakeWS.instances.length, 1, 'لازم يفتح اتصال WebSocket وحد بس');
  assert.ok(FakeWS.instances[0].url.includes('482913'), 'لازم يتصل بنفس كود الغرفة اللي رجع من السيرفر');
});

test('lobby state renders the countdown and player list correctly', async () => {
  const h = await setup(async () => ({ ok: true, json: async () => ({ ok: true, code: '111111' }) }));
  h.doc.getElementById('sudokuOnlineOpen').click();
  h.doc.getElementById('sudokuOnlineStart').click();
  await flush();
  const ws = FakeWS.instances[0];
  const now = Date.now();
  ws.emit('message', { type: 'welcome', playerId: 'me', token: 'me', state: {
    status: 'waiting', code: '111111', lobbyDeadline: now + 14000, serverNow: now,
    players: [{ id: 'me', name: 'نورة', connected: true }, { id: 'p2', name: 'سلمان', connected: true }],
  }});
  await flush();

  assert.equal(h.doc.getElementById('sudokuOnlineLobby').hidden, false, 'لازم لوحة اللوبي تظهر');
  const list = h.doc.getElementById('sudokuOnlinePlayers').innerHTML;
  assert.ok(list.includes('نورة') && list.includes('سلمان'), 'لازم يعرض أسماء اللاعبين الاثنين');
  assert.ok(list.includes('(أنت)'), 'لازم يعلّم لاعبي أنا بالذات');
  const timerText = h.doc.getElementById('sudokuOnlineTimer').textContent;
  assert.ok(Number(timerText) > 0 && Number(timerText) <= 14, `العد التنازلي لازم يكون منطقي، طلع: ${timerText}`);
});

test('playing state builds the board once, correct guess paints the cell, wrong guess does not', async () => {
  const h = await setup(async () => ({ ok: true, json: async () => ({ ok: true, code: '222222' }) }));
  h.doc.getElementById('sudokuOnlineOpen').click();
  h.doc.getElementById('sudokuOnlineStart').click();
  await flush();
  const ws = FakeWS.instances[0];
  const initial = new Array(81).fill(0); initial[0] = 5; // خانة أولى ثابتة، الباقي فاضي
  ws.emit('message', { type: 'welcome', playerId: 'me', token: 'me', state: {
    status: 'playing', code: '222222', puzzleInitial: initial,
    players: [{ id: 'me', name: 'نورة', correctCount: 0, mistakes: 0, eliminated: false, finishedAt: null, connected: true }],
  }});
  await flush();

  assert.equal(h.doc.getElementById('sudokuOnlineRace').hidden, false);
  const boardCells = h.doc.getElementById('sudokuOnlineBoard').children;
  assert.equal(boardCells.length, 81, 'لازم ٨١ خانة بالضبط');
  assert.ok(boardCells[0].className.includes('given'), 'الخانة الثابتة لازم تنعلّم given');
  assert.ok(boardCells[0].disabled, 'الخانة الثابتة لازم تكون معطّلة (ما تنضغط)');

  // نختار خانة فاضية وندخل رقم
  boardCells[1].click();
  h.doc.getElementById('sudokuOnlinePad').children[6].click(); // رقم 7
  await flush();
  assert.equal(ws.sent.at(-1).type, 'guess', 'لازم يرسل رسالة guess للسيرفر');
  assert.equal(ws.sent.at(-1).cell, 1);
  assert.equal(ws.sent.at(-1).value, 7);

  // السيرفر يرد إنه صح
  ws.emit('message', { type: 'guess_result', result: 'accepted_correct', cell: 1, value: 7, correctCount: 1, mistakes: 0, eliminated: false, finished: false });
  await flush();
  assert.equal(boardCells[1].textContent, '7', 'لازم الرقم الصحيح ينكتب بالخانة فعليًا');
  assert.ok(boardCells[1].className.includes('mine'), 'لازم تتعلّم كإدخال اللاعب نفسه');

  // تخمين غلط بخانة ثانية: الخانة لازم تضل فاضية، بس عداد الأغلاط يتحدث
  boardCells[2].click();
  h.doc.getElementById('sudokuOnlinePad').children[0].click();
  await flush();
  ws.emit('message', { type: 'guess_result', result: 'accepted_wrong', cell: 2, value: 1, correctCount: 1, mistakes: 1, eliminated: false, finished: false });
  await flush();
  assert.equal(boardCells[2].textContent, '', 'الخانة الغلط ما لازم تتعبّى بأي رقم');
  assert.equal(h.doc.getElementById('sudokuOnlineMistakes').textContent, '1 / 5 أغلاط');
});

test('finished state renders the final ranking in order', async () => {
  const h = await setup(async () => ({ ok: true, json: async () => ({ ok: true, code: '333333' }) }));
  h.doc.getElementById('sudokuOnlineOpen').click();
  h.doc.getElementById('sudokuOnlineStart').click();
  await flush();
  const ws = FakeWS.instances[0];
  ws.emit('message', { type: 'welcome', playerId: 'me', token: 'me', state: {
    status: 'finished', code: '333333',
    players: [{ id: 'me', name: 'نورة' }, { id: 'p2', name: 'سلمان' }],
    ranking: [
      { id: 'p2', name: 'سلمان', finalRank: 1, correctCount: 40, mistakes: 1, finishedAt: 999 },
      { id: 'me', name: 'نورة', finalRank: 2, correctCount: 30, mistakes: 3, finishedAt: null },
    ],
  }});
  await flush();
  assert.equal(h.doc.getElementById('sudokuOnlineResults').hidden, false);
  const items = h.doc.getElementById('sudokuOnlineRanking').children;
  assert.equal(items.length, 2);
  assert.ok(items[0].textContent.includes('سلمان'), 'لازم الفايز الفعلي يطلع أول بالترتيب');
  assert.ok(items[1].textContent.includes('نورة') && items[1].textContent.includes('أنت'), 'لازم يعلّم صفي أنا بالترتيب');
});
