import {
  createSudokuRoom, addSudokuPlayer, removeSudokuPlayer, sudokuLobbyShouldStart,
  startSudokuRoom, applySudokuGuess, sudokuRoomAllDone, computeSudokuRanking,
  SUDOKU_LOBBY_WAIT_MS, SUDOKU_MAX_MISTAKES, SUDOKU_ROOM_MAX_PLAYERS
} from './sudoku-room-logic.js';
import { solveSudoku } from '../../public/assets/js/engines/sudoku-core.js';

let t0 = Date.now();
let pass = 0, fail = 0;
function check(label, cond) {
  if (cond) { pass++; console.log("✅ " + label); }
  else { fail++; console.log("❌ FAIL: " + label); }
}

console.log("=== إنشاء غرفة ولوبي ٢٠ ثانية ===");
let room = createSudokuRoom({ code: '123456', hostId: 'p1', difficulty: 'medium', now: t0 });
check("الحالة الابتدائية waiting", room.status === 'waiting');
check("موعد بداية اللوبي = +20 ثانية بالضبط", room.lobbyDeadline === t0 + 20000);

console.log("\n=== إضافة لاعبين (حتى ١٠، الحادي عشر يرفض) ===");
for (let i = 1; i <= 10; i++) {
  const r = addSudokuPlayer(room, { id: 'p' + i, name: 'لاعب' + i }, t0 + 1000);
  check(`لاعب ${i} انقبل`, r.accepted === true);
  room = r.room;
}
const overflow = addSudokuPlayer(room, { id: 'p11', name: 'زائد' }, t0 + 1000);
check("اللاعب رقم ١١ ينرفض (الغرفة مليانة)", overflow.accepted === false && overflow.reason === 'room_full');
check("عدد اللاعبين بالضبط ١٠", Object.keys(room.players).length === 10);

console.log("\n=== لوبي ما يبدأ قبل ٢٠ ثانية ===");
check("ما لازم يبدأ قبل وقت الـ20 ثانية", sudokuLobbyShouldStart(room, t0 + 15000) === false);
check("لازم يبدأ بعد ٢٠ ثانية بالضبط مع وجود لاعبين", sudokuLobbyShouldStart(room, t0 + 20000) === true);

console.log("\n=== لوبي بلاعب واحد بس برضو يبدأ (من شخص واحد لـ١٠) ===");
let soloRoom = createSudokuRoom({ code: '999999', hostId: 'solo', difficulty: 'easy', now: t0 });
soloRoom = addSudokuPlayer(soloRoom, { id: 'solo', name: 'وحيد' }, t0).room;
check("لوبي بلاعب واحد يبدأ بعد ٢٠ ثانية", sudokuLobbyShouldStart(soloRoom, t0 + 20000) === true);

console.log("\n=== لوبي فاضي (ولا لاعب) ما يبدأ أبدًا ===");
let emptyRoom = createSudokuRoom({ code: '000000', hostId: 'x', difficulty: 'easy', now: t0 });
check("لوبي فاضي ما يبدأ حتى بعد ٢٠ ثانية", sudokuLobbyShouldStart(emptyRoom, t0 + 999999) === false);

console.log("\n=== بداية الجولة: نفس اللغز بالضبط لكل اللاعبين ===");
room = startSudokuRoom(room, t0 + 20000, 55); // نثبّت مرحلة 55 عشان الاختبار يصير حتمي
check("الحالة صارت playing", room.status === 'playing');
check("فيه لغز متولد بحل واحد محفوظ", Array.isArray(room.puzzle.solution) && room.puzzle.solution.length === 81);
const allSameBoard = Object.values(room.players).every(p => JSON.stringify(p.board) === JSON.stringify(room.puzzle.initial));
check("كل اللاعبين عندهم بالضبط نفس اللوحة الابتدائية", allSameBoard);

console.log("\n=== محاولة تخمين بخانة ثابتة (given) تنرفض ===");
const givenCell = room.puzzle.initial.findIndex(v => v !== 0);
const r1 = applySudokuGuess(room, 'p1', givenCell, room.puzzle.solution[givenCell], t0 + 21000);
check("رفض الكتابة بخانة ثابتة", r1.result === 'rejected' && r1.reason === 'given_cell');

console.log("\n=== تخمين صحيح فعليًا (مطابق للحل) ينقبل ويتسجل ===");
const emptyCell = room.puzzle.initial.findIndex(v => v === 0);
const correctValue = room.puzzle.solution[emptyCell];
const r2 = applySudokuGuess(room, 'p1', emptyCell, correctValue, t0 + 21500);
check("التخمين الصحيح انقبل", r2.result === 'accepted_correct');
check("انكتب بلوحة اللاعب فعليًا", r2.room.players.p1.board[emptyCell] === correctValue);
check("عداد الصح زاد", r2.room.players.p1.correctCount === 1);
room = r2.room;

console.log("\n=== نفس الخانة ما تتكرر (already_filled) ===");
const r3 = applySudokuGuess(room, 'p1', emptyCell, correctValue, t0 + 22000);
check("رفض إعادة ملء خانة معبّاة", r3.result === 'rejected' && r3.reason === 'already_filled');

console.log("\n=== تخمين غلط فعليًا (مو مطابق للحل) — أهم اختبار، لازم يقارن بالحل الحقيقي مو بتعارض محلي بس ===");
const emptyCell2 = room.puzzle.initial.findIndex((v, i) => v === 0 && !room.players.p1.board[i]);
const wrongValue = (room.puzzle.solution[emptyCell2] % 9) + 1; // رقم مختلف عمدًا عن الحل الصحيح
const r4 = applySudokuGuess(room, 'p1', emptyCell2, wrongValue, t0 + 22500);
check("التخمين الغلط انقبل كـ'accepted_wrong' (مو rejected)", r4.result === 'accepted_wrong');
check("الخانة ما انكتب فيها الرقم الغلط (تبقى فاضية)", r4.room.players.p1.board[emptyCell2] === 0);
check("عداد الأغلاط زاد لـ1", r4.room.players.p1.mistakes === 1);
check("ولا إقصاء بعد غلطة وحدة", r4.room.players.p1.eliminated === false);
room = r4.room;

console.log("\n=== ٥ أغلاط متتالية = إقصاء فوري ===");
let mistakeRoom = room;
for (let i = 0; i < SUDOKU_MAX_MISTAKES; i++) {
  const cell = mistakeRoom.puzzle.initial.findIndex((v, idx) => v === 0 && !mistakeRoom.players.p2.board[idx]);
  const wrong = (mistakeRoom.puzzle.solution[cell] % 9) + 1;
  const res = applySudokuGuess(mistakeRoom, 'p2', cell, wrong, t0 + 23000 + i * 100);
  mistakeRoom = res.room;
  console.log(`  غلطة ${i+1}: mistakes=${mistakeRoom.players.p2.mistakes}, eliminated=${mistakeRoom.players.p2.eliminated}`);
}
check("بعد 5 أغلاط بالضبط، اللاعب مُقصى", mistakeRoom.players.p2.eliminated === true && mistakeRoom.players.p2.mistakes === 5);
check("للاعب المُقصى رتبة مثبتة فورًا (rank)", mistakeRoom.players.p2.rank !== null);

console.log("\n=== لاعب مُقصى: أي محاولة تخمين بعدها تنرفض ===");
const afterElim = applySudokuGuess(mistakeRoom, 'p2', 10, 5, t0 + 25000);
check("رفض أي تخمين من لاعب مُقصى", afterElim.result === 'rejected' && afterElim.reason === 'player_done');

console.log("\n=== إنهاء لغز كامل (محاكاة لاعب يكمل كل الخانات بالحل الصحيح) ===");
let winRoom = startSudokuRoom(createSudokuRoom({ code: '555555', hostId: 'w1', difficulty: 'easy', now: t0 }), t0, 3);
winRoom = addSudokuPlayer(winRoom, { id: 'w1', name: 'سريع' }, t0).room;
winRoom = { ...winRoom, players: { w1: { ...winRoom.players.w1, board: winRoom.puzzle.initial.slice() } } };
let finishTime = null;
for (let cell = 0; cell < 81; cell++) {
  if (winRoom.puzzle.initial[cell]) continue;
  const res = applySudokuGuess(winRoom, 'w1', cell, winRoom.puzzle.solution[cell], t0 + 30000 + cell);
  winRoom = res.room;
  if (winRoom.players.w1.finishedAt) finishTime = winRoom.players.w1.finishedAt;
}
check("اللاعب أكمل اللوحة كاملة ويعتبر finished", Boolean(winRoom.players.w1.finishedAt));
check("الغرفة تتحول finished تلقائيًا (لاعب وحيد خلص)", winRoom.status === 'finished');
check("وقت الانتهاء منطقي (مسجل فعليًا)", finishTime !== null);

console.log("\n=== الترتيب النهائي: الفايزين بوقت الانتهاء، بعدين الباقي بعدد الصح ===");
let rankRoom = createSudokuRoom({ code: '777777', hostId: 'a', difficulty: 'easy', now: t0 });
rankRoom = addSudokuPlayer(rankRoom, { id: 'a', name: 'أ' }, t0).room;
rankRoom = addSudokuPlayer(rankRoom, { id: 'b', name: 'ب' }, t0).room;
rankRoom = addSudokuPlayer(rankRoom, { id: 'c', name: 'ج' }, t0).room;
rankRoom = startSudokuRoom(rankRoom, t0, 1);
// a يحل 3 خانات صح وما يكمل
let cells = [];
for (let i = 0; i < 81; i++) if (!rankRoom.puzzle.initial[i]) cells.push(i);
for (let i = 0; i < 3; i++) rankRoom = applySudokuGuess(rankRoom, 'a', cells[i], rankRoom.puzzle.solution[cells[i]], t0 + 1000 + i).room;
// b يحل خانة وحدة بس صح
rankRoom = applySudokuGuess(rankRoom, 'b', cells[0], rankRoom.puzzle.solution[cells[0]], t0 + 2000).room;
// c يكمل اللغز كامل (فايز)
for (const cell of cells) rankRoom = applySudokuGuess(rankRoom, 'c', cell, rankRoom.puzzle.solution[cell], t0 + 3000 + cell).room;
const ranking = computeSudokuRanking(rankRoom);
check("المركز الأول هو اللي خلص اللغز فعليًا (c)", ranking[0].id === 'c');
check("المركز الثاني أ (3 صح) قبل ب (صح وحدة)، لأن ولا وحد خلص منهم", ranking[1].id === 'a' && ranking[2].id === 'b');

console.log(`\n\n=== الخلاصة: ${pass} نجح، ${fail} فشل ===`);
if (fail > 0) process.exit(1);
