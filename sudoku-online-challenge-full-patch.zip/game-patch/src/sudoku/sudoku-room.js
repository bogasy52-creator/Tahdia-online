import {
  createSudokuRoom, addSudokuPlayer, removeSudokuPlayer, sudokuLobbyShouldStart,
  startSudokuRoom, applySudokuGuess, computeSudokuRanking,
  SUDOKU_ROOM_MAX_PLAYERS, SUDOKU_LOBBY_WAIT_MS
} from './sudoku-room-logic.js';

const TTL = 20 * 60_000;
const PROTOCOL = 'busraj-sudoku-v1';
const json = (body, status = 200) => Response.json(body, { status, headers: { 'cache-control': 'no-store' } });
const clean = value => String(value || 'لاعب').replace(/[<>\u0000-\u001f]/g, '').trim().slice(0, 24) || 'لاعب';
const secret = () => crypto.randomUUID() + crypto.randomUUID();
const isOpen = ws => !ws.closed && (ws.readyState === undefined || ws.readyState === 1);

export class SudokuRoom {
  constructor(ctx, env) {
    this.ctx = ctx; this.env = env; this.room = null;
    this.ready = ctx.blockConcurrencyWhile(async () => { this.room = await ctx.storage.get('sudoku') || null; });
  }

  async save() { if (this.room) await this.ctx.storage.put('sudoku', this.room); }

  // موعد التنبيه التالي: لحظة نهاية اللوبي (لو ما بدأت الجولة بعد)، أو انتهاء صلاحية الغرفة
  async schedule() {
    if (!this.room) return;
    const at = this.room.status === 'waiting' ? Math.min(this.room.expiresAt, this.room.lobbyDeadline) : this.room.expiresAt;
    await this.ctx.storage.setAlarm(at);
  }

  // الحالة العامة المُرسلة للكل — بدون لوحة أي لاعب ثاني وبدون الحل، حماية من الغش
  publicState() {
    if (!this.room) return null;
    const r = this.room;
    return {
      code: r.code, status: r.status, difficulty: r.difficulty,
      lobbyDeadline: r.lobbyDeadline, serverNow: Date.now(),
      puzzleInitial: r.puzzle?.initial || null, // المعطيات الثابتة فقط، مشتركة وآمنة
      players: Object.values(r.players).map(({ id, name, correctCount, mistakes, eliminated, finishedAt, rank, connected }) =>
        ({ id, name, correctCount, mistakes, eliminated, finishedAt, rank, connected })),
      ranking: r.status === 'finished' ? computeSudokuRanking(r).map(p => ({ id: p.id, name: p.name, finalRank: p.finalRank, correctCount: p.correctCount, mistakes: p.mistakes, finishedAt: p.finishedAt })) : null,
    };
  }

  broadcast() {
    const payload = JSON.stringify({ type: 'state', state: this.publicState() });
    for (const ws of this.ctx.getWebSockets()) if (isOpen(ws)) try { ws.send(payload); } catch {}
  }

  sendTo(ws, payload) { try { ws.send(JSON.stringify(payload)); } catch {} }
  error(ws, message) { this.sendTo(ws, { type: 'error', message }); }

  async fetch(request) {
    await this.ready;
    const url = new URL(request.url);

    if (url.pathname === '/init' && request.method === 'POST') {
      const body = await request.json().catch(() => ({}));
      if (this.room && this.room.expiresAt > Date.now()) return json({ ok: false, error: 'room_exists' }, 409);
      const difficulty = body.difficulty ?? 'medium';
      if (!['easy', 'medium', 'hard'].includes(difficulty) || !/^\d{6}$/.test(body.code || '') || typeof body.hostKey !== 'string' || body.hostKey.length < 32) {
        return json({ ok: false, error: 'إعدادات الغرفة غير صالحة' }, 400);
      }
      const base = createSudokuRoom({ code: body.code, hostId: null, difficulty, now: Date.now() });
      this.room = { ...base, hostKey: body.hostKey, expiresAt: Date.now() + TTL };
      await this.save(); await this.schedule();
      return json({ ok: true }, 201);
    }

    if (!this.room || this.room.expiresAt <= Date.now()) return json({ ok: false, error: 'الغرفة غير موجودة أو انتهت' }, 404);
    if (url.pathname === '/status') {
      return json({ ok: true, game: 'sudoku', code: this.room.code, status: this.room.status, players: Object.keys(this.room.players).length, maxPlayers: SUDOKU_ROOM_MAX_PLAYERS, difficulty: this.room.difficulty });
    }
    if (url.pathname === '/ws') return this.connect(request, url);
    return json({ ok: false, error: 'not_found' }, 404);
  }

  async connect(request, url) {
    if (request.headers.get('upgrade')?.toLowerCase() !== 'websocket') return json({ ok: false, error: 'WebSocket required' }, 426);
    const protocols = String(request.headers.get('sec-websocket-protocol') || '').split(',').map(s => s.trim());
    if (!protocols.includes(PROTOCOL)) return json({ ok: false, error: 'protocol_required' }, 426);
    const reconnect = protocols.find(s => s.startsWith('rt.'))?.slice(3);
    const name = clean(url.searchParams.get('name'));

    let playerId = reconnect && this.room.players[reconnect] ? reconnect : null;
    if (!playerId) {
      if (this.room.status !== 'waiting') return json({ ok: false, error: 'الجولة بدأت؛ انضم لتحدي جديد' }, 409);
      if (Object.keys(this.room.players).length >= SUDOKU_ROOM_MAX_PLAYERS) return json({ ok: false, error: 'اللوبي ممتلئ (10 لاعبين)' }, 409);
      playerId = crypto.randomUUID();
      const result = addSudokuPlayer(this.room, { id: playerId, name }, Date.now());
      if (!result.accepted) return json({ ok: false, error: result.reason || 'تعذر الانضمام' }, 409);
      this.room = result.room;
    }

    for (const old of this.ctx.getWebSockets()) try { if (old.deserializeAttachment()?.playerId === playerId) old.close(4001, 'reconnected'); } catch {}
    const pair = new WebSocketPair(), client = pair[0], server = pair[1];
    this.ctx.acceptWebSocket(server);
    server.serializeAttachment({ sudoku: true, playerId });
    if (this.room.players[playerId]) this.room.players[playerId].connected = true;
    this.room.expiresAt = Date.now() + TTL;
    await this.save(); await this.schedule();
    this.sendTo(server, { type: 'welcome', playerId, token: playerId, state: this.publicState() });
    this.broadcast();
    return new Response(null, { status: 101, webSocket: client, headers: { 'sec-websocket-protocol': PROTOCOL } });
  }

  async webSocketMessage(ws, raw) {
    await this.ready; if (!this.room) return;
    let attachment; try { attachment = ws.deserializeAttachment(); } catch { return; }
    const playerId = attachment?.playerId;
    const player = this.room.players[playerId];
    if (!player) return;
    const text = typeof raw === 'string' ? raw : new TextDecoder().decode(raw);
    if (text.length > 512) return this.error(ws, 'الرسالة أكبر من المسموح');
    let msg; try { msg = JSON.parse(text); } catch { return this.error(ws, 'رسالة غير صالحة'); }
    if (!msg || typeof msg !== 'object') return this.error(ws, 'رسالة غير صالحة');

    if (msg.type === 'resync') { this.sendTo(ws, { type: 'state', state: this.publicState() }); return; }

    if (msg.type === 'guess') {
      if (this.room.status !== 'playing') return;
      const result = applySudokuGuess(this.room, playerId, Number(msg.cell), Number(msg.value), Date.now());
      this.room = result.room;
      await this.save();
      const me = this.room.players[playerId];
      this.sendTo(ws, { type: 'guess_result', result: result.result, cell: Number(msg.cell), value: Number(msg.value), correctCount: me.correctCount, mistakes: me.mistakes, eliminated: me.eliminated, finished: Boolean(me.finishedAt) });
      this.broadcast();
      if (this.room.status === 'finished') await this.schedule();
      return;
    }

    if (msg.type === 'leave' && this.room.status === 'waiting') {
      this.room = removeSudokuPlayer(this.room, playerId);
      ws.close(1000, 'left'); await this.save(); this.broadcast();
    }
  }

  async webSocketClose(ws) {
    await this.ready; if (!this.room) return;
    let playerId; try { playerId = ws.deserializeAttachment()?.playerId; } catch { return; }
    const replacement = this.ctx.getWebSockets().some(other => other !== ws && isOpen(other) && other.deserializeAttachment()?.playerId === playerId);
    if (replacement) return;
    this.room = removeSudokuPlayer(this.room, playerId);
    await this.save(); await this.schedule(); this.broadcast();
  }
  async webSocketError(ws) { return this.webSocketClose(ws); }

  async alarm() {
    await this.ready; if (!this.room) return;
    if (sudokuLobbyShouldStart(this.room, Date.now())) {
      this.room = startSudokuRoom(this.room, Date.now());
      await this.save(); await this.schedule(); this.broadcast();
      return;
    }
    if (this.room.expiresAt <= Date.now()) {
      for (const ws of this.ctx.getWebSockets()) try { ws.close(1000, 'room_expired'); } catch {}
      await this.ctx.storage.delete('sudoku'); await this.ctx.storage.deleteAlarm(); this.room = null;
      return;
    }
    await this.schedule();
  }
}
