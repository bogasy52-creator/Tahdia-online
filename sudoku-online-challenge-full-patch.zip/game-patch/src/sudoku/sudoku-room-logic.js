// منطق غرفة "تحدي سودوكو الأونلاين" — دوال خالصة (بدون أي شبكة أو Durable Object)
// عشان تنفحص بالكامل بـ Node مباشرة قبل ما تنربط بالسيرفر.
import { createSudoku } from '../../public/assets/js/engines/sudoku-engine.js';
import { solveSudoku } from '../../public/assets/js/engines/sudoku-core.js';

export const SUDOKU_ROOM_MAX_PLAYERS = 10;
export const SUDOKU_ROOM_MIN_PLAYERS = 1;
export const SUDOKU_LOBBY_WAIT_MS = 20_000;
export const SUDOKU_MAX_MISTAKES = 5;

const DIFFICULTY_TIER_RANGE = {
  easy:   [1, 24],
  medium: [49, 72],
  hard:   [97, 120],
};

export function validSudokuDifficulty(d) {
  return Object.prototype.hasOwnProperty.call(DIFFICULTY_TIER_RANGE, d);
}

export function createSudokuRoom({ code, hostId, difficulty = 'medium', now = Date.now() }) {
  if (!validSudokuDifficulty(difficulty)) throw new Error('invalid_difficulty');
  return {
    code,
    hostId,
    difficulty,
    status: 'waiting', // waiting -> playing -> finished
    createdAt: now,
    lobbyDeadline: now + SUDOKU_LOBBY_WAIT_MS,
    players: {}, // id -> player state
    puzzle: null, // {initial, solution, level} — يتولّد لحظة البداية فقط
    startedAt: null,
    finishedAt: null,
    rankCounter: 0,
  };
}

export function addSudokuPlayer(room, { id, name }, now = Date.now()) {
  if (room.status !== 'waiting') return { room, accepted: false, reason: 'already_started' };
  if (room.players[id]) return { room, accepted: true, reason: 'already_joined' };
  if (Object.keys(room.players).length >= SUDOKU_ROOM_MAX_PLAYERS) return { room, accepted: false, reason: 'room_full' };
  const next = { ...room, players: { ...room.players, [id]: {
    id, name: String(name || 'لاعب').slice(0, 24),
    board: null, mistakes: 0, correctCount: 0,
    eliminated: false, finishedAt: null, rank: null,
    joinedAt: now, connected: true,
  } } };
  return { room: next, accepted: true };
}

export function removeSudokuPlayer(room, id) {
  if (!room.players[id]) return room;
  if (room.status === 'waiting') {
    const players = { ...room.players };
    delete players[id];
    return { ...room, players };
  }
  // بعد ما تبدأ الجولة، لاعب ينفصل يُعتبر بس "غير متصل"، يحتفظ بتقدمه ونتيجته
  return { ...room, players: { ...room.players, [id]: { ...room.players[id], connected: false } } };
}

export function sudokuLobbyShouldStart(room, now = Date.now()) {
  return room.status === 'waiting'
    && now >= room.lobbyDeadline
    && Object.keys(room.players).length >= SUDOKU_ROOM_MIN_PLAYERS;
}

// pickLevel قابلة للحقن عشان الاختبارات تقدر تثبّت أي مرحلة تتوقعها؛ افتراضيًا عشوائي ضمن نطاق الصعوبة
export function startSudokuRoom(room, now = Date.now(), pickLevel = null) {
  if (room.status !== 'waiting') return room;
  const [lo, hi] = DIFFICULTY_TIER_RANGE[room.difficulty];
  const level = pickLevel ?? (lo + Math.floor(Math.random() * (hi - lo + 1)));
  const state = createSudoku(level);
  const solved = solveSudoku(state.initial, { limit: 2 });
  if (solved.count !== 1) throw new Error('puzzle_generation_failed'); // ما يصير نظريًا؛ المراحل كلها محققة سلفًا
  const players = {};
  for (const [id, p] of Object.entries(room.players)) {
    players[id] = { ...p, board: state.initial.slice() };
  }
  return {
    ...room,
    status: 'playing',
    startedAt: now,
    puzzle: { initial: state.initial, solution: solved.solution, level },
    players,
  };
}

// نتيجة التخمين: 'accepted_correct' | 'accepted_wrong' | 'rejected'
export function applySudokuGuess(room, playerId, cell, value, now = Date.now()) {
  if (room.status !== 'playing') return { room, result: 'rejected', reason: 'not_playing' };
  const player = room.players[playerId];
  if (!player) return { room, result: 'rejected', reason: 'unknown_player' };
  if (player.eliminated || player.finishedAt) return { room, result: 'rejected', reason: 'player_done' };
  if (!Number.isInteger(cell) || cell < 0 || cell >= 81) return { room, result: 'rejected', reason: 'bad_cell' };
  if (!Number.isInteger(value) || value < 1 || value > 9) return { room, result: 'rejected', reason: 'bad_value' };
  if (room.puzzle.initial[cell]) return { room, result: 'rejected', reason: 'given_cell' }; // خانة ثابتة، ما تتعدل
  if (player.board[cell]) return { room, result: 'rejected', reason: 'already_filled' };

  const isCorrect = room.puzzle.solution[cell] === value;
  const board = player.board.slice();
  let updated;
  if (isCorrect) {
    board[cell] = value;
    const correctCount = player.correctCount + 1;
    const finished = !board.includes(0);
    updated = { ...player, board, correctCount, finishedAt: finished ? now : null };
  } else {
    // الرقم الغلط ما ينكتب بلوحة اللاعب (يبقى فاضي) — بس يحسب غلطة
    const mistakes = player.mistakes + 1;
    updated = { ...player, mistakes, eliminated: mistakes >= SUDOKU_MAX_MISTAKES };
  }

  let room2 = { ...room, players: { ...room.players, [playerId]: updated } };

  // لو خلص (فاز أو انقصى)، نثبّت ترتيبه فورًا (ترتيب وصول، أول وحد يخلص ياخذ رتبة 1)
  if ((updated.finishedAt || updated.eliminated) && updated.rank === null) {
    const rank = room2.rankCounter + 1;
    room2 = { ...room2, rankCounter: rank, players: { ...room2.players, [playerId]: { ...updated, rank } } };
  }

  if (sudokuRoomAllDone(room2) && room2.status === 'playing') {
    room2 = { ...room2, status: 'finished', finishedAt: now };
  }

  return { room: room2, result: isCorrect ? 'accepted_correct' : 'accepted_wrong' };
}

export function sudokuRoomAllDone(room) {
  const players = Object.values(room.players);
  if (!players.length) return false;
  return players.every(p => p.finished !== undefined ? p.finished : Boolean(p.finishedAt) || p.eliminated);
}

// ترتيب نهائي: الفايزين (خلصوا اللوحة) مرتبين بوقت الانتهاء، بعدين المُقصين بعدد الخانات الصحيحة تنازليًا
export function computeSudokuRanking(room) {
  const players = Object.values(room.players);
  const finished = players.filter(p => p.finishedAt).sort((a, b) => a.finishedAt - b.finishedAt);
  const others = players.filter(p => !p.finishedAt).sort((a, b) => b.correctCount - a.correctCount);
  return [...finished, ...others].map((p, i) => ({ ...p, finalRank: i + 1 }));
}
