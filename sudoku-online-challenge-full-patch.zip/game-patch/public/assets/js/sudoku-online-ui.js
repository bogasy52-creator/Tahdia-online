// واجهة تحدي سودوكو الأونلاين — لوبي ٢٠ ثانية، ١-١٠ لاعبين، ٥ أغلاط إقصاء
const $ = (id) => document.getElementById(id);
const PROTOCOL = 'busraj-sudoku-v1';

let ws = null, myId = null, myToken = null, myDifficulty = 'easy';
let lastState = null, countdownTimer = null, selectedCell = null;

function openPanel(id) {
  ['sudokuOnlineSetup', 'sudokuOnlineLobby', 'sudokuOnlineRace', 'sudokuOnlineResults'].forEach(p => {
    $(p).hidden = p !== id;
  });
}

function setupListeners() {
  $('sudokuOnlineOpen').addEventListener('click', () => {
    $('sudokuOnline').hidden = false;
    openPanel('sudokuOnlineSetup');
  });
  $('sudokuOnlineClose').addEventListener('click', closeOnline);

  [...$('sudokuOnlineDiff').children].forEach(btn => {
    btn.addEventListener('click', () => {
      myDifficulty = btn.dataset.diff;
      [...$('sudokuOnlineDiff').children].forEach(b => b.setAttribute('aria-pressed', String(b === btn)));
    });
  });

  $('sudokuOnlineStart').addEventListener('click', startOnlineFlow);
  $('sudokuOnlineLeaveLobby').addEventListener('click', () => {
    if (ws) try { ws.send(JSON.stringify({ type: 'leave' })); } catch {}
    closeOnline();
  });
  $('sudokuOnlinePlayAgain').addEventListener('click', () => {
    teardownSocket();
    openPanel('sudokuOnlineSetup');
    $('sudokuOnlineSetupError').hidden = true;
  });
  $('sudokuOnlineBackHub').addEventListener('click', closeOnline);
}

function closeOnline() {
  teardownSocket();
  $('sudokuOnline').hidden = true;
}

function teardownSocket() {
  if (countdownTimer) { clearInterval(countdownTimer); countdownTimer = null; }
  if (ws) { try { ws.close(1000, 'leave'); } catch {} ws = null; }
  myId = null; myToken = null; lastState = null; selectedCell = null;
}

async function startOnlineFlow() {
  $('sudokuOnlineSetupError').hidden = true;
  $('sudokuOnlineStart').disabled = true;
  try {
    const res = await fetch('/api/sudoku/rooms', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ difficulty: myDifficulty }),
    });
    const data = await res.json();
    if (!data.ok) throw new Error(data.error || 'تعذر إنشاء التحدي');
    connectSocket(data.code);
  } catch (err) {
    $('sudokuOnlineSetupError').textContent = err.message || 'صار خطأ، حاول مرة ثانية';
    $('sudokuOnlineSetupError').hidden = false;
  } finally {
    $('sudokuOnlineStart').disabled = false;
  }
}

function connectSocket(code) {
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  const name = encodeURIComponent((window.BS_PROFILE?.displayName || 'لاعب').slice(0, 24));
  const url = `${proto}//${location.host}/api/sudoku/rooms/${code}/ws?name=${name}`;
  ws = new WebSocket(url, [PROTOCOL]);
  ws.addEventListener('open', () => {});
  ws.addEventListener('message', (ev) => handleMessage(JSON.parse(ev.data)));
  ws.addEventListener('close', () => {});
  ws.addEventListener('error', () => {
    $('sudokuOnlineSetupError').textContent = 'انقطع الاتصال بالتحدي';
    $('sudokuOnlineSetupError').hidden = false;
  });
}

function handleMessage(msg) {
  if (msg.type === 'welcome') {
    myId = msg.playerId; myToken = msg.token;
    applyState(msg.state);
    return;
  }
  if (msg.type === 'state') { applyState(msg.state); return; }
  if (msg.type === 'guess_result') { applyGuessResult(msg); return; }
  if (msg.type === 'error') {
    $('sudokuOnlineMessage').textContent = msg.message || 'صار خطأ';
  }
}

function applyState(state) {
  lastState = state;
  if (state.status === 'waiting') renderLobby(state);
  else if (state.status === 'playing') renderRace(state);
  else if (state.status === 'finished') renderResults(state);
}

function renderLobby(state) {
  openPanel('sudokuOnlineLobby');
  $('sudokuOnlineCode').textContent = 'غرفة #' + state.code;
  if (countdownTimer) clearInterval(countdownTimer);
  // نعدّل فرق الساعة بين جهاز اللاعب والسيرفر عشان العد التنازلي يكون دقيق للكل
  const clockSkewMs = state.serverNow - Date.now();
  const tick = () => {
    const remainMs = state.lobbyDeadline - (Date.now() + clockSkewMs);
    $('sudokuOnlineTimer').textContent = String(Math.max(0, Math.ceil(remainMs / 1000)));
  };
  tick();
  countdownTimer = setInterval(tick, 250);

  $('sudokuOnlinePlayers').innerHTML = state.players.map(p =>
    `<li><span>${escapeHtml(p.name)}${p.id === myId ? ' (أنت)' : ''}</span><span><i class="dot"></i>${p.connected ? 'متصل' : 'غير متصل'}</span></li>`
  ).join('');
}

function renderRace(state) {
  openPanel('sudokuOnlineRace');
  if (countdownTimer) { clearInterval(countdownTimer); countdownTimer = null; }

  const me = state.players.find(p => p.id === myId);
  if (me) $('sudokuOnlineMistakes').textContent = `${me.mistakes} / 5 أغلاط`;

  // نبني اللوحة مرة وحدة فقط (أول دخول)، وبعدها نحدّث القيم بس
  const boardEl = $('sudokuOnlineBoard');
  if (!boardEl.childElementCount) {
    state.puzzleInitial.forEach((v, i) => {
      const btn = document.createElement('button');
      btn.type = 'button'; btn.dataset.cell = String(i);
      if (v) { btn.className = 'given'; btn.textContent = String(v); btn.disabled = true; }
      else { btn.addEventListener('click', () => selectCell(i)); }
      boardEl.appendChild(btn);
    });
    buildPad();
  }

  $('sudokuOnlineOpponents').innerHTML = state.players.filter(p => p.id !== myId).map(p => {
    const pct = Math.min(100, Math.round((p.correctCount / Math.max(1, state.puzzleInitial.filter(v => !v).length)) * 100));
    const status = p.finishedAt ? `خلص #${p.rank}` : p.eliminated ? `مُقصى #${p.rank}` : `${p.mistakes}/5 أغلاط`;
    return `<li class="${p.finishedAt ? 'finished' : ''}${p.eliminated ? ' eliminated' : ''}"><span>${escapeHtml(p.name)}</span><span class="bar"><i style="width:${pct}%"></i></span><b>${status}</b></li>`;
  }).join('');
}

function buildPad() {
  const pad = $('sudokuOnlinePad');
  pad.innerHTML = '';
  for (let n = 1; n <= 9; n++) {
    const btn = document.createElement('button');
    btn.type = 'button'; btn.textContent = String(n);
    btn.addEventListener('click', () => submitGuess(n));
    pad.appendChild(btn);
  }
}

function selectCell(i) {
  if (!lastState || lastState.puzzleInitial[i]) return;
  const me = lastState.players.find(p => p.id === myId);
  if (me?.eliminated || me?.finishedAt) return;
  selectedCell = i;
  [...$('sudokuOnlineBoard').children].forEach((el, idx) => el.classList.toggle('selected', idx === i));
}

function submitGuess(value) {
  if (selectedCell === null || !ws) return;
  ws.send(JSON.stringify({ type: 'guess', cell: selectedCell, value }));
}

function applyGuessResult(msg) {
  const cellEl = $('sudokuOnlineBoard').children[msg.cell];
  $('sudokuOnlineMistakes').textContent = `${msg.mistakes} / 5 أغلاط`;
  if (msg.result === 'accepted_correct') {
    cellEl.textContent = String(msg.value);
    cellEl.classList.add('mine');
    cellEl.disabled = true;
    $('sudokuOnlineMessage').textContent = msg.finished ? 'خلصت اللوحة! 🎉' : 'صح!';
    selectedCell = null;
  } else if (msg.result === 'accepted_wrong') {
    $('sudokuOnlineMessage').textContent = msg.eliminated ? 'وصلت ٥ أغلاط — انقصيت من هذي الجولة' : 'غلط، حاول رقم ثاني';
  }
}

function renderResults(state) {
  if (countdownTimer) { clearInterval(countdownTimer); countdownTimer = null; }
  openPanel('sudokuOnlineResults');
  $('sudokuOnlineRanking').innerHTML = (state.ranking || []).map(p =>
    `<li>${p.id === myId ? '<b>أنت —</b> ' : ''}${escapeHtml(p.name)} <span class="sudoku-small">${p.finishedAt ? 'أكمل اللوحة' : `${p.correctCount} خانة صحيحة`}</span></li>`
  ).join('');
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', setupListeners);
else setupListeners();
