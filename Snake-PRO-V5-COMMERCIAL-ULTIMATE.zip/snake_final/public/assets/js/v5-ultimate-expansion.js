// Snake PRO V5 Ultimate Expansion Layer
(function(){
'use strict';
const KEY='snake-pro-v5-ultimate-profile';
let data={level:1,xp:0,wins:0,losses:0,coins:0};
try{data={...data,...JSON.parse(localStorage.getItem(KEY)||'{}')}}catch(e){}
function save(){localStorage.setItem(KEY,JSON.stringify(data))}
window.SnakeUltimate={
 addWin(){data.wins++;data.coins+=50;gain(100);},
 addLoss(){data.losses++;gain(25);},
 reward(c=10){data.coins+=c;save();},
 profile(){return data}
};
function gain(x){data.xp+=x;while(data.xp>=data.level*500){data.xp-=data.level*500;data.level++}save()}
function style(){
const s=document.createElement('style');
s.textContent=`
.v5-ultimate-hud{position:fixed;top:14px;left:14px;z-index:9999;background:#101426dd;border:1px solid #ffffff22;border-radius:18px;padding:10px 14px;color:white;font:600 13px system-ui;backdrop-filter:blur(8px)}
.v5-ultimate-hud span{color:#f4c76d;margin:0 4px}
.v5-toast{position:fixed;bottom:25px;left:50%;transform:translateX(-50%);background:#111827ee;color:white;padding:12px 18px;border-radius:999px;z-index:9999}
`;
document.head.appendChild(s);
}
function hud(){
if(document.querySelector('.v5-ultimate-hud'))return;
const e=document.createElement('div');e.className='v5-ultimate-hud';e.innerHTML=`Lv <span>${data.level}</span> XP <span>${data.xp}</span> 🪙 <span>${data.coins}</span>`;document.body.appendChild(e);
}
function boot(){style();hud()}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
