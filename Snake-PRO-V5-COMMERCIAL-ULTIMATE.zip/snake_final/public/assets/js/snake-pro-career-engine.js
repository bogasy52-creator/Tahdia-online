/* Snake PRO V5 Professional Career Engine */
(function(){
'use strict';
const KEY='snake-pro-v5-career';
const defaults={level:1,xp:0,coins:100,wins:0,losses:0,rank:'Bronze',skin:'Classic',streak:0,achievements:[]};
let data={...defaults};
try{data={...data,...JSON.parse(localStorage.getItem(KEY)||'{}')}}catch(e){}
function save(){localStorage.setItem(KEY,JSON.stringify(data));}
function level(){return Math.floor(data.xp/1000)+1}
function updateRank(){const l=level();data.rank=l>=30?'Master':l>=20?'Diamond':l>=10?'Gold':l>=5?'Silver':'Bronze'}
function reward(win,score){data.xp+=Math.max(50,Math.floor(score||0));data.coins+=win?50:10;if(win){data.wins++;data.streak++}else{data.losses++;data.streak=0}updateRank();save();return data}
window.SnakeProCareer={get:()=>data,reward,level,save};
})();
