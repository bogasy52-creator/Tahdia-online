/* Snake PRO V5 Commercial Upgrade Layer */
(function(){
 const KEY='snake-pro-commercial-profile';
 const defaults={level:1,xp:0,coins:100,wins:0,losses:0,skin:'classic',rank:'Bronze'};
 function load(){try{return Object.assign({},defaults,JSON.parse(localStorage.getItem(KEY)||'{}'))}catch(e){return {...defaults}}}
 function save(p){localStorage.setItem(KEY,JSON.stringify(p));return p}
 function rank(xp){if(xp>=50000)return 'Master';if(xp>=20000)return 'Diamond';if(xp>=8000)return 'Gold';if(xp>=2500)return 'Silver';return 'Bronze'}
 window.SnakePRO={
  profile:load(),
  addMatchResult(win){let p=load();p.xp+=win?250:80;p.coins+=win?50:15;p.wins+=win?1:0;p.losses+=win?0:1;p.level=Math.floor(p.xp/1000)+1;p.rank=rank(p.xp);save(p);return p},
  unlockSkin(id){let p=load();p.skin=id;save(p);},
  getProfile(){return load()}
 };
 window.dispatchEvent(new CustomEvent('snakepro-ready'));
})();
